import os, sys, json
calls=[]
messages=[]
values=[None,b'S111\n',b'E',b'T',b'K',b'',b'S1',b'11\n',b'X']
limits=[16,4096,2,3,4,5,6,7,8]
def read_control(limit=4096):
    assert limit == limits[len(calls)]
    value=values[len(calls)]
    calls.append(value)
    return value
def send(message):
    messages.append(message)
def main():
    expected=[dict(type='prepared'),dict(type='ready'),dict(type='exit'),dict(type='cleanup')]
    for message in expected:
        send(message)
    assert all(a is b for a,b in zip(messages,expected))
    for i,limit in enumerate(limits):
        assert read_control(limit) is values[i]
    fd=send.__globals__['record_fd']
    assert not os.get_inheritable(fd)
    with open(os.environ['UNIT_RESULT'],'x') as f:
        json.dump(dict(pid=os.getpid(),executable=sys.executable,readCount=len(calls),limits=limits,sendIdentityPreserved=True,readIdentityPreserved=True,sidecarInheritable=os.get_inheritable(fd)),f)
