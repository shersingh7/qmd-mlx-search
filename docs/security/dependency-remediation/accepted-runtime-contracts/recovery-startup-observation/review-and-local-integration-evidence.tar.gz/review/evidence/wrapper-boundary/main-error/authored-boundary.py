def send(message):
    pass
def read_control(limit=4096):
    return None
def main():
    raise RuntimeError('authored-boundary-main-error')
