# B repaired candidate — independent SPEC re-review

**PASS. B-SPEC-1 and B-SPEC-2 are closed for the exact three postimages below.** No new blocking SPEC finding was demonstrated. This report was written before starting the full three-path QUALITY assessment. It is not integration, packaging, release, C1 cleanup qualification or actual macOS CI approval.

## Identity and isolation

Producer: `/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r`.
Independent owned review: `/Users/shersingh/.hermes/cache/scratch/qmd-B-re-review-3hobdccc`.

| Reviewed path | SHA256 |
|---|---|
| `.github/workflows/ci.yml` | `58cdcb86673d982e04d27d17b0cc3c438a17b499647fb9eba2da484d6c8c928f` |
| `test/helpers/recovery-startup-observation.ts` | `00d2f3fa3d0556323eba526192a28c8bdd21e18efce892bd47f241533486b1fc` |
| `test/helpers/recovery-startup-observation.selftest.mjs` | `ecb725f3d7219109abd70e47022e5a186614c71cc6ccca70922feba9f87f3459` |

The three producer indexes and their chain were independently authenticated: 313 + 6 + 6 = **325 unique files**, with exact declared bytes and no duplicate paths. Patch digests match the supplied two-file delta and updated three-path proposal. All **48 public source inputs** were copied and hash-bound; the parent approved composition has identical bytes for that closure. The negative copy uses the original reviewed helper/selftest bytes. Both copies have newly owned `node_modules` containers, four owned cache directories and **281 freshly resolved public package aliases**. No live/frozen sources, dependencies, services, settings or skills were edited. No network, installation, staging, commit or delegation occurred. Every subprocess received its own explicit credential-free offline HOME/cache/TMP environment; no producer shell was sourced and no persistent environment was exported.

## Closure: B-SPEC-1 — exceptional observer lifetime

The exact original `harness/reproduce-findings.mjs rejection`, including its original assertion, genuinely failed against retained old helper bytes: exit **1**, **13** retained observer callbacks, expected zero. The same unchanged file against repaired exact helper bytes exited **0**, with **zero** retained callbacks. Both receipts preserve spawn/named-export/environment restoration and truthful `observation-incomplete`; no real process is launched by this fake.

The repair transfers the call-local trace before finish/disposal (`257–258`), releases synchronous-start failures (`287–292`), and releases in asynchronous `finally` around caller/finish (`338–352`). The unchanged observer's finish already disposes in its own finally. These are ownership operations, not subject cleanup or signals. Source review confirms the primary caller/start/finish exception is preserved if secondary disposal throws; the public collection report intentionally suppresses arbitrary exception text, so it does not expose error identity.

Independent `heldout-lifetime.mjs` additionally checks delayed rejection while work is still pending, delayed rejection with an after-release disposal error, synchronous post-spawn throw, finish-snapshot throw, normal completion and unreaped-owner stop. Before rejection, global spawn/named bindings are already restored **and all 13 observer callbacks are still alive**; after settlement each distinct own callback is removed exactly once. Exact unrelated listener arrays, including symbol and once-wrapped callbacks, remain unchanged. Subject streams are not destroyed and caller-owned flow is unchanged. Failure creates no successful case or `case-5000`; unreaped ownership stops after one comparison. Permanent tests also pass normal, no-observer and no-observer-rejection paths. These mock exceptions are not claims about natural production rejections.

## Closure: B-SPEC-2 — strict bytes and validated prefix

The exact original `reproduce-findings.mjs utf8` genuinely failed against old helper bytes: exit **1**, invalid raw `0xff` became U+FFFD and a falsely complete sidecar. The same unchanged assertion against repaired bytes exited **0**: `malformed`, actual **150 raw bytes**, no records, no selected interpreter. Old lossy decoding had reported 152 bytes; neither raw receipt was relabelled.

Completed raw lines now use fatal UTF-8 decoding with BOM retained for the unchanged schema parser (`93–105`); an invalid completed row and everything after it cannot enter the validated prefix. Unterminated bytes remain raw partial evidence. The public string parser is byte-identical. Independent exact-reader controls passed **33 byte/schema cases on each actual Node and native Bun**, including valid literal/escaped U+FFFD, non-ASCII and CRLF; bad UTF-8 after a valid prefix with later valid rows; split multibyte/newline boundaries; raw invalid tails; terminal-plus-tail; first/later BOM; exact 2048-byte line and 16384-byte file positives and their over-limit negatives. Schema/sequence/PID/nonfinite/backward-clock/budget/record/terminal rules remain strict. Raw bytes are retained unchanged.

Actual-host link/hardlink/directory/FIFO controls pass. Node's independent inode-mismatch control verifies O_NOFOLLOW/O_NONBLOCK and one FD close; one-byte short reads still decode valid multibyte records, with both acquired FDs closed. The permanent Node I/O failure test proves one open/read/close. **Native Bun's namespace-to-existing-named-FS injection is unsupported, not a qualified fault pass**; real Bun byte/filesystem controls executed normally.

## Preserved full three-path contract

- YAML and byte reconstruction remove only B's additions and recover exact workflow preimage `f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f`. Canonical prefix remains `d723590bbdca7e4e20a61eb6782d77f25defd3a633403c2c9d654ecfcfa00aa1`. Whole parsed existing workflow is unchanged: commands, order, maxWorkers=2, pins, assertions, action versions and previous upload policy. New steps follow smoke and original observer selftests, use `always() && runner.os == 'macOS'`, `continue-on-error: true`, two-minute bounds and literal actual-host commands. All three new shell bodies pass bash syntax. The real offline wrapper strips authored ambient credentials/context/Node options and preserves literal post-wrapper diagnostic flags/paths. Nothing clears a canonical failure or warms its first invocation.
- Production caller/supervisor/worker/anchor/loader and original observer bytes are unchanged. There is no public `supervisorScript` option. Actual captures preserve `/usr/bin/python3 -S -u`, exact original configuration bytes, detached four-pipe ownership and immediate synchronous binding restoration. Bun retains its existing native owner and no second reader. Original caller-inclusive 200ms and 800ms teardown clocks are unchanged; no raw S200, restarted budget or cross-epoch subtraction is introduced.
- The wrapper hashes then compiles original Python bytes. Fresh generated-wrapper boundary executions preserve each send object's identity and exactly one original read with unchanged limit/returned object (including None, EOF, fragments and unknown bytes). Source mismatch refuses before module/main; existing sidecar refuses replacement; main error exits 1 although terminal sidecar is complete, without a cleanup event. Completeness is not work/cleanup success.
- Opt-in/import/host checks, exclusive owned publication, bounded 32-record/16384-byte sidecar/262144-byte JSON, missing-entry unknowns, independent clock labels, raw original results and `productQualified=false` are retained. Unsupported caller milestones remain null and native-Bun owner tracing remains unsupported. PID-existence sampling grants no ownership or signal authority. No subject fixture signals, broad new scans, privileged tracing, database, model, GPU or service activity was added.

## Fresh execution, not borrowed results

Original observer controls ran first: **8 pass, 0 fail, 0 skip**. Exactly **four** fresh real recovery calls followed, sequentially, without retries:

| Actual host | Original budget | External caller-return bracket | Python admission budget | Result |
|---|---:|---:|---:|---|
| Node 22.22.3 | 200ms | 150.892875ms | 102ms | authored work observed, uncontained |
| Node 22.22.3 | 5000ms | 131.407208ms | 4908ms | separate positive, uncontained |
| native Bun 1.3.8 | 200ms | 141.667ms | 105ms | authored work observed, uncontained |
| native Bun 1.3.8 | 5000ms | 174.797333ms | 4855ms | separate positive, uncontained |

All four have independently rehashed synthetic public-document work/report, wrapper/source bindings, complete strict sidecars, supervisor/worker reap and natural-close receipts, no forced pipe closure, no database and no sampled reported PID before fixture cleanup. Original uncontained errors and false product/containment qualification remain. The caller was imported **before** listener baselines: both actual hosts retain identical before/after library listeners, and Node retains no per-call observer callbacks. Selected product Python is CLT **3.9.6**; review Python **3.12.13** only performs static review. These are local warmed/instrumented Darwin 27.2.0 arm64 observations, not cold-causal or CI results.

Complete permanent selftests using these fresh artifacts: **14 pass, 0 fail, 0 skip**. All assertion receipts/raw stdout/stderr and exact argv/source/environment bindings are retained. No harness setup failure occurred in this re-review. Expected old-source REDs remain red; wrapper expected-negative child exits remain qualified negatives.

## Evidence and boundary

Primary: `evidence/intake-authentication.json`, `source-before.json`, `negative-source-before.json`, `independent-real-validation.json`, `heldout-{lifetime,bytes-node,bytes-bun,workflow}-summary.json`, `wrapper-boundary-summary.json`, `*.receipt.json`, raw outputs and guard logs. Immutable earlier failed review/raw receipts and parent composition/replay/canonical-build receipts are separately bound in `borrowed-evidence-bindings.json`; they are not this review's executions. Producer gate history and the persistent-shell-environment incident remain historical evidence, not new source defects or fabricated gate metadata.

**Next gate:** full QUALITY of this entire three-path candidate, not only its repair. Parent integration/full-project/package/actual CI acceptance, historical macOS failures, paused sole-owner C1 limitation and separate full-native-Bun allocator SIGTRAP remain outside this review.
