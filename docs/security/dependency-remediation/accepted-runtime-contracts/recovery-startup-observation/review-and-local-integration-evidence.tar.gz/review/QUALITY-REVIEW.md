# B repaired candidate — independent full QUALITY review

**PASS — no blocking QUALITY finding.** This assessment covers the **entire three-path B candidate**, including its original workflow/helper/selftests, not just the two-file repair. `SPEC-REVIEW.md` was written and hash-sealed before this phase (`evidence/quality-phase-start.json`). This is independent source-bound review, not implementer self-approval, integration/release acceptance or actual macOS CI approval.

## Reviewed scope

- `.github/workflows/ci.yml`: `58cdcb86673d982e04d27d17b0cc3c438a17b499647fb9eba2da484d6c8c928f`.
- `test/helpers/recovery-startup-observation.ts`: `00d2f3fa3d0556323eba526192a28c8bdd21e18efce892bd47f241533486b1fc`.
- `test/helpers/recovery-startup-observation.selftest.mjs`: `ecb725f3d7219109abd70e47022e5a186614c71cc6ccca70922feba9f87f3459`.

All source paths were read in full. Relevant exact public caller, Python supervisor/worker/anchor, loader, original observer, offline runner, package/lock/config and installed declaration boundaries were checked without restarting the production architecture audit. Independent strict hunk replay of **both** delivered patches reconstructs the expected exact postimages (`independent-patch-replay.json`). All 48 copied public inputs and old negative controls remain unchanged. Live B helpers remain absent and the live workflow remains the original preimage; no whole-live-tree equality is required across the parent's authorized A work.

## Full-candidate assessment

### Workflow and operational separation

The supplemental diagnostics are positioned after canonical suite, smoke and original observer controls. The canonical prefix and whole parsed existing workflow are preserved, including runtime/action pins, maxWorkers=2, command arguments/order, assertions and previous artifact policy. Literal host commands and post-offline-wrapper flags avoid event-text interpolation or ambient opt-in assumptions. `always()` plus macOS restriction permits failure evidence; `continue-on-error` keeps these diagnostics from clearing or replacing a canonical failure. Each new step has a two-minute ceiling. Added artifact paths are diagnostic evidence only, not actual-CI acceptance.

Fresh actionlint passed (exit **0**) after independently verifying binary SHA256 `8db11704dc296f096216db4db65d86cd7f0ebfdf4c38453a1da276b137b88388`. ShellCheck and Pyflakes were **explicitly disabled**, not silently treated as executed. All three parsed new shell bodies passed bash syntax; the real offline wrapper passed the synthetic ambient-context/literal-path check. No CI service or remote endpoint was contacted.

### Helper correctness, ownership and failure semantics

The helper remains test-only and inert on import, with explicit opt-in and actual-host verification before allocation. Original source, argv replacement, configuration, detached stdio ownership, process-relative clocks and deadline authority stay with the real caller. Native Bun adds no observer/reader/FD owner. The Python wrapper executes the bytes it hashes and instruments existing send/read boundaries without rewriting the program or adding permission/protocol bytes. Authored wrapper execution proves one original read and object identity, plus source-mismatch, main-error and exclusive-sidecar negatives.

The repaired lifetime is call-local: synchronous global binding restoration is separate from asynchronous observer release. Transfer-before-finish/dispose makes normal/error release idempotent and avoids double removal. The observer's own finally handles a finishing snapshot exception. Only owned callbacks are removed; neither streams nor processes are closed/signalled by the helper. Primary failure is retained when secondary disposal fails, with truthful incomplete collection and no successful case synthesized. Delayed-rejection held-outs prove observers remain present until settlement rather than being prematurely removed merely to satisfy a final count.

Strict raw-byte decoding is layered before the original schema parser, reusing validation rather than creating a second schema. File reads, line decoding, records and JSON publication remain explicitly bounded. A malformed completed row cannot promote invalid interpreter metadata or a later record; raw tails remain partial. Valid non-ASCII and literal/escaped U+FFFD are retained. No-follow/no-link/nonregular checks, descriptor identity and finally-close contracts remain. The small string concatenation/line loop is bounded by 16384 raw bytes and 32 accepted records; it is not an unbounded input-processing path.

Classification, original public results and actual work hashes are separate from sidecar completeness. Every comparison stays `productQualified=false` and uncontained. Source/wrapper/host/argv/interpreter provenance and unsupported/null caller/Bun milestones are explicit. PID-existence observations are not recycled-PID/PGID signal authority. Exceptions intentionally do not serialize arbitrary error text or ambient credentials. No database/model/service/index access was introduced.

### Tests, maintainability and coverage honesty

Permanent tests exercise the exact helper and existing observer through a mocked **public caller module**, not a fabricated public caller option or replacement observer. Their fake subjects cannot launch an OS process. Exact unrelated listener arrays and 13 distinct callback identities make the assertions materially stronger than final count/source-string checks. Actual Node and native Bun readers are both exercised; Bun's unsupported named-FS injection is explicitly **unqualified**, not a passed injected fault. Optional real-artifact assertions require both actual hosts and preserve the independent 200ms short outcomes instead of retrying them to green.

The original string parser, directory/environment/argv/wrapper span, native capture/spawn/restoration bodies, classification and post-caller observation/orchestrator/CLI span are hash-proven byte-identical across the repair (`unchanged-contract-spans.json`). The large generated Python literal is a deliberate test-only source-bound wrapper rather than a new production supervisor abstraction. No unrelated refactor, dependency addition, weakened assertion, timeout change or expanded production API was introduced. No style-only change is required for acceptance.

## Verified execution

| Check | Actual independent result |
|---|---|
| Original unchanged rejection reproducer, old → repaired exact helper | exit 1 / 13 retained → exit 0 / zero retained |
| Original unchanged invalid-UTF-8 reproducer, old → repaired exact helper | exit 1 / falsely complete → exit 0 / malformed, no interpreter or records |
| Complete permanent startup selftests using fresh actual artifacts | **14 pass, 0 fail, 0 skip** |
| Original unchanged observer selftests, before real comparisons | **8 pass, 0 fail, 0 skip** |
| Independent lifecycle controls | six modes passed, zero real recovery calls |
| Independent strict-byte/schema controls | **33 per actual host**, plus link/nonregular/Node FD/short-read controls |
| Real caller comparisons | exactly **four**, Node/Bun × original 200ms and separate 5000ms; no retries |
| Focused strict TypeScript, original compiler options | **548 source files, 0 diagnostics**, exit 0 |
| Focused compiler guard | **623 rows, 0 refusals**; 525 installed public declaration inputs separately hash-bound |
| Ordinary guarded executions | **22 guard files, 2467 rows, 0 refusals** |
| Deliberate guard-negative controls | **3 files / 4 expected refusals**, retained separately |
| Patch replay; YAML/shell/offline-wrapper/actionlint | passed within the stated scope |

All four fresh real comparisons executed the authored public-document work, with complete sidecars, original uncontained errors, existing reap/natural-close receipts, no forced close/database/fixture signals and no sampled reported PID before fixture cleanup. Actual host/selected product Python and per-process clocks are retained in `independent-real-validation.json`; these are local warmed/instrumented Darwin observations, not cold-start causality or CI. Node's unchanged caller was imported before counting its persistent library signal handlers. Spawn/named binding/environment object and process-listener baselines restored on both actual hosts.

The runtime read guard deliberately permits the owned fixture root; the separate compiler policy rejects owned runtime records as well as outside live source. Actual Node and explicit native-Bun preloads were verified; these FS hooks are **not an OS sandbox or coverage of Bun's internal transpiler**. Expected guard-negative denials were not omitted to claim zero refusals globally. No setup failure or unaccounted child occurred in this re-review; old-source RED assertions and expected-negative wrapper exits remain visible.

## Borrowed evidence and remaining authority

Producer/parent canonical builds and their exact gate history are authenticated **borrowed** evidence, not this review's build execution. The initial manager-path pre-execution scanner refusal, direct build-body pass, later ordinary canonical pass without separate tracker and final actual passing build/full metadata remain distinct. No tracker state was invented. The producer's persistent-shell-environment incident was not reproduced or repaired here: every review subprocess used an explicit isolated environment; no shell was sourced and no process-global orchestration environment was mutated.

The parent still owns full-project/combined tests, canonical build/package acceptance, merge/publication and actual CI. This review made no live edits, candidate fixes, frozen-root writes, install/network/delegation, staging/commit, service/settings/skill change, GPU/model or private-index access. Historical macOS failures, sole-owner C1 limitations and the separate full-native-Bun Vitest allocator SIGTRAP are not resolved by this PASS.

Primary navigation: `SPEC-REVIEW.md`, `verdict.json`, `evidence/review-verification-summary.json`, source/harness/borrowed bindings, raw receipts/stdout/stderr and `ARTIFACT-INDEX.json`.
