# Test-only self-observation; no shared-clock or cold-causality claim.
import time
origin = time.monotonic()
import os, sys, json
owner = os.getpid()
record_fd = os.open("/Users/shersingh/.hermes/cache/scratch/qmd-B-re-review-3hobdccc/outputs/node-xygqmM/case-200/python-self-observation.jsonl", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
os.set_inheritable(record_fd, False)
sequence = 0
written_bytes = 0
def witness(event, **extra):
    global sequence, written_bytes
    if os.getpid() != owner or sequence >= 32:
        return
    value = dict(event=event, seq=sequence, pid=owner, tMs=(time.monotonic() - origin) * 1000)
    value.update(extra)
    data = (json.dumps(value, separators=(',', ':')) + '\n').encode()
    if written_bytes + len(data) > 16384:
        return
    sequence += 1
    written_bytes += len(data)
    try:
        while data:
            count = os.write(record_fd, data)
            data = data[count:]
    except OSError:
        pass  # Evidence can remain partial; it never changes a cleanup receipt.
witness('python-entry', version=sys.version[:512], executable=sys.executable[:1024])
# Add only isolated offline/cache defaults missing from the unchanged caller env.
for key, folder in dict(HERMES_DIR='hermes', HERMES_KNOWLEDGE_DIR='knowledge', KNOWLEDGE_DIR='knowledge', XDG_DATA_HOME='data', XDG_STATE_HOME='state',
                        HF_HOME='hf', HF_HUB_CACHE='hf/hub', TRANSFORMERS_CACHE='hf/transformers', UV_CACHE_DIR='uv', BUN_INSTALL_CACHE_DIR='bun', npm_config_cache='npm').items():
    os.environ.setdefault(key, os.path.join(os.environ['HOME'], folder))
    os.makedirs(os.environ[key], mode=0o700, exist_ok=True)
os.environ.update(QMD_LLAMA_GPU='false', REQUIRE_BUN='1', UV_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
import hashlib
source = "/Users/shersingh/.hermes/cache/scratch/qmd-B-re-review-3hobdccc/candidate/scripts/phase5_recovery_process.py"
with open(source, 'rb') as source_file:
    code = source_file.read()
if hashlib.sha256(code).hexdigest() != "52a00fb5b891752f8d53f8d8b08fae3ce467d392461b6524f762376ade344bbf":
    raise RuntimeError('production source binding mismatch')
witness('source-verified')
sys.path.insert(0, os.path.dirname(source))
sys.argv[0] = source
scope = dict(__name__='owned_startup_observation')
exec(compile(code, source, 'exec'), scope)
witness('module-loaded')
original_send = scope['send']
def observed_send(message):
    kind = message.get('type')
    if kind == 'prepared':
        witness('prepared-before-send')
    original_send(message)
    event = {'prepared':'prepared-sent', 'ready':'ready-sent', 'exit':'worker-exit-sent', 'cleanup':'cleanup-sent',
             'not-started':'not-started-sent', 'supervisor-error':'supervisor-error-sent'}.get(kind)
    if event:
        witness(event)
scope['send'] = observed_send
original_read = scope['read_control']
def observed_read(limit=4096):
    # One original read only, returned unchanged. Never consume a second byte,
    # read the child lease, inspect a pipe elsewhere, or synthesize S/E.
    data = original_read(limit)
    if data == b'':
        witness('parent-eof')
    elif data == b'E':
        witness('execution-read')
    elif data and (b'T' in data or b'K' in data):
        witness('cancel-read')
    elif data and data.startswith(b'S') and data.endswith(b'\n') and data[1:-1].isdigit():
        witness('admission-read', budgetMs=int(data[1:-1]))
    return data
scope['read_control'] = observed_read
try:
    try:
        scope['main']()
    except BaseException as failure:
        # Same error boundary as the verified production __main__; original send.
        try:
            scope['send']({'type':'supervisor-error', 'error':f'Recovery supervisor failed: {failure}'})
        except OSError:
            pass
        sys.exit(1)
finally:
    witness('wrapper-return')
    os.close(record_fd)
