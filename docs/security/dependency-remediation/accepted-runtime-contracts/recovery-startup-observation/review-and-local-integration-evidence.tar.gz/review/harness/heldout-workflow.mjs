import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url)),candidate=path.join(root,'candidate');
const require=createRequire(path.join(candidate,'package.json')),yaml=require('yaml');
const sha=b=>createHash('sha256').update(b).digest('hex');
const bytes=readFileSync(path.join(candidate,'.github/workflows/ci.yml')),text=bytes.toString('utf8');
assert.equal(sha(bytes),'58cdcb86673d982e04d27d17b0cc3c438a17b499647fb9eba2da484d6c8c928f');
const parsed=yaml.parse(text),steps=parsed.jobs.javascript.steps;
const prefix=text.slice(0,text.indexOf('      # Explicit AFTER the canonical suite/smoke:'));
assert.equal(sha(prefix),'d723590bbdca7e4e20a61eb6782d77f25defd3a633403c2c9d654ecfcfa00aa1');
const oldSelftest=steps.findIndex(s=>s.name==='After-canonical Node diagnostic controls'),smoke=steps.findIndex(s=>s.name==='Real isolated tarball install and CLI/SQLite smoke');
const upload=steps.findIndex(s=>s.name==='Preserve first-invocation bootstrap observations even on failure');
const names=['After-canonical caller startup observation (actual Node)','After-canonical caller startup observation (native Bun)','After-canonical startup observation selftests'];
const controls=[];
for(const [j,name]of names.entries()){
 const i=steps.findIndex(s=>s.name===name),s=steps[i];assert.equal(i,oldSelftest+j+1);assert.ok(i>smoke&&i<upload);
 assert.equal(s.if,"always() && runner.os == 'macOS'");assert.equal(s['continue-on-error'],true);assert.equal(s['timeout-minutes'],2);
 const shell=spawnSync('/bin/bash',['-n'],{input:s.run,env:process.env,encoding:'utf8',timeout:3000});assert.equal(shell.status,0,shell.stderr);
 controls.push({name,position:i,bashSyntaxExit:shell.status,run:s.run});
}
let original=text.slice(0,text.indexOf('      # Supplemental and non-gating:'))+text.slice(text.indexOf('      - name: Preserve first-invocation bootstrap observations even on failure'));
for(const line of ['            ${{ runner.temp }}/qmd-recovery-startup/**/*.json\n','            ${{ runner.temp }}/qmd-recovery-startup/**/*.jsonl\n','            ${{ runner.temp }}/qmd-recovery-startup/*.tap\n']){
 assert.equal(original.split(line).length,2);original=original.replace(line,'');
}
assert.equal(sha(original),'f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f');
const originalYaml=yaml.parse(original);
assert.deepEqual(parsed.jobs['python-portable'],originalYaml.jobs['python-portable']);assert.deepEqual(parsed.jobs['python-macos'],originalYaml.jobs['python-macos']);
const sanitized=structuredClone(parsed);sanitized.jobs.javascript.steps=sanitized.jobs.javascript.steps.filter(s=>!names.includes(s.name));
sanitized.jobs.javascript.steps.find(s=>s.name===steps[upload].name).with.path=originalYaml.jobs.javascript.steps.find(s=>s.name===steps[upload].name).with.path;
assert.deepEqual(sanitized,originalYaml,'all previous action pins, command args/order/assertions and artifact policy unchanged');
const literal=path.join(root,'unused-literal-$()-path');
const check=`const assert=require('node:assert/strict');for(const k of ['OPENAI_API_KEY','GITHUB_TOKEN','QMD_REVIEW_AMBIENT_CONTEXT','NODE_OPTIONS'])assert.equal(k in process.env,false);assert.equal(process.env.QMD_RECOVERY_STARTUP_OBSERVATION,'1');assert.equal(process.env.QMD_RECOVERY_STARTUP_DIR,${JSON.stringify(literal)});console.log(JSON.stringify({ambientStripped:true,literalPostStripFlagsPreserved:true,actualHost:{node:process.versions.node,executable:process.execPath}}));`;
const py='/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python';
const offline=spawnSync(py,['scripts/run-offline.py','env','QMD_RECOVERY_STARTUP_OBSERVATION=1',`QMD_RECOVERY_STARTUP_DIR=${literal}`,process.execPath,'-e',check],{cwd:candidate,env:{...process.env,OPENAI_API_KEY:'synthetic-authored-not-credential',GITHUB_TOKEN:'synthetic-authored-not-credential',QMD_REVIEW_AMBIENT_CONTEXT:'authored-public-context',NODE_OPTIONS:'--trace-warnings'},encoding:'utf8',timeout:10000});
assert.equal(offline.status,0,offline.stdout+offline.stderr);assert.equal(existsSync(literal),false);
const summary={workflowSha256:sha(bytes),canonicalPrefixSha256:sha(prefix),originalReconstructedSha256:sha(original),wholeParsedExistingWorkflowPreserved:true,controls,offlineWrapper:{exit:offline.status,stdout:offline.stdout,stderr:offline.stderr},actualCI:false};
writeFileSync(path.join(root,'evidence/heldout-workflow-summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify(summary));
