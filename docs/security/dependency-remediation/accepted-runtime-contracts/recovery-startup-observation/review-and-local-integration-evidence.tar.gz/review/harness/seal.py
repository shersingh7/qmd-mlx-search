import hashlib,json,os,pathlib,stat
R=pathlib.Path(__file__).resolve().parent.parent
P=pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r')
O=pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
def digest(p):
    b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
verdict=json.loads((R/'verdict.json').read_text());assert verdict['spec']==verdict['quality']=='PASS'
phase=json.loads((R/'evidence/quality-phase-start.json').read_text());assert digest(R/'SPEC-REVIEW.md')['sha256']==phase['specReportSha256']
assert (R/'QUALITY-REVIEW.md').stat().st_mtime_ns>(R/'evidence/quality-phase-start.json').stat().st_mtime_ns
source=json.loads((R/'evidence/source-before.json').read_text())['files'];assert {p:digest(R/'candidate'/p) for p in source}==source
old=json.loads((R/'evidence/negative-source-before.json').read_text())['files'];assert {p:digest(R/'negative/candidate'/p) for p in old}==old
for rel,h in verdict['postimages'].items():assert digest(R/'candidate'/rel)['sha256']==h
assert (R/'harness/reproduce-findings.mjs').read_bytes()==(O/'harness/reproduce-findings.mjs').read_bytes()==(R/'negative/harness/reproduce-findings.mjs').read_bytes()
reauth=json.loads((R/'evidence/intake-authentication.json').read_text());unique=set()
for checked in reauth['indexes']:
    p=P/checked['path'];assert digest(p)=={k:checked[k] for k in ['sha256','bytes']}
    obj=json.loads(p.read_text());assert len(obj['artifacts'])==checked['authenticatedFiles']
    for row in obj['artifacts']:
        assert row['path'] not in unique;unique.add(row['path']);assert digest(P/row['path'])=={k:row[k] for k in ['sha256','bytes']},row['path']
assert len(unique)==325
bindings=json.loads((R/'evidence/borrowed-evidence-bindings.json').read_text())
for value in bindings.values():
    b=value['binding'];assert digest(pathlib.Path(b['path']))=={k:b[k] for k in ['sha256','bytes']}
summary=json.loads((R/'evidence/review-verification-summary.json').read_text())
assert summary['realComparisons']==verdict['execution']['freshRealRecoveryComparisons']==4
assert summary['ordinaryGuards']==verdict['execution']['ordinaryGuards']
assert summary['negativeGuards']['files']==3 and summary['negativeGuards']['expectedRefusals']==4
actual=json.loads((R/'evidence/independent-real-validation.json').read_text())
assert actual['selftests']['selftests']['pass']==14 and actual['selftests']['selftests']['fail']==actual['selftests']['selftests']['skipped']==0
assert actual['selftests']['observer-selftests']['pass']==8
public=json.loads((R/'evidence/compiler-public-declaration-bindings.json').read_text());suffixes={}
for path,identity in public.items():
    p=pathlib.Path(path);assert digest(p)==identity
    ext=''.join(p.suffixes[-2:]);suffixes[ext]=suffixes.get(ext,0)+1
# Exact harness bindings; orchestration evolution never changes candidate/test assertions.
harness={str(p.relative_to(R)):digest(p) for p in sorted((R/'harness').iterdir()) if p.is_file()}
save(R/'evidence/final-harness-bindings.json',harness)
excluded=[]
def excluded_dir(rel):
    return 'node_modules' in rel.parts or '__pycache__' in rel.parts or 'environment' in rel.parts or 'caller-environment' in rel.parts
for current,dirs,files in os.walk(R,followlinks=False):
    here=pathlib.Path(current)
    kept=[]
    for name in dirs:
        p=here/name;rel=p.relative_to(R)
        if p.is_symlink():excluded.append({'path':str(rel),'kind':'symlink-directory','target':os.readlink(p)})
        elif excluded_dir(rel):continue
        else:kept.append(name)
    dirs[:]=kept
    for name in files:
        p=here/name;rel=p.relative_to(R);s=p.lstat()
        if not stat.S_ISREG(s.st_mode):
            excluded.append({'path':str(rel),'kind':'symlink' if stat.S_ISLNK(s.st_mode) else 'fifo' if stat.S_ISFIFO(s.st_mode) else 'nonregular','target':os.readlink(p) if stat.S_ISLNK(s.st_mode) else None})
save(R/'evidence/excluded-filesystem-fixture-metadata.json',excluded)
save(R/'evidence/seal-verification.json',{'status':'VERIFIED','spec':'PASS','quality':'PASS','qualityScope':'whole-three-path-B','specReport':digest(R/'SPEC-REVIEW.md'),'qualityReport':digest(R/'QUALITY-REVIEW.md'),'verdict':digest(R/'verdict.json'),'sourceInputsUnchanged':len(source),'negativeInputsUnchanged':len(old),'producerArtifactsReauthenticated':len(unique),'originalReproducerByteIdentical':True,'publicDependencyInputsReauthenticated':len(public),'dependencyInputExtensions':suffixes,'realRecoveryComparisons':4,'noLiveOrFrozenWrites':True,'sourceBoundOnly':True})
artifacts=[]
for current,dirs,files in os.walk(R,followlinks=False):
    here=pathlib.Path(current)
    dirs[:]=[d for d in dirs if not (here/d).is_symlink() and not excluded_dir((here/d).relative_to(R))]
    for name in files:
        p=here/name;rel=p.relative_to(R)
        if str(rel) in ['ARTIFACT-INDEX.json','ARTIFACT-INDEX.sha256'] or not stat.S_ISREG(p.lstat().st_mode):continue
        artifacts.append({'path':str(rel),**digest(p)})
artifacts.sort(key=lambda x:x['path']);assert len({x['path'] for x in artifacts})==len(artifacts)
index={'schemaVersion':1,'root':str(R),'scope':'Independent repaired-B SPEC then full three-path QUALITY; exact source, harness, raw execution and proof artifacts, not integration/release/actual CI approval','artifactCount':len(artifacts),'artifactBytes':sum(x['bytes'] for x in artifacts),'indexSelfExcluded':True,'exclusions':['ARTIFACT-INDEX.json and checksum self-excluded to avoid circular binding','All node_modules alias containers and tool caches; current aliases plus actual compiler declaration bytes are separately hash-bound','Owned synthetic environment/caller-environment trees and __pycache__ files','Symlinks/FIFOs/nonregular fixtures are metadata-only in evidence/excluded-filesystem-fixture-metadata.json; their targets are never traversed','Frozen producer/original-review/parent artifacts stay outside this root and are explicitly bound by identity rather than copied in bulk'],'artifacts':artifacts}
save(R/'ARTIFACT-INDEX.json',index);indexhash=digest(R/'ARTIFACT-INDEX.json')['sha256']
(R/'ARTIFACT-INDEX.sha256').write_text(indexhash+'  ARTIFACT-INDEX.json\n')
# Verify the complete final enumerated set, declared count/bytes and checksum.
readback=json.loads((R/'ARTIFACT-INDEX.json').read_text());assert readback['artifactCount']==len(readback['artifacts'])
for row in readback['artifacts']:assert digest(R/row['path'])=={k:row[k] for k in ['sha256','bytes']}
assert sum(x['bytes'] for x in readback['artifacts'])==readback['artifactBytes']
assert (R/'ARTIFACT-INDEX.sha256').read_text().split()[0]==digest(R/'ARTIFACT-INDEX.json')['sha256']
print(json.dumps({'root':str(R),'spec':'PASS','quality':'PASS','wholeThreePathQuality':True,'artifacts':len(artifacts),'artifactBytes':index['artifactBytes'],'artifactIndexSha256':indexhash,'publicDependencyInputExtensions':suffixes,'sourceUnchanged':True,'liveEdits':False,'frozenEdits':False},indent=2))
