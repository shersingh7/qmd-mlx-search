import hashlib, json, pathlib, re
R=pathlib.Path(__file__).resolve().parent.parent
P=pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r')
I=pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-parent-B-repair-intake-nt8peif2')
O=pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
def binding(p):
    b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(name,obj): (R/'evidence'/name).write_text(json.dumps(obj,indent=2)+'\n')
def load(p):return json.loads(p.read_text())
rows=[]
for reportfile in sorted((R/'outputs').glob('*/observation.json')):
    report=load(reportfile);host=report['actualHost'];assert host['runtime'] in ['node','bun']
    assert not report['productQualified'] and not report['collectionErrors'] and report['coldCausality']=='not-established'
    assert [x['timeoutMs'] for x in report['cases']]==[200,5000]
    for rel,h in report['sourceSha256'].items(): assert binding(R/'candidate'/rel)['sha256']==h,rel
    for case in report['cases']:
        folder=reportfile.parent/('case-'+str(case['timeoutMs']))
        assert load(folder/'before-fixture-cleanup.json')==case
        assert case['classification']=='authored-work-observed-uncontained' and case['workValidated']
        assert case['productQualified'] is False and 'uncontained' in case['result']['error']
        result=case['result'];assert result['exitCode']==0 and result['signal'] is None and not result['timedOut']
        assert result['launch']['supervisorReaped']
        for key in ['childReaped','groupTerminated','pipesClosed','sessionTerminated']:assert result['cleanup'][key] is True
        assert result['cleanup']['forcedPipeClose'] is False and result['cleanup']['containmentVerified'] is False
        snapshot=case['snapshot'];assert snapshot['fixtureCleanupStarted'] is False and snapshot['subjectFixtureSignals']==0
        assert snapshot['databaseCreated'] is False and snapshot['supervisorPidPresent'] is False and snapshot['workerPidPresent'] is False
        inv=case['invocation'];assert inv['restored'];assert inv['originalArgv'][:4]==['/usr/bin/python3','-S','-u',str(R/'candidate/scripts/phase5_recovery_process.py')]
        assert inv['actualArgv'][:3]==inv['originalArgv'][:3] and inv['actualArgv'][3]==str(folder/'self-observing-supervisor.py') and inv['actualArgv'][4:]==inv['originalArgv'][4:]
        config=json.loads(inv['actualArgv'][4]);assert config['timeoutMs']==case['timeoutMs'] and config['contained'] is False and config['command'][0]==host['executable']
        assert binding(folder/'self-observing-supervisor.py')['sha256']==case['wrapperSha256']
        compile((folder/'self-observing-supervisor.py').read_bytes(),str(folder/'self-observing-supervisor.py'),'exec')
        work=load(folder/'authored-work.json');doc=(folder/'public-docs/public.md').read_bytes()
        assert work==case['work'] and work['pid']==result['pid'] and work['sha256']==hashlib.sha256(doc).hexdigest() and work['bytes']==len(doc)
        assert load(folder/'worker-report.json')==result['report']
        raw=(folder/'python-self-observation.jsonl').read_bytes();lines=raw.decode('utf-8','strict').splitlines();records=[json.loads(line) for line in lines]
        assert records==case['python']['records'] and case['python']['status']=='complete' and len(raw)==case['python']['bytes']
        assert records[0]['event']=='python-entry' and records[-1]['event']=='wrapper-return'
        assert records[0]['pid']==result['launch']['supervisorPid'] and all(x['pid']==records[0]['pid'] and x['seq']==n for n,x in enumerate(records))
        assert all(a['tMs']<=b['tMs'] for a,b in zip(records,records[1:]))
        budgets=[x['budgetMs'] for x in records if x['event']=='admission-read'];assert len(budgets)==1 and 1<=budgets[0]<=case['timeoutMs']
        assert all(x is None for k,x in case['unsupportedCallerMilestones'].items() if k!='reason')
        if host['runtime']=='bun':assert case['nodeOwner'] is None
        else:assert case['nodeOwner']['restoration']['listenersRemoved'] is True
        rows.append({'runtime':host['runtime'],'actualHost':host,'budgetMs':case['timeoutMs'],'callerReturnedMs':case['callerReturnedMs'],'pythonAdmissionBudgetMs':budgets[0],'selectedInterpreter':case['python']['selectedInterpreter'],'classification':case['classification'],'pythonSidecar':case['python']['status'],'productQualified':case['productQualified'],'snapshot':snapshot,'sourceSha256':case['sourceSha256'],'wrapperSha256':case['wrapperSha256'],'reportBinding':binding(reportfile),'caseBinding':binding(folder/'before-fixture-cleanup.json')})
assert len(rows)==4
# Parse authoritative TAP totals, do not count test names by eye.
tests={}
for label in ['selftests','observer-selftests']:
    text=(R/'evidence'/f'{label}.stdout.txt').read_text();counts={name:int(re.search(r'^# '+name+r' (\d+)$',text,re.M)[1]) for name in ['tests','pass','fail','skipped','cancelled']}
    assert counts['fail']==counts['skipped']==counts['cancelled']==0;assert counts['tests']==counts['pass'];tests[label]=counts
assert tests['selftests']['tests']==14 and tests['observer-selftests']['tests']==8
assert load(R/'evidence/red-rejection.receipt.json')['exit']==1 and load(R/'evidence/red-utf8.receipt.json')['exit']==1
assert load(R/'evidence/green-rejection.receipt.json')['exit']==0 and load(R/'evidence/green-utf8.receipt.json')['exit']==0
assert (R/'harness/reproduce-findings.mjs').read_bytes()==(R/'negative/harness/reproduce-findings.mjs').read_bytes()==(O/'harness/reproduce-findings.mjs').read_bytes()
# Parent evidence is reviewed/bound separately; never label it our execution.
borrowed={}
for rel in ['intake.json','source-before.json','source-after.json','evidence/parent-replay-summary.json','evidence/parent-canonical-build.json']:
    p=I/rel;obj=load(p);borrowed[rel]={'binding':binding(p),'topLevelKeys':list(obj),'scope':'parent execution; not this review'}
# Frozen preexisting raw failures are retained and separately bound.
for rel in ['SPEC-REVIEW.md','verdict.json','evidence/finding-red-rejection.receipt.json','evidence/finding-red-rejection.stdout.txt','evidence/finding-red-rejection.stderr.txt','evidence/finding-red-utf8.receipt.json','evidence/finding-red-utf8.stdout.txt','evidence/finding-red-utf8.stderr.txt']:
    borrowed[str(O/rel)]={'binding':binding(O/rel),'scope':'original failed independent review, immutable'}
# Exact patch spans plus every source postimage were read in this review.
for p in ['two-file-repair.patch','three-path-proposal.patch']:
    text=(P/p).read_text();paths=re.findall(r'^diff --git a/(.*?) b/.*$',text,re.M)
    expected=['test/helpers/recovery-startup-observation.selftest.mjs','test/helpers/recovery-startup-observation.ts'] if p.startswith('two-') else ['.github/workflows/ci.yml','test/helpers/recovery-startup-observation.selftest.mjs','test/helpers/recovery-startup-observation.ts']
    assert paths==expected,(p,paths)
    borrowed[p]={'binding':binding(P/p),'paths':paths,'firstHunk':text.splitlines()[:55]}
save('independent-real-validation.json',{'realComparisons':4,'allFourAuthoredWorkObserved':True,'rows':rows,'selftests':tests,'unchangedReproducer':binding(R/'harness/reproduce-findings.mjs')})
save('borrowed-evidence-bindings.json',borrowed)
print(json.dumps({'realComparisons':len(rows),'rows':[{k:r[k] for k in ['runtime','budgetMs','callerReturnedMs','pythonAdmissionBudgetMs','classification','pythonSidecar']} for r in rows],'tests':tests,'borrowedBindings':len(borrowed)},indent=2))
