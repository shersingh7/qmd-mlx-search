import hashlib, json, os, pathlib, shutil
R = pathlib.Path(__file__).resolve().parent.parent
P = pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r')
O = pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
I = pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-parent-B-repair-intake-nt8peif2')
LIVE = pathlib.Path('/Users/shersingh/github/qmd-mlx-search')
EXPECTED = {'ARTIFACT-INDEX.json':'3a428fca9827592307e7d068572cfb8c0abafae59d442ef63620d44dd68f84de','FOLLOWUP-INDEX.json':'6aad4ee18cbc323c6b056db365e045ee0f97832badf93a72e756d09587cdbe79','GATE-INDEX.json':'297f290b9e7bdaf17dd2dfa02acf72e8802bf6889cc982e7ff0655913f1383e4'}
def digest(p):
    b=p.read_bytes(); return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(name, obj):
    p=R/name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(obj,indent=2)+'\n')
seen=set(); checks=[]
for name, expected in EXPECTED.items():
    p=P/name; assert digest(p)['sha256']==expected
    idx=json.loads(p.read_text()); rows=idx['artifacts']; assert len(rows)==idx['artifactCount']
    count=0
    for row in rows:
        rel=row['path']; assert rel not in seen and not pathlib.Path(rel).is_absolute() and '..' not in pathlib.Path(rel).parts
        seen.add(rel); assert digest(P/rel)=={k:row[k] for k in ['sha256','bytes']}, rel; count+=row['bytes']
    assert count==idx['artifactBytes']
    checks.append({'path':name,**digest(p),'authenticatedFiles':len(rows),'authenticatedBytes':count})
assert len(seen)==325
follow=json.loads((P/'FOLLOWUP-INDEX.json').read_text()); gate=json.loads((P/'GATE-INDEX.json').read_text())
assert follow['baseIndexSha256']==EXPECTED['ARTIFACT-INDEX.json']
assert gate['baseIndexSha256']==EXPECTED['ARTIFACT-INDEX.json'] and gate['priorSupplementIndexSha256']==EXPECTED['FOLLOWUP-INDEX.json']
assert digest(O/'ARTIFACT-INDEX.json')['sha256']=='5944a057e3f0c1dcc6210123d3d7f9e86d586b80749dd80baf9550fe5f690e62'
original=json.loads((O/'ARTIFACT-INDEX.json').read_text()); oldrows={x['path']:x for x in original['artifacts']}
inputs=json.loads((P/'evidence/source-before.json').read_text())['files']
assert len(inputs)==48
copied={}; oldcopied={}; live={}; parent={}
for rel in inputs:
    src=P/'candidate'/rel; target=R/'candidate'/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,target)
    copied[rel]=digest(target); assert copied[rel]==digest(src)
    if rel not in ['test/helpers/recovery-startup-observation.ts','test/helpers/recovery-startup-observation.selftest.mjs']:
        assert copied[rel]==inputs[rel]
    oldsrc=O/'candidate'/rel if ('candidate/'+rel) in oldrows else src
    oldtarget=R/'negative/candidate'/rel; oldtarget.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(oldsrc,oldtarget); oldcopied[rel]=digest(oldtarget)
    if ('candidate/'+rel) in oldrows: assert oldcopied[rel]=={k:oldrows['candidate/'+rel][k] for k in ['sha256','bytes']}
    if (LIVE/rel).is_file(): live[rel]=digest(LIVE/rel)
    else: live[rel]={'state':'ABSENT'}
    assert digest(I/'candidate'/rel)==copied[rel], rel
    parent[rel]=digest(I/'candidate'/rel)
for rel in ['.github/workflows/ci.yml','test/helpers/recovery-startup-observation.ts','test/helpers/recovery-startup-observation.selftest.mjs']:
    assert digest(P/'proposal'/rel)==copied[rel]
assert live['.github/workflows/ci.yml']['sha256']=='f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f'
assert all(live[x]=={'state':'ABSENT'} for x in ['test/helpers/recovery-startup-observation.ts','test/helpers/recovery-startup-observation.selftest.mjs'])
# Fresh dependency discovery: no stale aliases are reused.
mods=LIVE/'node_modules'; aliases={}
for item in sorted(mods.iterdir()):
    if item.name.startswith('.'): continue
    if item.name.startswith('@'):
        for pkg in sorted(item.iterdir()):
            if (pkg/'package.json').is_file(): aliases[item.name+'/'+pkg.name]=str(pkg.resolve(strict=True))
    elif (item/'package.json').is_file(): aliases[item.name]=str(item.resolve(strict=True))
assert len(aliases)==281, len(aliases)
for dest in [R, R/'negative']:
    for folder in ['harness','evidence','outputs','environment']:(dest/folder).mkdir(parents=True,exist_ok=True)
    nm=dest/'candidate/node_modules'; nm.mkdir()
    for name,target in aliases.items():
        link=nm/name; link.parent.mkdir(parents=True,exist_ok=True); link.symlink_to(target,target_is_directory=True)
    for cache in ['.vite','.vite-temp','.cache','.vitest']:(nm/cache).mkdir()
    (dest/'evidence/package-aliases.json').write_text(json.dumps(aliases,indent=2)+'\n')
    for name in ['reproduce-findings.mjs']:
        shutil.copyfile(O/'harness'/name,dest/'harness'/name)
        assert digest(dest/'harness'/name)==digest(O/'harness'/name)
    shutil.copyfile(I/'harness/read-guard.cjs',dest/'harness/read-guard.cjs')
# Proven read-only scaffolds; source-relative paths remain unchanged.
for name in ['replay.mjs','selftest-preload.cjs','wrapper-boundary.mjs','focused-strict.cjs']:
    shutil.copyfile(P/'harness'/name,R/'harness'/name)
    assert digest(P/'harness'/name)==digest(R/'harness'/name)
save('evidence/intake-authentication.json',{'indexes':checks,'uniqueArtifacts':len(seen),'chainedReferences':True,'originalIndex':digest(O/'ARTIFACT-INDEX.json'),'producerPatch':digest(P/'two-file-repair.patch'),'threePathPatch':digest(P/'three-path-proposal.patch'),'parentSourceAfter':digest(I/'source-after.json') if (I/'source-after.json').exists() else digest(I/'evidence/source-after.json')})
save('evidence/source-before.json',{'origin':str(P/'candidate'),'files':copied})
save('evidence/negative-source-before.json',{'origin':str(O/'candidate'),'files':oldcopied})
save('evidence/live-scope-before.json',live)
save('evidence/parent-closure-bindings.json',parent)
save('evidence/harness-intake-bindings.json',{name:digest(R/'harness'/name) for name in ['reproduce-findings.mjs','replay.mjs','read-guard.cjs','selftest-preload.cjs','wrapper-boundary.mjs','focused-strict.cjs']})
print(json.dumps({'root':str(R),'indexes':checks,'uniqueArtifacts':len(seen),'copiedSourceInputs':len(copied),'currentPublicPackageAliases':len(aliases),'liveBUnchanged':True},indent=2))
