import hashlib,json,pathlib,re,stat
R=pathlib.Path(__file__).resolve().parent.parent
P=pathlib.Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r')
L=pathlib.Path('/Users/shersingh/github/qmd-mlx-search')
def digest(p):
    b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(rel,obj):(R/'evidence'/rel).write_text(json.dumps(obj,indent=2)+'\n')
def apply_unified(old,lines):
    src=old.splitlines(keepends=True);out=[];cursor=0;i=0
    while i<len(lines):
        m=re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i])
        if not m:i+=1;continue
        oldstart=int(m[1]);oldcount=int(m[2]) if m[2] is not None else 1
        newcount=int(m[4]) if m[4] is not None else 1
        start=oldstart-1 if oldstart else 0;assert start>=cursor
        out.extend(src[cursor:start]);cursor=start;i+=1;oc=nc=0
        while i<len(lines) and not lines[i].startswith('@@ '):
            t=lines[i]
            if t.startswith(' '):assert src[cursor]==t[1:];out.append(t[1:]);cursor+=1;oc+=1;nc+=1
            elif t.startswith('-'):assert src[cursor]==t[1:];cursor+=1;oc+=1
            elif t.startswith('+'):out.append(t[1:]);nc+=1
            elif t.startswith('\\ No newline'):raise AssertionError('unanticipated unterminated hunk')
            else:break
            i+=1
        assert oc==oldcount and nc==newcount,(oc,oldcount,nc,newcount)
    out.extend(src[cursor:]);return ''.join(out)
replays=[]
for patch,base in [('two-file-repair.patch','negative'),('three-path-proposal.patch','live')]:
    text=(P/patch).read_text();parts=re.split(r'(?m)^diff --git a/(.*?) b/(.*?)\n',text);outputs={}
    for j in range(1,len(parts),3):
        rel,other,body=parts[j:j+3];assert rel==other
        if base=='negative':old=(R/'negative/candidate'/rel).read_text()
        else:old=(L/rel).read_text() if rel=='.github/workflows/ci.yml' else ''
        final=apply_unified(old,body.splitlines(keepends=True));assert final.encode()==(R/'candidate'/rel).read_bytes()
        dest=R/'patch-replay'/patch.removesuffix('.patch')/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(final.encode());outputs[rel]=digest(dest)
    replays.append({'patch':patch,'patchIdentity':digest(P/patch),'method':'independent strict unified-hunk replay; no git/global state','postimages':outputs})
save('independent-patch-replay.json',replays)
source=json.loads((R/'evidence/source-before.json').read_text())['files'];after={p:digest(R/'candidate'/p) for p in source};assert after==source
old=json.loads((R/'evidence/negative-source-before.json').read_text())['files'];assert {p:digest(R/'negative/candidate'/p) for p in old}==old
liveBefore=json.loads((R/'evidence/live-scope-before.json').read_text());liveAfter={p:digest(L/p) if (L/p).is_file() else {'state':'ABSENT'} for p in liveBefore}
assert liveAfter['.github/workflows/ci.yml']==liveBefore['.github/workflows/ci.yml']
for p in ['test/helpers/recovery-startup-observation.ts','test/helpers/recovery-startup-observation.selftest.mjs']:assert liveAfter[p]=={'state':'ABSENT'}
save('source-after.json',{'files':after,'sameAsBefore':True,'sourceFiles':len(after)})
save('live-scope-after.json',{'files':liveAfter,'changedAllowedClosureInputs':[p for p in liveBefore if liveAfter[p]!=liveBefore[p]],'liveBWrites':False,'scope':'B payload and copied public closure only, not whole live-tree equality'})
# Every source read path in the focused compiler closure is source-bound.
types=json.loads((R/'evidence/focused-strict-summary.json').read_text());assert types['diagnostics']==0 and len(types['sourceFiles'])==548
aliases=json.loads((R/'evidence/package-aliases.json').read_text());roots=sorted(set(aliases.values()))
def inside(p,root):return p==root or p.startswith(root+'/')
depBindings={}
for path in types['sourceFiles']:
    real=str(pathlib.Path(path).resolve(strict=True));assert inside(real,str(R/'candidate')) or any(inside(real,p) for p in roots),real
    if not inside(real,str(R/'candidate')):depBindings[real]=digest(pathlib.Path(real))
save('compiler-public-declaration-bindings.json',depBindings)
# Keep expected denial controls separate from ordinary guarded execution.
guards=[];ordinary=[];negative=[]
for folder in [R/'evidence',R/'negative/evidence']:
    for p in sorted(folder.glob('*guard-*.jsonl')):
        rows=[json.loads(line) for line in p.read_text().splitlines()]
        refusals=[x for x in rows if x.get('allowed') is False]
        item={'path':str(p.relative_to(R)),**digest(p),'rows':len(rows),'refusals':len(refusals),'installs':[x for x in rows if x.get('kind')=='guard-installed']}
        guards.append(item)
        if refusals:
            assert p.name.startswith('guard-negative-') or (p.name.startswith('types-compiler-guard-') and len(refusals)==2),item
            negative.append(item)
        else:ordinary.append(item)
assert len(negative)==3 and sum(x['refusals'] for x in negative)==4
normalCompiler=[x for x in ordinary if '-compiler-guard-' in x['path']];assert len(normalCompiler)==1
assert normalCompiler[0]['refusals']==0
receipts=[]
for p in sorted((R/'evidence').glob('*.receipt.json')):
    obj=json.loads(p.read_text());assert not obj['timeout']
    expected=1 if obj['label'].startswith('red-') else 0;assert obj['exit']==expected,(p,obj['exit'])
    receipts.append({'label':obj['label'],'exit':obj['exit'],'rawReceipt':digest(p),'realComparisons':obj['realComparisons']})
assert sum(x['realComparisons'] for x in receipts)==4
phase=json.loads((R/'evidence/quality-phase-start.json').read_text());assert digest(R/'SPEC-REVIEW.md')['sha256']==phase['specReportSha256']
qualityLabels=['types','guard-negative-node','guard-negative-bun','compiler-negative','actionlint']
assert all((R/'evidence'/f'{x}.receipt.json').stat().st_mtime_ns>(R/'evidence/quality-phase-start.json').stat().st_mtime_ns for x in qualityLabels)
summary={'reviewRoot':str(R),'sourceFiles':len(after),'sourceUnchanged':True,'helperPostimages':{p:after[p] for p in ['.github/workflows/ci.yml','test/helpers/recovery-startup-observation.ts','test/helpers/recovery-startup-observation.selftest.mjs']},'liveBUnchanged':True,'executions':receipts,'realComparisons':4,'ordinaryGuards':{'files':len(ordinary),'rows':sum(x['rows'] for x in ordinary),'refusals':0},'negativeGuards':{'files':len(negative),'rows':sum(x['rows'] for x in negative),'expectedRefusals':sum(x['refusals'] for x in negative)},'guards':guards,'focusedCompiler':{'sourceFiles':len(types['sourceFiles']),'diagnostics':0,'guardRows':normalCompiler[0]['rows'],'refusals':0,'publicDependencyDeclarationFilesHashBound':len(depBindings)},'specReportSealedBeforeQuality':phase,'actionlint':{'binary':'/Users/shersingh/.hermes/cache/scratch/qmd-actionlint-4voz5mzz/actionlint','sha256':'8db11704dc296f096216db4db65d86cd7f0ebfdf4c38453a1da276b137b88388','exit':0,'shellcheck':'explicitly disabled; not installed/qualified','pyflakes':'explicitly disabled; not installed/qualified'},'wholeProjectBuildTestsPackagingActualCI':'not executed in independent review; parent-owned','guardScope':'Node-FS source read/readdir hook, not an OS sandbox or native Bun internal transpiler guard'}
save('review-verification-summary.json',summary)
print(json.dumps({k:summary[k] for k in ['sourceFiles','sourceUnchanged','liveBUnchanged','realComparisons','ordinaryGuards','negativeGuards','focusedCompiler']},indent=2))
