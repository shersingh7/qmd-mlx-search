const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
for(const p of ['/Users/shersingh/github/qmd-mlx-search/package.json',path.join(root,'evidence/heldout-bytes-node-summary.json')])assert.throws(()=>fs.readFileSync(p),e=>e.code==='REVIEW_READ_DENIED');
assert.ok(fs.readFileSync(path.join(root,'candidate/package.json')).length>0);
console.log(JSON.stringify({policy:'compiler-only-no-runtime-fixtures',outsideLivePublicSourceRefused:true,ownedRuntimeFixtureRefused:true,ownedSourceAllowed:true,actualHost:{executable:process.execPath,node:process.versions.node,bun:process.versions.bun??null}}));
