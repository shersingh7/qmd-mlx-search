const fs=require('node:fs'), path=require('node:path'), {fileURLToPath}=require('node:url');
const root=path.resolve(__dirname,'..');
const raw={readFileSync:fs.readFileSync,readFile:fs.readFile,readdirSync:fs.readdirSync,readdir:fs.readdir,realpathSync:fs.realpathSync,appendFileSync:fs.appendFileSync};
const aliases=JSON.parse(raw.readFileSync(path.join(root,'evidence/package-aliases.json'),'utf8'));
const packageRoots=[...new Set(Object.values(aliases))];
const label=process.env.REVIEW_GUARD_LABEL||'guard';
if(!/^[a-z0-9-]+$/.test(label))throw Error('fixed review label required');
const log=path.join(root,'evidence',`${label}-guard-${process.pid}.jsonl`);
const inside=(p,dir)=>p===dir||p.startsWith(dir+path.sep);
function guard(value,operation){
 if(typeof value==='number')return;
 const lexical=path.resolve(value instanceof URL?fileURLToPath(value):String(value));
 let real;try{real=raw.realpathSync(lexical);}catch(e){if(e.code==='ENOENT'||e.code==='ENOTDIR')return;throw e;}
 const allowed=inside(real,root)||packageRoots.some(dir=>inside(real,dir));
 raw.appendFileSync(log,JSON.stringify({operation,lexical,real,allowed})+'\n');
 if(!allowed)throw Object.assign(new Error('REVIEW_READ_DENIED '+lexical),{code:'REVIEW_READ_DENIED'});
}
for(const key of ['readFileSync','readFile','readdirSync','readdir'])fs[key]=function(value,...rest){guard(value,key);return raw[key].call(this,value,...rest);};
for(const key of ['readFile','readdir','opendir']){
 const orig=fs.promises[key];fs.promises[key]=async function(value,...rest){guard(value,'promises.'+key);return orig.call(this,value,...rest);};
}
require('node:module').syncBuiltinESMExports();
raw.appendFileSync(log,JSON.stringify({kind:'guard-installed',actualHost:{executable:process.execPath,node:process.versions.node,bun:process.versions.bun??null},packageRoots:packageRoots.length})+'\n');
process.on('exit',()=>raw.appendFileSync(log,JSON.stringify({kind:'guard-host-exit',code:process.exitCode??0,actualHost:{executable:process.execPath,node:process.versions.node,bun:process.versions.bun??null}})+'\n'));
