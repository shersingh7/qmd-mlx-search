// Independent exact-helper ownership controls. Only a public caller module is
// mocked; EventEmitter/PassThrough subjects have no OS process or signal path.
import assert from 'node:assert/strict';
import {mock} from 'node:test';
import cp,{spawn as namedSpawn} from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {EventEmitter,errorMonitor} from 'node:events';
import {PassThrough} from 'node:stream';
import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
const source=path.join(root,'candidate/scripts/phase5_recovery_process.py');
const dir=path.join(root,'evidence/heldout-lifetime');mkdirSync(dir,{mode:0o700});
const environment=process.env,originalSpawn=cp.spawn;
const result={launch:{state:'started',supervisorReaped:true},timedOut:false,exitCode:0,signal:null,
 cleanup:{containmentVerified:false,childReaped:true,groupTerminated:true,sessionTerminated:true,pipesClosed:true,forcedPipeClose:false}};
const primary=new Error('authored primary failure'),secondary=new Error('authored disposal-after-release failure');
let mode,calls,records,notify,reject,failSnapshot=false;
const fakeSpawn=function(exe,args,options){
 assert.equal(exe,'/usr/bin/python3');assert.deepEqual(args.slice(0,2),['-S','-u']);
 assert.ok(args[2].endsWith('/self-observing-supervisor.py'));assert.deepEqual(options.stdio,['pipe','pipe','pipe','pipe']);
 const child=new EventEmitter();Object.assign(child,{exitCode:null,signalCode:null,stdout:new PassThrough(),stderr:new PassThrough()});
 child.stdio=[null,child.stdout,child.stderr,new PassThrough()];child.kill=()=>assert.fail('no subject signals');
 Object.defineProperty(child,'_closesGot',{get(){if(failSnapshot)throw primary;return 0;}});
 const targets=[child,child.stdout,child.stderr,child.stdio[3]],baselines=[],removed=new Set();
 let attempts=0;
 for(const [i,target] of targets.entries()){
  // Include caller-owned symbol and once-wrapped listeners, not just counts.
  for(const event of ['spawn','exit','close','end','data',errorMonitor])target.on(event,()=>{});
  target.once('close',()=>{});
  const baseline=new Map(target.eventNames().map(event=>[event,target.rawListeners(event)]));baselines.push(baseline);
  const remove=target.removeListener;
  target.removeListener=function(event,callback){
   if(!(baseline.get(event)||[]).includes(callback)){
    attempts++;assert.equal(removed.has(callback),false,'no duplicate observer release');removed.add(callback);
    const answer=remove.call(this,event,callback);
    if(mode==='late-reject-disposal-error'&&removed.size===13)throw secondary;
    return answer;
   }
   return remove.call(this,event,callback);
  };
 }
 const record={child,targets,baselines,removed,get attempts(){return attempts;}};records.push(record);return child;
};
cp.spawn=fakeSpawn;syncBuiltinESMExports();
const replacement=mock.module(new URL('../candidate/scripts/phase5_e2e_runner.ts',import.meta.url).href,{namedExports:{executeRecoveryWorker(options){
 calls++;
 if(mode==='unreaped')return Promise.resolve({...result,launch:{state:'unconfirmed',supervisorReaped:false}});
 namedSpawn('/usr/bin/python3',['-S','-u',source,JSON.stringify({timeoutMs:options.timeoutMs,contained:false})],{detached:true,stdio:['pipe','pipe','pipe','pipe']});
 if(mode.startsWith('late-reject')){notify();return new Promise((_resolve,rejector)=>{reject=rejector;});}
 if(mode==='sync-throw')throw primary;
 if(mode==='finish-throw')failSnapshot=true;
 return Promise.resolve(result);
}}});
const summaries=[];
try{
 const {runStartupObservation}=await import('../candidate/test/helpers/recovery-startup-observation.ts');
 process.env.QMD_RECOVERY_STARTUP_OBSERVATION='1';
 for(mode of ['late-reject','late-reject-disposal-error','sync-throw','finish-throw','normal','unreaped']){
  calls=0;records=[];failSnapshot=false;
  let run;
  if(mode.startsWith('late-reject')){
   const launched=new Promise(resolve=>{notify=resolve;});run=runStartupObservation(dir,'node');await launched;
   await new Promise(resolve=>setImmediate(resolve));
   assert.equal(cp.spawn,fakeSpawn);assert.equal(namedSpawn,fakeSpawn,'global named binding restored before await settles');
   const added=records[0].targets.reduce((n,target,i)=>n+target.eventNames().reduce((k,event)=>k+target.rawListeners(event).filter(fn=>!(records[0].baselines[i].get(event)||[]).includes(fn)).length,0),0);
   assert.equal(added,13,'observer remains alive for call-owned in-flight work');assert.equal(records[0].attempts,0);
   reject(primary);
  }else run=runStartupObservation(dir,'node');
  const observed=await run;
  assert.equal(cp.spawn,fakeSpawn);assert.equal(namedSpawn,fakeSpawn);assert.equal(process.env,environment);
  const failed=mode!=='normal'&&mode!=='unreaped';
  assert.equal(calls,mode==='normal'?2:1);
  assert.equal(observed.report.cases.length,mode==='normal'?2:mode==='unreaped'?1:0);
  if(failed)assert.deepEqual(observed.report.collectionErrors,['observation-incomplete; inspect retained owned artifacts']);
  if(mode==='unreaped')assert.deepEqual(observed.report.collectionErrors,['prior-supervisor-unreaped; further calls refused; partial evidence retained']);
  if(mode!=='normal')assert.equal(existsSync(path.join(observed.directory,'case-5000')),false);
  assert.deepEqual(JSON.parse(readFileSync(path.join(observed.directory,'observation.json'),'utf8')),observed.report);
  failSnapshot=false;
  for(const record of records){
   assert.equal(record.attempts,13);assert.equal(record.removed.size,13);
   for(const [i,target]of record.targets.entries()){
    assert.deepEqual(new Map(target.eventNames().map(event=>[event,target.rawListeners(event)])),record.baselines[i]);
    if(i>0){assert.equal(target.destroyed,false);assert.equal(target.readableFlowing,true,'caller data listener flow unchanged');}
   }
  }
  summaries.push({mode,calls,ownCallbacksRemoved:records.map(x=>x.attempts),collectionErrors:observed.report.collectionErrors,spawnAndNamedRestored:true,environmentObjectRestored:true,fixtureCleanupStarted:false,subjectFixtureSignals:0,zeroRealRecoveryCalls:true});
 }
 writeFileSync(path.join(root,'evidence/heldout-lifetime-summary.json'),JSON.stringify({checks:summaries,realRecoveryCalls:0},null,2)+'\n',{flag:'wx',mode:0o600});
 console.log(JSON.stringify({checks:summaries,realRecoveryCalls:0}));
}finally{replacement.restore();cp.spawn=originalSpawn;syncBuiltinESMExports();}
