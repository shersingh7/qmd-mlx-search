// Independent byte/record boundary controls on the exact public helper.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {actualHost,LIMITS,readPythonSidecar,parsePythonSidecar} from '../candidate/test/helpers/recovery-startup-observation.ts';
const root=fileURLToPath(new URL('../',import.meta.url));
const host=actualHost();const dir=path.join(root,'evidence','heldout-bytes-'+host.runtime);fs.mkdirSync(dir,{mode:0o700});
const entry={event:'python-entry',seq:0,pid:711,tMs:100000000,version:'日本語 café 🐍 �',executable:'/literal/解释器'};
const row=(event,seq,extra={})=>({event,seq,pid:entry.pid,tMs:entry.tMs+seq,...extra});
const line=value=>JSON.stringify(value)+'\n';
const prefix=line(entry),terminal=line(row('wrapper-return',1)),complete=prefix+terminal;
const results=[];
function check(name,bytes,status,count,tail=0){
 if(typeof bytes==='string')bytes=Buffer.from(bytes);
 const file=path.join(dir,name+'.jsonl');fs.writeFileSync(file,bytes,{flag:'wx',mode:0o600});
 const actual=readPythonSidecar(file);
 assert.equal(actual.status,status,name);assert.equal(actual.records.length,count,name);assert.equal(actual.bytes,bytes.length,name+' actual raw bytes');assert.equal(actual.trailingBytes,tail,name);
 assert.deepEqual(fs.readFileSync(file),bytes,name+' raw evidence unchanged');
 if(count===0)assert.equal(actual.selectedInterpreter,null,name);
 else assert.notEqual(actual.selectedInterpreter,null,name);
 results.push({name,status,count,bytes:bytes.length,trailingBytes:tail});return actual;
}
check('unicode-literal-fffd',complete,'complete',2);
check('unicode-escaped-fffd',complete.replace('�','\\ufffd'),'complete',2);
check('crlf-valid-json-whitespace',complete.replaceAll('\n','\r\n'),'complete',2);
check('empty-file',Buffer.alloc(0),'partial',0);
check('no-lf-invalid-utf8-is-raw-tail',Buffer.from([0xff]),'partial',0,1);
check('no-lf-complete-json-is-tail',JSON.stringify(entry),'partial',0,Buffer.byteLength(JSON.stringify(entry)));
const corrupt=Buffer.concat([Buffer.from('{"event":"module-'),Buffer.from([0xe2,0x28,0xa1]),Buffer.from('loaded","seq":1,"pid":711,"tMs":100000001}\n')]);
check('invalid-after-valid-prefix-with-later-valid-row',Buffer.concat([Buffer.from(prefix),corrupt,Buffer.from(line(row('wrapper-return',2)))]),'malformed',1);
const invalidTail=Buffer.from([0xf0,0x9f]);
check('invalid-row-plus-partial-tail',Buffer.concat([Buffer.from(prefix),corrupt,invalidTail]),'malformed',1,invalidTail.length);
check('terminal-followed-by-invalid-utf8-row',Buffer.concat([Buffer.from(complete),Buffer.from([0xff,10])]),'malformed',2);
check('terminal-followed-by-unterminated-multibyte',Buffer.concat([Buffer.from(complete),invalidTail]),'partial',2,invalidTail.length);
check('split-utf8-across-newline',Buffer.concat([Buffer.from(prefix),Buffer.from([0xe2,10,0x82,0xac,10])]),'malformed',1);
check('leading-bom-not-stripped',Buffer.concat([Buffer.from([0xef,0xbb,0xbf]),Buffer.from(complete)]),'malformed',0);
check('later-bom-not-stripped',Buffer.concat([Buffer.from(prefix),Buffer.from([0xef,0xbb,0xbf]),Buffer.from(terminal)]),'malformed',1);
check('valid-json-error-before-bad-bytes',Buffer.concat([Buffer.from(prefix+'[]\n'),Buffer.from([255,10]),Buffer.from(line(row('wrapper-return',3)))]),'malformed',1);
const boundary={...entry,version:'é'.repeat(400),executable:'/'};
const available=2048-Buffer.byteLength(JSON.stringify(boundary));assert.ok(available>0);
boundary.executable+='界'.repeat(Math.floor(available/3))+'x'.repeat(available%3);
assert.equal(Buffer.byteLength(JSON.stringify(boundary)),2048);
check('exact-line-byte-bound-valid',line(boundary)+terminal,'complete',2);
check('line-one-byte-too-long',line({...boundary,executable:boundary.executable+'x'})+terminal,'malformed',0);
const cap=Buffer.concat([Buffer.from(prefix),Buffer.alloc(LIMITS.sidecarBytes-Buffer.byteLength(prefix),0xff)]);
check('exact-file-cap-raw-tail',cap,'partial',1,cap.length-Buffer.byteLength(prefix));
check('one-byte-over-cap',Buffer.concat([cap,Buffer.from('x')]),'oversized',0);
const matrix=[
 ['foreign-pid',prefix+line(row('module-loaded',1,{pid:712})),1],
 ['fractional-pid',line({...entry,pid:1.5}),0],
 ['zero-pid',line({...entry,pid:0}),0],
 ['sequence-gap',prefix+line(row('module-loaded',2)),1],
 ['clock-backwards',prefix+line(row('module-loaded',1,{tMs:entry.tMs-1})),1],
 ['nonfinite-clock',prefix+'{"event":"module-loaded","seq":1,"pid":711,"tMs":1e999}\n',1],
 ['unexpected-extra-key',prefix+line(row('module-loaded',1,{secret:'public-sentinel'})),1],
 ['missing-entry-field',line({...entry,version:undefined}),0],
 ['budget-zero',prefix+line(row('admission-read',1,{budgetMs:0})),1],
 ['budget-too-large',prefix+line(row('admission-read',1,{budgetMs:5001})),1],
 ['budget-fractional',prefix+line(row('admission-read',1,{budgetMs:1.5})),1],
 ['after-terminal',complete+line(row('module-loaded',2)),2],
 ['unknown-event',prefix+line(row('authored-unknown',1)),1],
 ['record-overflow',prefix+Array.from({length:32},(_,i)=>line(row('module-loaded',i+1))).join(''),32]
];
for(const [name,text,n]of matrix){const actual=check(name,text,'malformed',n);assert.deepEqual(actual,parsePythonSidecar(text),name+' string schema contract preserved');}
check('budget-edge-positives',prefix+line(row('admission-read',1,{budgetMs:1}))+line(row('admission-read',2,{budgetMs:5000}))+line(row('wrapper-return',3)),'complete',4);
const target=path.join(dir,'regular.jsonl');fs.writeFileSync(target,complete,{flag:'wx',mode:0o600});
const hard=path.join(dir,'hardlink');fs.linkSync(target,hard);assert.equal(readPythonSidecar(hard).status,'unsafe');assert.equal(readPythonSidecar(target).status,'unsafe');fs.unlinkSync(hard);
assert.equal(readPythonSidecar(target).status,'complete');
const symlink=path.join(dir,'symlink');fs.symlinkSync(target,symlink);assert.equal(readPythonSidecar(symlink).status,'unsafe');assert.equal(readPythonSidecar(dir).status,'unsafe');
const fifo=path.join(dir,'fifo');const made=spawnSync('/usr/bin/mkfifo',[fifo],{env:process.env,timeout:2000});assert.equal(made.status,0);assert.equal(readPythonSidecar(fifo).status,'unsafe');
// Actual Node named-FS seam: TOCTOU identity mismatch and short-read byte splits.
// Bun's unsupported namespace->existing named binding seam stays unclaimed.
let faults={qualified:false,reason:'native Bun namespace-to-existing-named-FS mock seam unsupported'};
if(!process.versions.bun){
 const original={fstatSync:fs.fstatSync,openSync:fs.openSync,closeSync:fs.closeSync,readSync:fs.readSync};let opens=0,closes=0,reads=0;
 fs.openSync=(...args)=>{opens++;assert.ok((args[1]&fs.constants.O_NOFOLLOW)!==0);assert.ok((args[1]&fs.constants.O_NONBLOCK)!==0);return original.openSync(...args);};
 fs.closeSync=(...args)=>{closes++;return original.closeSync(...args);};
 fs.fstatSync=(...args)=>{const s=original.fstatSync(...args);s.ino+=1;return s;};syncBuiltinESMExports();
 try{assert.equal(readPythonSidecar(target).status,'unsafe');assert.equal(opens,1);assert.equal(closes,1);
  fs.fstatSync=original.fstatSync;fs.readSync=(fd,b,off,len,pos)=>{reads++;return original.readSync(fd,b,off,Math.min(len,1),pos);};syncBuiltinESMExports();
  assert.equal(readPythonSidecar(target).status,'complete');assert.equal(opens,2);assert.equal(closes,2);assert.ok(reads>Buffer.byteLength(complete));
  faults={qualified:true,inodeMismatchRefused:true,noFollowAndNonblock:true,byteSplitShortReads:reads,opens,closes};
 }finally{Object.assign(fs,original);syncBuiltinESMExports();}
}
const summary={actualHost:host,checks:results,unsafeObjects:['hardlink','symlink','directory','fifo'],faults,fixtureCleanupStarted:false,realRecoveryCalls:0};
fs.writeFileSync(path.join(root,'evidence','heldout-bytes-'+host.runtime+'-summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify(summary));
