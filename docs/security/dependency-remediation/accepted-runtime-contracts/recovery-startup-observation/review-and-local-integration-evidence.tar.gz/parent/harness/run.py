import hashlib, json, pathlib, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parent.parent
NODE='/Users/shersingh/.hermes/node/bin/node'
BUN='/Users/shersingh/.bun/bin/bun'
PY='/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'
def digest(p):
    b=p.read_bytes(); return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def environment(dest,label):
    base=dest/'environment'/label; base.mkdir(parents=True,exist_ok=True)
    env={'PATH':str(pathlib.Path(PY).parent)+':'+str(pathlib.Path(NODE).parent)+':'+str(pathlib.Path(BUN).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','CI':'1','REQUIRE_BUN':'1','QMD_LLAMA_GPU':'false','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','TOKENIZERS_PARALLELISM':'false','npm_config_offline':'true','REVIEW_GUARD_LABEL':label}
    folders={'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes','HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge','XDG_CONFIG_HOME':'config','XDG_CACHE_HOME':'cache','XDG_DATA_HOME':'data','XDG_STATE_HOME':'state','HF_HOME':'hf','HF_HUB_CACHE':'hf/hub','TRANSFORMERS_CACHE':'hf/transformers','TMPDIR':'tmp','TMP':'tmp','TEMP':'tmp','BUN_INSTALL_CACHE_DIR':'bun','npm_config_cache':'npm','UV_CACHE_DIR':'uv','TSX_TMPDIR':'tsx'}
    for key,folder in folders.items():
        p=base/folder;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
    return env
label=sys.argv[1]; assert label.replace('-','').isalnum()
dest=ROOT/'negative' if label.startswith('red-') else ROOT
cwd=dest/'candidate'; guard=str(dest/'harness/read-guard.cjs')
env=environment(dest,label)
if label.startswith('red-') or label.startswith('green-'):
    mode=label.split('-',1)[1];assert mode in ['rejection','utf8']
    argv=[NODE,'--experimental-test-module-mocks','--require',guard,'--import','tsx',str(dest/'harness/reproduce-findings.mjs'),mode]
elif label=='observer-selftests':
    argv=[NODE,'--require',str(ROOT/'harness/selftest-preload.cjs'),'--test','--test-concurrency=1','test/helpers/recovery-bootstrap-diagnostics.selftest.mjs']
elif label in ['actual-node','actual-bun']:
    runtime=label.split('-')[1]; env.update(QMD_RECOVERY_STARTUP_OBSERVATION='1',QMD_RECOVERY_STARTUP_DIR=str(ROOT/'outputs'))
    argv=([NODE,'--require',guard,'--import','tsx'] if runtime=='node' else [BUN,'--preload',guard])+[str(ROOT/'harness/replay.mjs'),runtime]
elif label=='selftests':
    env['QMD_RECOVERY_STARTUP_TEST_DIR']=str(ROOT/'outputs')
    argv=[NODE,'--require',str(ROOT/'harness/selftest-preload.cjs'),'--import','tsx','--test','--test-concurrency=1','test/helpers/recovery-startup-observation.selftest.mjs']
elif label in ['bytes-node','bytes-bun','lifetime','workflow','wrapper','types','guard-negative-node','guard-negative-bun']:
    runtime='bun' if label in ['bytes-bun','guard-negative-bun'] else 'node'
    harness={'bytes-node':'heldout-bytes.mjs','bytes-bun':'heldout-bytes.mjs','lifetime':'heldout-lifetime.mjs','workflow':'heldout-workflow.mjs','wrapper':'wrapper-boundary.mjs','types':'focused-strict.cjs','guard-negative-node':'guard-negative.mjs','guard-negative-bun':'guard-negative.mjs'}[label]
    argv=([NODE,'--require',str(ROOT/'harness/compiler-guard.cjs') if label=='types' else guard] if runtime=='node' else [BUN,'--preload',guard])
    if label=='lifetime':argv+=['--experimental-test-module-mocks']
    if label not in ['types']:argv+=['--import','tsx'] if runtime=='node' else []
    argv +=[str(ROOT/'harness'/harness)]
elif label=='compiler-negative':
    argv=[NODE,'--require',str(ROOT/'harness/compiler-guard.cjs'),str(ROOT/'harness/compiler-guard-negative.cjs')]
elif label=='actionlint':
    action='/Users/shersingh/.hermes/cache/scratch/qmd-actionlint-4voz5mzz/actionlint'
    assert digest(pathlib.Path(action))['sha256']=='8db11704dc296f096216db4db65d86cd7f0ebfdf4c38453a1da276b137b88388'
    argv=[action,'-shellcheck=','-pyflakes=','.github/workflows/ci.yml']
else: raise ValueError(label)
receipt=ROOT/'evidence'/f'{label}.receipt.json'; assert not receipt.exists(),receipt
before=json.loads((ROOT/('evidence/negative-source-before.json' if dest!=ROOT else 'evidence/source-before.json')).read_text())
for rel,d in before['files'].items(): assert digest(cwd/rel)==d,rel
start=time.monotonic()
try:
    r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=80)
    stdout,stderr,code=r.stdout,r.stderr,r.returncode; timeout=False
except subprocess.TimeoutExpired as exc:
    stdout,stderr,code=exc.stdout or b'',exc.stderr or b'',None;timeout=True
elapsed=time.monotonic()-start
prefix=ROOT/'evidence'/label
pathlib.Path(str(prefix)+'.stdout.txt').write_bytes(stdout);pathlib.Path(str(prefix)+'.stderr.txt').write_bytes(stderr)
after={rel:digest(cwd/rel) for rel in before['files']}
assert after==before['files'],'candidate changed'
obj={'label':label,'argv':argv,'cwd':str(cwd),'exit':code,'timeout':timeout,'durationSeconds':elapsed,'sourceManifest':digest(ROOT/('evidence/negative-source-before.json' if dest!=ROOT else 'evidence/source-before.json')),'environment':env,'stdout':digest(pathlib.Path(str(prefix)+'.stdout.txt')),'stderr':digest(pathlib.Path(str(prefix)+'.stderr.txt')),'unchangedSourceFiles':len(after),'realComparisons':2 if label.startswith('actual-') else 0}
receipt.write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps({k:obj[k] for k in ['label','exit','timeout','durationSeconds','unchangedSourceFiles','realComparisons']}))
print(stdout.decode('utf-8',errors='replace')[-16000:])
if stderr:print('STDERR:\n'+stderr.decode('utf-8',errors='replace')[-6000:])
sys.exit(0 if label.startswith('red-') and code==1 else code if code is not None else 124)
