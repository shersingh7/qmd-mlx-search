from pathlib import Path
import hashlib
import io
import json
import stat
import tarfile

ROOT = Path(__file__).resolve().parent.parent
REPO = Path('/Users/shersingh/github/qmd-mlx-search')
DEST = REPO / 'docs/security/dependency-remediation/accepted-runtime-contracts/recovery-startup-observation'
PRODUCER = Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r')
REVIEW = Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-re-review-3hobdccc')
PREVIOUS = Path('/Users/shersingh/.hermes/cache/scratch/qmd-A-live-integration-8gg39bno')
members = {}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add(name, source):
    name = str(name)
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert source.name != 'AGENTS.md' and not source.is_symlink()
    assert stat.S_ISREG(source.lstat().st_mode), source
    if name in members:
        assert digest(members[name]) == digest(source), name
    members[name] = source


def bundle(root, prefix, indexes, expected_unique):
    unique = set()
    identities = {}
    for name, expected_sha in indexes.items():
        source = root / name
        assert digest(source) == expected_sha
        data = json.loads(source.read_text())
        assert len(data['artifacts']) == data['artifactCount']
        assert sum(row['bytes'] for row in data['artifacts']) == data['artifactBytes']
        add(prefix + '/' + name, source)
        identities[name] = expected_sha
        for row in data['artifacts']:
            relative = Path(row['path'])
            assert not relative.is_absolute() and '..' not in relative.parts
            path = root / relative
            assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
            add(prefix + '/' + str(relative), path)
            unique.add(str(relative))
    assert len(unique) == expected_unique, (prefix, len(unique))
    return {'indexedUniqueArtifacts': len(unique), 'indexSha256': identities}


bindings = {
    'producer': bundle(PRODUCER, 'producer', {
        'ARTIFACT-INDEX.json': '3a428fca9827592307e7d068572cfb8c0abafae59d442ef63620d44dd68f84de',
        'FOLLOWUP-INDEX.json': '6aad4ee18cbc323c6b056db365e045ee0f97832badf93a72e756d09587cdbe79',
        'GATE-INDEX.json': '297f290b9e7bdaf17dd2dfa02acf72e8802bf6889cc982e7ff0655913f1383e4',
    }, 325),
    'review': bundle(REVIEW, 'review', {
        'ARTIFACT-INDEX.json': 'b468460f687903a1a3d7dfad1fd48adeff1637d18f6145d9402157d882d7fb49',
    }, 557),
}
add('review/ARTIFACT-INDEX.sha256', REVIEW / 'ARTIFACT-INDEX.sha256')
excluded = []
for directory in ('evidence', 'probes', 'harness'):
    for path in sorted((ROOT / directory).rglob('*')):
        if path.is_dir() and not path.is_symlink():
            continue
        relative = path.relative_to(ROOT)
        if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
            excluded.append(str(relative))
            continue
        add('parent/' + str(relative), path)
for name in ('integration.json', 'environment.json', 'source-before.json', 'source-after.json'):
    add('parent/' + name, ROOT / name)

qualification = json.loads((ROOT / 'evidence/qualification-summary.json').read_text())
assert qualification['status'] == 'B_LOCAL_INTEGRATION_ACCEPTED_REVIEWED_SOURCE_ACTUAL_CI_PENDING'
assert all(digest(REPO / name) == value for name, value in qualification['sourceSha256'].items())
package = Path(qualification['packageEvidence']['tarball'])
assert digest(package) == qualification['packageEvidence']['tarballSha256']
add('carried-package/' + package.name, package)
for name in ('qualification-summary.json', 'package-node.installed-receipt.json',
             'package-bun.installed-receipt.json', 'package-node.stdout.txt', 'package-bun.stdout.txt'):
    add('carried-package/prior-evidence/' + name, PREVIOUS / 'evidence' / name)
for name in ('main-failed.log', 'failure-summary.json', 'source-verified-readback.json',
             'missing-stage-diagnostics.json', 'missing-stage-reduction.json',
             'ast-and-unhandled-reduction.json'):
    add('prior-ci-fd9b902/' + name, PREVIOUS / 'evidence/ci-fd9b902' / name)

rows = [{'path': name, 'bytes': source.stat().st_size, 'sha256': digest(source)}
        for name, source in sorted(members.items())]
manifest = {'schemaVersion': 1, 'scope': 'B reviewed source and parent local integration; prior CI stays negative',
            'artifactCount': len(rows), 'artifactBytes': sum(row['bytes'] for row in rows),
            'manifestSelfExcluded': True, 'indexedInputs': bindings,
            'excludedNonRegularParentFixturePaths': excluded, 'artifacts': rows}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
archive_path = DEST / 'review-and-local-integration-evidence.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, source in sorted(members.items()):
        archive.add(source, arcname=name, recursive=False)
    info = tarfile.TarInfo('MANIFEST.json')
    info.size = len(manifest_bytes)
    info.mode = 0o644
    archive.addfile(info, io.BytesIO(manifest_bytes))
with tarfile.open(archive_path, 'r:gz') as archive:
    found = archive.getmembers()
    assert len(found) == len(rows) + 1 and len({member.name for member in found}) == len(found)
    assert archive.extractfile('MANIFEST.json').read() == manifest_bytes
    for row in rows:
        data = archive.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

record = {'status': qualification['status'], 'baseHead': json.loads((ROOT / 'integration.json').read_text())['baseHead'],
    'sourcePostimages': json.loads((REVIEW / 'verdict.json').read_text())['postimages'],
    'spec': 'PASS', 'fullThreePathQuality': 'PASS', 'reviewArtifactsVerified': 557,
    'archive': archive_path.name, 'archiveSha256': digest(archive_path),
    'manifestSha256': hashlib.sha256(manifest_bytes).hexdigest(), 'verifiedArchiveArtifacts': len(rows),
    'fullNode': qualification['fullNode'], 'build': qualification['canonicalBuild'],
    'wholeRootNode': qualification['whole-root-node'], 'wholeRootBun': qualification['whole-root-bun'],
    'startupSelftests': qualification['startup-selftests'], 'originalObserverSelftests': qualification['observer-selftests'],
    'heldoutLifecycleModes': qualification['heldoutLifecycleModes'], 'heldoutBytes': qualification['heldoutBytes'],
    'packageEvidencePolicy': qualification['packageEvidence']['scope'],
    'packageSha256': qualification['packageEvidence']['tarballSha256'],
    'verifiedRegularPackageEntries': qualification['packageEvidence']['verifiedRegularEntries'],
    'actualCIPassClaimed': False, 'limits': qualification['limits'],
    'evidenceLocations': {'review': 'review/verdict.json', 'parent': 'parent/evidence/qualification-summary.json',
                          'previousCI': 'prior-ci-fd9b902/source-verified-readback.json'}}
(DEST / 'acceptance-summary.json').write_text(json.dumps(record, indent=2) + '\n')
(ROOT / 'evidence/archive-readback.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('status', 'archive', 'archiveSha256',
      'manifestSha256', 'verifiedArchiveArtifacts', 'actualCIPassClaimed')}, indent=2))
