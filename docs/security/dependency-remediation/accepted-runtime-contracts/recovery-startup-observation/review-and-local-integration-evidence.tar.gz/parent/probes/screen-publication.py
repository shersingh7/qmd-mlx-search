from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
import zipfile

repo = Path('/Users/shersingh/github/qmd-mlx-search')
out = Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-live-integration-n6yq39on/evidence/prepublish-secret-screen.json')
patterns = {
    'github_token': rb'gh[pousr]_[A-Za-z0-9]{30,}',
    'github_fine_grained_token': rb'github_pat_[A-Za-z0-9_]{70,}',
    'huggingface_token': rb'hf_[A-Za-z0-9]{25,}',
    'openai_key_shape': rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}',
    'google_key_shape': rb'AIza[A-Za-z0-9_-]{35}',
    'aws_access_id_shape': rb'(?:AKIA|ASIA)[A-Z0-9]{16}',
    'private_key_header': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
}
compiled = {name: re.compile(pattern) for name, pattern in patterns.items()}
max_member = 64 * 1024 * 1024
max_archive = 256 * 1024 * 1024
max_total = 1024 * 1024 * 1024
leaves = 0
total = 0
hits = []
public_examples = []
unscanned = []


def scan(data, label, depth=0):
    global leaves, total
    if len(data) > max_archive or total + len(data) > max_total or depth > 4:
        unscanned.append(label)
        return
    if data.startswith(b'\x1f\x8b'):
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
                expanded = stream.read(max_archive + 1)
            scan(expanded, label + '!gzip', depth + 1)
            return
        except (OSError, EOFError):
            pass  # Invalid archive fixtures are still scanned as ordinary bytes.
    if data.startswith(b'PK\x03\x04'):
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                for member in archive.infolist():
                    if member.is_dir():
                        continue
                    if member.file_size > max_member:
                        unscanned.append(label + '!' + member.filename)
                        continue
                    scan(archive.read(member), label + '!' + member.filename, depth + 1)
            return
        except (zipfile.BadZipFile, RuntimeError):
            pass
    if len(data) > 265 and data[257:262] == b'ustar':
        try:
            with tarfile.open(fileobj=io.BytesIO(data), mode='r:') as archive:
                for member in archive:
                    if not member.isfile():
                        continue
                    if member.size > max_member:
                        unscanned.append(label + '!' + member.name)
                        continue
                    scan(archive.extractfile(member).read(), label + '!' + member.name, depth + 1)
            return
        except tarfile.TarError:
            pass
    if len(data) > max_member:
        unscanned.append(label)
        return
    leaves += 1
    total += len(data)
    for name, pattern in compiled.items():
        for match in pattern.finditer(data):
            digest = hashlib.sha256(match.group()).hexdigest()
            finding = dict(path=label, pattern=name, byteOffset=match.start(), valueSha256=digest)
            # Independently matched to the standard AWS example in the genuine
            # bun-types declaration's @example block; never exempt other values.
            if (name == 'aws_access_id_shape'
                    and digest == '1a5d44a2dca19669d72edf4c4f1c27c4c1ca4b4408fbb17f6ce4ad452d78ddb3'
                    and label.endswith(('bun-types/globals.d.ts', 'package/globals.d.ts'))):
                public_examples.append(finding)
            else:
                hits.append(finding)


names = set()
for args in (['diff', '--name-only', '--diff-filter=ACM', '-z'],
             ['ls-files', '--others', '--exclude-standard', '-z']):
    result = subprocess.run(['/usr/bin/git', *args], cwd=repo, capture_output=True, check=True)
    names.update(p.decode() for p in result.stdout.split(b'\0') if p)
for name in sorted(names):
    path = repo / name
    if path.is_file() and not path.is_symlink():
        scan(path.read_bytes(), name)
report = dict(scope='changed/untracked repository bytes and bounded nested archive leaves; pattern screen, not a comprehensive secret audit',
              repositoryFiles=len(names), leafBlobsScanned=leaves, decodedLeafBytes=total,
              findings=hits, verifiedPublicDocumentationExamples=public_examples,
              unscanned=unscanned, actualSecretValuesPrinted=False)
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(1 if hits or unscanned else 0)
