from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = Path('/Users/shersingh/github/qmd-mlx-search')
E = ROOT / 'evidence'
ENV = json.loads((ROOT / 'environment.json').read_text())
SOURCES = json.loads((ROOT / 'source-after.json').read_text())
NODE = '/Users/shersingh/.hermes/node/bin/node'
BUN = '/Users/shersingh/.bun/bin/bun'
PY = '/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'
GUARD = str(ROOT / 'probes/compiler-read-guard.cjs')
RUNTIME_GUARD = str(ROOT / 'probes/runtime-read-guard.cjs')
summary = {'runs': {}, 'actualCIPassClaimed': False}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preserved():
    assert all(digest(REPO / name) == value for name, value in SOURCES.items())
    copied = json.loads((E / 'source-before.json').read_text())['files']
    assert all(digest(ROOT / 'candidate' / name) == row['sha256'] for name, row in copied.items())


def run(label, argv, extra=None, timeout=90):
    target = E / (label + '.receipt.json')
    if target.exists():
        receipt = json.loads(target.read_text())
        assert receipt['exit'] == 0 and not receipt['timedOut']
        assert receipt['argv'] == argv and receipt['sourceManifestSha256'] == digest(ROOT / 'source-after.json')
        preserved()
        summary['runs'][label] = {**receipt, 'retainedExecutionReusedNotRerun': True}
        return (E / (label + '.stdout.txt')).read_text()
    env = {**ENV, 'QMD_COMPOSE_ROOT': str(ROOT), 'QMD_RUN_LABEL': label, **(extra or {})}
    started = time.monotonic()
    try:
        result = subprocess.run(argv, cwd=REPO, env=env, capture_output=True, timeout=timeout)
        stdout, stderr, code, timed_out = result.stdout, result.stderr, result.returncode, False
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code, timed_out = error.stdout or b'', error.stderr or b'', None, True
    (E / (label + '.stdout.txt')).write_bytes(stdout)
    (E / (label + '.stderr.txt')).write_bytes(stderr)
    receipt = {'argv': argv, 'cwd': str(REPO), 'exit': code, 'timedOut': timed_out,
               'seconds': time.monotonic() - started,
               'sourceManifestSha256': digest(ROOT / 'source-after.json'),
               'stdoutSha256': digest(E / (label + '.stdout.txt')),
               'stderrSha256': digest(E / (label + '.stderr.txt'))}
    target.write_text(json.dumps(receipt, indent=2) + '\n')
    summary['runs'][label] = receipt
    (E / 'qualification-progress.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert code == 0 and not timed_out, (label, stdout[-4000:], stderr[-4000:])
    preserved()
    return stdout.decode('utf-8')


def records(pattern):
    return [json.loads(line) for file in E.glob(pattern) for line in file.read_text().splitlines()]


preserved()
raw_log = Path('/Users/shersingh/.hermes/cache/terminal-output/out-1794669685-25697-b360.log')
shutil.copy2(raw_log, E / 'full-node-tests.raw.log')
text = re.sub(r'\x1b\[[0-9;]*m', '', raw_log.read_text())
passed = re.findall(r'^\s*✓\s+(test/\S+\.test\.ts)\s+>', text, re.M)
skipped = re.findall(r'^\s*↓\s+(test/\S+\.test\.ts)\s+>', text, re.M)
assert len(passed) == 1524 and len(skipped) == 66 and len(set(passed + skipped)) == 54
assert re.search(r'Test Files\s+54 passed \(54\)', text)
assert re.search(r'Tests\s+1524 passed \| 66 skipped \(1590\)', text)
summary['fullNode'] = {'command': 'pnpm run test', 'passed': len(passed), 'skipped': len(skipped),
                       'files': len(set(passed + skipped)), 'rawLogSha256': digest(E / 'full-node-tests.raw.log'),
                       'terminalExit': 0, 'terminalVerification': {'status': 'passed', 'kind': 'test', 'scope': 'full'},
                       'reduction': 'parent-canonical-stdout-reduction-v1'}
(E / 'full-node-test-summary.json').write_text(json.dumps(summary['fullNode'], indent=2) + '\n')
rows = records('canonical-build-compiler-reads-*.jsonl')
hosts = [row for row in rows if row.get('kind') == 'compiler-host']
assert len(hosts) == 2 and all(row.get('allowed', True) for row in rows)
assert all(host['versions']['node'] == '22.22.3' for host in hosts)
summary['canonicalBuild'] = {'command': 'pnpm run build', 'terminalExit': 0,
    'terminalVerification': {'status': 'passed', 'kind': 'build', 'scope': 'full'},
    'guardRows': len(rows), 'guardRefusals': 0, 'actualHosts': hosts}

for runtime, prefix in [('node', [NODE]), ('bun', [BUN, '--bun', '--preload=' + GUARD])]:
    label = 'whole-root-' + runtime
    extra = {'QMD_RUN_LABEL': label}
    if runtime == 'node':
        extra['NODE_OPTIONS'] = '--require=' + GUARD
    files = json.loads(run(label + '-config', prefix + ['node_modules/typescript/bin/tsc', '--showConfig'], extra))['files']
    assert './test/helpers/recovery-startup-observation.ts' in files and len(files) == len(set(files))
    run(label, prefix + ['node_modules/typescript/bin/tsc', '--noEmit', '--pretty', 'false'], extra)
    rows = records(label + '-compiler-reads-*.jsonl')
    hosts = [row for row in rows if row.get('kind') == 'compiler-host']
    assert len(hosts) == 2 and all(row.get('allowed', True) for row in rows)
    assert all(bool(host['versions'].get('bun')) == (runtime == 'bun') for host in hosts)
    summary[label] = {'compilerRoots': len(files), 'diagnostics': 0, 'guardRefusals': 0, 'actualHosts': hosts}

outside = '/Users/shersingh/.hermes/cache/scratch/qmd-parent-B-negative-u5zwaqui/harness/reproduce-findings.mjs'
run('runtime-guard-control', [NODE, '--require', RUNTIME_GUARD, '-e',
    "const f=require('node:fs'),a=require('node:assert/strict');a.equal(typeof f.readFileSync(process.env.QMD_COMPOSE_ROOT+'/environment.json','utf8'),'string');a.throws(()=>f.readFileSync(" + json.dumps(outside) + "),e=>e.code==='COMPOSE_RUNTIME_READ_DENIED');console.log('owned read allowed; unrelated fixture refused before bytes')"])
outputs = E / 'actual-startup'
for runtime, prefix in [('node', [NODE, '--require', RUNTIME_GUARD, '--import', 'tsx']),
                        ('bun', [BUN, '--preload', RUNTIME_GUARD])]:
    label = 'actual-' + runtime
    run(label, prefix + ['test/helpers/recovery-startup-observation.ts', '--runtime', runtime],
        {'QMD_RECOVERY_STARTUP_OBSERVATION': '1', 'QMD_RECOVERY_STARTUP_DIR': str(outputs)}, 30)
    rows = records(label + '-runtime-reads-*.jsonl')
    installed = [row for row in rows if row.get('kind') == 'runtime-guard-installed']
    assert installed and all(row.get('allowed', True) for row in rows)
    assert all(bool(row['versions'].get('bun')) == (runtime == 'bun') for row in installed)

for label, test_file, expected_pass, extra in [
    ('startup-selftests', 'test/helpers/recovery-startup-observation.selftest.mjs', 14,
     {'QMD_RECOVERY_STARTUP_TEST_DIR': str(outputs)}),
    ('observer-selftests', 'test/helpers/recovery-bootstrap-diagnostics.selftest.mjs', 8, {})]:
    out = run(label, [NODE, '--require', RUNTIME_GUARD, '--import', 'tsx', '--test',
                      '--test-concurrency=1', test_file], extra)
    counts = {key: int(value) for key, value in re.findall(r'^# (tests|pass|fail|skipped) (\d+)\s*$', out, re.M)}
    assert counts == {'tests': expected_pass, 'pass': expected_pass, 'fail': 0, 'skipped': 0}, counts
    summary[label] = counts

reports = [json.loads(file.read_text()) for file in outputs.glob('*/observation.json')]
assert len(reports) == 2 and {report['actualHost']['runtime'] for report in reports} == {'node', 'bun'}
summary['actualControls'] = []
for report in reports:
    assert not report['productQualified'] and not report['collectionErrors']
    assert [case['timeoutMs'] for case in report['cases']] == [200, 5000]
    for case in report['cases']:
        assert case['invocation']['restored'] and not case['productQualified']
        assert case['invocation']['originalArgv'][:4] == ['/usr/bin/python3', '-S', '-u', str(REPO / 'scripts/phase5_recovery_process.py')]
    summary['actualControls'].append({'actualHost': report['actualHost'], 'cases': [
        {'budget': case['timeoutMs'], 'classification': case['classification'], 'pythonSidecar': case['python']['status'],
         'beforeCleanup': case['snapshot'], 'sourceSha256': case['sourceSha256']} for case in report['cases']]})

for label in ['lifetime', 'bytes-node', 'bytes-bun']:
    run('heldout-' + label, [PY, '-I', '-B', str(ROOT / 'harness/run.py'), label])
    rows = records(label + '-guard-*.jsonl')
    assert rows and any(row.get('kind') == 'guard-installed' for row in rows)
    assert all(row.get('allowed', True) for row in rows)
lifetime = json.loads((E / 'heldout-lifetime-summary.json').read_text())
assert len(lifetime['checks']) == 6 and lifetime['realRecoveryCalls'] == 0
summary['heldoutLifecycleModes'] = len(lifetime['checks'])
summary['heldoutBytes'] = {}
for runtime in ('node', 'bun'):
    report = json.loads((E / ('heldout-bytes-' + runtime + '-summary.json')).read_text())
    assert report['actualHost']['runtime'] == runtime and len(report['checks']) == 33
    assert len({case['name'] for case in report['checks']}) == len(report['checks'])
    assert report['realRecoveryCalls'] == 0 and report['faults']['qualified'] == (runtime == 'node')
    summary['heldoutBytes'][runtime] = {'cases': len(report['checks']), 'unsafeObjects': report['unsafeObjects'],
                                      'faults': report['faults'], 'actualHost': report['actualHost']}

actionlint = Path('/Users/shersingh/.hermes/cache/scratch/qmd-actionlint-4voz5mzz/actionlint')
assert digest(actionlint) == '8db11704dc296f096216db4db65d86cd7f0ebfdf4c38453a1da276b137b88388'
run('actionlint', [str(actionlint), '-shellcheck=', '-pyflakes=', '.github/workflows/ci.yml'])
summary['workflow'] = {'actionlintExit': 0, 'shellcheckAndPyflakes': 'explicitly disabled; not qualified'}

previous = json.loads(Path('/Users/shersingh/.hermes/cache/scratch/qmd-A-live-integration-8gg39bno/evidence/qualification-summary.json').read_text())
packages = {item['tarballSha256']: item for item in previous['packageSmokes']}
assert len(packages) == 1 and {item['runtime'] for item in previous['packageSmokes']} == {'node', 'bun'}
package_sha, package_info = next(iter(packages.items()))
package = Path(package_info['tarball'])
assert digest(package) == package_sha
entries = []
with tarfile.open(package, 'r:gz') as archive:
    for member in archive.getmembers():
        assert member.name.startswith('package/') and '..' not in Path(member.name).parts
        if member.isfile():
            relative = member.name.removeprefix('package/')
            data = archive.extractfile(member).read()
            assert data == (REPO / relative).read_bytes(), relative
            entries.append({'path': relative, 'sha256': hashlib.sha256(data).hexdigest()})
        else:
            assert member.isdir(), member.name
assert entries and not any(entry['path'] in json.loads((ROOT / 'integration.json').read_text())['postimages'] for entry in entries)
summary['packageEvidence'] = {'scope': 'Previous actual Node/native-Bun installed smokes carried forward, not rerun; all package files byte-identical to current build',
    'tarball': str(package), 'tarballSha256': package_sha, 'verifiedRegularEntries': len(entries),
    'priorReceipt': '/Users/shersingh/.hermes/cache/scratch/qmd-A-live-integration-8gg39bno/evidence/qualification-summary.json',
    'priorSmokes': previous['packageSmokes']}
(E / 'package-entry-bindings.json').write_text(json.dumps(entries, indent=2) + '\n')
preserved()
summary['status'] = 'B_LOCAL_INTEGRATION_ACCEPTED_REVIEWED_SOURCE_ACTUAL_CI_PENDING'
summary['sourceSha256'] = SOURCES
summary['limits'] = ['Supplemental local instrumentation is not original canonical or CI/cold causality proof',
    'Injected commands remain uncontained and productQualified=false',
    'Native Bun named-FS fault injection is unsupported and not qualified',
    'C1 sole-owner limitation and full-native-Bun Vitest allocator SIGTRAP remain',
    'Remote macOS test failures, merge and default-branch alert closure remain pending']
(E / 'qualification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ('runs', 'sourceSha256')}, indent=2))
