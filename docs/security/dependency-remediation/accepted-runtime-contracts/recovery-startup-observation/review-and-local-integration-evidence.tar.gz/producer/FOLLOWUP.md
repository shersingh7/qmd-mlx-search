# Verification follow-up — canonical local build actually executed

After the sealed delivery, the ordinary canonical command **`pnpm run build`** was invoked in `candidate/` with the explicit credential-free HOME/cache allowlist and an environment-only preload. It actually ran the unchanged package build script and original `tsconfig.build.json` compiler roots/options, returning **exit 0**.

- Actual build and compiler host: `/Users/shersingh/.hermes/node/bin/node`, **22.22.3**.
- Active build/compiler guards: **626 rows, zero refusals**, with both actual-host receipts retained.
- All **313 previously sealed artifacts**, including both helper postimages, patches and generated build outputs, were reauthenticated and remain byte-identical.
- No source repair changed, no additional recovery comparison ran, and no live file was edited.

Evidence: `evidence/canonical-followup.receipt.json`, `canonical-followup-hosts.jsonl`, and `canonical-followup-guard-*.jsonl`. The follow-up preload is separately bound; it preserves the earlier sealed host log rather than overwriting it. `FOLLOWUP-INDEX.json` binds these additions and links to the unchanged base index.

The earlier explicit-manager-path lifecycle-scanner refusal remains genuine historical pre-execution evidence in `evidence/canonical-build-preflight-refusal.json`; it was not deleted, relabelled or bypassed. The ordinary package-script invocation was accepted and executed without changing the guard, package scripts, argv, compiler settings or system temp policy. The terminal returned an actual exit code but no separate tracker-verification object; no such metadata is invented.

This follow-up supersedes only the earlier report's statement that this lane lacked a fresh executed canonical pnpm build. Fresh independent **SPEC → QUALITY**, parent combined tests/package acceptance and actual CI remain pending. No remote-CI repair or independent approval is claimed.
