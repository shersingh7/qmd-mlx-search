// Preserved parser/filesystem/workflow controls; zero real recovery calls.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import * as h from '../candidate/test/helpers/recovery-startup-observation.ts';
const root=fileURLToPath(new URL('../',import.meta.url)),candidate=path.join(root,'candidate');
const work=path.join(root,'evidence/preserved-controls-'+h.actualHost().runtime);fs.mkdirSync(work,{mode:0o700});
const sha=b=>createHash('sha256').update(b).digest('hex');
const row=(event,seq,tMs=seq,extra={})=>({event,seq,pid:123,tMs,...extra});
const entry=row('python-entry',0,0,{version:'3.9.6 authored',executable:'/authored/python'});
const lines=rows=>rows.map(x=>JSON.stringify(x)+'\n').join('');
const complete=lines([entry,row('wrapper-return',1)]);
const corpus=[
 ['foreign-pid',lines([entry,row('module-loaded',1,1,{pid:456})])],
 ['noninteger-pid',lines([{...entry,pid:1.25}])],
 ['backwards-clock',lines([entry,row('module-loaded',1,1),row('wrapper-return',2,0.5)])],
 ['nonfinite-number',lines([entry])+'{"event":"wrapper-return","seq":1,"pid":123,"tMs":1e999}\n'],
 ['missing-required-key',lines([{...entry,version:undefined}])],
 ['extra-executable-key',lines([entry,row('module-loaded',1,1,{executable:'/extra'})])],
 ['after-terminal',complete+lines([row('cleanup-sent',2)])],
 ['nonscalar-record',lines([entry])+'[]\n'],
 ['above-budget-max',lines([entry,row('admission-read',1,1,{budgetMs:5001})])],
 ['fractional-budget',lines([entry,row('admission-read',1,1,{budgetMs:1.5})])],
 ['not-dense-sequence',lines([entry,row('module-loaded',2)])],
 ['record-limit',lines([entry,...Array.from({length:32},(_,i)=>row('module-loaded',i+1))])],
 ['line-limit',JSON.stringify({...entry,version:'x'.repeat(2049)})+'\n'],
 ['bom-not-stripped','\ufeff'+complete]
];
const results=[];
for(const [name,text]of corpus){
 const parsed=h.parsePythonSidecar(text);assert.equal(parsed.status,'malformed',name);
 const file=path.join(work,name+'.jsonl');fs.writeFileSync(file,text,{flag:'wx',mode:0o600});
 assert.deepEqual(h.readPythonSidecar(file),parsed,name+' reader must retain original strict rules');
 results.push({name,status:parsed.status,prefix:parsed.records.length});
}
const local=h.parsePythonSidecar(lines([{...entry,tMs:1e8},row('wrapper-return',1,1e8+1)]));assert.equal(local.status,'complete');
const target=path.join(work,'complete.jsonl');fs.writeFileSync(target,complete,{flag:'wx',mode:0o600});
assert.equal(h.readPythonSidecar(target).status,'complete');
const hard=path.join(work,'hard');fs.linkSync(target,hard);assert.equal(h.readPythonSidecar(target).status,'unsafe');fs.unlinkSync(hard);
const symlink=path.join(work,'symlink');fs.symlinkSync(target,symlink);assert.equal(h.readPythonSidecar(symlink).status,'unsafe');
assert.equal(h.readPythonSidecar(work).status,'unsafe');
const fifo=path.join(work,'fifo');const made=spawnSync('/usr/bin/mkfifo',[fifo],{env:process.env,timeout:2000});assert.equal(made.status,0);
assert.equal(h.readPythonSidecar(fifo).status,'unsafe');
// Byte-identical workflow is not a new independent workflow approval.
const workflow=fs.readFileSync(path.join(candidate,'.github/workflows/ci.yml'));
assert.deepEqual(workflow,fs.readFileSync(path.join(root,'baseline/.github/workflows/ci.yml')));
const text=workflow.toString('utf8'),require=createRequire(path.join(candidate,'package.json'));
const steps=require('yaml').parse(text).jobs.javascript.steps;
const names=['After-canonical caller startup observation (actual Node)','After-canonical caller startup observation (native Bun)','After-canonical startup observation selftests'];
const oldSelftest=steps.findIndex(x=>x.name==='After-canonical Node diagnostic controls');
const controls=[];
for(const [j,name]of names.entries()){
 const i=steps.findIndex(x=>x.name===name),s=steps[i];assert.equal(i,oldSelftest+j+1);
 assert.equal(s.if,"always() && runner.os == 'macOS'");assert.equal(s['continue-on-error'],true);assert.equal(s['timeout-minutes'],2);
 const r=spawnSync('/bin/bash',['-n'],{input:s.run,env:process.env,encoding:'utf8',timeout:2000});assert.equal(r.status,0,r.stderr);
 controls.push({name,bashSyntaxExit:r.status});
}
const prefixSha=sha(text.slice(0,text.indexOf('      # Explicit AFTER the canonical suite/smoke:')));
assert.equal(prefixSha,'d723590bbdca7e4e20a61eb6782d77f25defd3a633403c2c9d654ecfcfa00aa1');
let original=text.slice(0,text.indexOf('      # Supplemental and non-gating:'))+text.slice(text.indexOf('      - name: Preserve first-invocation bootstrap observations even on failure'));
for(const line of ['            ${{ runner.temp }}/qmd-recovery-startup/**/*.json\n','            ${{ runner.temp }}/qmd-recovery-startup/**/*.jsonl\n','            ${{ runner.temp }}/qmd-recovery-startup/*.tap\n']){assert.equal(original.split(line).length,2);original=original.replace(line,'');}
assert.deepEqual(Buffer.from(original),fs.readFileSync(path.join(root,'preimages/.github/workflows/ci.yml')));
const output={actualHost:h.actualHost(),parserResults:results,unsafeObjects:['hardlink','symlink','directory','fifo'],independentClockPositive:true,
 workflow:{sha256:sha(workflow),canonicalPrefixSha256:prefixSha,originalReconstructedSha256:sha(original),controls,independentlyAccepted:false,actionlintRerun:'not-needed-unchanged-reviewed-bytes'},fixtureCleanupStarted:false,realRecoveryCalls:0};
fs.writeFileSync(path.join(root,'evidence/preserved-controls-'+h.actualHost().runtime+'.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify(output));
