// Held-out exact-helper orchestrator negatives. Public caller MODULE is mocked;
// runtime spawn is a hard no-OS fake. These make ZERO real recovery calls.
import assert from 'node:assert/strict';
import {mock} from 'node:test';
import childProcess,{spawn as namedSpawn} from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {EventEmitter,errorMonitor} from 'node:events';
import {PassThrough} from 'node:stream';
import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)), mode=process.argv[2];
assert.ok(['unreaped','postspawn-reject'].includes(mode));
const source=path.join(root,'candidate/scripts/phase5_recovery_process.py'),parent=path.join(root,'evidence',`orchestrator-${mode}`);mkdirSync(parent,{mode:0o700});
const oldEnv=process.env, originalSpawn=childProcess.spawn;
let calls=0,fakeChild;
const onlyFake=function(exe,args,options){
 assert.equal(mode,'postspawn-reject');assert.equal(exe,'/usr/bin/python3');
 assert.deepEqual(args.slice(0,2),['-S','-u']);assert.equal(args[2].endsWith('/self-observing-supervisor.py'),true);
 const c=new EventEmitter();c.pid=123;c.exitCode=null;c.signalCode=null;c.stdout=new PassThrough();c.stderr=new PassThrough();c.stdio=[null,c.stdout,c.stderr,new PassThrough()];fakeChild=c;return c;
};
childProcess.spawn=onlyFake;syncBuiltinESMExports();
const fakeResult={launch:{state:'unconfirmed',admissionGranted:false,supervisorReaped:false},timedOut:true,exitCode:null,signal:null,stdout:'',stderr:'',error:'authored incomplete owner receipt',cleanup:{childReaped:false,groupTerminated:false,sessionTerminated:false,pipesClosed:false,forcedPipeClose:true,containmentVerified:false,sigkillUsed:false,processGroups:[]}};
const mocked=mock.module(new URL('../candidate/scripts/phase5_e2e_runner.ts',import.meta.url).href,{namedExports:{executeRecoveryWorker(options){
 calls++;assert.equal(calls,1,'no second call may occur after unreaped/rejection');assert.equal(options.timeoutMs,200);
 if(mode==='unreaped')return Promise.resolve(structuredClone(fakeResult));
 namedSpawn('/usr/bin/python3',['-S','-u',source,JSON.stringify({command:options.command,timeoutMs:options.timeoutMs,contained:false})],{detached:true,stdio:['pipe','pipe','pipe','pipe']});
 return Promise.reject(new Error('authored caller rejection after observed fake spawn'));
}}});
const {runStartupObservation}=await import('../candidate/test/helpers/recovery-startup-observation.ts');
process.env.QMD_RECOVERY_STARTUP_OBSERVATION='1';
try{
 const observed=await runStartupObservation(parent,'node');
 assert.equal(calls,1);assert.equal(process.env,oldEnv);assert.equal(childProcess.spawn,onlyFake);assert.equal(namedSpawn,onlyFake);
 if(mode==='unreaped'){
  assert.equal(observed.report.cases.length,1);assert.match(observed.report.collectionErrors[0],/prior-supervisor-unreaped/);assert.equal(existsSync(path.join(observed.directory,'case-5000')),false);
 }else{
  assert.equal(observed.report.cases.length,0);assert.match(observed.report.collectionErrors[0],/observation-incomplete/);
 }
 const targets=fakeChild?[['child',fakeChild],['stdout',fakeChild.stdout],['stderr',fakeChild.stderr],['proof',fakeChild.stdio[3]]]:[];
 const retained=targets.map(([name,target])=>({target:name,listeners:target.eventNames().map(event=>({event:String(event),count:target.listenerCount(event)}))}));
 const observerCount=targets.reduce((sum,[_name,target])=>sum+target.eventNames().reduce((n,event)=>n+target.listenerCount(event),0),0);
 const result={scope:'exact-helper-with-mocked-public-caller-zero-real-recovery-calls',mode,calls,spawnRestored:true,namedExportRestored:true,environmentRestored:true,
  helperPath:path.join(root,'candidate/test/helpers/recovery-startup-observation.ts'),observedDirectory:observed.directory,report:observed.report,retained,observerCount};
 writeFileSync(path.join(root,'evidence',`orchestrator-${mode}-summary.json`),JSON.stringify(result,null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify(result));
}finally{
 mocked.restore();childProcess.spawn=originalSpawn;syncBuiltinESMExports();
 // Review-owned fakes only, after the retained-listener receipt. No process/FD cleanup.
 for(const x of fakeChild?[fakeChild,fakeChild.stdout,fakeChild.stderr,fakeChild.stdio[3]]:[])x.removeAllListeners();
}
