from pathlib import Path
import json, subprocess, sys, time, hashlib
ROOT=Path(__file__).resolve().parents[1]
NODE='/Users/shersingh/.hermes/node/bin/node'
BUN='/Users/shersingh/.bun/bin/bun'
PY='/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'
CWD=ROOT/'candidate'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,argv,additions=None,timeout=90):
    env=json.loads((ROOT/'evidence/clean-environment.json').read_text());env.update(additions or {})
    env['REVIEW_GUARD_LABEL']=label
    sources={k:digest(CWD/k) for k in json.loads((ROOT/'evidence/input-manifest.json').read_text())['files']}
    started=time.monotonic()
    try:
        p=subprocess.run(argv,cwd=CWD,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
        code=p.returncode;stdout=p.stdout;stderr=p.stderr;timedout=False
    except subprocess.TimeoutExpired as e:
        code=None;stdout=e.stdout or b'';stderr=e.stderr or b'';timedout=True
    for name,b in [('stdout',stdout),('stderr',stderr)]:
        with (ROOT/'evidence'/f'{label}.{name}.txt').open('xb') as f:f.write(b)
    guards=[]
    for file in sorted((ROOT/'evidence').glob(label+'-guard-*.jsonl')):
        rows=[json.loads(s) for s in file.read_text().splitlines()]
        guards.append({'path':str(file),'sha256':digest(file),'rows':len(rows),'refusals':sum(r.get('allowed') is False for r in rows),'install':[r for r in rows if r.get('kind')=='guard-installed']})
    receipt={'label':label,'argv':argv,'cwd':str(CWD),'exit':code,'timeout':timedout,'elapsedSeconds':time.monotonic()-started,
      'stdout':str(ROOT/'evidence'/f'{label}.stdout.txt'),'stderr':str(ROOT/'evidence'/f'{label}.stderr.txt'),'sourceSha256':sources,
      'inputManifestSha256':digest(ROOT/'evidence/input-manifest.json'),'environmentAllowlistSha256':digest(ROOT/'evidence/clean-environment.json'),
      'explicitEnvironment':additions or {},'guards':guards}
    with (ROOT/'evidence'/f'{label}.receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='sourceSha256'}));print(stdout.decode(errors='replace')[:19000]);print(stderr.decode(errors='replace')[:8000],file=sys.stderr)
    return code
if __name__=='__main__':
    task=sys.argv[1];guard=str(ROOT/'harness/read-guard.cjs')
    node=[NODE,'--require',guard,'--import','tsx']
    if task.startswith(('original-red-','original-green-')):
        mode=task.rsplit('-',1)[1]
        cmd=[NODE,'--experimental-test-module-mocks','--require',guard,'--import','tsx',str(ROOT/'harness/reproduce-findings.mjs'),mode]
        rc=run(task,cmd)
    elif task in ['permanent-red','permanent-green','selftest-green']:
        select=['--test-name-pattern','raw UTF-8|exceptional caller'] if task.startswith('permanent') else []
        additions={'QMD_RECOVERY_STARTUP_TEST_DIR':str(ROOT/'outputs')} if task=='selftest-green' else {}
        rc=run(task,[NODE,'--require',str(ROOT/'harness/selftest-preload.cjs'),'--import','tsx','--test','--test-concurrency=1',*select,'test/helpers/recovery-startup-observation.selftest.mjs'],additions)
    elif task=='observer-selftest':
        rc=run(task,[NODE,'--require',guard,'--test','--test-concurrency=1','test/helpers/recovery-bootstrap-diagnostics.selftest.mjs'])
    elif task=='types-green':
        rc=run(task,[NODE,'--require',guard,str(ROOT/'harness/focused-strict.cjs')])
    elif task in ['actual-node','actual-bun']:
        runtime=task.split('-')[1]
        command=[*node,str(ROOT/'harness/replay.mjs'),'node'] if runtime=='node' else [BUN,'--preload',guard,str(ROOT/'harness/replay.mjs'),'bun']
        rc=run(task,[PY,'scripts/run-offline.py','env','QMD_RECOVERY_STARTUP_OBSERVATION=1',f'QMD_RECOVERY_STARTUP_DIR={ROOT}/outputs',f'REVIEW_GUARD_LABEL={task}',*command])
    elif task in ['preserved-node','preserved-bun']:
        cmd=[*node,str(ROOT/'harness/preserved-controls.mjs')] if task.endswith('node') else [BUN,'--preload',guard,str(ROOT/'harness/preserved-controls.mjs')]
        rc=run(task,cmd)
    elif task=='unreaped-green':
        rc=run(task,[NODE,'--experimental-test-module-mocks','--require',guard,'--import','tsx',str(ROOT/'harness/orchestrator-negative.mjs'),'unreaped'])
    elif task=='import-listeners':
        rc=run(task,[*node,str(ROOT/'harness/import-listeners.mjs')])
    elif task=='build-script':
        rc=run(task,[NODE,'--require',str(ROOT/'harness/build-preload.cjs'),'scripts/build.mjs'],{'NODE_OPTIONS':'--require '+str(ROOT/'harness/build-preload.cjs')})
    elif task=='syntax-green':
        rc=run(task,[NODE,'--require',guard,'--check','test/helpers/recovery-startup-observation.selftest.mjs'])
    elif task=='versions':
        rc=run(task,[NODE,'--require',guard,'-e','console.log(JSON.stringify({execPath:process.execPath,versions:process.versions,platform:process.platform,arch:process.arch,kernel:require("node:os").release()}))'])
    else:raise SystemExit('unknown task')
    sys.exit(0 if rc==0 else 1)
