// Contract-correct RED reproducers against the exact candidate helper.
// Run with --experimental-test-module-mocks --import tsx; no real recovery calls.
import assert from 'node:assert/strict';
import {mock} from 'node:test';
import childProcess,{spawn as namedSpawn} from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {EventEmitter} from 'node:events';
import {PassThrough} from 'node:stream';
import {mkdtempSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url)),dir=mkdtempSync(path.join(root,'evidence/finding-red-'));
const mode=process.argv[2],source=path.join(root,'candidate/scripts/phase5_recovery_process.py');
if(mode==='utf8'){
 const {readPythonSidecar}=await import('../candidate/test/helpers/recovery-startup-observation.ts');
 const file=path.join(dir,'invalid-utf8.jsonl');
 writeFileSync(file,Buffer.concat([Buffer.from('{"event":"python-entry","seq":0,"pid":123,"tMs":0,"version":"'),Buffer.from([0xff]),Buffer.from('","executable":"/authored/python"}\n{"event":"wrapper-return","seq":1,"pid":123,"tMs":1}\n')]),{flag:'wx',mode:0o600});
 const actual=readPythonSidecar(file);const receipt={finding:'B-SPEC-2',scope:'exact-public-sidecar-reader',file,expectedStatus:'malformed',actual};
 writeFileSync(path.join(dir,'result.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));assert.equal(actual.status,'malformed','invalid UTF-8 must not become selected-interpreter evidence');
}else if(mode==='rejection'){
 let fake,calls=0;const previous=childProcess.spawn,oldEnvironment=process.env;
 const fakeSpawn=function(exe,args){assert.equal(exe,'/usr/bin/python3');assert.equal(args[2].endsWith('/self-observing-supervisor.py'),true);
  fake=new EventEmitter();fake.pid=123;fake.exitCode=null;fake.signalCode=null;fake.stdout=new PassThrough();fake.stderr=new PassThrough();fake.stdio=[null,fake.stdout,fake.stderr,new PassThrough()];return fake;};
 childProcess.spawn=fakeSpawn;syncBuiltinESMExports();
 const replacement=mock.module(new URL('../candidate/scripts/phase5_e2e_runner.ts',import.meta.url).href,{namedExports:{executeRecoveryWorker(options){calls++;
  namedSpawn('/usr/bin/python3',['-S','-u',source,JSON.stringify({command:options.command,timeoutMs:options.timeoutMs,contained:false})],{detached:true,stdio:['pipe','pipe','pipe','pipe']});
  return Promise.reject(new Error('held-out post-spawn rejection'));}}});
 process.env.QMD_RECOVERY_STARTUP_OBSERVATION='1';
 try{
  const {runStartupObservation}=await import('../candidate/test/helpers/recovery-startup-observation.ts');
  const observed=await runStartupObservation(dir,'node');assert.equal(calls,1);assert.equal(childProcess.spawn,fakeSpawn);assert.equal(namedSpawn,fakeSpawn);assert.equal(process.env,oldEnvironment);
  const targets=[fake,fake.stdout,fake.stderr,fake.stdio[3]];
  const retained=targets.flatMap((target,i)=>target.eventNames().flatMap(event=>target.rawListeners(event).filter(fn=>String(fn).includes('append(label')).map(()=>({target:i,event:String(event)}))));
  const receipt={finding:'B-SPEC-1',scope:'exact-helper-mocked-caller-and-no-OS-fake-child',directory:observed.directory,calls,expectedRetainedObserverListeners:0,actualRetainedObserverListeners:retained.length,retained,
   spawnRestored:true,namedExportRestored:true,environmentRestored:true,collectionErrors:observed.report.collectionErrors};
  writeFileSync(path.join(dir,'result.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));assert.equal(retained.length,0,'observer listeners must be removed when caller rejects');
 }finally{replacement.restore();childProcess.spawn=previous;syncBuiltinESMExports();for(const t of fake?[fake,fake.stdout,fake.stderr,fake.stdio[3]]:[])t.removeAllListeners();}
}else throw Error('literal utf8|rejection required');
