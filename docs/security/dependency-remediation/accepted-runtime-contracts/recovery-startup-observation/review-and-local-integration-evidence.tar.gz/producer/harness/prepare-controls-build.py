from pathlib import Path
import os, json, hashlib, shutil
ROOT=Path(__file__).resolve().parents[1]
P=Path('/Users/shersingh/.hermes/cache/scratch/qmd-recovery-composition-peukmjbv')
REVIEW=Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
manifest=json.loads((P/'source-after.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
name='scripts/build.mjs';data=(P/'candidate'/name).read_bytes();assert sha(data)==manifest[name]
with (ROOT/'candidate'/name).open('xb') as f:f.write(data)
data2=(REVIEW/'harness/orchestrator-negative.mjs').read_bytes()
with (ROOT/'harness/orchestrator-negative.mjs').open('xb') as f:f.write(data2)
env=json.loads((ROOT/'evidence/clean-environment.json').read_text())
pnpm=shutil.which('pnpm',path=env['PATH']);assert pnpm is not None
real=Path(pnpm).resolve()
info={'additionalPublicSource':{name:{'sha256':sha(data),'bytes':len(data)}},'copiedUnreapedHarnessSha256':sha(data2),
 'pnpm':{'executable':pnpm,'real':str(real),'sha256':sha(real.read_bytes())}}
with (ROOT/'evidence/additional-public-inputs.json').open('x') as f:json.dump(info,f,indent=2);f.write('\n')
print(json.dumps(info))
