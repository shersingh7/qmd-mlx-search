// Fresh exact-source real caller replay; outer passive spawn capture only.
import assert from 'node:assert/strict';
import childProcess, { spawn as namedSpawn } from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { errorMonitor } from 'node:events';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const {runStartupObservation}=await import(new URL('../candidate/test/helpers/recovery-startup-observation.ts',import.meta.url));
const expected=process.argv[2];
assert.equal(expected,process.versions.bun?'bun':'node');
const oldEnv=process.env;
const nativeOriginal=process.versions.bun?Bun.spawn:childProcess.spawn;
const captures=[];
const children=[];
function note(argv,options,child){
 if(argv[0]!=='/usr/bin/python3') return;
 const row={argv:[...argv],config:JSON.parse(argv[4]),cwd:options.cwd,detached:options.detached,stdio:options.stdio,
  shimRestoredAfterStack:null};captures.push(row);children.push(child);
 queueMicrotask(()=>{row.shimRestoredAfterStack=(process.versions.bun?Bun.spawn:childProcess.spawn)===outer;
  if(!process.versions.bun)row.namedExportRestored=namedSpawn===outer;});
}
const outer=process.versions.bun?function(argv,options){const c=nativeOriginal.call(Bun,argv,options);note(argv,options,c);return c;}
 :function(exe,args,options){const c=nativeOriginal(exe,args,options);note([exe,...args],options,c);return c;};
if(process.versions.bun)Bun.spawn=outer;
else {childProcess.spawn=outer;syncBuiltinESMExports();}
// Establish import-only module listeners before judging caller listener release.
await import(new URL('../candidate/scripts/phase5_e2e_runner.ts',import.meta.url));
const beforeListeners=Object.fromEntries(['exit','SIGTERM','SIGINT'].map(k=>[k,process.listenerCount(k)]));
let replay;
try{
 replay=await runStartupObservation(process.env.QMD_RECOVERY_STARTUP_DIR,expected);
 assert.equal(process.env,oldEnv,'process environment object must restore');
 assert.equal(process.versions.bun?Bun.spawn:childProcess.spawn,outer,'spawn shim must restore');
 assert.equal(captures.length,2);
 assert.deepEqual(captures.map(x=>x.config.timeoutMs),[200,5000]);
 for(const row of captures){assert.equal(row.shimRestoredAfterStack,true);if(!process.versions.bun)assert.equal(row.namedExportRestored,true);
  assert.deepEqual(row.argv.slice(0,3),['/usr/bin/python3','-S','-u']);assert.equal(row.config.contained,false);
  assert.equal(row.detached,true);assert.deepEqual(row.stdio,['pipe','pipe','pipe','pipe']);}
 const report=replay.report;
 assert.equal(report.collectionErrors.length,0);assert.equal(report.productQualified,false);
 assert.deepEqual(report.cases.map(x=>x.timeoutMs),[200,5000]);
 for(const item of report.cases){
  assert.equal(item.productQualified,false);assert.equal(item.result.cleanup.containmentVerified,false);
  assert.equal(item.invocation.restored,true);assert.equal(item.snapshot.subjectFixtureSignals,0);assert.equal(item.snapshot.fixtureCleanupStarted,false);
  assert.equal(item.snapshot.databaseCreated,false);assert.equal(item.snapshot.supervisorPidPresent,false);
  assert.match(item.result.error,/uncontained/);
  assert.equal(item.python.selectedInterpreter.pid,item.result.launch.supervisorPid);
  for(const e of item.python.records.filter(x=>x.event==='admission-read'))assert.ok(e.budgetMs>=1&&e.budgetMs<=item.timeoutMs);
  for(const [key,value] of Object.entries(item.unsupportedCallerMilestones))if(key!=='reason')assert.equal(value,null);
  assert.equal(item.sourceSha256,report.sourceSha256['scripts/phase5_recovery_process.py']);
 }
 const positive=report.cases[1];assert.equal(positive.classification,'authored-work-observed-uncontained');assert.equal(positive.workValidated,true);
 assert.equal(positive.python.status,'complete');assert.equal(positive.snapshot.workerPidPresent,false);assert.equal(positive.result.cleanup.forcedPipeClose,false);
 const observerListeners=[];
 if(!process.versions.bun){for(const [i,child]of children.entries()){
  for(const [label,obj]of [['owner',child],['stdout',child.stdout],['stderr',child.stderr],['proof',child.stdio[3]]]){
   for(const key of ['spawn','exit','close','end',errorMonitor]){
    const matches=obj.rawListeners(key).filter(fn=>String(fn).includes('append(label'));
    observerListeners.push({child:i,target:label,event:String(key),remainingObserverListeners:matches.length});assert.equal(matches.length,0);
   }
  }
 }}else assert.equal(positive.nodeOwner,null);
 const afterListeners=Object.fromEntries(['exit','SIGTERM','SIGINT'].map(k=>[k,process.listenerCount(k)]));
 assert.deepEqual(afterListeners,beforeListeners);
 const receipt={runtime:expected,actualHost:report.actualHost,output:replay.directory,environmentRestored:true,spawnRestored:true,
  beforeListeners,afterListeners,captures,observerListeners,
  cases:report.cases.map(x=>({timeoutMs:x.timeoutMs,callerReturnedMs:x.callerReturnedMs,classification:x.classification,python:x.python.status,
   admissionBudgets:x.python.records.filter(x=>x.event==='admission-read').map(x=>x.budgetMs),selectedInterpreter:x.python.selectedInterpreter,cleanup:x.result.cleanup}))};
 writeFileSync(path.join(root,'evidence',`real-${expected}-assertions.json`),JSON.stringify(receipt,null,2)+'\n',{flag:'wx',mode:0o600});
 console.log(JSON.stringify(receipt));
}finally{
 if(process.versions.bun)Bun.spawn=nativeOriginal;
 else{childProcess.spawn=nativeOriginal;syncBuiltinESMExports();}
}
