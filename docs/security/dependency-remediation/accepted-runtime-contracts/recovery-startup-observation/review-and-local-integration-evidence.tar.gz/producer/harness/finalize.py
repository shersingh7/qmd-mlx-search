from pathlib import Path
import os, stat, json, hashlib, difflib, subprocess, re, sys
ROOT=Path(__file__).resolve().parents[1]
C=ROOT/'candidate';LIVE=Path('/Users/shersingh/github/qmd-mlx-search')
B=Path('/Users/shersingh/.hermes/cache/scratch/qmd-startup-owner-b-6a4ic8ig')
REVIEW=Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
sha=lambda b:hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_text())
def put(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def digest(p):return {'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def save(name,value):put(ROOT/'evidence'/name,value)
def regular(p):return stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
inputs=readj(ROOT/'evidence/input-manifest.json')
files=dict(inputs['files']);files.update(readj(ROOT/'evidence/additional-public-inputs.json')['additionalPublicSource'])
after={name:digest(C/name) for name in files}
changed=sorted(name for name in files if after[name]!=files[name])
owned=['test/helpers/recovery-startup-observation.selftest.mjs','test/helpers/recovery-startup-observation.ts']
paths=['.github/workflows/ci.yml',*owned]
assert changed==owned,changed
assert after[paths[0]]==files[paths[0]]
for value in [*[d['sha256'] for d in after.values()],*[d['sha256'] for d in files.values()]]:assert re.fullmatch('[0-9a-f]{64}',value)
for name,digest0 in inputs['baseline'].items():
    assert sha((B/'proposal'/name).read_bytes())==digest0
    assert sha((ROOT/'baseline'/name).read_bytes())==digest0
assert sha((REVIEW/'ARTIFACT-INDEX.json').read_bytes())==inputs['reviewIndexSha256']
assert (ROOT/'harness/reproduce-findings.mjs').read_bytes()==(REVIEW/'harness/reproduce-findings.mjs').read_bytes()
# Bind unchanged public functions/launch implementations as well as untouched production closure.
before_text=(ROOT/'baseline'/owned[1]).read_text();after_text=(C/owned[1]).read_text()
def span(text,start,end):return text[text.index(start):text.index(end,text.index(start))]
unchanged={}
for name,start,end in [
 ('string-parser','export function parsePythonSidecar','/** O_NONBLOCK'),
 ('environment-and-argv-wrapper','export function isolatedEnvironment','type Invocation ='),
 ('runtime-and-source-schema','const ROOT =','/** Retain only a validated prefix;'),
 ('native-spawn-bodies','  const capture =','  try { return { result: start()'),
 ('classification','/** PID-existence sample only;','const DOC ='),
 ('orchestrator-and-cli','export async function runStartupObservation',None)]:
    old=span(before_text,start,end) if end else before_text[before_text.index(start):]
    new=span(after_text,start,end) if end else after_text[after_text.index(start):]
    assert old==new,name;unchanged[name]=sha(old.encode())
assert re.findall(r'^export .*',before_text,re.M)==re.findall(r'^export .*',after_text,re.M)
save('source-before.json',{'sourceOrigin':inputs['publicSourceOrigin'],'files':files})
save('source-after.json',{'sourceRoot':str(C),'files':after,'changedPaths':changed,'publicFunctionAndSpawnBodiesUnchanged':unchanged,'additionalClosureNotProposal':['scripts/build.mjs']})
# Make an explicit exactly-three-file proposal payload, copying workflow unchanged.
proposal=ROOT/'proposal';proposal.mkdir(mode=0o700)
for name in paths:
    p=proposal/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write((C/name).read_bytes())
def delta(name,old,new,is_new=False):
    header=f'diff --git a/{name} b/{name}\n'+('new file mode 100644\n' if is_new else '')
    return header+''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='/dev/null' if is_new else 'a/'+name,tofile='b/'+name))
repair=''.join(delta(name,(ROOT/'baseline'/name).read_text(),(C/name).read_text()) for name in owned)
original_pre=(ROOT/'preimages'/paths[0]).read_bytes()
three=delta(paths[0],original_pre.decode(),(C/paths[0]).read_text())+''.join(delta(name,'',(C/name).read_text(),True) for name in owned)
for name,text in [('two-file-repair.patch',repair),('three-path-proposal.patch',three)]:
    with (ROOT/name).open('x') as f:f.write(text)
assert re.findall(r'^diff --git a/(.*?) b/.*$',repair,re.M)==owned
assert re.findall(r'^diff --git a/(.*?) b/.*$',three,re.M)==paths
# Actual dry-run and actual scratch replay of both patches. No staging/index/commit.
env=readj(ROOT/'evidence/clean-environment.json')
patch_runs=[]
for kind,names,patchfile,source_root in [('two-file',paths,'two-file-repair.patch',ROOT/'baseline'),('three-path',[paths[0]],'three-path-proposal.patch',ROOT/'preimages')]:
    target=ROOT/(kind+'-replay');target.mkdir(mode=0o700)
    for name in names:
        p=target/name;p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as f:f.write((source_root/name).read_bytes())
    for extra in [['--check','--whitespace=error-all'],['--whitespace=error-all'],['--numstat']]:
        cmd=['/usr/bin/git','apply',*extra,str(ROOT/patchfile)]
        r=subprocess.run(cmd,cwd=target,env=env,capture_output=True,timeout=10)
        patch_runs.append({'kind':kind,'argv':cmd,'cwd':str(target),'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
        assert r.returncode==0,patch_runs[-1]
    for name in paths:assert (target/name).read_bytes()==(C/name).read_bytes(),(kind,name)
save('patch-replay.json',{'commands':patch_runs,'twoFileReplayExact':True,'threePathReplayExact':True})
save('repair-bindings.json',{'base':'frozen B reviewed postimages; original SPEC REQUEST_CHANGES, QUALITY NOT_STARTED_SPEC_FAILED','patch':digest(ROOT/'two-file-repair.patch'),
 'paths':{name:{'preimage':files[name],'postimage':after[name]} for name in owned},'workflowUnchanged':after[paths[0]],'newIndependentReview':'SPEC then QUALITY pending; no self-approval'})
save('three-path-bindings.json',{'patch':digest(ROOT/'three-path-proposal.patch'),'paths':{name:{'preimage':digest(ROOT/'preimages'/name) if name==paths[0] else {'absent':True},'postimage':after[name]} for name in paths},
 'workflowDelta':'original pending B workflow delta copied unchanged, not independently accepted'})
# Inspect/read back actual retained runtime receipts, without invoking another recovery.
runtimes=[]
for d in sorted((ROOT/'outputs').iterdir()):
    if not d.is_dir():continue
    report=readj(d/'observation.json');assert report['collectionErrors']==[]
    runtime=report['actualHost']['runtime'];assert runtime in ['node','bun']
    assert report['actualHost']['executable']==('/Users/shersingh/.hermes/node/bin/node' if runtime=='node' else '/Users/shersingh/.bun/bin/bun')
    assert report['actualHost']['node']=='22.22.3' if runtime=='node' else report['actualHost']['bun']=='1.3.8'
    assert report['productQualified'] is False
    for name,value in report['sourceSha256'].items():assert sha((C/name).read_bytes())==value,name
    assert [i['timeoutMs'] for i in report['cases']]==[200,5000]
    for item in report['cases']:
        assert item==readj(d/f'case-{item["timeoutMs"]}'/'before-fixture-cleanup.json')
        assert item['snapshot']['subjectFixtureSignals']==0 and item['snapshot']['fixtureCleanupStarted'] is False
        assert item['snapshot']['databaseCreated'] is False and item['snapshot']['supervisorPidPresent'] is False and item['snapshot']['workerPidPresent'] is False
        assert item['python']['status']=='complete' and item['workValidated'] is True
        assert item['classification']=='authored-work-observed-uncontained'
        assert item['result']['cleanup']['containmentVerified'] is False and item['productQualified'] is False
        assert 'uncontained' in item['result']['error']
        assert item['result']['launch']['supervisorReaped'] is True
        for k in ['childReaped','groupTerminated','sessionTerminated','pipesClosed']:assert item['result']['cleanup'][k] is True
        assert item['result']['cleanup']['forcedPipeClose'] is False
        assert item['invocation']['originalArgv'][:4]==['/usr/bin/python3','-S','-u',str(C/'scripts/phase5_recovery_process.py')]
        assert item['invocation']['actualArgv'][:3]==['/usr/bin/python3','-S','-u']
        assert item['invocation']['originalArgv'][4]==item['invocation']['actualArgv'][4]
        assert item['python']['selectedInterpreter']['pid']==item['result']['launch']['supervisorPid']
        wrapper=d/f'case-{item["timeoutMs"]}'/'self-observing-supervisor.py'
        assert sha(wrapper.read_bytes())==item['wrapperSha256']
        compile(wrapper.read_bytes(),str(wrapper),'exec')
        budgets=[v['budgetMs'] for v in item['python']['records'] if v['event']=='admission-read']
        assert all(1<=v<=item['timeoutMs'] for v in budgets)
        runtimes.append({'runtime':runtime,'actualHost':report['actualHost'],'budgetMs':item['timeoutMs'],'callerReturnMs':round(item['callerReturnedMs'],3),
          'pythonAdmissionBudgets':budgets,'selectedInterpreter':item['python']['selectedInterpreter'],'classification':item['classification'],'sidecar':item['python']['status'],'directory':str(wrapper.parent)})
assert len(runtimes)==4 and sorted((r['runtime'],r['budgetMs']) for r in runtimes)==[('bun',200),('bun',5000),('node',200),('node',5000)]
save('actual-runtime-summary.json',{'realRecoveryCalls':len(runtimes),'comparisons':runtimes,'wrapperCompilation':{'actualReviewPython':sys.version,'executable':sys.executable,'count':len(runtimes)},
 'qualification':'local warmed/instrumented public authored work only; productQualified=false/uncontained; independent process-local clock domains; not cold or CI/C1 evidence'})
# Aggregate all fresh guards, including explicit Bun child preloads; no compiler exit0 with denials qualifies.
guards=[]
for p in sorted((ROOT/'evidence').glob('*guard-*.jsonl')):
    rows=[json.loads(s) for s in p.read_text().splitlines()]
    assert not any(r.get('allowed') is False for r in rows),str(p)
    installs=[r for r in rows if r.get('kind')=='guard-installed'];assert installs,str(p)
    guards.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes()),'rows':len(rows),'refusals':0,'install':installs})
# Check retained RED and GREEN executions against the exact source identities.
expected={'original-red-rejection':1,'original-red-utf8':1,'permanent-red':1,'permanent-green':0,'original-green-rejection':0,'original-green-utf8':0,'observer-selftest':0,'types-green':0,'actual-node':0,'actual-bun':0,'selftest-green':0,'preserved-node':0,'preserved-bun':0,'syntax-green':0,'import-listeners':0,'unreaped-green':0,'build-script':0}
executions=[]
for label,code in expected.items():
    r=readj(ROOT/'evidence'/f'{label}.receipt.json');assert r['exit']==code and not r['timeout'],label
    assert r['sourceSha256'][owned[1]]==(files if label.endswith('red') or label.startswith('original-red-') else after)[owned[1]]['sha256'],label
    executions.append({'label':label,'exit':r['exit'],'receiptSha256':sha((ROOT/'evidence'/f'{label}.receipt.json').read_bytes())})
for label,tests,passed,failed in [('permanent-red',3,0,3),('permanent-green',3,3,0),('selftest-green',14,14,0),('observer-selftest',8,8,0)]:
    text=(ROOT/'evidence'/f'{label}.stdout.txt').read_text()
    for key,val in [('tests',tests),('pass',passed),('fail',failed),('skipped',0)]:assert re.search(rf'^# {key} {val}$',text,re.M),(label,key)
assert '13 !== 0' in (ROOT/'evidence/original-red-rejection.stderr.txt').read_text()
assert "actual: 'complete'" in (ROOT/'evidence/original-red-utf8.stderr.txt').read_text()
type_summary=readj(ROOT/'evidence/focused-strict-summary.json');assert type_summary['diagnostics']==0
build_dist={name:digest(C/name) for name in ['dist/index.js','dist/index.d.ts','dist/cli/qmd.js','dist/mcp/server.js']}
save('verification-summary.json',{'scope':'repair-only source-bound local verification; no independent SPEC/QUALITY approval','executions':executions,'guards':guards,
 'guardTotals':{'files':len(guards),'rows':sum(g['rows'] for g in guards),'refusals':0},'actualRecoveryCalls':len(runtimes),
 'selftests':{'passed':14,'failed':0,'skipped':0},'originalObserverSelftests':{'passed':8,'failed':0,'skipped':0},'focusedStrict':{'sourceFiles':len(type_summary['sourceFiles']),'diagnostics':type_summary['diagnostics'],'originalOptions':type_summary['unalteredOptions']},
 'build':{'canonicalPnpm':'pre-execution lifecycle guard refused; not executed/not passing gate','declaredBuildBodyExit':0,'guardedBuildBodyOutputs':build_dist,'fullProjectTestsAndPackaging':'parent-owned-not-run'},
 'BunFsMockInjection':'explicitly unsupported/not-qualified; real Bun raw reader controls executed','freshIndependentReview':'required SPEC then QUALITY'})
# Current live transitions are observed only. Disjoint parent integration is not imported/reverted.
commands={}
for key,args in {'head':['rev-parse','HEAD'],'branch':['branch','--show-current'],'status':['status','--short'],'changedPaths':['diff','--name-only'],
 'authorizedTransitionsSinceStart':['log','a6144903be9715334f66bd9ea134157f679516a5..HEAD','--format=%H %s','--name-status']}.items():
    r=subprocess.run(['/usr/bin/git','-C',str(LIVE),*args],env=env,capture_output=True,timeout=10)
    commands[key]={'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
live_rows={}
for name in files:
    p=LIVE/name
    live_rows[name]=digest(p) if p.is_file() else {'absent':not p.exists()}
for name in owned:assert live_rows[name]=={'absent':True}
assert live_rows[paths[0]]['sha256']=='f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f'
before_live=readj(ROOT/'evidence/live-before.json')
transitions={name:{'before':before_live['scopedSource'][name],'after':live_rows[name]} for name in before_live['scopedSource'] if before_live['scopedSource'][name]!=live_rows[name]}
save('live-after.json',{'git':commands,'scopedSource':live_rows,'scopedTransitions':transitions,'unrelatedParentTransitionsAuthorized':True,'wholeLiveTreeEqualityRequired':False,'noLiveWrites':True})
# Index actual immutable source-bound local REDs before making them read-only.
negative=[]
for p in sorted((ROOT/'evidence').rglob('*')):
    rel=p.relative_to(ROOT/'evidence')
    if not regular(p):continue
    if p.name.startswith(('original-red-','permanent-red')) or str(rel).startswith(('finding-red-NuOtyv/','finding-red-qOBgan/')):
        negative.append({'path':str(p.relative_to(ROOT)),**digest(p)})
        p.chmod(0o444)
save('retained-red-bindings.json',{'artifacts':negative,'contentImmutableAfterCollection':True,'originalFrozenReviewsUntouched':True})
print(json.dumps({'root':str(ROOT),'changedSourcePaths':changed,'sourceFiles':len(after),'repairPatch':digest(ROOT/'two-file-repair.patch'),'threePathPatch':digest(ROOT/'three-path-proposal.patch'),
 'postimages':{name:after[name] for name in paths},'runtimeRows':runtimes,'guardRows':sum(g['rows'] for g in guards),'guardRefusals':0,'liveHead':commands['head'],'liveStatus':commands['status'],'liveTransitions':transitions},indent=2))
