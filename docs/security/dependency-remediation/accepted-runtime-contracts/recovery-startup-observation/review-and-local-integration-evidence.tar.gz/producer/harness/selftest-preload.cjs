// Review harness only: read-guard every selftest subprocess after its allowlist.
require('./read-guard.cjs');
const cp=require('node:child_process'),path=require('node:path');
const original=cp.spawnSync,guard=path.join(__dirname,'read-guard.cjs');
cp.spawnSync=function(executable,args,options){
 const isNode=executable===process.execPath;
 const isBun=executable==='bun';
 if(isNode||isBun){
  args=[isBun?'--preload':'--require',guard,...args];
  options={...options,env:{...options.env,REVIEW_GUARD_LABEL:(process.env.REVIEW_GUARD_LABEL||'selftest')+'-child'}};
 }
 return original.call(this,executable,args,options);
};
require('node:module').syncBuiltinESMExports();
