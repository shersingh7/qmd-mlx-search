// Canonical bare-command gate instrumentation; no argv/options rewrite.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),candidate=path.join(root,'candidate');
const entry=process.argv[1]?path.resolve(process.argv[1]):null;
const compiler=fs.realpathSync(path.join(candidate,'node_modules/typescript/bin/tsc'));
const guarded=entry===path.join(candidate,'scripts/build.mjs')||entry===compiler||entry===path.join(candidate,'node_modules/typescript/bin/tsc');
fs.appendFileSync(path.join(root,'evidence/final-gate-hosts.jsonl'),JSON.stringify({kind:'actual-build-host',guarded,execPath:process.execPath,versions:process.versions,argv:process.argv,cwd:process.cwd()})+'\n');
if(guarded)require('./read-guard.cjs');
