// Actual generated Python wrapper execution against an authored boundary stub.
// These are NOT recovery caller comparisons and never fork/signal/create a DB.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdirSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {makeSupervisorWrapper,readPythonSidecar,isolatedEnvironment} from '../candidate/test/helpers/recovery-startup-observation.ts';
const root=fileURLToPath(new URL('../',import.meta.url)), work=path.join(root,'evidence/wrapper-boundary');mkdirSync(work,{mode:0o700});
const sha=b=>createHash('sha256').update(b).digest('hex');
const results=[];
const authored=`import os, sys, json
calls=[]
messages=[]
values=[None,b'S111\\n',b'E',b'T',b'K',b'',b'S1',b'11\\n',b'X']
limits=[16,4096,2,3,4,5,6,7,8]
def read_control(limit=4096):
    assert limit == limits[len(calls)]
    value=values[len(calls)]
    calls.append(value)
    return value
def send(message):
    messages.append(message)
def main():
    expected=[dict(type='prepared'),dict(type='ready'),dict(type='exit'),dict(type='cleanup')]
    for message in expected:
        send(message)
    assert all(a is b for a,b in zip(messages,expected))
    for i,limit in enumerate(limits):
        assert read_control(limit) is values[i]
    fd=send.__globals__['record_fd']
    assert not os.get_inheritable(fd)
    with open(os.environ['UNIT_RESULT'],'x') as f:
        json.dump(dict(pid=os.getpid(),executable=sys.executable,readCount=len(calls),limits=limits,sendIdentityPreserved=True,readIdentityPreserved=True,sidecarInheritable=os.get_inheritable(fd)),f)
`;
for(const mode of ['positive-read-send','source-mismatch','main-error','exclusive-sidecar-refusal']){
 const dir=path.join(work,mode);mkdirSync(dir,{mode:0o700});const source=path.join(dir,'authored-boundary.py'),sidecar=path.join(dir,'sidecar.jsonl'),wrapper=path.join(dir,'generated-wrapper.py'),result=path.join(dir,'main-result.json');
 const bytes=mode==='main-error'?Buffer.from("def send(message):\n    pass\ndef read_control(limit=4096):\n    return None\ndef main():\n    raise RuntimeError('authored-boundary-main-error')\n"):Buffer.from(authored);
 writeFileSync(source,bytes,{flag:'wx',mode:0o600});
 const digest=mode==='source-mismatch'?'0'.repeat(64):sha(bytes);
 const code=makeSupervisorWrapper({source,expectedSha256:digest,sidecar});writeFileSync(wrapper,code,{flag:'wx',mode:0o600});
 if(mode==='exclusive-sidecar-refusal')writeFileSync(sidecar,'retained-public-sidecar\n',{flag:'wx',mode:0o600});
 const env={...isolatedEnvironment(path.join(dir,'environment')),UNIT_RESULT:result};
 const r=spawnSync('/usr/bin/python3',['-S','-u',wrapper,'{"authored":"boundary-only-not-recovery"}'],{env,encoding:'utf8',timeout:5000});
 writeFileSync(path.join(dir,'stdout.txt'),r.stdout??'',{flag:'wx'});writeFileSync(path.join(dir,'stderr.txt'),r.stderr??'',{flag:'wx'});
 assert.equal(r.signal,null);const parsed=readPythonSidecar(sidecar);
 if(mode==='positive-read-send'){
  assert.equal(r.status,0,r.stderr);const data=JSON.parse(readFileSync(result,'utf8'));assert.equal(data.readCount,9);assert.equal(data.readIdentityPreserved,true);assert.equal(data.sendIdentityPreserved,true);assert.equal(data.sidecarInheritable,false);
  assert.equal(parsed.status,'complete');assert.equal(parsed.selectedInterpreter.pid,data.pid);
  assert.deepEqual(parsed.records.filter(x=>['admission-read','execution-read','cancel-read','parent-eof'].includes(x.event)).map(x=>x.event),['admission-read','execution-read','cancel-read','cancel-read','parent-eof']);
  assert.equal(parsed.records.find(x=>x.event==='admission-read').budgetMs,111);
 }else if(mode==='source-mismatch'){
  assert.equal(r.status,1);assert.match(r.stderr,/source binding mismatch/);assert.equal(existsSync(result),false);assert.equal(parsed.status,'partial');assert.equal(parsed.records.length,1);assert.equal(parsed.milestones['source-verified'],null);assert.equal(parsed.milestones['wrapper-return'],null);
 }else if(mode==='main-error'){
  assert.equal(r.status,1);assert.equal(parsed.status,'complete');assert.notEqual(parsed.milestones['supervisor-error-sent'],null);assert.equal(parsed.milestones['cleanup-sent'],null);assert.equal(existsSync(result),false);
 }else{
  assert.equal(r.status,1);assert.equal(readFileSync(sidecar,'utf8'),'retained-public-sidecar\n');assert.equal(existsSync(result),false);
 }
 results.push({mode,argv:['/usr/bin/python3','-S','-u',wrapper,'{"authored":"boundary-only-not-recovery"}'],exit:r.status,signal:r.signal,sourceSha256:sha(bytes),expectedSha256:digest,wrapperSha256:sha(code),sidecar:parsed,
  qualification:'authored wrapper boundary control only; no production supervisor main/caller/no fork/no DB/no workload'});
}
console.log(JSON.stringify({scope:'actual-product-interpreter-generated-wrapper-boundary-only',results}));
writeFileSync(path.join(root,'evidence/wrapper-boundary-summary.json'),JSON.stringify({results},null,2)+'\n',{flag:'wx',mode:0o600});
