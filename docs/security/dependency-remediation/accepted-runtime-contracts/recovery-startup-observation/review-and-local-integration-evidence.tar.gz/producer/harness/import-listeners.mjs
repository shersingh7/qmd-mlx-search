import assert from 'node:assert/strict';
import {errorMonitor} from 'node:events';
const snapshot=()=>Object.fromEntries(['exit','SIGTERM','SIGINT'].map(k=>[k,process.rawListeners(k).map(fn=>String(fn))]));
const before=snapshot();
await import(new URL('../candidate/scripts/phase5_e2e_runner.ts',import.meta.url));
const after=snapshot();
assert.equal(after.exit.length,before.exit.length);
assert.equal(after.SIGTERM.length-before.SIGTERM.length,1);
assert.equal(after.SIGINT.length-before.SIGINT.length,1);
assert.equal(after.SIGTERM.some(s=>s.includes('onParentTerm')),false);
assert.equal(after.SIGINT.some(s=>s.includes('onParentInt')),false);
console.log(JSON.stringify({scope:'import-only-no-recovery-calls',actualHost:{node:process.versions.node,bun:process.versions.bun??null,executable:process.execPath},before,after,
 conclusion:'two persistent library signal listeners are installed on importing the unchanged caller closure, not leaked production onParentTerm/onParentInt callbacks'}));
