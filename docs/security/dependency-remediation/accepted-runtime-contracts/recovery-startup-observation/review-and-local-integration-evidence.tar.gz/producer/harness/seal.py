from pathlib import Path
import os, stat, json, hashlib, subprocess, re
ROOT=Path(__file__).resolve().parents[1];C=ROOT/'candidate'
LIVE=Path('/Users/shersingh/github/qmd-mlx-search')
REVIEW=Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
B=Path('/Users/shersingh/.hermes/cache/scratch/qmd-startup-owner-b-6a4ic8ig')
sha=lambda b:hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_text())
def put(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def bind(p):return {'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def regular(p):return stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
source=readj(ROOT/'evidence/source-after.json')['files']
for name,value in source.items():assert bind(C/name)==value,name
repair=readj(ROOT/'evidence/repair-bindings.json');three=readj(ROOT/'evidence/three-path-bindings.json')
assert bind(ROOT/'two-file-repair.patch')==repair['patch'];assert bind(ROOT/'three-path-proposal.patch')==three['patch']
for name,value in three['paths'].items():assert bind(ROOT/'proposal'/name)==value['postimage']
for row in readj(ROOT/'evidence/retained-red-bindings.json')['artifacts']:
    assert bind(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']}
# Re-authenticate frozen evidence without any writes to it.
idx=(REVIEW/'ARTIFACT-INDEX.json').read_bytes();assert sha(idx)=='5944a057e3f0c1dcc6210123d3d7f9e86d586b80749dd80baf9550fe5f690e62'
ri=json.loads(idx)
for row in ri['artifacts']:
    assert re.fullmatch('[0-9a-f]{64}',row['sha256']);p=REVIEW/row['path'];assert regular(p)
    assert bind(p)=={k:row[k] for k in ['bytes','sha256']},str(p)
assert sha((B/'three-path-proposal.patch').read_bytes())=='448125a2f4739cda1bfa2875705799229546ae4e05ce9d1c3b27153cf83e60b4'
for name,digest in readj(ROOT/'evidence/input-manifest.json')['baseline'].items():
    assert re.fullmatch('[0-9a-f]{64}',digest);assert sha((B/'proposal'/name).read_bytes())==digest
put(ROOT/'evidence/frozen-reverification.json',{'reviewIndexSha256':sha(idx),'reviewArtifactCount':len(ri['artifacts']),
 'reviewArtifactBytes':sum(row['bytes'] for row in ri['artifacts']),'allReviewedArtifactsStillMatch':True,'originalProducerPatchAndThreePostimagesStillMatch':True,'noExternalWrites':True})
env=readj(ROOT/'evidence/clean-environment.json')
commands={}
for key,args in {'head':['rev-parse','HEAD'],'branch':['branch','--show-current'],'status':['status','--short'],
 'transitionsSinceInitial':['log','a6144903be9715334f66bd9ea134157f679516a5..HEAD','--format=%H %s','--name-status']}.items():
    r=subprocess.run(['/usr/bin/git','-C',str(LIVE),*args],env=env,capture_output=True,timeout=10)
    commands[key]={'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
parent_paths=['test/audit-recovery-execution-admission.test.ts','test/fixtures/bun_recovery_ownership.ts']
transitions={}
for name in parent_paths:
    r=subprocess.run(['/usr/bin/git','-C',str(LIVE),'show','a6144903be9715334f66bd9ea134157f679516a5:'+name],env=env,capture_output=True,timeout=10)
    assert r.returncode==0
    transitions[name]={'initialCleanHeadPreimage':{'sha256':sha(r.stdout),'bytes':len(r.stdout)},'currentPublicLiveBytes':bind(LIVE/name),'owner':'parent-authorized A integration, not imported/reverted'}
for name in repair['paths']:assert not (LIVE/name).exists()
assert sha((LIVE/'.github/workflows/ci.yml').read_bytes())=='f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f'
put(ROOT/'evidence/parent-transitions-at-seal.json',{'git':commands,'authorizedDisjointTransitions':transitions,'wholeLiveTreeEqualityRequired':False,'laneWritesToLive':False})
put(ROOT/'evidence/scope-checks.json',{'copiedSourceCount':len(source),'changedSourcePaths':readj(ROOT/'evidence/source-after.json')['changedPaths'],
 'twoFileDeltaOnlyOwnedHelpers':True,'proposalPaths':list(three['paths']),'proposalPayloadCount':len(three['paths']),
 'workflowUnchangedFromB':repair['workflowUnchanged'],'workflowIndependentlyAccepted':False,'canonicalPrefixSha256':'d723590bbdca7e4e20a61eb6782d77f25defd3a633403c2c9d654ecfcfa00aa1',
 'productionObserverApiProtocolDependenciesLocksUntouched':True,'noPublicCallerOptionInvented':True,'liveHelpersAbsent':True,'liveWorkflowOriginal':True,
 'stagingCommitPushNetworkInstallDelegationModelsGpuPerformed':False,'parentFullSuitePackagingCiRunByThisLane':False,
 'canonicalPnpmGate':'preflight-refused-not-executed','freshIndependentSpec':'PENDING','freshIndependentQuality':'NOT_STARTED_PENDING_SPEC'})
put(ROOT/'DELIVERY.json',{'schemaVersion':1,'root':str(ROOT),'status':'REPAIR_READY_FOR_FRESH_INDEPENDENT_SPEC_REVIEW',
 'priorReview':{'spec':'REQUEST_CHANGES','quality':'NOT_STARTED_SPEC_FAILED','reviewIndexSha256':sha(idx)},
 'newIndependentSpec':None,'newIndependentQuality':None,'noSelfApproval':True,'noCiFixClaim':True,
 'report':'REPORT.md','reviewedBaselineToRepairPatch':{'path':'two-file-repair.patch',**repair['patch']},
 'originalLiveToUpdatedProposalPatch':{'path':'three-path-proposal.patch',**three['patch']},'payloadRoot':'proposal','sourceClosureRoot':'candidate',
 'postimages':{name:value['postimage'] for name,value in three['paths'].items()},'verification':'evidence/verification-summary.json',
 'scopeChecks':'evidence/scope-checks.json','artifactIndex':'ARTIFACT-INDEX.json','artifactIndexChecksum':'ARTIFACT-INDEX.sha256'})
# Enumerate only the explicit public source/evidence/payload closure; never follow symlinks.
selected=set()
for name in ['REPORT.md','DELIVERY.json','two-file-repair.patch','three-path-proposal.patch']:
    selected.add(ROOT/name)
for name in source:selected.add(C/name)
# Hash the actual generated public build outputs, separately from source scope.
for folder in ['harness','evidence','baseline','preimages','proposal']:
    for p in (ROOT/folder).rglob('*'):
        if regular(p):selected.add(p)
for p in (C/'dist').rglob('*'):
    if regular(p):selected.add(p)
excluded_special=[]
for base,dirs,names in os.walk(ROOT/'outputs',followlinks=False):
    dirs[:]=[d for d in dirs if d not in ['state','caller-environment','__pycache__'] and not Path(base,d).is_symlink()]
    for name in names:
        p=Path(base,name)
        if regular(p):selected.add(p)
        else:excluded_special.append(str(p.relative_to(ROOT)))
rows=[]
for p in sorted(selected):
    assert regular(p);rel=p.relative_to(ROOT);assert not rel.is_absolute() and '..' not in rel.parts
    rows.append({'path':str(rel),**bind(p)})
index={'schemaVersion':1,'root':str(ROOT),'scope':'bounded B repair delivery, not independent acceptance','artifactCount':len(rows),'artifactBytes':sum(r['bytes'] for r in rows),
 'indexSelfExcluded':True,'exclusions':['ARTIFACT-INDEX.json','ARTIFACT-INDEX.sha256','node_modules/per-package read-only aliases and caches','owned home/Hermes/knowledge/XDG/HF/TMP/tool caches','outputs/*/{state,caller-environment}/ caches','scratch patch-replay duplicates','nonregular FIFO/symlink fixtures'],
 'artifacts':rows}
put(ROOT/'ARTIFACT-INDEX.json',index)
# Authenticate the serialized complete index against every selected artifact.
loaded=readj(ROOT/'ARTIFACT-INDEX.json');assert loaded['artifactCount']==len(loaded['artifacts'])
assert loaded['artifactBytes']==sum(x['bytes'] for x in loaded['artifacts'])
for row in loaded['artifacts']:assert bind(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']}
index_hash=sha((ROOT/'ARTIFACT-INDEX.json').read_bytes())
with (ROOT/'ARTIFACT-INDEX.sha256').open('x') as f:f.write(index_hash+'  ARTIFACT-INDEX.json\n')
print(json.dumps({'root':str(ROOT),'status':'REPAIR_READY_FOR_FRESH_INDEPENDENT_SPEC_REVIEW','artifactIndexSha256':index_hash,'artifacts':len(rows),'artifactBytes':index['artifactBytes'],
 'reportSha256':sha((ROOT/'REPORT.md').read_bytes()),'twoFilePatchSha256':repair['patch']['sha256'],'threePathPatchSha256':three['patch']['sha256'],
 'sourceManifestSha256':sha((ROOT/'evidence/source-after.json').read_bytes()),'verificationSummarySha256':sha((ROOT/'evidence/verification-summary.json').read_bytes()),
 'parentHead':commands['head'],'parentStatus':commands['status'],'noLiveEdits':True,'freshSpec':'PENDING','freshQuality':'NOT_STARTED_PENDING_SPEC'},indent=2))
