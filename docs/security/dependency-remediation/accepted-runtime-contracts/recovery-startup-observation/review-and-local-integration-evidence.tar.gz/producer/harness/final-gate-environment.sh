# Source only in the verified Bash tool shell; no ambient values printed.
[ -n "${BASH_VERSION-}" ] || return 1
for name in $(compgen -e); do unset "$name" 2>/dev/null || true; done
export PATH=/Users/shersingh/.hermes/node/bin:/Users/shersingh/.bun/bin:/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin:/opt/homebrew/bin:/usr/bin:/bin
export HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/home
export HERMES_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/hermes
export HERMES_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/hermes
export HERMES_KNOWLEDGE_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/knowledge
export KNOWLEDGE_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/knowledge
export XDG_CONFIG_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/config
export XDG_CACHE_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/cache
export XDG_DATA_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/data
export XDG_STATE_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/state
export HF_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/hf
export HF_HUB_CACHE=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/hf/hub
export TRANSFORMERS_CACHE=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/hf/transformers
export UV_CACHE_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/uv
export TMPDIR=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/tmp
export TMP=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/tmp
export TEMP=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/tmp
export BUN_INSTALL_CACHE_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/bun
export npm_config_cache=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/npm
export npm_config_userconfig=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/config/empty.npmrc
export npm_config_globalconfig=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/config/empty.npmrc
export PNPM_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/cache/pnpm
export NODE_COMPILE_CACHE=/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/cache/node
export LANG=C.UTF-8 CI=1 REQUIRE_BUN=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 UV_OFFLINE=1 QMD_LLAMA_GPU=false
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 TOKENIZERS_PARALLELISM=false npm_config_offline=true PNPM_DISABLE_SELF_UPDATE_CHECK=1
export REVIEW_GUARD_LABEL=final-gate
export NODE_OPTIONS='--require /Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r/harness/final-gate-preload.cjs'
