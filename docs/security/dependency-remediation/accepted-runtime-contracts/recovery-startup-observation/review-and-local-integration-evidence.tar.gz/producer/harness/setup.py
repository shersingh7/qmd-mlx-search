from pathlib import Path
import os, stat, json, hashlib, re, subprocess
ROOT=Path(__file__).resolve().parents[1]
B=Path('/Users/shersingh/.hermes/cache/scratch/qmd-startup-owner-b-6a4ic8ig')
REVIEW=Path('/Users/shersingh/.hermes/cache/scratch/qmd-B-independent-review-vun3q06a')
P=Path('/Users/shersingh/.hermes/cache/scratch/qmd-recovery-composition-peukmjbv')
LIVE=Path('/Users/shersingh/github/qmd-mlx-search')
def sha(b):return hashlib.sha256(b).hexdigest()
def publish(name,value):
    p=ROOT/'evidence'/name
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def authenticated(p,digest):
    assert re.fullmatch('[0-9a-f]{64}',digest),digest
    assert p.is_file() and not p.is_symlink(),str(p)
    data=p.read_bytes();assert sha(data)==digest,str(p)
    return data
review_index=authenticated(REVIEW/'ARTIFACT-INDEX.json','5944a057e3f0c1dcc6210123d3d7f9e86d586b80749dd80baf9550fe5f690e62')
ri=json.loads(review_index)
review_rows=ri['artifacts'];verified=[]
for row in review_rows:
    rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts
    data=authenticated(REVIEW/rel,row['sha256']);assert len(data)==row['bytes']
    verified.append(row)
publish('review-authentication.json',{'indexSha256':sha(review_index),'artifacts':verified,'artifactCount':len(verified),'bytes':sum(r['bytes'] for r in verified)})
original_patch=authenticated(B/'three-path-proposal.patch','448125a2f4739cda1bfa2875705799229546ae4e05ce9d1c3b27153cf83e60b4')
with (ROOT/'baseline/original-three-path-proposal.patch').open('xb') as f:f.write(original_patch)
source_bytes=authenticated(P/'source-after.json','7197501a2c7034693eb428063aeaa7571c53378d0d96acceafa0f19aafe7f23e')
manifest=json.loads(source_bytes)
required={'.github/workflows/ci.yml','package.json','bun.lock','pnpm-lock.yaml','tsconfig.json','tsconfig.build.json',
 'scripts/phase5_e2e_runner.ts','scripts/phase5_recovery_worker.ts','scripts/phase5_recovery_process.py',
 'scripts/phase5_recovery_process_loader.mjs','scripts/qmd_mlx/process_anchor.py','scripts/qmd_mlx/__init__.py','scripts/run-offline.py',
 'test/fixtures/public_eval_dataset.ts','test/helpers/recovery-bootstrap-diagnostics.mjs','test/helpers/recovery-bootstrap-diagnostics.selftest.mjs',
 'test/helpers/recovery-startup-observation.ts','test/helpers/recovery-startup-observation.selftest.mjs',
 'test/audit-recovery-startup.test.ts','test/audit-recovery-transition.test.ts'}
required.update(k for k in manifest if k.startswith('src/') and k.endswith(('.ts','.json')))
candidate=ROOT/'candidate';candidate.mkdir(mode=0o700)
rows={}
for name in sorted(required):
    data=authenticated(P/'candidate'/name,manifest[name]);dest=candidate/name;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f:f.write(data)
    rows[name]={'sha256':sha(data),'bytes':len(data)}
expected={'.github/workflows/ci.yml':'58cdcb86673d982e04d27d17b0cc3c438a17b499647fb9eba2da484d6c8c928f',
 'test/helpers/recovery-startup-observation.ts':'7d3d8c27d33206319c6742527e3dd4a7bd305271e9bd9b9fff22703d23159a99',
 'test/helpers/recovery-startup-observation.selftest.mjs':'1e100d07a96843f261d6fb56d0c8a8a929a99acdac014a78043601f247badf15'}
for name,digest in expected.items():
    data=authenticated(B/'proposal'/name,digest);assert rows[name]['sha256']==digest
    dest=ROOT/'baseline'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f:f.write(data)
pre=authenticated(B/'preimages/.github/workflows/ci.yml','f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f')
dest=ROOT/'preimages/.github/workflows/ci.yml';dest.parent.mkdir(parents=True,exist_ok=True)
with dest.open('xb') as f:f.write(pre)
# Copy only explicit, public review harnesses; frozen receipts stay in their owner roots.
for name in ['reproduce-findings.mjs','read-guard.cjs','focused-strict.cjs','replay.mjs','workflow-controls.mjs','wrapper-boundary.mjs','import-listeners.mjs']:
    data=(REVIEW/'harness'/name).read_bytes()
    with (ROOT/'harness'/name).open('xb') as f:f.write(data)
# Native per-package aliases into the installed public dependency closure. Caches owned BEFORE RED.
nm=candidate/'node_modules';nm.mkdir();aliases={}
def add(name,p):
    if not p.is_dir():return
    real=p.resolve();assert real.is_relative_to(LIVE/'node_modules'),str(real)
    dest=nm/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(real,target_is_directory=True);aliases[name]=str(real)
for p in sorted((LIVE/'node_modules').iterdir()):
    if p.name.startswith('.'):continue
    if p.name.startswith('@'):
        for q in sorted(p.iterdir()):add(p.name+'/'+q.name,q)
    else:add(p.name,p)
store=LIVE/'node_modules/.bun'
if store.is_dir():
    for item in sorted(store.iterdir()):
        inner=item/'node_modules'
        if not inner.is_dir():continue
        for p in sorted(inner.iterdir()):
            if p.name.startswith('.'):continue
            if p.name.startswith('@') and p.is_dir():
                for q in sorted(p.iterdir()):
                    name=p.name+'/'+q.name
                    if name not in aliases:add(name,q)
            elif p.name not in aliases:add(p.name,p)
for folder in ['.vite','.vite-temp','.cache','.vitest']:(nm/folder).mkdir()
clean={'PATH':'/Users/shersingh/.hermes/node/bin:/Users/shersingh/.bun/bin:/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
 'LANG':'C.UTF-8','CI':'1','REQUIRE_BUN':'1','QMD_LLAMA_GPU':'false','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1',
 'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','TOKENIZERS_PARALLELISM':'false','npm_config_offline':'true','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(ROOT/'cache/bun-transpile'),
 'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0','GIT_PAGER':'cat'}
for key,folder in {'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes','HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge',
 'XDG_CONFIG_HOME':'config','XDG_CACHE_HOME':'cache','XDG_DATA_HOME':'data','XDG_STATE_HOME':'state','HF_HOME':'hf','HF_HUB_CACHE':'hf/hub','TRANSFORMERS_CACHE':'hf/transformers',
 'TMPDIR':'tmp','TMP':'tmp','TEMP':'tmp','BUN_INSTALL_CACHE_DIR':'bun','npm_config_cache':'npm','UV_CACHE_DIR':'uv','NODE_COMPILE_CACHE':'cache/node'}.items():
    clean[key]=str(ROOT/folder);(ROOT/folder).mkdir(parents=True,exist_ok=True)
(ROOT/'outputs').mkdir(mode=0o700)
publish('package-aliases.json',aliases)
publish('clean-environment.json',clean)
publish('dependency-bindings.json',{k:{'real':v,'packageJsonSha256':sha((Path(v)/'package.json').read_bytes()) if (Path(v)/'package.json').is_file() else None} for k,v in aliases.items()})
live_rows={}
for name in sorted(required):
    p=LIVE/name
    live_rows[name]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} if p.is_file() else {'absent':not p.exists()}
commands={}
for key,args in {'head':['rev-parse','HEAD'],'branch':['branch','--show-current'],'status':['status','--short'],'changedPaths':['diff','--name-only'],'lastCommit':['log','-1','--format=%H %s']}.items():
    r=subprocess.run(['/usr/bin/git','-C',str(LIVE),*args],env=clean,capture_output=True,timeout=10)
    commands[key]={'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
publish('live-before.json',{'git':commands,'scopedSource':live_rows,'unrelatedParentTransitionsAuthorized':True,'wholeLiveTreeEqualityRequired':False})
publish('input-manifest.json',{'root':str(ROOT),'publicSourceOrigin':str(P/'candidate'),'parentSourceAfterSha256':sha(source_bytes),'files':rows,'aliasCount':len(aliases),'reviewIndexSha256':sha(review_index),'baseline':expected})
print(json.dumps({'root':str(ROOT),'copiedFiles':len(rows),'aliases':len(aliases),'reviewArtifactsVerified':len(verified),'reviewBytes':sum(r['bytes'] for r in verified),'liveHead':commands['head'],'liveStatus':commands['status']}))
