# B bounded repair — ready for fresh independent SPEC → QUALITY

**Both demonstrated helper defects are repaired in the isolated proposal. No live edits, integration, independent approval, or actual-CI success is claimed.**

Root: `/Users/shersingh/.hermes/cache/scratch/qmd-B-repair-3yo32k3r`.

## Deliverables and identity

- `two-file-repair.patch`: delta **from the exact frozen B reviewed helper postimages**, not from live absent files. SHA256 `f1f3de0f742bef3e57b24c897d76fe063ede830b7d3dcdbfbe6e816d61daebd2`.
- `three-path-proposal.patch`: updated proposal from the original live workflow preimage and absent helper preimages. SHA256 `8bca9594cb97ea89197430585b51301d71dba578fae9dc0fe9346dec2db55a64`.
- `proposal/`: exactly those three postimages. `candidate/`: the hash-bound public runtime/type/build closure, not a live checkout.
- `evidence/repair-bindings.json`, `three-path-bindings.json`, `source-before.json`, `source-after.json`, `patch-replay.json`, `verification-summary.json`, and `ARTIFACT-INDEX.json` bind the payloads, checks and raw evidence.

| Path | Reviewed B preimage SHA256 | Repair postimage SHA256 |
|---|---|---|
| `test/helpers/recovery-startup-observation.ts` | `7d3d8c27d33206319c6742527e3dd4a7bd305271e9bd9b9fff22703d23159a99` | `00d2f3fa3d0556323eba526192a28c8bdd21e18efce892bd47f241533486b1fc` |
| `test/helpers/recovery-startup-observation.selftest.mjs` | `1e100d07a96843f261d6fb56d0c8a8a929a99acdac014a78043601f247badf15` | `ecb725f3d7219109abd70e47022e5a186614c71cc6ccca70922feba9f87f3459` |

Workflow remains **byte-identical to original B**: `58cdcb86673d982e04d27d17b0cc3c438a17b499647fb9eba2da484d6c8c928f`. Its original pending delta is included, **not independently accepted**. The original live workflow preimage is `f4a8f301be216c80a07668b8ddbbb8d9e3e44f12acfc3fb48fd51670dfbdf67f`.

The prior independent result remains **SPEC=REQUEST_CHANGES, QUALITY=NOT_STARTED_SPEC_FAILED**. No QUALITY report or new approval was created. Parent must authenticate/replay this delivery and commission new independent SPEC, then QUALITY.

## B-SPEC-1: release after caller/observation exceptions

The existing observer's `finish()` already disposes in its own `finally`; `dispose()` removes only its own registered callbacks. The repair transfers its call-local handle before either finish or release, making later release a no-op. `runCase` invokes release from asynchronous `finally`, including caller rejection; synchronous start failures also release. Caller/finish failures remain primary if release additionally throws. Collection still records incomplete observation and stops rather than publishing success.

Permanent exact-helper controls exercise post-spawn rejection, synchronous post-spawn throw, finishing-snapshot throw, normal completion, no observer, and no-observer rejection. The authored EventEmitter/PassThrough fake cannot launch an OS process. Before any fixture cleanup, assertions prove:

- Each attached observer has exactly **13 distinct callbacks removed once**, preserving the exact caller/unrelated listener arrays.
- Spawn, its named builtin export and the original environment object restore.
- Rejection/throw yields no successful case, retains `observation-incomplete`, and never creates `case-5000`.
- No fixture signal, stream close or successful cleanup claim is introduced. Normal finish plus final release does not double-remove callbacks.

This exceptional mock contract is not evidence that a natural production invocation rejected.

## B-SPEC-2: validate raw UTF-8 without replacement

The bounded raw reader now decodes completed lines with fatal UTF-8 decoding, retaining only already-valid preceding records when a completed line is corrupt. It never uses replacement-decoded corruption as interpreter evidence. Raw bytes remain on disk, and `bytes`/`trailingBytes` count actual bytes. An unterminated tail, including a cut multibyte sequence, is retained only as partial raw evidence and never promoted into a record.

Permanent exact-reader controls run on **actual Node and native Bun**: invalid first entry, corruption after a valid entry, stray/overlong/bad-continuation/surrogate/out-of-range/truncated sequences, a bounded tail, an over-cap file, and valid Unicode including a **correctly encoded literal U+FFFD**. Valid Unicode remains complete; the corrupt first entry has no selected interpreter, and a corrupt later row retains the valid prefix without claiming complete.

The public string parser is byte-identical. Additional fresh Node/Bun controls preserve strict schema/sequence/PID/clock/budget/record/line/terminal/BOM rules and reject symlink, hardlink, directory and FIFO inputs. Node's injected read failure proves one acquired FD closes once. **Native Bun does not apply this namespace-to-existing-named-FS mock seam: its zero-injection receipt is explicitly not qualified**, not passed off as an injected-fault success.

## RED → GREEN evidence

All raw outputs and exact argv/source/environment bindings are in `evidence/*.receipt.json`, `.stdout.txt`, `.stderr.txt` and guard JSONL files. Original RED receipts were not rewritten; owned negative files are hash-bound and read-only after collection.

| Check | Actual result |
|---|---|
| Unchanged reviewer `reproduce-findings.mjs rejection`, before repair | exit 1; **13 retained observer callbacks**, expected 0 |
| Unchanged reviewer `reproduce-findings.mjs utf8`, before repair | exit 1; corrupt entry falsely **complete** |
| New permanent regressions before helper edit | **3 genuine assertion failures**: Node UTF-8, native Bun UTF-8, rejection disposal; no bootstrap substitute |
| The same unchanged reviewer reproducer, repaired helper | both exit **0**; 0 retained observer callbacks; malformed bytes/no selected interpreter |
| The same new permanent tests, repaired helper | **3 passed, 0 failed, 0 skipped** |
| Complete existing + new startup selftests, including fresh actual artifacts | **14 passed, 0 failed, 0 skipped** |
| Original unchanged observer selftests, before fresh real comparisons | **8 passed, 0 failed, 0 skipped** |
| Focused strict TypeScript, original compiler options | **548 source files, 0 diagnostics**, exit 0; **623 guard rows, 0 refusals** |
| Selftest syntax, fresh preserved parser/FS/workflow controls | exit **0** on the applicable actual hosts |
| Exact-helper unreaped-owner mock | one call only; incomplete receipt retained; no `case-5000` |
| Both patch dry-runs and actual scratch replays | exit **0**, exact expected three-file postimages |

The two-file patch has only 165 added selftest lines and 41 added / 6 removed helper lines. All **48 copied source inputs** are hash-bound; only the two owned helper paths differ. The native spawn bodies, original string parser, wrapper generator/environment/argv seam, classification, orchestrator and CLI are explicitly checked unchanged. Production caller/supervisor/worker/anchor/loader and old observer are untouched.

Fresh installed public dependency aliases were resolved (**281**), not copied from an obsolete allowlist. The owned `node_modules` container and `.vite/.vite-temp/.cache/.vitest` directories existed before any RED. Fresh HOME/Hermes/knowledge/XDG/HF/TMP/tool caches and an explicit credential-free environment allowlist were used. Across **34 guard files / 4,295 rows**, there were **0 read refusals**. Native Bun guards were installed with explicit `--preload`; no claim is made that Node FS hooks cover Bun's internal transpiler.

### Build boundary / retained tool refusal

The requested ordinary standalone `pnpm run build` was **refused before execution** by the terminal lifecycle scanner because installed `pnpm/dist/pnpm.cjs` exceeds its 1 MiB scan cap. See `evidence/canonical-build-preflight-refusal.json`. No guard was bypassed or verification metadata rewritten. **No new passing canonical pnpm terminal gate is claimed.**

As separate scoped evidence, the already-read small declared package build body, `node scripts/build.mjs`, actually ran unchanged with environment-only preload: exit **0**, **618 guarded rows / 0 refusals**; expected built entrypoints exist and are hash-bound. This is not relabelled as a package-manager/canonical acceptance result. Parent's earlier canonical build proof remains prior-parent evidence. Full-project tests, packaging and CI are parent-owned and were not run here; no full-native-Bun Vitest/model suite was launched.

## Exactly four fresh real comparisons

The actual `executeRecoveryWorker` was called once at each original budget on each actual host, sequentially, with no retry-to-green. The public seam remains synchronous native-spawn **script-argument substitution**, not a public `supervisorScript` caller option. Literal `/usr/bin/python3 -S -u`, original configuration string, native ownership, detached/four-pipe transport, caller-inclusive budget and 800ms teardown are unchanged. No extra Bun owner/reader is added.

| Actual host | Original budget | External caller-return bracket | Python-observed admission budget | Observation |
|---|---:|---:|---:|---|
| Node 22.22.3 | 200ms | 140.940ms | 102ms | authored work observed, uncontained |
| Node 22.22.3 | 5000ms | 148.073ms | 4909ms | independent positive, uncontained |
| native Bun 1.3.8 | 200ms | 154.104ms | 96ms | authored work observed, uncontained |
| native Bun 1.3.8 | 5000ms | 121.562ms | 4910ms | independent positive, uncontained |

Raw retained directories: `outputs/node-nm5ttl/` and `outputs/bun-CE2hRL/`. `evidence/actual-runtime-summary.json` and `real-{node,bun}-assertions.json` retain bindings, full original results and before-fixture-cleanup observations. All four have actual public-document work/report evidence, complete sidecars, existing supervisor/worker reap and natural-close receipts, no forced pipe close, no database, and no reported PID present at the recorded pre-cleanup sample. Sampling is not kernel identity proof. All original **uncontained** errors remain; `productQualified=false`, `containmentVerified=false`.

Selected product Python was CLT **3.9.6** at `/Library/Developer/CommandLineTools/usr/bin/python3`, reached via the literal interpreter argv. Review Python **3.12.13** only compiled the same four retained generated wrappers for static verification. Wrapper code still hashes and compiles original source without AST rewriting/tracing/sleeps; the same original read is called once and its result returned unchanged.

These are local warmed/instrumented Darwin **27.2.0 arm64** observations, not macOS CI or cold-start causality. All clocks retain their independent process-local labels; unsupported caller milestones are null. Native Bun owner observation remains null/unsupported. Node's listener baseline was established **after importing** the unchanged caller closure; a separate import-only proof attributes its two persistent library signal listeners, not per-call leaks. The original review's failed pre-import-baseline outer receipt remains untouched at its frozen owner root.

## Workflow, live scope and remaining gates

Fresh YAML/shell checks prove the workflow copy is unchanged, the canonical prefix is still `d723590bbdca7e4e20a61eb6782d77f25defd3a633403c2c9d654ecfcfa00aa1`, and removing only original B additions reconstructs the exact original workflow. Supplemental steps remain after suite/smoke and old observer selftests, always-on-macOS, non-gating and two-minute bounded. Canonical commands/order/maxWorkers=2/runtime pins/deadlines/actions/upload paths remain unchanged. Actionlint was not rerun because these bytes are unchanged; its prior independent passing receipt is not presented as a fresh repair run or GitHub Actions execution.

Live B helpers remain absent and live workflow remains its original preimage. Parent's authorized concurrent A integration appeared as changes to `test/audit-recovery-execution-admission.test.ts` and `test/fixtures/bun_recovery_ownership.ts`; those transitions are recorded, not imported, reverted or treated as isolation failures. No whole-live-tree equality claim is required. At source finalization the live HEAD was still `a6144903be9715334f66bd9ea134157f679516a5`; later authorized parent commits/pushes are outside this lane.

No live source, frozen producer/review/parent roots, production, dependencies, locks, docs, skills, configuration, services or personal index were written. No staging, commit, network, installation, delegation, GPU or model activity was performed.

**Still required:** fresh independent SPEC → QUALITY review of this exact repair, parent replay/integration and combined canonical/package/real-CI acceptance. Historical macOS failures, cold-causal attribution, paused-owner C1 limits and the separate full-native-Bun Vitest SIGTRAP are not resolved by this bounded repair.
