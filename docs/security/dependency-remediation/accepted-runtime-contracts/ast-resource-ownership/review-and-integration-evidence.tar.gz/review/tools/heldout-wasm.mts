import assert from "node:assert/strict";
import { getASTBreakPoints, getASTStatus } from "../candidate/src/ast.ts";
import { Parser, Tree, Query } from "../candidate/node_modules/web-tree-sitter/web-tree-sitter.js";

// Real exports and native WASM throughout: no Vitest/module mocks or fake trees.
// Throwing-destructor controls throw BEFORE native delegation. Fixture cleanup is
// recorded after product snapshots and is never counted as a product release.
const runtime = process.versions.bun ? "bun" : "node";
assert.equal(runtime, process.env.QMD_EXPECT_RUNTIME);
const status = await getASTStatus();
assert.equal(status.available, true);
assert.equal(status.languages.length, 6);
for (const entry of status.languages) assert.equal(entry.available, true, entry.language);
const content = "export class Box { method() {} }\nexport function echo() {}\n";
const expected = [
  { token: "export class", type: "export", score: 90 },
  { token: "class Box", type: "class", score: 100 },
  { token: "method()", type: "method", score: 90 },
  { token: "export function", type: "export", score: 90 },
  { token: "function echo", type: "func", score: 90 },
].map(({ token, type, score }) => ({ pos: content.indexOf(token), type: `ast:${type}`, score }));
assert.deepEqual(await getASTBreakPoints(content, "heldout.ts"), expected);
const originals = {
  setLanguage: Parser.prototype.setLanguage,
  parse: Parser.prototype.parse,
  parserDelete: Parser.prototype.delete,
  treeDelete: Tree.prototype.delete,
  root: Object.getOwnPropertyDescriptor(Tree.prototype, "rootNode")!,
  captures: Query.prototype.captures,
  warn: console.warn,
};
const observedParsers = new WeakSet<object>();
const observedTrees = new WeakSet<object>();
type Options = {
  stage?: "setLanguage-native" | "parse-native" | "null-native" | "root" | "captures" | "iteration";
  treeError?: boolean;
  parserError?: boolean;
  empty?: boolean;
  extension?: string;
};
const results: unknown[] = [];
async function runOne(name: string, options: Options = {}) {
  const parsers = new Map<Parser, { attempts: number; nativeReturned: boolean }>();
  const trees = new Map<Tree, { attempts: number; nativeReturned: boolean }>();
  const events: string[] = [];
  const warnings: string[] = [];
  let nativeCaptures = 0;
  let pointResult: unknown;
  let productSnapshot: unknown;
  let failure: string | null = null;
  const fixtureEvents: string[] = [];
  Parser.prototype.setLanguage = function(language) {
    assert(!observedParsers.has(this), "a parser was reused across calls");
    observedParsers.add(this);
    parsers.set(this, { attempts: 0, nativeReturned: false });
    events.push("setLanguage");
    // Genuine installed-library rejection, not an invented thrown message.
    return originals.setLanguage.call(this, options.stage === "setLanguage-native" ? {} as never : language);
  };
  Parser.prototype.parse = function(source, oldTree, parseOptions) {
    events.push("parse");
    if (options.stage === "null-native") originals.setLanguage.call(this, null);
    const tree = originals.parse.call(this, options.stage === "parse-native" ? undefined as never : source, oldTree, parseOptions);
    if (tree) {
      assert(tree instanceof Tree, "must be an actual native Tree");
      assert(!observedTrees.has(tree), "a tree was reused across calls");
      observedTrees.add(tree);
      trees.set(tree, { attempts: 0, nativeReturned: false });
      events.push("native-tree-returned");
    } else events.push("native-null-returned");
    return tree;
  };
  Object.defineProperty(Tree.prototype, "rootNode", {
    ...originals.root,
    get() {
      events.push("rootNode");
      if (options.stage === "root") throw new Error("heldout root operation");
      return originals.root.get!.call(this);
    },
  });
  Query.prototype.captures = function(node, queryOptions) {
    const captures = originals.captures.call(this, node, queryOptions);
    nativeCaptures++;
    events.push("native-captures-returned");
    if (options.stage === "captures") throw new Error("heldout captures operation");
    if (options.stage === "iteration") {
      assert(captures.length > 1);
      captures[Symbol.iterator] = function*() {
        yield captures[0]!;
        throw new Error("heldout iteration operation");
      };
    }
    return captures;
  };
  Tree.prototype.delete = function() {
    const record = trees.get(this);
    assert(record, "only the acquired tree may be released");
    record.attempts++;
    events.push("tree.delete");
    if (options.treeError) throw new Error("heldout tree cleanup");
    originals.treeDelete.call(this);
    record.nativeReturned = true;
  };
  Parser.prototype.delete = function() {
    const record = parsers.get(this);
    assert(record, "only the acquired parser may be released");
    record.attempts++;
    events.push("parser.delete");
    if (options.parserError) throw new Error("heldout parser cleanup");
    originals.parserDelete.call(this);
    record.nativeReturned = true;
  };
  console.warn = (...args) => warnings.push(args.map(String).join(" "));
  try {
    pointResult = await getASTBreakPoints(options.empty ? "" : content, `heldout.${options.extension ?? "ts"}`);
    productSnapshot = {
      parserCount: parsers.size, treeCount: trees.size,
      parserAttempts: [...parsers.values()].map(x => x.attempts),
      treeAttempts: [...trees.values()].map(x => x.attempts),
      parserNativeReturned: [...parsers.values()].map(x => x.nativeReturned),
      treeNativeReturned: [...trees.values()].map(x => x.nativeReturned),
      events: [...events], warnings: [...warnings], points: pointResult, nativeCaptures,
    };
    assert.equal(parsers.size, 1, "actual product Parser must reach instrumented public API");
    const hasTree = !["setLanguage-native", "parse-native", "null-native"].includes(options.stage ?? "");
    assert.equal(trees.size, hasTree ? 1 : 0);
    for (const record of parsers.values()) assert.equal(record.attempts, 1, "parser release attempts");
    for (const record of trees.values()) assert.equal(record.attempts, 1, "tree release attempts");
    assert.deepEqual(events.filter(e => e.endsWith(".delete")), hasTree ? ["tree.delete", "parser.delete"] : ["parser.delete"]);
    const operation = options.stage && options.stage !== "null-native";
    const fallback = operation || options.treeError || options.parserError;
    assert.deepEqual(pointResult, fallback || options.empty || options.stage === "null-native" ? [] : expected);
    assert.equal(warnings.length, fallback ? 1 : 0);
    if (fallback) {
      assert(warnings[0]!.startsWith(`[qmd] AST parse failed for heldout.${options.extension ?? "ts"}, falling back to regex: `));
      const expectedErrors: string[] = [];
      if (options.stage === "setLanguage-native") expectedErrors.push("Argument must be a Language");
      if (options.stage === "parse-native") expectedErrors.push("Argument must be a string or a function");
      if (options.stage === "root") expectedErrors.push("heldout root operation");
      if (options.stage === "captures") expectedErrors.push("heldout captures operation");
      if (options.stage === "iteration") expectedErrors.push("heldout iteration operation");
      if (options.treeError) expectedErrors.push("heldout tree cleanup");
      if (options.parserError) expectedErrors.push("heldout parser cleanup");
      let previous = -1;
      for (const message of expectedErrors) {
        const position = warnings[0]!.indexOf(message);
        assert(position > previous, `original/cleanup message ordering: ${message}`);
        previous = position;
      }
    }
    if (hasTree && options.stage !== "root") assert.equal(nativeCaptures, 1);
  } catch (error) {
    failure = error instanceof Error ? error.stack ?? error.message : String(error);
  } finally {
    Parser.prototype.setLanguage = originals.setLanguage;
    Parser.prototype.parse = originals.parse;
    Parser.prototype.delete = originals.parserDelete;
    Tree.prototype.delete = originals.treeDelete;
    Object.defineProperty(Tree.prototype, "rootNode", originals.root);
    Query.prototype.captures = originals.captures;
    console.warn = originals.warn;
    // Snapshot above is immutable. Native cleanup below is explicitly fixture-owned.
    for (const [tree, record] of trees) if (!record.nativeReturned) {
      originals.treeDelete.call(tree);
      fixtureEvents.push("fixture.tree.delete");
    }
    for (const [parser, record] of parsers) if (!record.nativeReturned) {
      originals.parserDelete.call(parser);
      fixtureEvents.push("fixture.parser.delete");
    }
  }
  results.push({ name, options, passed: failure === null, failure, productSnapshot, fixtureEvents });
}
const cases: [string, Options][] = [
  ["success", {}],
  ["empty-real-tree", { empty: true }],
  ["native-setLanguage-rejection", { stage: "setLanguage-native" }],
  ["native-parse-rejection", { stage: "parse-native" }],
  ["native-null-tree", { stage: "null-native" }],
  ["real-tree-root-failure", { stage: "root" }],
  ["real-captures-then-failure", { stage: "captures" }],
  ["partial-capture-iteration-failure", { stage: "iteration" }],
  ["tree-destructor-predelegate-failure", { treeError: true }],
  ["parser-destructor-predelegate-failure", { parserError: true }],
  ["both-destructors-predelegate-failure", { treeError: true, parserError: true }],
  ["native-setLanguage-plus-parser-failure", { stage: "setLanguage-native", parserError: true }],
  ["captures-plus-both-destructor-failures", { stage: "captures", treeError: true, parserError: true }],
];
for (const [name, options] of cases) {
  await runOne(name, options);
  if (name !== "success" && name !== "empty-real-tree") await runOne(`${name}-same-module-recovery`, { extension: "mts" });
}
assert.deepEqual(await getASTStatus(), status, "failures must not poison grammar/query availability");
const failures = results.filter((x: any) => !x.passed).length;
console.log(JSON.stringify({ runtime, execPath: process.execPath, versions: process.versions,
  status, expected, caseCount: results.length, passed: results.length - failures, failed: failures, results }, null, 2));
process.exitCode = failures ? 1 : 0;
