from pathlib import Path
import hashlib, json, os, stat, subprocess
root = Path(__file__).resolve().parents[1]
evidence = root/'evidence'
producer = Path('/Users/shersingh/.hermes/cache/scratch/qmd-ast-ownership-rx4oinc5')
live = Path('/Users/shersingh/github/qmd-mlx-search')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
intake = load(evidence/'intake.json')
post = intake['candidatePostimages']
pre = intake['closure']['src/ast.ts']
expected_hosts = {'node':('/Users/shersingh/.hermes/node/bin/node','22.22.3'), 'bun':('/Users/shersingh/.bun/bin/bun','1.3.8')}
qualified = {}
for receipt_path in sorted(evidence.glob('q-*.receipt.json')):
 r = load(receipt_path); label = r['label']; host = 'bun' if 'bun' in label else 'node'
 assert not r['timedOut']
 for var in ['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE','UV_OFFLINE','CI','REQUIRE_BUN']:
  assert r['environment'][var] == '1', (label,var)
 assert r['environment']['QMD_LLAMA_GPU'] == 'false'
 assert r['environment']['HOME'] == str(root/'home')
 assert all(r['harnessSha256AtLaunch'][p] == sha(root/'tools'/p) for p in r['harnessSha256AtLaunch'])
 assert r['sourceSha256AtLaunch']['test/ast-lifecycle.test.ts'] == post['test/ast-lifecycle.test.ts']
 assert sha(Path(r['stdout'])) == r['stdoutSha256']
 assert sha(Path(r['stderr'])) == r['stderrSha256']
 before = any(x in label for x in ['-red-','-baseline-','-before-'])
 assert r['sourceSha256AtLaunch']['src/ast.ts'] == (pre if before else post['src/ast.ts'])
 if 'vitest' in r:
  files = r['files']; a = [t for f in files for t in f['tests']]
  counts = {status:sum(t['status']==status for t in a) for status in ['passed','failed','pending','skipped','todo']}
  assert len(a) == counts['passed']+counts['failed']
  assert r['vitest']['numPassedTests'] == counts['passed'] and r['vitest']['numFailedTests'] == counts['failed']
  if '-red-' in label:
   assert (len(files),len(a),counts['passed'],counts['failed'],r['rawReturnCode']) == (1,24,9,15,1)
   assert all('to be called 1 times, but got 0 times' in '\n'.join(t['failureMessages']) for t in a if t['status']=='failed')
  elif '-baseline-' in label: assert (len(files),len(a),counts['passed'],r['rawReturnCode']) == (2,38,38,0)
  else: assert (len(files),len(a),counts['passed'],r['rawReturnCode']) == (3,62,62,0)
  assert len(r['testHosts']) == len(files)
  for h in r['testHosts']:
   assert h['runtime'] == host and h['execPath'] == expected_hosts[host][0]
   assert h['versions'][host] == expected_hosts[host][1]
  qualified[label] = {'runtime':host,'fileCount':len(files),'passed':counts['passed'],'failed':counts['failed'],
   'skipped':0,'rawReturnCode':r['rawReturnCode'],'receipt':str(receipt_path),'workerIdentities':r['testHosts']}
 else:
  d = load(Path(r['stdout']))
  assert d['runtime'] == host and d['execPath'] == expected_hosts[host][0]
  assert d['versions'][host] == expected_hosts[host][1]
  assert d['status']['available'] and len(d['status']['languages'])==6
  assert all(x['available'] for x in d['status']['languages'])
  if 'heldout' in label:
   assert len(d['results']) == d['caseCount'] == 24
   assert sum(x['passed'] for x in d['results']) == d['passed']
   assert sum(not x['passed'] for x in d['results']) == d['failed']
   target = (15,9,1) if '-red-' in label else (24,0,0)
   assert (d['passed'],d['failed'],r['rawReturnCode']) == target
   qualified[label] = {'runtime':host,'caseCount':24,'passed':d['passed'],'failed':d['failed'],
    'rawReturnCode':r['rawReturnCode'],'receipt':str(receipt_path),'failedCases':[x['name'] for x in d['results'] if not x['passed']]}
  else:
   assert len(d['results']) == 6 and r['rawReturnCode']==0
   qualified[label] = {'runtime':host,'languageCount':6,'rawReturnCode':0,'stdoutSha256':r['stdoutSha256'],'receipt':str(receipt_path)}
assert len(qualified)==14
transitions = {}
for host in ['node','bun']:
 red = load(evidence/f'q-red-{host}.receipt.json'); green = load(evidence/f'q-green-{host}.receipt.json')
 ra = {t['name']:t['status'] for f in red['files'] for t in f['tests']}
 ga = {t['name']:t['status'] for f in green['files'] if f['name'].endswith('/ast-lifecycle.test.ts') for t in f['tests']}
 assert len(ra)==24 and set(ra)==set(ga) and all(x=='passed' for x in ga.values())
 assert red['sourceSha256AtLaunch']['test/ast-lifecycle.test.ts'] == green['sourceSha256AtLaunch']['test/ast-lifecycle.test.ts']
 hr = load(evidence/f'q-heldout-red-{host}.receipt.json'); hg = load(evidence/f'q-heldout-green-{host}.receipt.json')
 assert hr['harnessSha256AtLaunch']['heldout-wasm.mts'] == hg['harnessSha256AtLaunch']['heldout-wasm.mts']
 before = (evidence/f'q-before-{host}-wasm.stdout.txt').read_bytes(); after=(evidence/f'q-after-{host}-wasm.stdout.txt').read_bytes()
 assert before==after
 transitions[host] = {'same24LifecycleNames':True,'sameLifecycleTestBytes':True,'failingCasesTransitioned':sum(v=='failed' for v in ra.values()),
  'sameHeldoutProbeBytes':True,'all24HeldoutCasesGreen':True,'wasmOutputByteIdentical':True,'wasmOutputSha256':hashlib.sha256(after).hexdigest()}
for rel,digest in intake['closure'].items(): assert sha(root/'candidate'/rel)==post.get(rel,digest), rel
assert sha(root/'ast-lifecycle.patch') == '1539352e30bb2ecd2f8b52a3195dd86867e71c2d27d065127569e511d6335116'
# Reauthenticate producer frozen bytes without executing any frozen tools.
index = load(producer/'review-index.json')
assert sha(producer/'review-index.json') == '2cf1cec4c5626aa674becc2584c959cb06f41bc973857c5b01d0c1099e061cd9'
for rel,item in index['artifacts'].items(): assert sha(producer/rel)==item['sha256'], rel
candidate_manifest = load(producer/'evidence/candidate-manifest.json')
for rel,digest in candidate_manifest['sourceSha256'].items(): assert sha(producer/'candidate'/rel)==digest, rel

def inventory(path):
 rows={}
 for directory,dirs,files in os.walk(path,followlinks=False):
  for name in sorted(dirs+files):
   p=Path(directory)/name; s=p.lstat(); rel=str(p.relative_to(path))
   if name=='AGENTS.md': row={'kind':'AGENTS-metadata-only','mode':stat.S_IMODE(s.st_mode),'size':s.st_size,'mtime_ns':s.st_mtime_ns}
   elif p.is_symlink(): row={'kind':'symlink','target':os.readlink(p)}
   elif p.is_file(): row={'kind':'file','size':s.st_size,'sha256':sha(p)}
   elif p.is_dir(): row={'kind':'directory'}
   else: row={'kind':'special','mode':s.st_mode}
   rows[rel]=row
 return rows
before=load(evidence/'dependencies-before.json'); after=inventory(live/'node_modules')
(evidence/'dependencies-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
delta={'added':sorted(set(after)-set(before)), 'removed':sorted(set(before)-set(after)),
 'changed':sorted(p for p in set(before)&set(after) if before[p]!=after[p])}
assert not any(delta.values()), delta
base=load(Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-final-composition-mer5fi8x/candidate-manifest.json'))['sourceSha256']
live_deltas={rel:{'bound':digest,'current':sha(live/rel)} for rel,digest in base.items() if sha(live/rel)!=digest}
assert live_deltas == intake['authorizedLiveDeltas'], live_deltas
assert sha(live/'src/ast.ts')==pre and not (live/'test/ast-lifecycle.test.ts').exists()
for p in ['test/ast.test.ts','test/ast-chunking.test.ts']: assert sha(live/p)==base[p]
modules=root/'candidate/node_modules'
assert modules.is_dir() and not modules.is_symlink()
assert all((modules/n).is_dir() and not (modules/n).is_symlink() for n in ['.vite','.vite-temp','.cache','.vitest'])
report={'qualifiedRuns':qualified,'transitions':transitions,'qualifiedRunCount':len(qualified),
 'payloadSha256':post,'patchSha256':sha(root/'ast-lifecycle.patch'),
 'producerArtifactsReverified':85,'producerSourcePostimagesReverified':299,
 'ownedPublicSourceClosureCount':len(intake['closure']), 'ownedSourceComplementUnchanged':True,
 'dependencyBeforeRowCount':len(before),'dependencyAfterRowCount':len(after),'dependencyDelta':delta,
 'dependencyBeforeSha256':sha(evidence/'dependencies-before.json'),'dependencyAfterSha256':sha(evidence/'dependencies-after.json'),
 'ownedCachesBeforeFirstRed':intake['ownedCaches'],'ownedCachesAfter':True,
 'liveAstUnchanged':True,'liveExistingAstTestsUnchanged':True,'liveNewLifecycleTestAbsent':True,
 'authorizedUnrelatedLiveDeltasUnchanged':live_deltas,
 'harnessIssues':['intake-first-failure.json','isolation-correction.json'],
 'scope':'Independent source-bound SPEC inputs; not full-project/type/package/build/CI/release acceptance'}
(evidence/'verification-summary.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='qualifiedRuns'},indent=2))
print('qualified counts:',json.dumps({k:{p:v[p] for p in ['fileCount','caseCount','passed','failed','rawReturnCode'] if p in v} for k,v in qualified.items()},indent=2))
