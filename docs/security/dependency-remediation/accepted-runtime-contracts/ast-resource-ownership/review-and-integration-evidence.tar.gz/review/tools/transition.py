from pathlib import Path
import hashlib, json, os, shutil, subprocess
root = Path(__file__).resolve().parents[1]
base_root = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-final-composition-mer5fi8x')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
intake = json.loads((root/'evidence/intake.json').read_text())
work = root/'candidate'
assert sha(work/'src/ast.ts') == intake['closure']['src/ast.ts']
assert sha(work/'test/ast-lifecycle.test.ts') == intake['candidatePostimages']['test/ast-lifecycle.test.ts']
for host in ['node','bun']:
 red = json.loads((root/f'evidence/red-{host}.receipt.json').read_text())
 assert red['rawReturnCode'] == 1 and red['vitest']['numPassedTests'] == 9 and red['vitest']['numFailedTests'] == 15
 assert red['sourceSha256AtLaunch']['src/ast.ts'] == intake['closure']['src/ast.ts']
 assert red['sourceSha256AtLaunch']['test/ast-lifecycle.test.ts'] == intake['candidatePostimages']['test/ast-lifecycle.test.ts']
 assert all('to be called 1 times, but got 0 times' in '\n'.join(t['failureMessages']) for f in red['files'] for t in f['tests'] if t['status'] == 'failed')
replay = root/'patch-replay'
(replay/'src').mkdir(parents=True)
(replay/'test').mkdir()
shutil.copy2(base_root/'candidate/src/ast.ts', replay/'src/ast.ts')
env = {'HOME':str(root/'home'),'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}
commands = []
for args in [['--numstat'], ['--check'], []]:
 argv = ['/usr/bin/git','apply',*args,str(root/'ast-lifecycle.patch')]
 p = subprocess.run(argv,cwd=replay,env=env,capture_output=True,text=True)
 commands.append({'argv':argv,'cwd':str(replay),'rawReturnCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 assert p.returncode == 0, commands[-1]
post = {rel:sha(replay/rel) for rel in intake['candidatePostimages']}
assert post == intake['candidatePostimages']
assert sorted(str(p.relative_to(replay)) for p in replay.rglob('*') if p.is_file()) == sorted(post)
shutil.copy2(replay/'src/ast.ts',work/'src/ast.ts')
assert all(sha(work/p) == digest for p,digest in intake['closure'].items() if p != 'src/ast.ts')
report = {'commands':commands,'patchSha256':sha(root/'ast-lifecycle.patch'),
 'preimageSha256':intake['closure']['src/ast.ts'],'postimages':post,
 'candidateComplementUnchanged':True,'protectedTestsUnchanged':True,
 'lifecycleTestUnchangedBetweenRedAndGreen':True,'heldoutProbeSha256':sha(root/'tools/heldout-wasm.mts'),
 'harnessDelta':'Only owned run.py probe mode gained selection of review-only heldout-wasm.mts; original runner config, assertion deadlines and Vitest arguments unchanged.'}
(root/'evidence/patch-replay.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
