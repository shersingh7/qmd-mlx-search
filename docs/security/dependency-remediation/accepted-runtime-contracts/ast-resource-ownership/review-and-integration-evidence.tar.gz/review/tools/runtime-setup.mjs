import { writeFileSync } from "node:fs";

const runtime = process.versions.bun ? "bun" : "node";
if (runtime !== process.env.QMD_EXPECT_RUNTIME) {
  throw new Error(`Wrong test-host runtime: expected ${process.env.QMD_EXPECT_RUNTIME}, got ${runtime}`);
}
writeFileSync(`${process.env.QMD_RUNTIME_PROOF}.${process.pid}.json`, JSON.stringify({
  runtime, execPath: process.execPath, versions: process.versions,
  pid: process.pid, ppid: process.ppid, cwd: process.cwd(),
}, null, 2) + "\n");
