import assert from "node:assert/strict";
import { getASTBreakPoints, getASTStatus } from "../candidate/src/ast.ts";

const samples = [
  { language: "typescript", extension: "ts", content: "export function alpha() { return 1; }\nclass Beta {}\n", declarations: [
    { token: "export", type: "export", score: 90 }, { token: "function", type: "func", score: 90 },
    { token: "class", type: "class", score: 100 },
  ] },
  { language: "tsx", extension: "tsx", content: "export function Widget() { return <div />; }\n", declarations: [
    { token: "export", type: "export", score: 90 }, { token: "function", type: "func", score: 90 },
  ] },
  { language: "javascript", extension: "js", content: "export function alpha() { return 1; }\nclass Beta {}\n", declarations: [
    { token: "export", type: "export", score: 90 }, { token: "function", type: "func", score: 90 },
    { token: "class", type: "class", score: 100 },
  ] },
  { language: "python", extension: "py", content: "class Alpha:\n    pass\n\ndef beta():\n    pass\n", declarations: [
    { token: "class", type: "class", score: 100 }, { token: "def", type: "func", score: 90 },
  ] },
  { language: "go", extension: "go", content: "package main\n\ntype Alpha struct {}\n\nfunc beta() {}\n", declarations: [
    { token: "type", type: "type", score: 80 }, { token: "func", type: "func", score: 90 },
  ] },
  { language: "rust", extension: "rs", content: "struct Alpha {}\n\nfn beta() {}\n", declarations: [
    { token: "struct", type: "struct", score: 100 }, { token: "fn", type: "func", score: 90 },
  ] },
];
const status = await getASTStatus();
assert.equal(status.available, true);
assert.equal(status.languages.length, 6);
assert(status.languages.every(item => item.available));
const results = [];
for (const sample of samples) {
  const expected = sample.declarations.map(({ token, type, score }) => ({
    pos: sample.content.indexOf(token), score, type: `ast:${type}`,
  })).sort((a, b) => a.pos - b.pos);
  const points = await getASTBreakPoints(sample.content, `synthetic.${sample.extension}`);
  assert.deepEqual(points, expected, sample.language);
  results.push({ language: sample.language, content: sample.content, points });
}
console.log(JSON.stringify({ runtime: process.versions.bun ? "bun" : "node",
  execPath: process.execPath, versions: process.versions, status, results }, null, 2));
