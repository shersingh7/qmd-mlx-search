from pathlib import Path
import hashlib, json, os, signal, subprocess, sys, time

root = Path(__file__).resolve().parent.parent
work = root / 'candidate'
evidence = root / 'evidence'
label, runtime, mode, *args = sys.argv[1:]
assert runtime in ['node', 'bun'] and mode in ['vitest', 'probe', 'types']
assert label.replace('-', '').isalnum()
assert not (evidence/f'{label}.receipt.json').exists(), 'Use a fresh label; retained receipts are immutable'
node = '/Users/shersingh/.hermes/node/bin/node'
bun = '/Users/shersingh/.bun/bin/bun'
env = {
    'PATH': '/Users/shersingh/.hermes/node/bin:/Users/shersingh/.bun/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    'HOME': str(root/'home'), 'HERMES_HOME': str(root/'hermes'),
    'HERMES_KNOWLEDGE_DIR': str(root/'knowledge'),
    'XDG_CACHE_HOME': str(root/'xdg/cache'), 'XDG_CONFIG_HOME': str(root/'xdg/config'),
    'XDG_DATA_HOME': str(root/'xdg/data'), 'XDG_STATE_HOME': str(root/'xdg/state'),
    'HF_HOME': str(root/'hf'), 'HF_HUB_CACHE': str(root/'hf/hub'),
    'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1',
    'HF_DATASETS_CACHE': str(root/'hf/datasets'),
    'UV_OFFLINE': '1', 'UV_CACHE_DIR': str(root/'uv'),
    'QMD_LLAMA_GPU': 'false', 'CI': '1', 'REQUIRE_BUN': '1',
    'TMPDIR': str(root/'tmp')+'/', 'TMP': str(root/'tmp'), 'TEMP': str(root/'tmp'),
    'BUN_INSTALL': str(root/'bun'), 'BUN_INSTALL_CACHE_DIR': str(root/'bun/cache'),
    'NPM_CONFIG_CACHE': str(root/'npm'), 'VITE_CACHE_DIR': str(root/'vite'),
    'QMD_EXPECT_RUNTIME': runtime, 'QMD_RUNTIME_PROOF': str(evidence/f'{label}.testhost'),
    'LANG': 'en_US.UTF-8', 'TZ': 'UTC', 'NO_COLOR': '1',
}
if mode == 'vitest':
    argv = [node] if runtime == 'node' else [bun, '--bun']
    argv += ['node_modules/vitest/vitest.mjs', 'run', '--config', str(root/'tools/vitest-config.mts'),
        '--configLoader', 'runner', '--no-cache', '--maxWorkers=1', '--reporter=json',
        f'--outputFile={evidence/label}.vitest.json', *args]
elif mode == 'probe':
    assert args in [[], ['heldout']]
    probe = str(root/'tools'/('heldout-wasm.mts' if args else 'wasm-probe.mts'))
    argv = [node, '--import', 'tsx', probe] if runtime == 'node' else [bun, '--bun', probe]
else:
    argv = [node, str(root/'tools/types.cjs')]
    assert runtime == 'node'

hashes = {}
for rel in ['src/ast.ts', 'test/ast-lifecycle.test.ts', 'test/ast.test.ts', 'test/ast-chunking.test.ts', 'vitest.config.ts', 'package.json', 'bun.lock', 'pnpm-lock.yaml']:
    p = work/rel
    if p.exists(): hashes[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
harness_hashes = {p: hashlib.sha256((root/'tools'/p).read_bytes()).hexdigest() for p in ['run.py','runtime-setup.mjs','vitest-config.mts','wasm-probe.mts','heldout-wasm.mts']}
start = time.time()
process = subprocess.Popen(argv, cwd=work, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=150)
except subprocess.TimeoutExpired:
    timed_out = True
    # The unreaped leader still pins the owned process-group identity here.
    os.killpg(process.pid, signal.SIGKILL)
    stdout, stderr = process.communicate()
stdout_path = evidence/f'{label}.stdout.txt'
stderr_path = evidence/f'{label}.stderr.txt'
stdout_path.write_bytes(stdout)
stderr_path.write_bytes(stderr)
report = {
    'label': label, 'cwd': str(work), 'argv': argv, 'environment': env,
    'rawReturnCode': process.returncode, 'timedOut': timed_out,
    'elapsedSeconds': time.time()-start,
    'sourceSha256AtLaunch': hashes,
    'harnessSha256AtLaunch': harness_hashes,
    'stdout': str(stdout_path), 'stderr': str(stderr_path),
    'stdoutSha256': hashlib.sha256(stdout).hexdigest(), 'stderrSha256': hashlib.sha256(stderr).hexdigest(),
    'testHosts': [json.loads(p.read_text()) for p in sorted(evidence.glob(f'{label}.testhost.*.json'))],
}
vitest_path = evidence/f'{label}.vitest.json'
if vitest_path.exists():
    result = json.loads(vitest_path.read_text())
    report['vitest'] = {k: result[k] for k in ['success', 'numTotalTestSuites', 'numPassedTestSuites', 'numFailedTestSuites', 'numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests'] if k in result}
    report['files'] = [{ 'name': item['name'], 'status': item['status'],
        'tests': [{ 'name': test['fullName'], 'status': test['status'], 'failureMessages': test['failureMessages'] } for test in item['assertionResults']] } for item in result['testResults']]
(evidence/f'{label}.receipt.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['environment','sourceSha256AtLaunch','files','testHosts']},indent=2))
print('test hosts:', json.dumps([{'runtime': h['runtime'], 'execPath': h['execPath'], 'node': h['versions'].get('node'), 'bun': h['versions'].get('bun')} for h in report['testHosts']]))
if process.returncode != 0:
    print(stdout.decode(errors='replace')[-5000:])
    print(stderr.decode(errors='replace')[-5000:])
sys.exit(process.returncode if process.returncode >= 0 else 128-process.returncode)
