import original from "../candidate/vitest.config.ts";

// Receipt-only setup; retain the repository configuration and test deadlines.
export default {
  ...original,
  test: {
    ...original.test,
    setupFiles: [new URL("./runtime-setup.mjs", import.meta.url).pathname],
  },
};
