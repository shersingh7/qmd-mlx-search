from pathlib import Path
import hashlib, json, os, re, shutil, stat, subprocess, sys

root = Path(__file__).resolve().parents[1]
producer = Path('/Users/shersingh/.hermes/cache/scratch/qmd-ast-ownership-rx4oinc5')
base_root = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-final-composition-mer5fi8x')
live = Path('/Users/shersingh/github/qmd-mlx-search')
shared = live/'node_modules'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = {
 'REPORT.md':'f2d113a8fb7749049bc456e79bf91233e9c1234437e94f82a7763b0c9f956c10',
 'ast-lifecycle.patch':'1539352e30bb2ecd2f8b52a3195dd86867e71c2d27d065127569e511d6335116',
 'review-index.json':'2cf1cec4c5626aa674becc2584c959cb06f41bc973857c5b01d0c1099e061cd9',
}
for rel,digest in expected.items(): assert sha(producer/rel) == digest, rel
index = json.loads((producer/'review-index.json').read_text())
assert len(index['artifacts']) == index['artifactCount'] == 85
for rel,item in index['artifacts'].items():
 assert Path(rel).name != 'AGENTS.md'
 assert sha(producer/rel) == item['sha256'], rel
 assert (producer/rel).stat().st_size == item['bytes'], rel
base_manifest = base_root/'candidate-manifest.json'
assert sha(base_manifest) == 'cada46c60b45ccd367282c06c6daecc58f233ff2c831c96c53318b597e29d3b0'
base = json.loads(base_manifest.read_text())['sourceSha256']
post = json.loads((producer/'evidence/candidate-manifest.json').read_text())['sourceSha256']
assert len(base) == 298 and len(post) == 299
assert sorted(set(post)-set(base)) == ['test/ast-lifecycle.test.ts']
assert sorted(p for p in base if base[p] != post[p]) == ['src/ast.ts']
for rel,digest in post.items():
 assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and Path(rel).name != 'AGENTS.md'
 assert sha(producer/'candidate'/rel) == digest, rel
assert sha(base_root/'candidate/src/ast.ts') == base['src/ast.ts']
live_deltas = {rel:{'bound':digest,'current':sha(live/rel)} for rel,digest in base.items() if sha(live/rel) != digest}
assert sorted(live_deltas) == ['flake.nix','test/security/test_gguf_workflow_controller.py'], live_deltas
assert not (live/'test/ast-lifecycle.test.ts').exists()

# Explicit public source closure of the three focused suites, plus runner metadata.
seeds = ['src/ast.ts','test/ast.test.ts','test/ast-chunking.test.ts','test/ast-lifecycle.test.ts',
         'vitest.config.ts','package.json','tsconfig.json','bun.lock','pnpm-lock.yaml']
closure = set()
queue = list(seeds)
def actual_imports(path):
 code = """const ts=require('/Users/shersingh/github/qmd-mlx-search/node_modules/typescript');
const fs=require('node:fs'); const p=process.argv[1];
const sf=ts.createSourceFile(p,fs.readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true);
const out=[]; function visit(n) {
 if ((ts.isImportDeclaration(n)||ts.isExportDeclaration(n))&&n.moduleSpecifier&&ts.isStringLiteral(n.moduleSpecifier)) out.push(n.moduleSpecifier.text);
 if (ts.isCallExpression(n)&&n.expression.kind===ts.SyntaxKind.ImportKeyword&&n.arguments.length===1&&ts.isStringLiteral(n.arguments[0])) out.push(n.arguments[0].text);
 ts.forEachChild(n,visit);
} visit(sf); console.log(JSON.stringify(out.filter(p=>p.startsWith('.'))));"""
 result = subprocess.run(['/Users/shersingh/.hermes/node/bin/node','-e',code,str(path)],
  env={'PATH':'/usr/bin:/bin','HOME':str(root/'home')},capture_output=True,text=True,check=True)
 return json.loads(result.stdout)
while queue:
 rel = queue.pop()
 if rel in closure: continue
 assert rel in post, rel
 closure.add(rel)
 if Path(rel).suffix not in ['.ts','.mts','.js','.mjs']: continue
 for target in actual_imports(producer/'candidate'/rel):
  p = Path(os.path.normpath(str(Path(rel).parent/target)))
  candidates = [str(p)]
  if p.suffix in ['.js','.mjs','.cjs']: candidates += [str(p.with_suffix('.ts')),str(p.with_suffix('.mts'))]
  found = [c for c in candidates if c in post]
  assert found, (rel,target)
  queue.append(found[0])
work = root/'candidate'
work.mkdir()
for rel in sorted(closure):
 src = base_root/'candidate'/rel if rel == 'src/ast.ts' else producer/'candidate'/rel
 digest = base[rel] if rel == 'src/ast.ts' else post[rel]
 assert sha(src) == digest
 dest = work/rel
 dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(src,dest)
modules = work/'node_modules'
modules.mkdir()
aliases = {}
for entry in sorted(shared.iterdir()):
 if entry.name.startswith('.'): continue
 if entry.name.startswith('@'):
  (modules/entry.name).mkdir()
  packages = [(modules/entry.name/p.name,p) for p in sorted(entry.iterdir()) if not p.name.startswith('.')]
 else: packages = [(modules/entry.name,entry)]
 for dest,src in packages:
  dest.symlink_to(src, target_is_directory=src.is_dir())
  aliases[str(dest.relative_to(work))] = str(src)
for name in ['.vite','.vite-temp','.cache','.vitest']: (modules/name).mkdir()
for name in ['home','hermes','knowledge','xdg/cache','xdg/config','xdg/data','xdg/state','hf/hub','tmp','uv','npm','bun/cache','vite','evidence']:
 (root/name).mkdir(parents=True,exist_ok=True)
for rel in ['run.py','runtime-setup.mjs','vitest-config.mts','wasm-probe.mts']:
 shutil.copy2(producer/'tools'/rel,root/'tools'/rel)
shutil.copy2(producer/'ast-lifecycle.patch',root/'ast-lifecycle.patch')

def inventory(path):
 rows = {}
 for directory,dirs,files in os.walk(path,followlinks=False):
  for name in sorted(dirs+files):
   p = Path(directory)/name
   s = p.lstat(); rel = str(p.relative_to(path))
   if name == 'AGENTS.md': row = {'kind':'AGENTS-metadata-only','mode':stat.S_IMODE(s.st_mode),'size':s.st_size,'mtime_ns':s.st_mtime_ns}
   elif p.is_symlink(): row = {'kind':'symlink','target':os.readlink(p)}
   elif p.is_file(): row = {'kind':'file','size':s.st_size,'sha256':sha(p)}
   elif p.is_dir(): row = {'kind':'directory'}
   else: row = {'kind':'special','mode':s.st_mode}
   rows[rel] = row
 return rows
if __name__ == '__main__':
 deps = inventory(shared)
 (root/'evidence/dependencies-before.json').write_text(json.dumps(deps,sort_keys=True,indent=2)+'\n')
 env = {'PATH':'/usr/bin:/bin','HOME':str(root/'home'),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}
 head = subprocess.run(['/usr/bin/git','rev-parse','HEAD'],cwd=live,env=env,capture_output=True,text=True,check=True).stdout.strip()
 receipt = {'root':str(root),'frozenRoot':str(producer),'artifactCountVerified':len(index['artifacts']),
  'candidateSourceCountVerified':len(post),'baseSourceCount':len(base),'sourceComplementUnchanged':True,
  'closure':{p:(base[p] if p == 'src/ast.ts' else post[p]) for p in sorted(closure)},
  'candidatePostimages':{p:post[p] for p in ['src/ast.ts','test/ast-lifecycle.test.ts']},
  'liveHead':head,'authorizedLiveDeltas':live_deltas,'liveLifecycleTestAbsent':True,
  'dependencyAliases':aliases,'dependencyRowCount':len(deps),
  'ownedNodeModules':modules.is_dir() and not modules.is_symlink(),
  'ownedCaches':{n:(modules/n).is_dir() and not (modules/n).is_symlink() for n in ['.vite','.vite-temp','.cache','.vitest']},
  'reviewPython':{'execPath':sys.executable,'version':sys.version},
  'copiedTools':{p:sha(root/'tools'/p) for p in ['run.py','runtime-setup.mjs','vitest-config.mts','wasm-probe.mts']}}
 (root/'evidence/intake.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items() if k not in ['closure','dependencyAliases','copiedTools']},indent=2))
 print('public closure:',json.dumps(sorted(closure)))
