from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
assert not (root/'verdict.json').exists() and not (root/'review-index.json').exists()
summary = load(root/'evidence/verification-summary.json')
quality = load(root/'evidence/quality-check.json')
assert quality['rawReturnCode'] == 0
assert quality['specReportSha256'] == sha(root/'SPEC-REVIEW.md')
assert quality['boundPayloadSha256'] == summary['payloadSha256']
assert all(sha(root/'candidate'/p)==h for p,h in summary['payloadSha256'].items())
reports = {p:sha(root/p) for p in ['SPEC-REVIEW.md','QUALITY-REVIEW.md']}
verdict = {
 'status':'PASS_SOURCE_BOUND_NOT_RELEASE_APPROVAL','spec':'PASS','quality':'PASS',
 'stageOrder':['SPEC','QUALITY'],'importantFindingCount':0,'findings':[],
 'producerRoot':'/Users/shersingh/.hermes/cache/scratch/qmd-ast-ownership-rx4oinc5',
 'reviewRoot':str(root),'patchSha256':summary['patchSha256'],'payloadSha256':summary['payloadSha256'],
 'reportsSha256':reports,'reviewerDidNotAuthorRepair':True,
 'freshEvidence': {k:v for k,v in summary['qualifiedRuns'].items()},
 'transitions':summary['transitions'],
 'preservation':{
  'producerArtifactCountReverified':summary['producerArtifactsReverified'],
  'producerCandidateCountReverified':summary['producerSourcePostimagesReverified'],
  'ownedPublicSourceClosureCount':summary['ownedPublicSourceClosureCount'],
  'sourceComplementUnchanged':summary['ownedSourceComplementUnchanged'],
  'protectedTestsUnchanged':True,'twoPathPatchReplayExact':True,
  'liveASTUnchanged':summary['liveAstUnchanged'],'liveNewTestAbsent':summary['liveNewLifecycleTestAbsent'],
  'sharedDependencyInventoryRows':summary['dependencyAfterRowCount'],
  'sharedDependencyDelta':summary['dependencyDelta'],'ownedCachesBeforeFirstRed':summary['ownedCachesBeforeFirstRed'],
  'authorizedUnrelatedLiveChangesPreserved':summary['authorizedUnrelatedLiveDeltasUnchanged'],
 },
 'harnessIssues':[
  {'id':'intake-import-discovery','status':'CORRECTED','evidence':'evidence/intake-first-failure.json',
   'description':'Initial regex source-closure discovery misclassified embedded fixture text; no test ran. Actual TypeScript AST discovery corrected it.'},
  {'id':'datasets-offline-allowlist','status':'CORRECTED_AND_FRESH_REQUALIFIED','evidence':'evidence/isolation-correction.json',
   'description':'Initial copied runner lacked explicit HF_DATASETS_OFFLINE; old receipts retained and excluded from final isolation qualification. All final q-prefixed controls have the flag and owned datasets cache.'},
 ],
 'limitations':[
  'Exactly one release attempt is not guaranteed native deallocation when delete throws.',
  'No cleanup guarantee is claimed for an object never returned by a throwing constructor.',
  'Native memory retention, RSS and throughput were not measured.',
  'Focused one-worker execution does not qualify full native-Bun Vitest or fix the separate allocator SIGTRAP.',
  'Producer focused compiler/build evidence was authenticated, not independently rerun here.',
 ],
 'remainingOwner':'PARENT',
 'remainingGates':['live integration','whole-project/default-root type acceptance','build/package acceptance','full-project test acceptance','CI acceptance','release decision'],
 'externalSideEffects':[],'liveEdits':[],'trackedWorkClosed':False,
}
(root/'verdict.json').write_text(json.dumps(verdict,sort_keys=True,indent=2)+'\n')
paths = [root/p for p in ['SPEC-REVIEW.md','QUALITY-REVIEW.md','verdict.json','ast-lifecycle.patch']]
for directory in ['tools','evidence','patch-replay','quality-patch-check']:
 for p in (root/directory).rglob('*'):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts: paths.append(p)
intake = load(root/'evidence/intake.json')
paths += [root/'candidate'/p for p in intake['closure']]
artifacts={str(p.relative_to(root)):{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(set(paths))}
index={'status':verdict['status'],'root':str(root),'artifactCount':len(artifacts),'artifacts':artifacts,
 'patchSha256':summary['patchSha256'],'payloadSha256':summary['payloadSha256'],
 'reportPaths':[str(root/p) for p in ['SPEC-REVIEW.md','QUALITY-REVIEW.md','verdict.json']],
 'indexExcludes':['review-index.json itself','read-use dependency aliases and their targets','runtime/tool caches'],
 'allPathsOwned':True,'scope':'Only frozen two-path AST ownership repair; no live integration or release approval'}
(root/'review-index.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
# Validate every explicit indexed artifact; do not walk aliased dependency trees.
for rel,item in artifacts.items():
 assert sha(root/rel)==item['sha256'] and (root/rel).stat().st_size==item['bytes']
assert len(artifacts)==index['artifactCount']
print(json.dumps({'root':str(root),'status':verdict['status'],'spec':'PASS','quality':'PASS',
 'importantFindingCount':0,'artifactCount':len(artifacts),
 'artifactIndex':str(root/'review-index.json'),'artifactIndexSha256':sha(root/'review-index.json'),
 'verdict':str(root/'verdict.json'),'verdictSha256':sha(root/'verdict.json'),'reportsSha256':reports},indent=2))
