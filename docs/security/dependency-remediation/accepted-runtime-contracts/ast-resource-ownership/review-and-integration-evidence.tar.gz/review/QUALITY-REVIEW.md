# Independent QUALITY review — PASS (source-bound)

Performed only after `SPEC-REVIEW.md` recorded PASS, against the same authenticated two-path payload. No important correctness, maintainability or regression-test defect was found. No repair was authored by this reviewer.

## Reviewed target

- Patch: `1539352e30bb2ecd2f8b52a3195dd86867e71c2d27d065127569e511d6335116`
- `src/ast.ts`: `ce7e7609538ea35c972abd7b0a04af72bf744108ea630c26542257baceb5f79a`
- `test/ast-lifecycle.test.ts`: `98dbec000a3e83c575f83f7030bbd7a584043db8acd4ead38d0124df03b5e4cb`

The code/test review was restricted to acquisition/release ownership, exception ordering, fallback, successful breakpoint behavior and repeated-call/cache behavior. It did not broaden into recovery, workflow, model-serving or whole-project architecture.

## Findings

**No actionable findings.**

- **Resource scope is local and inspectable.** `src/ast.ts:275–319` has one parser acquisition, one nullable tree slot and one cleanup location. The independent cleanup blocks make tree-before-parser order explicit and prevent a failed tree destructor from skipping parser cleanup. There are no retry branches, ownership registries, detached cleanup tasks or new public abstractions to maintain.
- **The error path does not hide failed cleanup.** Lines 305–326 retain operation/tree/parser errors in order. Checking the collected errors before returning points avoids falsely successful AST output. The normal public warning and fallback remain in the original outer catch. The error-array length, rather than truthiness of an error value, correctly handles thrown undefined values.
- **Successful processing is preserved rather than rewritten.** The score lookup, highest-score deduplication and position sort retain their expressions and tie behavior. Results are materialized before native cleanup; sorting is now inside the cleanup-protected operation scope. Grammar/query caching and language routing are not part of the production hunk. No dependency, runtime option, production compiler configuration or deadline was introduced.
- **Regression tests observe the actual module boundary.** `test/ast-lifecycle.test.ts:17–115` substitutes only `web-tree-sitter` exports and imports the real product module. Acquisition arrays and per-object spies at lines 124–128 distinguish missing releases from aggregate-count coincidence. Tests assert order and public results, not implementation-source strings.
- **Failure and recovery controls are discriminating.** The supplied suite covers unsupported/init/grammar/constructor paths, parser-only ownership, tree ownership, both destructors, combined failures, non-Error throws, cache reuse and query-construction retry. Each test resets modules, removes the dependency mock and restores spies, lines 138–143. Original AST suites were not edited or weakened.
- **Mock confidence is complemented by native execution.** The separate owned real-WASM held-out matrix proved the instrumentation reaches the actual installed Parser/Tree/Query exports and reproduced missing attempts on the baseline. Its original-source 15-pass/9-fail controls transitioned to 24-pass/0-fail on both actual Node and native Bun, with separate product snapshots and fixture cleanup. Successful recovery through the same module and six-language exact-output positives remained green.

The post-SPEC `git apply --check --whitespace=error` check passed with exit 0 and no stderr in a separate owned preimage directory (`evidence/quality-check.json`). That receipt binds the completed SPEC report and the unchanged payload hashes. It is a whitespace/applicability check, not a substitute for the executed tests.

## Evidence and limitations

Final qualifying receipts are the `q-` records summarized in `evidence/verification-summary.json`: supplied lifecycle RED 9 passed/15 failed, GREEN three files/62 passed, zero skips on each host; genuine six-language WASM outputs unchanged. The reviewer harness's initial import-discovery failure and missing datasets-offline flag were retained and corrected before these final controls; neither was counted as a product defect or silently relabeled green.

Quality PASS applies only to this frozen repair. The native destructor tests prove **attempts**, not deallocation when deletion throws, and no heap/RSS/throughput improvement was measured. The separate full-native-Bun Vitest allocator SIGTRAP and other CI failures remain open. Live integration and whole-project/default-root type, build/package, CI and release acceptance remain with the parent. This review does not authorize a merge, commit, push or closure of tracked work.
