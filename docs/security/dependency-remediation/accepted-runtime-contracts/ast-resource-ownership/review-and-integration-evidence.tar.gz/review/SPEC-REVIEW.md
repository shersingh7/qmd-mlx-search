# Independent SPEC review — PASS (source-bound)

## Bound target and disposition

Reviewed only the frozen ownership repair for `src/ast.ts` and new `test/ast-lifecycle.test.ts`, not the live checkout or a newly authored repair. No important specification defect was found. QUALITY review may proceed only against these same bytes.

- Frozen producer root: `/Users/shersingh/.hermes/cache/scratch/qmd-ast-ownership-rx4oinc5`
- Owned review root: `/Users/shersingh/.hermes/cache/scratch/qmd-ast-independent-review-5kk9lp52`
- Patch SHA-256: `1539352e30bb2ecd2f8b52a3195dd86867e71c2d27d065127569e511d6335116`
- `src/ast.ts`: `ce7e7609538ea35c972abd7b0a04af72bf744108ea630c26542257baceb5f79a`
- `test/ast-lifecycle.test.ts`: `98dbec000a3e83c575f83f7030bbd7a584043db8acd4ead38d0124df03b5e4cb`

The indexed 85 producer artifacts and all 299 candidate source postimages were independently authenticated at intake and after execution. The manifest complement contains only one changed existing file, `src/ast.ts`, and one added lifecycle test. An owned, actual `git apply --check` followed by application reproduced both postimages exactly (`evidence/patch-replay.json`). Only a verified 21-file public source/config/test closure was copied for execution.

## Specification findings

| Requirement | Verdict and source/evidence |
| --- | --- |
| Release only acquired resources | PASS. Construction is outside the inner resource scope at `src/ast.ts:275`; an unreturned constructor result is not claimed as owned. After a successful constructor, `setLanguage` and `parse` run inside the protected block, lines 280–282. Tree ownership starts only with a returned non-null tree. Unsupported files, init/grammar/constructor failures and null trees are covered by the new suite. |
| One release attempt per acquired parser/tree on success and ordinary exception paths | PASS. The `finally` at lines 307–319 unconditionally attempts the owned parser and conditionally attempts the returned tree. No alternate deletion/retry branch remains. Operation exceptions from language assignment, parsing, query creation, root access, capture collection/processing, and independent iterator failure reach this block. |
| Tree before parser, despite tree deletion failure | PASS. Lines 309–317 use separate cleanup `try/catch` blocks. Both the supplied per-resource spies and the independent native-WASM call-through snapshots show `tree.delete` followed by `parser.delete`, including a tree destructor throwing before delegation. |
| Cleanup failure must not masquerade as successful AST output | PASS. Errors are checked before `return points` at lines 321–328; any cleanup failure enters the existing warning/`[]` fallback at lines 329–331. Successful intermediate captures are discarded on failure. The unchanged caller in `src/store.ts:2689–2703` retains regex breakpoints when AST points are empty. |
| Original operation context ahead of cleanup errors | PASS. The operation catch appends first, followed by tree and parser cleanup errors; a lone error is rethrown unchanged. Multiple errors become an `AggregateError` with original objects and first-error `cause`, lines 321–326. The public warning order was exercised with normal errors, undefined/string failures in the supplied suite, and real operation plus both destructor faults in the held-out probe. |
| Preserve successful output and caches/language selection | PASS. Deduplication still keeps the highest score at each position and returns position-sorted points. Language maps, grammar promises and per-language query cache code are unchanged. Repeated calls, TS/JS/TSX cache separation and unsuccessful query-construction retry are covered by the new suite. Six-language genuine WASM positives are byte-identical before/after; held-out same-module recovery returns fresh parser/tree objects without poisoning status. |
| Two-path scope and existing tests unchanged | PASS. The patch has exactly the two permitted paths. Both existing AST test hashes are unchanged in the frozen payload, owned closure and live checkout. No dependency, compiler-root/config, test deadline or production cache change was made. |

The exactly-once statement is about **release attempts**, not guaranteed native deallocation when `delete()` throws. Constructor failure cannot prove cleanup of an object that was never returned. These limits are not counted as defects in the requested contract.

## Fresh qualified executions

Final qualification uses the `q-` receipt labels only. Each Vitest invocation retained repository configuration and deadlines, added receipt-only setup, selected explicit files and used `--configLoader runner --no-cache --maxWorkers=1`.

| Control | Actual Node 22.22.3 | Actual native Bun 1.3.8 |
| --- | --- | --- |
| Unmodified existing suites | 2 files, 38 passed, 0 failed/skipped, exit 0 | 2 files, 38 passed, 0 failed/skipped, exit 0 |
| RED, new lifecycle suite on original source | 1 file, 9 passed, 15 failed, 0 skipped, exit 1 | 1 file, 9 passed, 15 failed, 0 skipped, exit 1 |
| GREEN, new plus both existing suites | 3 files, 62 passed, 0 failed/skipped, exit 0 | 3 files, 62 passed, 0 failed/skipped, exit 0 |
| Independent real-WASM lifecycle matrix, original source | 24 cases, 15 passed, 9 failed, exit 1 | 24 cases, 15 passed, 9 failed, exit 1 |
| Same independent matrix, repaired source | 24 passed, 0 failed, exit 0 | 24 passed, 0 failed, exit 0 |

Every supplied RED failure was an executed release assertion (one expected versus zero observed), not setup/import failure. The same 24 supplied lifecycle names and exact test bytes became green. Worker receipts identify the actual executable and runtime, rather than inferring native Bun from a launcher or Bun's Node-compatibility version string.

Unmocked six-language WASM probes passed on both sources under both hosts, requiring all six grammars and exact expected outputs. Before/after stdout SHA-256 is identical within each host:

- Node: `ad2341c1817b509310b92e691e2f17803c50bfc18c36829de6cda1d86fc3c7c4`
- Bun: `c2ee122a51a95ed2aac9abb8f93f0a6c627091901b0f4931118b25d98b38cada`

The independent `tools/heldout-wasm.mts` uses real installed exports and real parser/tree/query objects, without module mocks. It covers actual installed-library language/parse argument rejection, native null-tree return, real-root failure, failure after real captures, partial capture iteration, predelegation destructor faults and combined faults. Every negative control is followed by a successful call through the same product module, and status remains available for all languages. Resource-attempt snapshots are captured **before** separately labeled fixture cleanup; fixture deletion is not relabeled as product cleanup. Probe bytes are unchanged across RED/GREEN: `083b5c71dd83909a5fd35d4733c21deee554042268ad09f5505fc9ccf577bf6d`.

Exact argv, environment, source/harness bindings, raw stdout/stderr, raw statuses and host receipts are retained in `evidence/q-*.receipt.json`, `evidence/q-*.vitest.json` and paired raw outputs. Programmatic count/transition/preservation checks passed in `tools/verify.py`; see `evidence/verification-summary.json`.

## Isolation, retained harness issues and preservation

- An owned `node_modules` directory with per-package read-use aliases and owned `.vite`, `.vite-temp`, `.cache`, `.vitest` directories existed before the first RED. No root dependency-directory symlink was used.
- Current shared dependency inventories were collected independently before/after: 19,085 rows each, with no added/removed/changed rows. Dependency `AGENTS.md` was metadata-only, never content-read or hashed. Historical inventory equality was not assumed and nothing was restored.
- Child environments are explicit allowlists with owned HOME/Hermes/knowledge/XDG/HF/temp/tool caches, HF/transformers/datasets/uv offline flags, `QMD_LLAMA_GPU=false`, `CI=1`, `REQUIRE_BUN=1`. Inherited credentials/context were not forwarded or displayed.
- The initial intake's regex import scanner mistook embedded test sample text for an import; it failed before creating the candidate or running tests. Actual TypeScript syntax-tree import discovery corrected the review harness. Failure retained at `evidence/intake-first-failure.json`.
- The initially copied producer runner omitted `HF_DATASETS_OFFLINE`. Earlier runs are retained, but **not used as final isolation qualification**. Fresh `q-` RED/GREEN/WASM/held-out runs add that flag and an owned datasets cache, without changing product, test assertions or deadlines. See `evidence/isolation-correction.json`.
- Live `src/ast.ts` remains original, the new live test remains absent, and existing AST tests remain unchanged. The authorized unrelated `flake.nix` and `test/security/test_gguf_workflow_controller.py` transitions were recorded without importing, changing or reverting them.
- No producer helper was executed in its frozen root, no frozen evidence was relabeled, and no live source/config/service/skill change, install, external harness, further delegation, model/GPU/index/daemon work, staging or commit was performed.

## Scope boundary

This is a **PASS for this source-bound specification only**. Live integration, whole-project/default-root type checking, packaging/build/release and CI acceptance remain the parent's responsibility. The producer's focused compiler/build receipts were authenticated, not independently re-executed or promoted into whole-project approval here. The separate full-native-Bun Vitest allocator SIGTRAP and other CI failures remain open. No native heap/RSS retention or throughput improvement was measured or claimed.
