import { writeFileSync } from "node:fs";
const runtime = process.versions.bun ? "bun" : "node";
if (runtime !== process.env.QMD_EXPECT_RUNTIME) throw new Error(`Unexpected test host: ${runtime}`);
writeFileSync(`${process.env.QMD_RUNTIME_PROOF}.${process.pid}.json`, JSON.stringify({
  runtime, execPath: process.execPath, versions: process.versions,
  pid: process.pid, cwd: process.cwd(),
}) + "\n", { flag: "wx" });
