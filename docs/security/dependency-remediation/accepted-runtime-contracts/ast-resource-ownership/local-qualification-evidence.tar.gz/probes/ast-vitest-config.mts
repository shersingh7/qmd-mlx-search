import original from "/Users/shersingh/github/qmd-mlx-search/vitest.config.ts";
export default {
  ...original,
  test: {
    ...original.test,
    setupFiles: [new URL("./runtime-setup.mjs", import.meta.url).pathname],
  },
};
