from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = Path('/Users/shersingh/github/qmd-mlx-search')
EVIDENCE = ROOT / 'evidence'
BASE_ENV = json.loads((ROOT / 'environment.json').read_text())
NODE = '/Users/shersingh/.hermes/node/bin/node'
BUN = '/Users/shersingh/.bun/bin/bun'
SOURCE_PATHS = ['src/ast.ts', 'test/ast-lifecycle.test.ts', 'package.json',
                'bun.lock', 'pnpm-lock.yaml', 'tsconfig.json',
                'tsconfig.build.json', 'vitest.config.ts', 'CHANGELOG.md']
source_hashes = {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest()
                 for name in SOURCE_PATHS}
summary = {'sourceSha256': source_hashes, 'runs': {}, 'packageSmokes': []}

def run(label, argv, extra=None, timeout=180):
    assert not (EVIDENCE / f'{label}.receipt.json').exists(), 'Retained receipts must not be overwritten'
    env = dict(BASE_ENV)
    env.update(extra or {})
    start = time.monotonic()
    result = subprocess.run(argv, cwd=REPO, env=env, capture_output=True,
                            text=True, timeout=timeout)
    (EVIDENCE / f'{label}.stdout.txt').write_text(result.stdout)
    (EVIDENCE / f'{label}.stderr.txt').write_text(result.stderr)
    receipt = {'argv': argv, 'cwd': str(REPO), 'exitCode': result.returncode,
               'elapsedSeconds': time.monotonic() - start,
               'sourceSha256': source_hashes, 'environmentKeys': sorted(env)}
    (EVIDENCE / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    summary['runs'][label] = receipt
    (EVIDENCE / 'qualification-progress.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert result.returncode == 0, (label, result.stdout[-6000:], result.stderr[-6000:])
    assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest
               for name, digest in source_hashes.items())
    return result

# Preserve the already completed canonical run; do not re-run it for formatting.
if not (EVIDENCE / 'full-node-tests.raw.log').exists():
    shutil.copy2('/Users/shersingh/.hermes/cache/terminal-output/out-1794659207-25697-6650.log',
                 EVIDENCE / 'full-node-tests.raw.log')
full = json.loads((EVIDENCE / 'full-node-tests.json').read_text())
assert full['success'] and full['numFailedTests'] == 0
summary['fullNode'] = {'passed': full['numPassedTests'], 'skipped': full['numPendingTests'],
                       'failed': full['numFailedTests'], 'files': len(full['testResults'])}

guard_path = str(ROOT / 'probes/compiler-read-guard.cjs')
for runtime, prefix in [('node', [NODE]), ('bun', [BUN, '--bun', '--preload=' + guard_path])]:
    label = f'qualified-whole-root-{runtime}'
    guarded = {'QMD_COMPOSE_ROOT': str(ROOT), 'QMD_RUN_LABEL': label}
    if runtime == 'node':
        guarded['NODE_OPTIONS'] = '--require=' + guard_path
    config = run(label + '-config', prefix + ['node_modules/typescript/bin/tsc', '--showConfig'], guarded)
    parsed = json.loads(config.stdout)
    files = parsed['files']
    assert './test/ast-lifecycle.test.ts' in files and len(files) == len(set(files))
    run(label, prefix + ['node_modules/typescript/bin/tsc', '--noEmit', '--pretty', 'false'], guarded)
    observations = [json.loads(line) for p in EVIDENCE.glob(label + '-compiler-reads-*.jsonl')
                    for line in p.read_text().splitlines()]
    assert observations and all(row.get('allowed', True) for row in observations)
    hosts = [row for row in observations if row.get('kind') == 'compiler-host']
    assert len(hosts) == 2
    assert all(bool(row['versions'].get('bun')) == (runtime == 'bun') for row in hosts)
    summary[label] = {'compilerRoots': len(files), 'diagnostics': 0,
                       'readRefusals': 0, 'actualCompilerHosts': hosts}

run('native-bun-ast', [BUN, '--bun', 'node_modules/vitest/vitest.mjs', 'run',
    '--config', str(ROOT / 'probes/ast-vitest-config.mts'), '--configLoader', 'runner',
    '--no-cache', '--maxWorkers=1', '--reporter=json',
    '--outputFile=' + str(EVIDENCE / 'native-bun-ast.json'),
    'test/ast-lifecycle.test.ts', 'test/ast.test.ts', 'test/ast-chunking.test.ts'],
    {'QMD_EXPECT_RUNTIME': 'bun', 'QMD_RUNTIME_PROOF': str(EVIDENCE / 'native-bun-ast.testhost')})
native = json.loads((EVIDENCE / 'native-bun-ast.json').read_text())
assert native['success'] and native['numFailedTests'] == native['numPendingTests'] == 0
hosts = [json.loads(p.read_text()) for p in EVIDENCE.glob('native-bun-ast.testhost.*.json')]
assert hosts and all(row['runtime'] == 'bun' and row['versions']['bun'] == '1.3.8' for row in hosts)
summary['nativeBunAST'] = {'passed': native['numPassedTests'], 'files': len(native['testResults']),
                           'failed': 0, 'skipped': 0, 'actualHost': 'Bun 1.3.8'}

tarball = None
for runtime in ('node', 'bun'):
    previous = set((ROOT / 'tmp').glob('qmd-package-smoke-*'))
    argv = ['/bin/bash', 'test/smoke-install.sh', '--runtime', runtime]
    if tarball is not None:
        argv += ['--package', str(tarball)]
    run('package-smoke-' + runtime, argv, timeout=480)
    created = set((ROOT / 'tmp').glob('qmd-package-smoke-*')) - previous
    assert len(created) == 1
    workspace = next(iter(created))
    data = json.loads((workspace / 'receipt.json').read_text())
    assert data['ok'] is True and data['runtime'] == runtime
    tarball = Path(data['tarball'])
    assert tarball.is_file()
    (EVIDENCE / f'package-smoke-{runtime}.installed-receipt.json').write_text(json.dumps(data, indent=2) + '\n')
    with tarfile.open(tarball, 'r:gz') as archive:
        for rel in ['dist/ast.js', 'CHANGELOG.md']:
            assert archive.extractfile('package/' + rel).read() == (REPO / rel).read_bytes()
    row = {'runtime': runtime, 'exitCode': 0, 'ownedWorkspace': str(workspace),
           'tarball': str(tarball), 'tarballSha256': hashlib.sha256(tarball.read_bytes()).hexdigest(),
           'httpSupported': data['httpSupported'], 'checks': data['checks'],
           'packagedASTAndChangelogMatchActualCheckout': True}
    summary['packageSmokes'].append(row)
    print(json.dumps(row), flush=True)

assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest
           for name, digest in source_hashes.items())
summary['status'] = 'LOCAL_AST_INTEGRATION_ACCEPTED_NOT_CI_OR_RELEASE_APPROVAL'
summary['limitations'] = ['Full native-Bun Vitest allocator crash remains unqualified',
                         'Known recovery CI failures and parallel fixture/diagnostic proposals remain separate gates',
                         'Bun HTTP refusal is not HTTP feature acceptance']
(EVIDENCE / 'qualification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ['runs', 'sourceSha256']}, indent=2))
