from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = Path('/Users/shersingh/github/qmd-mlx-search')
E = ROOT / 'evidence'
ENV = json.loads((ROOT / 'environment.json').read_text())
SOURCES = json.loads((ROOT / 'source-after.json').read_text())
NODE = '/Users/shersingh/.hermes/node/bin/node'
BUN = '/Users/shersingh/.bun/bin/bun'
GUARD = str(ROOT / 'probes/compiler-read-guard.cjs')
RUNTIME_GUARD = str(ROOT / 'probes/runtime-read-guard.cjs')
PROOF = str(ROOT / 'probes/runtime-proof.cjs')
summary = {'fullNode': json.loads((E / 'full-node-test-summary.json').read_text()), 'runs': {}, 'packageSmokes': []}

def preserved():
    assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest for name, digest in SOURCES.items())


def run(label, argv, extra=None, timeout=180):
    target = E / (label + '.receipt.json')
    if target.exists():
        # Resume only a completed successful invocation from this unchanged source.
        # This is retained evidence, not a new test/compiler execution.
        previous = json.loads(target.read_text())
        assert previous['exit'] == 0 and not previous['timedOut']
        assert previous['argv'] == argv
        assert previous['sourceManifestSha256'] == hashlib.sha256((ROOT / 'source-after.json').read_bytes()).hexdigest()
        preserved()
        summary['runs'][label] = {**previous, 'retainedSuccessfulExecutionReusedNotRerun': True}
        return (E / (label + '.stdout.txt')).read_text(), (E / (label + '.stderr.txt')).read_text()
    env = {**ENV, 'QMD_COMPOSE_ROOT': str(ROOT), 'QMD_RUN_LABEL': label, **(extra or {})}
    start = time.monotonic()
    try:
        result = subprocess.run(argv, cwd=REPO, env=env, capture_output=True, text=True, timeout=timeout)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
        timed_out = False
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code = error.stdout or b'', error.stderr or b'', None
        stdout = stdout.decode(errors='replace') if isinstance(stdout, bytes) else stdout
        stderr = stderr.decode(errors='replace') if isinstance(stderr, bytes) else stderr
        timed_out = True
    (E / (label + '.stdout.txt')).write_text(stdout)
    (E / (label + '.stderr.txt')).write_text(stderr)
    receipt = {'argv': argv, 'cwd': str(REPO), 'exit': code, 'timedOut': timed_out,
               'seconds': time.monotonic() - start,
               'sourceManifestSha256': hashlib.sha256((ROOT / 'source-after.json').read_bytes()).hexdigest()}
    target.write_text(json.dumps(receipt, indent=2) + '\n')
    summary['runs'][label] = receipt
    (E / 'qualification-progress.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert code == 0 and not timed_out, (label, stdout[-4000:], stderr[-4000:])
    preserved()
    return stdout, stderr


preserved()
rows = [json.loads(line) for file in E.glob('canonical-build-compiler-reads-*.jsonl') for line in file.read_text().splitlines()]
assert rows and all(row.get('allowed', True) for row in rows)
hosts = [row for row in rows if row.get('kind') == 'compiler-host']
assert len(hosts) == 2 and all(row['versions']['node'] == '22.22.3' for row in hosts)
summary['canonicalBuild'] = {'command': 'pnpm run build', 'terminalExit': 0,
    'terminalVerification': {'status': 'passed', 'kind': 'build', 'scope': 'full'},
    'guardRows': len(rows), 'guardRefusals': 0, 'actualHosts': hosts}

for runtime, prefix in [('node', [NODE]), ('bun', [BUN, '--bun', '--preload=' + GUARD])]:
    label = 'whole-root-' + runtime
    extra = {'QMD_RUN_LABEL': label}
    if runtime == 'node':
        extra['NODE_OPTIONS'] = '--require=' + GUARD
    stdout, _ = run(label + '-config', prefix + ['node_modules/typescript/bin/tsc', '--showConfig'], extra)
    files = json.loads(stdout)['files']
    assert './test/audit-recovery-execution-admission.test.ts' in files and len(files) == len(set(files))
    run(label, prefix + ['node_modules/typescript/bin/tsc', '--noEmit', '--pretty', 'false'], extra)
    rows = [json.loads(line) for p in E.glob(label + '-compiler-reads-*.jsonl') for line in p.read_text().splitlines()]
    hosts = [row for row in rows if row.get('kind') == 'compiler-host']
    assert len(hosts) == 2 and all(row.get('allowed', True) for row in rows)
    assert all(bool(row['versions'].get('bun')) == (runtime == 'bun') for row in hosts)
    summary[label] = {'compilerRoots': len(files), 'diagnostics': 0, 'guardRefusals': 0, 'actualHosts': hosts}

pattern = 'publishes a complete child stage|witnesses real E delivery|missing-stage diagnostics|identical primary stage error|rejects caller EOF'
run('runtime-guard-control', [NODE, '--require', RUNTIME_GUARD, '-e',
    "const fs=require('node:fs'),assert=require('node:assert/strict');assert.equal(typeof fs.readFileSync(process.env.QMD_COMPOSE_ROOT+'/environment.json','utf8'),'string');assert.throws(()=>fs.readFileSync('/Users/shersingh/.hermes/cache/scratch/qmd-parent-B-negative-u5zwaqui/harness/reproduce-findings.mjs'),e=>e.code==='COMPOSE_RUNTIME_READ_DENIED');console.log('Owned fixture read allowed; unrelated public fixture refused before bytes')"])
out, err = run('native-bun-A-qualified', [BUN, 'test', '--preload', RUNTIME_GUARD, '--preload', PROOF,
    './test/audit-recovery-execution-admission.test.ts', '--timeout', '30000', '--test-name-pattern', pattern],
    {'QMD_EXPECT_RUNTIME': 'bun', 'QMD_RUNTIME_PROOF': str(E / 'native-bun-A-qualified.host')})
text = re.sub(r'\x1b\[[0-9;]*m', '', out + err)
counts = {name: int(value) for value, name in re.findall(r'^\s*(\d+) (pass|fail|filtered out)\s*$', text, re.M)}
assert counts == {'pass': 6, 'filtered out': 43, 'fail': 0}, counts
proofs = [json.loads(p.read_text()) for p in E.glob('native-bun-A-qualified.host.*.json')]
assert proofs and all(p['runtime'] == 'bun' and p['versions']['bun'] == '1.3.8' for p in proofs)
runtime_rows = [json.loads(line) for p in E.glob('native-bun-A-qualified-runtime-reads-*.jsonl') for line in p.read_text().splitlines()]
assert runtime_rows and any(row.get('kind') == 'runtime-guard-installed' for row in runtime_rows)
assert all(row.get('allowed', True) for row in runtime_rows)
summary['nativeBunChangedBehavior'] = counts

out, _ = run('native-wrapper-observation-on', [NODE, '--require', PROOF,
    'node_modules/vitest/vitest.mjs', 'run', '--configLoader', 'runner', '--maxWorkers=1', '--no-cache',
    '--reporter=verbose', '--reporter=json', '--outputFile=' + str(E / 'native-wrapper-observation-on.json'),
    'test/audit-native-bun-recovery.test.ts', '-t',
    'preserves proof across sequential|survives eight active-call GC|cleans the owned worker on a real parent'],
    {'QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS': '1', 'QMD_EXPECT_RUNTIME': 'node',
     'QMD_RUNTIME_PROOF': str(E / 'native-wrapper-observation-on.host')})
result = json.loads((E / 'native-wrapper-observation-on.json').read_text())
assert result['success'] and result['numPassedTests'] == 4 and result['numFailedTests'] == 0 and result['numPendingTests'] == 3
records = [json.loads(line) for line in out.splitlines() if line.startswith('{"evidence":')]
observations = []
def collect(value):
    if isinstance(value, dict):
        if value.get('evidence') == 'native-recovery-before-finally':
            observations.append(value)
        for child in value.values():
            collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)
for record in records:
    collect(record)
assert len(observations) == 13, len(observations)
assert all(row['descriptorObservation']['scope'] == 'parent-side-fstat-only-not-writer-or-resource-identity' for row in observations)
assert all(not row['guardFired'] and row['sentinelAlive'] and row['descriptorSentinelOpen'] for row in observations)
summary['nativeWrapperObservationOn'] = {'passed': 4, 'failed': 0, 'filtered': 3,
                                        'realNativeCalls': len(observations), 'descriptorObservations': len(observations)}

package = None
for runtime in ('node', 'bun'):
    before = set((ROOT / 'tmp').glob('qmd-package-smoke-*'))
    argv = ['/bin/bash', 'test/smoke-install.sh', '--runtime', runtime]
    if package is not None:
        argv += ['--package', str(package)]
    run('package-' + runtime, argv, timeout=480)
    created = set((ROOT / 'tmp').glob('qmd-package-smoke-*')) - before
    assert len(created) == 1
    workspace = next(iter(created))
    receipt = json.loads((workspace / 'receipt.json').read_text())
    assert receipt['ok'] and receipt['runtime'] == runtime
    package = Path(receipt['tarball'])
    with tarfile.open(package, 'r:gz') as archive:
        for rel in ('dist/ast.js', 'CHANGELOG.md'):
            assert archive.extractfile('package/' + rel).read() == (REPO / rel).read_bytes()
    (E / ('package-' + runtime + '.installed-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    summary['packageSmokes'].append({'runtime': runtime, 'tarball': str(package),
        'tarballSha256': hashlib.sha256(package.read_bytes()).hexdigest(),
        'httpSupported': receipt['httpSupported'], 'checks': receipt['checks']})

preserved()
summary['status'] = 'A_LOCAL_INTEGRATION_ACCEPTED_ACTUAL_CI_PENDING_B_NOT_APPLIED'
summary['retainedHarnessFailure'] = {'receipt': 'native-bun-A.receipt.json',
    'classification': 'Compiler-only read guard incorrectly used for runtime tests; it refused owned fixture stage reads',
    'originalCounts': {'passed': 1, 'failed': 5, 'filtered': 43},
    'correction': 'Separate runtime guard permits the exact call-owned scratch root; compiler guard unchanged; out-of-scope read negative passed',
    'reusedCompilerExecutions': 'Previously completed successful compiler receipts remain source-bound and were not rerun'}
summary['limits'] = ['Native Bun focused coverage is not the full native Vitest suite',
                     'B diagnostic proposal remains rejected pending its separate repair/review',
                     'Package Bun HTTP refusal is not HTTP feature acceptance',
                     'Existing C1/actual-CI/cold-start/FD-holder qualifications remain']
(E / 'qualification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'runs'}, indent=2))
