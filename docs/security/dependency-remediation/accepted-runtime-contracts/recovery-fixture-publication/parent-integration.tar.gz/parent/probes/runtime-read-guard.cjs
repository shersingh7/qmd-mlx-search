// Runtime fixture policy: public source/dependencies plus this call-owned root.
// Separate from the narrower compiler-only policy; no personal-root reads.
const fs = require('node:fs');
const path = require('node:path');
const { fileURLToPath } = require('node:url');
const root = process.env.QMD_COMPOSE_ROOT;
const source = path.resolve(process.cwd());
const raw = { readFileSync: fs.readFileSync, readFile: fs.readFile, readdirSync: fs.readdirSync,
  readdir: fs.readdir, realpathSync: fs.realpathSync, appendFileSync: fs.appendFileSync };
const aliases = JSON.parse(raw.readFileSync(path.join(root, 'evidence', path.basename(source) + '-package-aliases.json'), 'utf8'));
const packages = Object.values(aliases);
const inside = (value, directory) => value === directory || value.startsWith(directory + path.sep);
const sourceReal = raw.realpathSync(source);
const rootReal = raw.realpathSync(root);
const log = path.join(root, 'evidence', process.env.QMD_RUN_LABEL + '-runtime-reads-' + process.pid + '.jsonl');
function guard(value, operation) {
  if (typeof value === 'number') return;
  const lexical = path.resolve(value instanceof URL ? fileURLToPath(value) : String(value));
  let real;
  try { real = raw.realpathSync(lexical); }
  catch (error) { if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return; throw error; }
  const allowed = (inside(lexical, source) && inside(real, sourceReal))
    || (inside(lexical, root) && inside(real, rootReal))
    || packages.some(directory => inside(real, directory));
  raw.appendFileSync(log, JSON.stringify({operation, lexical, real, allowed}) + '\n');
  if (!allowed) throw Object.assign(new Error('COMPOSE_RUNTIME_READ_DENIED ' + lexical), {code: 'COMPOSE_RUNTIME_READ_DENIED'});
}
for (const name of ['readFileSync', 'readFile', 'readdirSync', 'readdir']) {
  fs[name] = function(value, ...args) { guard(value, name); return raw[name].call(this, value, ...args); };
}
for (const name of ['readFile', 'readdir', 'opendir']) {
  const original = fs.promises[name];
  fs.promises[name] = async function(value, ...args) { guard(value, 'promises.' + name); return original.call(this, value, ...args); };
}
require('node:module').syncBuiltinESMExports();
raw.appendFileSync(log, JSON.stringify({kind: 'runtime-guard-installed', execPath: process.execPath, versions: process.versions, source, ownedFixtureRoot: root}) + '\n');
