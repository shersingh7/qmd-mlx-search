const fs = require('node:fs');
const runtime = process.versions.bun ? 'bun' : 'node';
if (runtime !== process.env.QMD_EXPECT_RUNTIME) throw new Error(`Wrong runtime: ${runtime}`);
fs.writeFileSync(`${process.env.QMD_RUNTIME_PROOF}.${process.pid}.json`, JSON.stringify({
  runtime, execPath: process.execPath, versions: process.versions, cwd: process.cwd(),
}) + '\n', {flag: 'wx'});
