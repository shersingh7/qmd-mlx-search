"use strict";

const fs = require("node:fs");
const path = require("node:path");
const root = path.dirname(__dirname);
const mode = process.env.QMD_VERIFY_MODE || "build";
if (mode !== "build" && mode !== "test") throw new Error("Unknown verification mode");
const allowed = JSON.parse(fs.readFileSync(path.join(root, "environment.json"), "utf8"));
allowed.npm_config_offline = "true";
allowed.QMD_COMPOSE_ROOT = root;
allowed.QMD_RUN_LABEL = `canonical-${mode}`;
// The compiler guard is for source compilation. Tests need their genuine
// temporary-file/IPC fixtures, isolated by the synthetic HOME/cache/temp paths.
if (mode === "build") {
  allowed.npm_config_node_options = `--require=${path.join(__dirname, "compiler-read-guard.cjs")}`;
}
for (const name of Object.keys(process.env)) delete process.env[name];
Object.assign(process.env, allowed);
