from pathlib import Path
import hashlib,json,os
ROOT=Path(__file__).resolve().parent.parent;E=ROOT/'evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((E/'independent-summary.json').read_text())
assert summary['strict']['diagnostics']==0 and summary['runs']['node-full49']['exit']==0
spec=ROOT/'SPEC-REVIEW.md';quality=ROOT/'QUALITY-REVIEW.md'
assert spec.exists() and quality.exists() and spec.stat().st_mtime_ns<quality.stat().st_mtime_ns
assert '**Verdict: PASS' in spec.read_text() and '**Verdict: PASS' in quality.read_text()
verdict={'spec':'PASS','quality':'PASS','blockingFindings':[],'nonblockingFindings':[],'scope':summary['scope'],'postimageSha256':summary['postimages'],'reviewRoot':str(ROOT),'reviewOrder':['SPEC','QUALITY'],'reports':{'SPEC-REVIEW.md':sha(spec),'QUALITY-REVIEW.md':sha(quality)},'evidenceSummary':'evidence/independent-summary.json','evidenceSummarySha256':sha(E/'independent-summary.json'),'verified':{'nodeAdmission':{'host':'Node 22.22.3','passed':49,'failed':0,'skipped':0,'files':1},'nativeBunSelected':{'host':'Bun 1.3.8','passed':6,'failed':0,'filtered':43,'fullSuite':False},'nativeWrapperModes':{'disabled':{'passed':4,'filtered':3,'nativeCalls':13,'optionalFDObservations':0,'requiredReuseObservations':7},'enabled':{'passed':4,'filtered':3,'nativeCalls':13,'optionalFDObservations':13,'requiredReuseObservations':7}},'red':{'failed':2,'filtered':47},'atomicOnly':{'passed':1,'failed':1,'filtered':47},'heldoutCausalCases':3,'heldoutPublisherControls':5,'strictDiagnostics':0,'actualReadGuardExecution':True,'liveSourceNegativeControlRefusedBeforeBytes':True,'candidateAndLiveTargetBytesPreserved':True},'retainedIssues':['Initial reviewer Bun option-position failure before tests; corrected explicit native command only','Reducer initially assumed final RED stage stayed empty; actual empty stageAtEOF and later complete record retained','Bundled-config Node runner upward package.json probes refused before bytes; guard policy unchanged','Initial metadata tools/probes discovery failure'], 'openGates':['Parent live application and integration','Whole-root/full-suite/package gates','Actual macOS/Linux CI rerun','Full native-Bun Vitest SIGTRAP qualification','Historical startup/missing-stage incidents outside demonstrated mechanism','Kernel FD writer/resource identity and causal holder proof','C1 paused-owner bounded complete cleanup limitation'],'sourceManifestSha256':sha(E/'source-manifest.json'),'parentCompositionManifestSha256':'7197501a2c7034693eb428063aeaa7571c53378d0d96acceafa0f19aafe7f23e'}
(ROOT/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
artifacts=[]
def walk(folder):
    for p in sorted(folder.iterdir()):
        if p.is_symlink():continue
        if p.is_dir():
            if p.name in ['node_modules','isolated','__pycache__','.git','dist']:continue
            walk(p)
        elif p.is_file() and p!=ROOT/'INDEX.json':artifacts.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)})
walk(ROOT)
index={'workspace':str(ROOT),'spec':'PASS','quality':'PASS','scope':'A two-file independent SPEC then QUALITY review only','artifactCountExcludingIndex':len(artifacts),'artifactBytesExcludingIndex':sum(x['bytes'] for x in artifacts),'excluded':'Dependency symlinks, all node_modules/tool caches, synthetic environment/cache dirs, pycache; retained public source and evidence included','artifacts':artifacts}
(ROOT/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
# Authenticate enumeration from disk once; reject duplicates/missing/count/size drift.
assert len({x['path'] for x in artifacts})==len(artifacts)
for x in artifacts:
    p=ROOT/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
print(json.dumps({'reviewRoot':str(ROOT),'spec':'PASS','quality':'PASS','artifacts':len(artifacts),'artifactBytes':index['artifactBytesExcludingIndex'],'hashes':{k:sha(ROOT/k) for k in ['SPEC-REVIEW.md','QUALITY-REVIEW.md','verdict.json','INDEX.json']},'ownedSourceManifestSha256':sha(E/'source-manifest.json')},indent=2))
