from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parent.parent
A=Path('/Users/shersingh/.hermes/cache/scratch/qmd-fixture-owner-a-1fz0d84c')
P=Path('/Users/shersingh/.hermes/cache/scratch/qmd-recovery-composition-peukmjbv')
LIVE=Path('/Users/shersingh/github/qmd-mlx-search')
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,obj): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,indent=2)+'\n')
expected={'INDEX.json':'37074a6a9d40f8982cb0bb72861c4bb00c574ec60ae5a95dc3cb31eb0765668f','REPORT.md':'9e3a15ee8b9d9efd247b951c3062b44c6d70c201d789af6e1fda6eaf82ad83f2','candidate/recovery-fixture-repair.patch':'21a74212439e8e6a1393e472dabbe0dc72d37d23db8bff42dee91ab94922e021'}
assert all(sha(A/k)==v for k,v in expected.items())
assert sha(P/'source-after.json')=='7197501a2c7034693eb428063aeaa7571c53378d0d96acceafa0f19aafe7f23e'
manifest=json.loads((P/'source-after.json').read_text())
# A small public transitive closure; retain current composition bytes, not producer's older AST.
paths=set(json.loads((A/'evidence/qualification-summary.json').read_text())['candidate']['sourceSha256'])
# Imported at type-check/runtime only; no unrelated tests are executed.
paths.update(k for k in manifest if k.startswith('src/'))
for name in sorted(paths):
    assert name in manifest, name
    src=P/'candidate'/name
    assert sha(src)==manifest[name],name
    out=ROOT/'candidate'/name; out.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,out)
post={'test/audit-recovery-execution-admission.test.ts':'9b305d366775be0e04a856a47ea40be467c37d7f7fe14644d81adeda028fdc0b','test/fixtures/bun_recovery_ownership.ts':'8830c5fff7e66b82141a47c2a03cf92e97bbb858793ed0d7e979bc21bfed1592'}
pre={'test/audit-recovery-execution-admission.test.ts':'6a516aebe57bcd1580adb8d83a99d5d5e4bb41a5685f5d334e06d2d721b79010','test/fixtures/bun_recovery_ownership.ts':'125d2ec7269ef2035e71a9ad2a98f7ed11e66e6386dd57a5f0307de2e34243cb'}
assert all(sha(LIVE/k)==v and sha(ROOT/'candidate'/k)==post[k] for k,v in pre.items())
patch=(A/'candidate/recovery-fixture-repair.patch').read_text()
patchpaths=[line[6:] for line in patch.splitlines() if line.startswith('+++ b/')]
assert patchpaths==list(post)
# Apply supplied patch once in reviewer-owned two-file tree and compare exact postimages.
apply=ROOT/'patch-check'
for name in pre:
    f=apply/name; f.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(LIVE/name,f)
r=subprocess.run(['/usr/bin/git','apply','--unsafe-paths',str(A/'candidate/recovery-fixture-repair.patch')],cwd=apply,capture_output=True,text=True)
put(ROOT/'evidence/patch-check.json',{'argv':['/usr/bin/git','apply',str(A/'candidate/recovery-fixture-repair.patch')],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'paths':patchpaths,'postimages':{k:sha(apply/k) for k in post}})
assert r.returncode==0 and all(sha(apply/k)==v for k,v in post.items())
# Actual public package targets, resolved now. Never link the node_modules directory itself.
shared=LIVE/'node_modules'; modules=ROOT/'candidate/node_modules'; modules.mkdir()
aliases={}
for entry in sorted(shared.iterdir()):
    if entry.name.startswith('.'): continue
    if entry.name.startswith('@'):
        for package in sorted(entry.iterdir()):
            if package.is_dir() and (package/'package.json').is_file(): aliases[f'{entry.name}/{package.name}']=str(package.resolve())
    elif entry.is_dir() and (entry/'package.json').is_file(): aliases[entry.name]=str(entry.resolve())
for name,target in aliases.items():
    out=modules/name; out.parent.mkdir(parents=True,exist_ok=True); out.symlink_to(target,target_is_directory=True)
for cache in ['.vite','.vite-temp','.cache','.vitest']: (modules/cache).mkdir()
put(ROOT/'evidence/candidate-package-aliases.json',aliases)
owned={'PATH':'/Users/shersingh/.hermes/node/bin:/Users/shersingh/.bun/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','LANG':'en_US.UTF-8','CI':'1','REQUIRE_BUN':'1','BUN_EXECUTABLE':'/Users/shersingh/.bun/bin/bun','QMD_LLAMA_GPU':'false','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','npm_config_offline':'true','npm_config_update_notifier':'false','COREPACK_ENABLE_NETWORK':'0'}
for key in ['HOME','HERMES_HOME','HERMES_DIR','HERMES_KNOWLEDGE_DIR','KNOWLEDGE_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_STATE_HOME','HF_HOME','HF_HUB_CACHE','TRANSFORMERS_CACHE','HF_DATASETS_CACHE','TMPDIR','TMP','TEMP','BUN_INSTALL_CACHE_DIR','npm_config_cache','PNPM_HOME','npm_config_store_dir','UV_CACHE_DIR']:
    folder=ROOT/'isolated'/key.lower(); folder.mkdir(parents=True,exist_ok=True); owned[key]=str(folder)
put(ROOT/'environment.json',owned)
put(ROOT/'evidence/source-manifest.json',{k:sha(ROOT/'candidate'/k) for k in sorted(paths)})
index=json.loads((A/'INDEX.json').read_text()); selected=[]
for item in index['artifacts']:
    rel=str(Path(item['path']).relative_to(A))
    # Authenticate all explicit receipts/raw reductions, not thousands of fixture payloads.
    if rel in expected or (rel.startswith('evidence/') and (rel.endswith(('execution.json','records.json','recovered-records.json','stdout.log','stderr.log','qualification-summary.json','postimage-manifest.json','input-manifest.json')))):
        f=A/rel; assert f.stat().st_size==item['bytes'] and sha(f)==item['sha256'],rel
        selected.append(item)
put(ROOT/'evidence/authenticated-upstream.json',{'indexSha256':expected['INDEX.json'],'indexDeclaredArtifacts':index['artifactCountExcludingIndex'],'selectedVerifiedCount':len(selected),'selected':selected,'parentCompositionSha256':sha(P/'source-after.json')})
put(ROOT/'evidence/setup.json',{'root':str(ROOT),'python':sys.executable,'pythonVersion':sys.version,'sourceFiles':len(paths),'packageAliases':len(aliases),'ownedCaches':[(str(modules/k),not (modules/k).is_symlink()) for k in ['.vite','.vite-temp','.cache','.vitest']],'preimages':pre,'postimages':post,'sourceManifestSha256':sha(ROOT/'evidence/source-manifest.json'),'liveFilesReadOnly':True,'initialToolingFailure':{'kind':'metadata listing','exit':1,'cause':'nonexistent parent tools directory; corrected to probes; no candidate execution or writes'}})
print(json.dumps({'root':str(ROOT),'sourceFiles':len(paths),'packageAliases':len(aliases),'verifiedUpstreamArtifacts':len(selected),'patchScope':patchpaths}))
