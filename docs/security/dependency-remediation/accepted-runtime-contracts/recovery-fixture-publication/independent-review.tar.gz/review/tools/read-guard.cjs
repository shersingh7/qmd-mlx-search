const fs = require('node:fs'), path = require('node:path');
const { fileURLToPath } = require('node:url');
const root = path.dirname(__dirname), source = path.join(root,'candidate');
const raw = { readFileSync:fs.readFileSync,readFile:fs.readFile,readdirSync:fs.readdirSync,readdir:fs.readdir,realpathSync:fs.realpathSync,appendFileSync:fs.appendFileSync };
const aliases = JSON.parse(raw.readFileSync(path.join(root,'evidence/candidate-package-aliases.json'),'utf8'));
const dependencyRoots = Object.values(aliases), sourceNM=path.join(source,'node_modules');
const under = (p,d) => p===d || p.startsWith(d+path.sep);
const destination=path.join(root,'evidence',`${process.env.QMD_RUN_LABEL||'unset'}-guard-${process.pid}.jsonl`);
function check(value,operation) {
 if (typeof value==='number') return;
 const p=path.resolve(value instanceof URL ? fileURLToPath(value) : Buffer.isBuffer(value) ? value.toString() : String(value));
 let actual; try { actual=raw.realpathSync(p); } catch(e) { if(e.code==='ENOENT'||e.code==='ENOTDIR') return; throw e; }
 const own = under(p,root) && under(actual,root);
 const packagePath = Object.keys(aliases).some(n=>under(p,path.join(sourceNM,n))) || dependencyRoots.some(d=>under(p,d));
 const allowed = own || (packagePath && dependencyRoots.some(d=>under(actual,d)));
 raw.appendFileSync(destination,JSON.stringify({kind:'read',operation,lexical:p,real:actual,allowed})+'\n');
 if(!allowed) { const e=new Error('REVIEW_READ_DENIED '+p+' -> '+actual);e.code='REVIEW_READ_DENIED';throw e; }
}
for (const name of ['readFileSync','readdirSync','readFile','readdir']) fs[name]=function(value,...args){ check(value,name);return raw[name].call(this,value,...args); };
const fp=fs.promises;
for(const name of ['readFile','readdir','opendir']) {const old=fp[name];fp[name]=async function(value,...args){check(value,'promises.'+name);return old.call(this,value,...args);};}
require('node:module').syncBuiltinESMExports();
raw.appendFileSync(destination,JSON.stringify({kind:'host-start',execPath:process.execPath,versions:process.versions,cwd:process.cwd(),argv:process.argv})+'\n');
process.on('exit',code=>raw.appendFileSync(destination,JSON.stringify({kind:'host-exit',code,execPath:process.execPath})+'\n'));
