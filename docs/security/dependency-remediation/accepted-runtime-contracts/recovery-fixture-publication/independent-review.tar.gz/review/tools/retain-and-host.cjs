const fs=require('node:fs'),path=require('node:path');
const runtime=process.versions.bun?'bun':'node';
if(process.env.QMD_EXPECT_RUNTIME && runtime!==process.env.QMD_EXPECT_RUNTIME) throw new Error('Unexpected actual test host '+runtime);
if(process.env.QMD_HOST_PROOF) fs.writeFileSync(`${process.env.QMD_HOST_PROOF}.${process.pid}.json`,JSON.stringify({runtime,execPath:process.execPath,versions:process.versions,cwd:process.cwd(),argv:process.argv})+'\n',{flag:'wx'});
// Retain fixture bytes only after product proof/assertions and fixture cleanup; never add a subject wait or signal.
const remove=fs.rmSync;
fs.rmSync=function(target,options){
 const archive=process.env.QMD_FIXTURE_ARCHIVE;
 if(archive && typeof target==='string' && /^qmd-execution-(admission|budget)-/.test(path.basename(target)) && fs.existsSync(target)) {
   fs.mkdirSync(archive,{recursive:true});fs.cpSync(target,path.join(archive,path.basename(target)),{recursive:true,errorOnExist:true});
 }
 return remove.call(this,target,options);
};
require('node:module').syncBuiltinESMExports();
