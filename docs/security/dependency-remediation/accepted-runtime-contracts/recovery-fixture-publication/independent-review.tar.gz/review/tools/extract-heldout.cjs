// Execute only exact declarations selected from the bound candidate AST.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const root=path.dirname(__dirname),base=path.join(root,'candidate'),ts=require(path.join(base,'node_modules/typescript'));
const filename=path.join(base,'test/audit-recovery-execution-admission.test.ts'),text=fs.readFileSync(filename,'utf8');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
if(sha(text)!=='9b305d366775be0e04a856a47ea40be467c37d7f7fe14644d81adeda028fdc0b')throw Error('wrong candidate');
const tree=ts.createSourceFile(filename,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
const selected=tree.statements.filter(s=>ts.isFunctionDeclaration(s)&&['instrument','observeStageFailure'].includes(s.name?.text));
if(selected.length!==2)throw Error('bad declaration selection');
const source=path.join(base,'scripts/phase5_recovery_process.py'),extracted=selected.map(n=>n.getText(tree)).join('\n');
const compiled=ts.transpileModule(extracted,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
const context={writeFileSync:fs.writeFileSync,path,source,JSON,process,console};vm.createContext(context);vm.runInContext(compiled,context);
const dest=path.join(root,'evidence/heldout');fs.mkdirSync(dest);
fs.writeFileSync(path.join(dest,'exact-declarations.ts'),extracted+'\n');
const bindings={candidateSha256:sha(text),productSha256:sha(fs.readFileSync(source)),extractSha256:sha(extracted),declarations:selected.map(n=>({name:n.name.text,startLine:tree.getLineAndCharacterOfPosition(n.getStart(tree)).line+1,endLine:tree.getLineAndCharacterOfPosition(n.end).line+1})),generated:{}};
for(const label of ['real-E-interrupted','no-E','no-admission']){
 const folder=path.join(dest,label);fs.mkdirSync(folder);
 const file=context.instrument(folder,'supervisor-forwarded','delay',true,undefined,0,'forward-write-hold');
 bindings.generated[label]={file,sha256:sha(fs.readFileSync(file))};
}
(async()=>{
 const check=context.observeStageFailure,primary=new Error('heldout-primary');let calls=0,logs=0;const prior=process.env.QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS,log=console.log;
 try{
  process.env.QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS='0';
  try{await check(async()=>{throw primary},()=>{calls++;throw Error('should not observe disabled')});throw Error('missing rejection')}catch(e){if(e!==primary)throw e}
  if(calls!==0)throw Error('disabled side effect');
  process.env.QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS='1';
  await check(async()=>{},()=>{calls++;});if(calls!==0)throw Error('success observation');
  for(const mode of ['snapshot-throw','json-throw','log-throw']){
   console.log=()=>{logs++;throw Error('log failure')};
   let atFinally=false;
   try{try{await check(async()=>{throw primary},()=>{calls++;if(atFinally)throw Error('late observation');if(mode==='snapshot-throw')throw Error('snapshot failure');if(mode==='json-throw')return {toJSON(){throw Error('json failure')}};return {evidence:'throw-log'};});throw Error('missing primary')}catch(e){if(e!==primary)throw e}}finally{atFinally=true}
  }
  if(calls!==3||logs!==1)throw Error('wrong observation boundaries');
  bindings.diagnosticControls={disabledSnapshotCalls:0,successSnapshotCalls:0,throwModes:['snapshot','JSON serialization','log'],exactPrimaryIdentity:true,snapshotBeforeFinally:true};
 }finally{console.log=log;if(prior===undefined)delete process.env.QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS;else process.env.QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS=prior}
 fs.writeFileSync(path.join(dest,'bindings.json'),JSON.stringify(bindings,null,2)+'\n');console.log(JSON.stringify({heldout:'exact function extraction and error identity',...bindings.diagnosticControls}));
})().catch(e=>{console.error(e);process.exitCode=1});
