from pathlib import Path
import hashlib,json,shutil,subprocess,time,re
ROOT=Path(__file__).resolve().parent.parent; BASE=ROOT/'candidate'; E=ROOT/'evidence'
ENV=json.loads((ROOT/'environment.json').read_text()); manifest=json.loads((E/'source-manifest.json').read_text());aliases=json.loads((E/'candidate-package-aliases.json').read_text())
name='test/audit-recovery-execution-admission.test.ts'
original=(BASE/name).read_text()
child='''        if os.getpid()!=owner and ${stage === "supervisor-forwarded" && forwardDelayMs === 0 ? "True" : "False"}:
            # Real child receipt proves forwarding before its EOF refusal can
            # signal/interrupt the supervisor's auxiliary post-write observer.
            # Do not hold this child: this case requires a still-positive lease.
            publish_stage('supervisor-forwarded','child-received-E')
'''
assert original.count(child)==1
oldhold='''hold('supervisor-forwarded',publish=${stage === "supervisor-forwarded" && forwardDelayMs === 0 ? "False" : "True"})'''
assert original.count(oldhold)==1
atomic=original.replace(child,'').replace(oldhold,"hold('supervisor-forwarded')")
block='''    stage_temp=stage_path+'.'+str(os.getpid())+'.tmp'
    # Existence is a cancellation handshake: publish only a complete record.
    with open(stage_temp,'x') as out:
        json.dump(dict(stage=label,pid=os.getpid(),owner=owner,at=time.monotonic(),witness=witness),out)
    os.replace(stage_temp,stage_path)'''
assert atomic.count(block)==1
old='''    with open(stage_path,'w') as out:
        json.dump(dict(stage=label,pid=os.getpid(),owner=owner,at=time.monotonic(),witness=witness),out)'''
red=atomic.replace(block,old)
results=[]
for label,text,expected in [('red-no-atomic-no-witness',red,1),('atomic-only-no-witness',atomic,1)]:
    base=ROOT/label;base.mkdir();out=E/label;out.mkdir()
    for path,digest in manifest.items():
        src=BASE/path;assert hashlib.sha256(src.read_bytes()).hexdigest()==digest
        dest=base/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
    (base/name).write_text(text)
    nm=base/'node_modules';nm.mkdir()
    for pkg,target in aliases.items():
        dest=nm/pkg;dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(target,target_is_directory=True)
    for c in ['.vite','.vite-temp','.cache','.vitest']: (nm/c).mkdir()
    variant={p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in manifest}
    (out/'source-manifest.json').write_text(json.dumps(variant,indent=2)+'\n')
    argv=['/Users/shersingh/.hermes/node/bin/node','node_modules/vitest/vitest.mjs','run','--maxWorkers=1','--no-cache','--reporter=verbose','test/audit-recovery-execution-admission.test.ts','-t','publishes a complete child stage|witnesses real E delivery']
    env={**ENV,'NODE_OPTIONS':f'--require={ROOT}/tools/read-guard.cjs --require={ROOT}/tools/retain-and-host.cjs','QMD_EXPECT_RUNTIME':'node','QMD_RUN_LABEL':label,'QMD_HOST_PROOF':str(out/'actual-host'),'QMD_FIXTURE_ARCHIVE':str(out/'fixtures')}
    start=time.monotonic();r=subprocess.run(argv,cwd=base,env=env,capture_output=True,text=True,timeout=45)
    (out/'stdout.log').write_text(r.stdout);(out/'stderr.log').write_text(r.stderr)
    clean=re.sub(r'\x1b\[[0-9;]*m','',r.stdout);records=[]
    for line in clean.splitlines():
        if line.startswith('{"evidence":'): records.append(json.loads(line))
    (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    item={'label':label,'argv':argv,'cwd':str(base),'exit':r.returncode,'expectedExit':expected,'elapsedSeconds':time.monotonic()-start,'sourceSha256':variant,'mutatedPaths':[name],'environment':env,'deltas':{'childWitnessRemoved':True,'originalSupervisorPublicationRestored':True,'directStageOpenRestored':label.startswith('red-')},'summaries':[x for x in clean.splitlines() if 'Tests ' in x or 'Test Files' in x]}
    (out/'execution.json').write_text(json.dumps(item,indent=2)+'\n'); results.append(item)
    assert r.returncode==expected,(label,r.stdout[-4000:],r.stderr[-4000:])
    assert all(hashlib.sha256((base/p).read_bytes()).hexdigest()==h for p,h in variant.items())
    print(json.dumps({k:item[k] for k in ['label','exit','elapsedSeconds','summaries']}))
(E/'mutations-summary.json').write_text(json.dumps(results,indent=2)+'\n')
