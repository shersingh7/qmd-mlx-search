from pathlib import Path
import hashlib,json,subprocess,sys,time,re
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'candidate'; E=ROOT/'evidence'
NODE='/Users/shersingh/.hermes/node/bin/node';BUN='/Users/shersingh/.bun/bin/bun'
ENV=json.loads((ROOT/'environment.json').read_text())
def hashes(): return {k:hashlib.sha256((BASE/k).read_bytes()).hexdigest() for k in json.loads((E/'source-manifest.json').read_text())}
def run(label,args,extra=None,expected=0,timeout=180):
    dest=E/label;dest.mkdir()
    env={**ENV,**(extra or {}),'QMD_RUN_LABEL':label}
    env.setdefault('QMD_HOST_PROOF',str(dest/'actual-host'))
    before=hashes();started=time.monotonic();timed=False
    try:
        r=subprocess.run(args,cwd=BASE,env=env,capture_output=True,text=True,timeout=timeout)
        out,err,code=r.stdout,r.stderr,r.returncode
    except subprocess.TimeoutExpired as exc:
        out=exc.stdout or b'';err=exc.stderr or b'';out=out.decode() if isinstance(out,bytes) else out;err=err.decode() if isinstance(err,bytes) else err;code=None;timed=True
    (dest/'stdout.log').write_text(out);(dest/'stderr.log').write_text(err)
    records=[]
    for line in re.sub(r'\x1b\[[0-9;]*m','',out).splitlines():
        if line.startswith('{"evidence":'):
            try: records.append(json.loads(line))
            except json.JSONDecodeError: pass
    (dest/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    receipt={'label':label,'argv':args,'cwd':str(BASE),'exit':code,'timedOut':timed,'elapsedSeconds':time.monotonic()-started,'environment':env,'sourceBefore':before,'sourceAfter':hashes(),'recordCount':len(records),'expectedExit':expected}
    (dest/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['label','exit','elapsedSeconds','recordCount']}))
    print('\n'.join(x for x in re.sub(r'\x1b\[[0-9;]*m','',out+err).splitlines() if x.lstrip().startswith(('Test Files','Tests ')) or re.fullmatch(r'\s*\d+ (?:pass|fail|filtered out)\s*',x)))
    assert not timed and code==expected,(label,code,out[-3000:],err[-3000:])
    assert before==hashes(),label+' changed bound source'
    return receipt
if __name__=='__main__':
    mode=sys.argv[1]
    guard=str(ROOT/'tools/read-guard.cjs');retain=str(ROOT/'tools/retain-and-host.cjs')
    preload={'NODE_OPTIONS':f'--require={guard} --require={retain}','QMD_EXPECT_RUNTIME':'node'}
    vit=[NODE,'node_modules/vitest/vitest.mjs','run','--maxWorkers=1','--no-cache','--reporter=verbose']
    changed='publishes a complete child stage|witnesses real E delivery|missing-stage diagnostics|identical primary stage error|rejects caller EOF'
    if mode=='node':
        label='node-full49';run(label,vit+['test/audit-recovery-execution-admission.test.ts'],{**preload,'QMD_FIXTURE_ARCHIVE':str(E/label/'fixtures')})
    elif mode=='bun':
        label='native-bun-selected-corrected';run(label,[BUN,'test','--preload',guard,'--preload',retain,'./test/audit-recovery-execution-admission.test.ts','--timeout','30000','--test-name-pattern',changed],{'QMD_EXPECT_RUNTIME':'bun','QMD_FIXTURE_ARCHIVE':str(E/label/'fixtures')})
    elif mode in ['wrapper-off','wrapper-on']:
        run(mode,vit+['test/audit-native-bun-recovery.test.ts','-t','preserves proof across sequential|survives eight active-call GC|cleans the owned worker on a real parent'],{**preload,'QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS':'1' if mode=='wrapper-on' else '0'})
    elif mode=='heldout-extract': run('heldout-extract',[NODE,'--require',guard,str(ROOT/'tools/extract-heldout.cjs')])
    elif mode=='strict': run('strict',[NODE,'--require',guard,str(ROOT/'tools/strict-check.cjs')])
    elif mode=='guard-negative': run('guard-negative',[NODE,'--require',guard,'-e',"const fs=require('node:fs');require('node:assert/strict').throws(()=>fs.readFileSync('/Users/shersingh/github/qmd-mlx-search/src/index.ts'),e=>e.code==='REVIEW_READ_DENIED');console.log('Real live-source read refused before bytes')"])
    else: raise ValueError(mode)
