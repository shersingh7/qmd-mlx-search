from pathlib import Path
import hashlib,json,os,selectors,signal,subprocess,time,sys
ROOT=Path(__file__).resolve().parent.parent;E=ROOT/'evidence/heldout';ENV=json.loads((ROOT/'environment.json').read_text())
bindings=json.loads((E/'bindings.json').read_text());all_results=[]
def alive(pid):
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
def optional(p):return p.read_text() if p.exists() else None
for label in ['real-E-interrupted','no-E','no-admission']:
    folder=E/label;wrapper=folder/'execution-boundary.py';assert hashlib.sha256(wrapper.read_bytes()).hexdigest()==bindings['generated'][label]['sha256']
    work=folder/'work';config={'command':['/bin/sh','-c','printf real-heldout-work > "$1"','owned-shell',str(work)],'timeoutMs':200,'contained':False}
    sentinel=subprocess.Popen(['/usr/bin/python3','-B','-S','-c','import time;time.sleep(60)'],env=ENV,start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    argv=['/usr/bin/python3','-B','-S','-u',str(wrapper),json.dumps(config)]
    process=subprocess.Popen(argv,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    sel=selectors.DefaultSelector();sel.register(process.stdout,selectors.EVENT_READ,'out');sel.register(process.stderr,selectors.EVENT_READ,'err')
    pending=b'';out=b'';err=b'';messages=[];worker=None;actions=[];kills=[];started=time.monotonic();failure=None
    try:
        while sel.get_map() and time.monotonic()-started<1.8:
            for key,_ in sel.select(.005):
                data=os.read(key.fileobj.fileno(),65536)
                if not data:sel.unregister(key.fileobj);continue
                if key.data=='err':err+=data;continue
                out+=data;pending+=data
                while b'\n' in pending:
                    line,pending=pending.split(b'\n',1);message=json.loads(line);messages.append(message)
                    if message['type']=='prepared':
                        if label=='no-admission':process.stdin.close();actions.append('EOF without S')
                        else:process.stdin.write(b'S200\n');process.stdin.flush();actions.append('S200 after actual PREPARED')
                    if message['type']=='ready':
                        worker=message['pid']
                        if label=='real-E-interrupted':process.stdin.write(b'E');process.stdin.flush();actions.append('actual E after READY')
                        process.stdin.close();actions.append('actual caller EOF')
        assert not sel.get_map(),'product did not drain in original 1800ms guard'
        process.wait(timeout=.1)
        stage=optional(folder/'stage.json');validation=optional(folder/'validation.json');reaps=[json.loads(s) for s in (optional(folder/'reaps.jsonl') or '').splitlines() if s]
        receipt={'label':label,'argv':argv,'actualInterpreter':'/usr/bin/python3','wrapperSha256':hashlib.sha256(wrapper.read_bytes()).hexdigest(),'productSha256':bindings['productSha256'],'elapsedMs':(time.monotonic()-started)*1000,'exitCode':process.returncode,'supervisorPid':process.pid,'workerPid':worker,'supervisorAbsent':not alive(process.pid),'workerAbsent':worker is None or not alive(worker),'sentinelAlive':alive(sentinel.pid),'stage':json.loads(stage) if stage else None,'validation':json.loads(validation) if validation else None,'queuedEOF':optional(folder/'queued-eof.json'),'gateForwarded':optional(folder/'gate-forwarded.json'),'reaps':reaps,'messages':messages,'actions':actions,'work':optional(work),'fixtureCleanupStarted':False}
        (folder/'before-finally.json').write_text(json.dumps(receipt,indent=2)+'\n')
        assert receipt['supervisorAbsent'] and receipt['workerAbsent'] and receipt['sentinelAlive'] and receipt['work'] is None
        if worker is not None:assert any(x['pid']==worker and x['owner']==process.pid for x in reaps)
        if label=='real-E-interrupted':
            assert receipt['stage']['witness']=='child-received-E' and receipt['stage']['pid']==worker and receipt['stage']['owner']==process.pid
            assert receipt['validation']['allowed'] is False and receipt['validation']['remainingMs']>0
            assert receipt['queuedEOF'] is not None and receipt['gateForwarded'] is None
            assert messages[-1]['type']=='cleanup' and messages[-1]['childReaped'] is True
        else:
            assert receipt['stage'] is None and receipt['validation'] is None and receipt['queuedEOF'] is None and receipt['gateForwarded'] is None
            if label=='no-admission':assert worker is None and not (folder/'forks.jsonl').exists() and not reaps
        all_results.append(receipt);print(json.dumps({'heldout':label,'passed':True,'stage':receipt['stage'],'validation':receipt['validation']}))
    except BaseException as error:
        failure=repr(error);raise
    finally:
        if process.poll() is None:kills.append(process.pid);process.kill();process.wait(timeout=2)
        # Only the still-owned leader handle may be signalled here; a failed child proof is not numeric signal authority.
        sentinel.kill();sentinel.wait(timeout=2);sel.close()
        (folder/'stdout.log').write_bytes(out);(folder/'stderr.log').write_bytes(err)
        (folder/'finally.json').write_text(json.dumps({'failure':failure,'subjectFinallyKills':kills,'sentinelReaped':not alive(sentinel.pid),'fixtureCleanupStarted':True},indent=2)+'\n')
        assert not kills,'fixture cleanup masked missing product termination'
(E/'causal-results.json').write_text(json.dumps(all_results,indent=2)+'\n')
# Exercise source-exact exclusive publisher on the real product interpreter, not the review interpreter.
argv=['/usr/bin/python3','-B','-S',str(ROOT/'tools/publication-contract.py')];result=subprocess.run(argv,env=ENV,capture_output=True,text=True,timeout=10)
(E/'publication-contract-execution.json').write_text(json.dumps({'argv':argv,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
print(result.stdout.strip());assert result.returncode==0,result.stderr
