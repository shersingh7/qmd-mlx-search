from pathlib import Path
import ast,builtins,hashlib,json,os,sys,time,types
ROOT=Path(__file__).resolve().parent.parent;E=ROOT/'evidence/heldout'
source=E/'no-E/execution-boundary.py';text=source.read_text();tree=ast.parse(text)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='publish_stage')
segment=ast.get_source_segment(text,node);(E/'exact-publish-stage.py').write_text(segment+'\n')
# No production mutation: remap only literal fixture paths into a separate unit-test root.
base=E/'publication-contract';base.mkdir();oldroot=source.parent
stage=base/'stage.json';temp=base/('stage.json.'+str(os.getpid())+'.tmp');victim=base/'unrelated-owned-victim';victim.write_text('KEEP')
handles=[];events=[];mode='positive'
def mapped(p):
    p=Path(p);assert p.parent==oldroot,(p,oldroot);return base/p.name
def open_file(file,*args,**kwargs):
    target=mapped(file);assert args==('x',),args;assert target.parent==stage.parent and target==temp
    h=builtins.open(target,*args,**kwargs);handles.append(h);events.append({'operation':'exclusive-open','mode':args[0],'target':str(target),'finalPresent':stage.exists()});return h
def dump(value,out):
    assert not stage.exists(),'stage prematurely visible'
    if mode=='write-fail':out.write('{"partial":');raise OSError('heldout write error')
    json.dump(value,out)
def replace(src,dst):
    src,dst=mapped(src),mapped(dst)
    assert src==temp and dst==stage and src.parent==dst.parent
    assert handles[-1].closed,'rename before complete close'
    value=json.loads(src.read_text());assert value['stage']=='heldout'
    events.append({'operation':'rename-after-close','source':str(src),'target':str(dst),'completeJson':True,'closed':handles[-1].closed})
    if mode=='rename-fail':raise OSError('heldout replace error')
    os.replace(src,dst)
namespace={'open':open_file,'os':types.SimpleNamespace(getpid=os.getpid,replace=replace),'json':types.SimpleNamespace(dump=dump),'owner':os.getpid(),'time':time}
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),namespace)
publish=namespace['publish_stage'];controls=[]
publish('heldout','real-unit');value=json.loads(stage.read_text());assert value['witness']=='real-unit' and not temp.exists();controls.append({'case':'positive','json':value,'closedBeforeRename':True});stage.unlink()
for alias in ['symlink','hardlink']:
    if alias=='symlink': temp.symlink_to(victim)
    else: os.link(victim,temp)
    try:publish('heldout');raise AssertionError('alias was accepted')
    except FileExistsError:pass
    assert victim.read_text()=='KEEP' and not stage.exists();controls.append({'case':alias,'refusedExclusive':True,'unrelatedBytesIntact':True,'finalAbsent':True});temp.unlink()
for failure in ['write-fail','rename-fail']:
    mode=failure
    try:publish('heldout');raise AssertionError('fault was accepted')
    except OSError as error:assert str(error).startswith('heldout ')
    assert not stage.exists() and temp.exists() and handles[-1].closed
    controls.append({'case':failure,'finalAbsent':True,'ownedTemporaryRetained':True,'temporaryBytes':temp.stat().st_size,'closed':handles[-1].closed});temp.unlink()
result={'actualInterpreter':sys.executable,'pythonVersion':sys.version,'sourceWrapper':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exactFunctionSha256':hashlib.sha256(segment.encode()).hexdigest(),'pathMapping':{'from':str(oldroot),'to':str(base)},'controls':controls,'events':events,'qualification':'Source-exact publisher body with unit-only owned path remapping. Actual held-open process race is separately exercised by unchanged candidate tests.'}
(E/'publication-contract.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'publicationControls':len(controls),'passed':True,'actualInterpreter':sys.executable}))
