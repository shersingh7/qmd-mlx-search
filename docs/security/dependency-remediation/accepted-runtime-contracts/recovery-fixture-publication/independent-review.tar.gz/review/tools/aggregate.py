from pathlib import Path
import collections,hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parent.parent;E=ROOT/'evidence';BASE=ROOT/'candidate';LIVE=Path('/Users/shersingh/github/qmd-mlx-search');A=Path('/Users/shersingh/.hermes/cache/scratch/qmd-fixture-owner-a-1fz0d84c')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((E/'source-manifest.json').read_text());assert all(sha(BASE/k)==v for k,v in manifest.items())
post={'test/audit-recovery-execution-admission.test.ts':'9b305d366775be0e04a856a47ea40be467c37d7f7fe14644d81adeda028fdc0b','test/fixtures/bun_recovery_ownership.ts':'8830c5fff7e66b82141a47c2a03cf92e97bbb858793ed0d7e979bc21bfed1592'}
pre={'test/audit-recovery-execution-admission.test.ts':'6a516aebe57bcd1580adb8d83a99d5d5e4bb41a5685f5d334e06d2d721b79010','test/fixtures/bun_recovery_ownership.ts':'125d2ec7269ef2035e71a9ad2a98f7ed11e66e6386dd57a5f0307de2e34243cb'}
assert all(sha(LIVE/k)==v and sha(BASE/k)==post[k] for k,v in pre.items())
summary={'scope':list(post),'postimages':post,'preimagesStillLive':pre,'runs':{},'assertionPreservation':{}}
for name in pre:
    old=collections.Counter(line.strip() for line in (LIVE/name).read_text().splitlines() if 'expect(' in line or 'assert.' in line)
    new=collections.Counter(line.strip() for line in (BASE/name).read_text().splitlines());missing=old-new
    assert not missing,(name,missing)
    summary['assertionPreservation'][name]={'originalLines':sum(old.values()),'missing':dict(missing),'note':'Mechanical check is supplemental; all original cases independently executed in full49 or unchanged native wrapper.'}
for label in ['node-full49','native-bun-selected-corrected','wrapper-off','wrapper-on','red-no-atomic-no-witness','atomic-only-no-witness']:
    out=E/label;receipt=json.loads((out/'execution.json').read_text());raw=(out/'stdout.log').read_text()+(out/'stderr.log').read_text();raw=re.sub(r'\x1b\[[0-9;]*m','',raw);records=json.loads((out/'records.json').read_text())
    hosts=[json.loads(p.read_text()) for p in out.glob('actual-host.*.json')];assert hosts,label
    summary['runs'][label]={'exit':receipt['exit'],'actualHosts':[{'runtime':h['runtime'],'execPath':h['execPath'],'node':h['versions']['node'],'bun':h['versions'].get('bun')} for h in hosts],'summaries':[x.strip() for x in raw.splitlines() if x.lstrip().startswith(('Test Files','Tests ')) or re.fullmatch(r'\s*\d+ (?:pass|fail|filtered out)\s*',x)],'records':len(records)}
    finals=[r for r in records if r['evidence'].endswith('-finally') and not r['evidence'].endswith('-before-finally')]
    assert all(not r.get('finallyKilled') for r in finals),label
    if label=='node-full49':
        assert receipt['exit']==0 and re.search(r'Tests\s+49 passed \(49\)',raw)
        before=[r for r in records if r['evidence']=='recovery-execution-admission-before-finally'];assert len(before)==17,len(before)
        for r in before:
            assert r['supervisorAbsent'] and r['workerAbsent'] and r['sentinelAlive'] and not r['guardFired'] and not r['fixtureCleanupStarted']
            assert any(x['pid']==r['workerPid'] and x['owner']==r['supervisorPid'] for x in r['reaps'])
            positive=r['stage']=='none' and r['grant']=='open' and 'fault' not in r
            assert r['work']==('actual-user-work' if positive else None)
        stage=next(r for r in before if r.get('probe')=='stage-open-hold');assert json.loads(stage['probeRecord'])['stageVisible'] is False and json.loads(stage['stageAtEOF'])['stage']=='child-validation'
        eof=[r for r in before if r['stage']=='supervisor-forwarded' and r['forwardDelayMs']==0];assert len(eof)==2
        for r in eof:
            m=json.loads(r['stageRecord']);assert m['witness']=='child-received-E' and m['pid']==r['workerPid'] and m['owner']==r['supervisorPid']
            assert r['validation']['allowed'] is False and r['validation']['remainingMs']>0 and r['queuedEof']
        noE=next(r for r in before if r['grant']=='none');assert noE['stageRecord'] is None and noE['validation'] is None and noE['work'] is None
        hostsBefore=[r for r in records if r['evidence']=='recovery-parent-death-before-finally'];assert len(hostsBefore)==22,len(hostsBefore)
        assert all(r['supervisorsAbsent'] and r['workersAbsent'] and r['sentinelAlive'] and not r['guardFired'] for r in hostsBefore)
        modes=collections.Counter((r['runtime'],r['mode']) for r in hostsBefore)
        assert len([r for r in hostsBefore if r['mode']=='valid' and r['work']=='actual-user-work'])==2
        missing=[r for r in records if r['evidence']=='recovery-missing-stage-before-finally'];assert len(missing)==1
        m=missing[0];assert not m['stageFilePresent'] and not m['forks'] and not m['workFilePresent'] and m['helperJsonComplete'] and not m['fixtureCleanupStarted']
        assert m['helper']['launch']['state']=='not-started' and m['helper']['launch']['supervisorReaped'] and not m['helper']['launch']['admissionGranted']
        missingIndex=records.index(m);finalIndex=next(i for i in range(missingIndex+1,len(records)) if records[i]['evidence']=='recovery-parent-death-finally');assert finalIndex>missingIndex
        summary['nodeContracts']={'rawCases':len(before),'hostCases':len(hostsBefore),'hostModes':{str(k):v for k,v in modes.items()},'positiveLeaseEOFRemainingMs':[r['validation']['remainingMs'] for r in eof],'missingSnapshotBeforeFinally':True,'allSubjectFixtureKillsEmpty':True,'noEMarkerAbsent':True,'completeStageAtActualEOF':True}
    elif label.startswith('wrapper-'):
        obs=[r for r in records if r['evidence']=='native-recovery-before-finally'];assert len(obs)==13,len(obs)
        enabled=label=='wrapper-on';assert sum('descriptorObservation' in r for r in obs)==(13 if enabled else 0)
        assert all(r['parentAbsent'] and r['sentinelAlive'] and r['descriptorSentinelOpen'] and not r['guardFired'] for r in obs)
        reuse=[r for r in obs if r['scenario']=='fd-reuse' and r['index']>1];assert len(reuse)==7 and all(r['reusedFDs'] for r in reuse)
        assert all(r['gcDuringActive'] for r in obs if r['scenario']=='fd-reuse' and r['index']>=1)
        if enabled:
            for r in obs:
                fd=r['descriptorObservation'];assert fd['scope']=='parent-side-fstat-only-not-writer-or-resource-identity'
                assert all(isinstance(v,int) for key in ['beforeFDs','seenActiveFDs','atReturnFDs'] for v in fd[key])
                assert set(r['activeFDs']).issubset(fd['seenActiveFDs'])
        summary['runs'][label].update({'nativeCalls':len(obs),'optionalFDObservations':sum('descriptorObservation' in r for r in obs),'requiredReuseObservations':len(reuse),'scenarios':dict(collections.Counter(r['scenario'] for r in obs))})
    elif label.startswith(('red-','atomic-')):
        before=[r for r in records if r['evidence']=='recovery-execution-admission-before-finally'];assert len(before)==2
        stage=before[0];eof=before[1]
        assert eof['stageRecord'] is None and eof['queuedEof'] and eof['validation']['allowed'] is False and eof['validation']['remainingMs']>0 and eof['work'] is None
        assert json.loads(stage['probeRecord'])['stageVisible']==label.startswith('red-')
        if label.startswith('red-'): assert stage['stageAtEOF']=='',stage
        else: assert json.loads(stage['stageRecord'])['stage']=='child-validation' and json.loads(stage['stageAtEOF'])['stage']=='child-validation'
        summary['runs'][label]['causalNullRemainingMs']=eof['validation']['remainingMs']
# Actual preload evidence including native Bun flags, strict reads and an independently denied live path.
guards={}
for p in E.glob('*-guard-*.jsonl'):
    rows=[json.loads(x) for x in p.read_text().splitlines()];key=p.name.split('-guard-')[0];entry=guards.setdefault(key,{'files':0,'reads':0,'denied':[],'hosts':[]});entry['files']+=1
    for r in rows:
        if r['kind']=='read':entry['reads']+=1;entry['denied']+=([r] if not r['allowed'] else [])
        elif r['kind']=='host-start':entry['hosts'].append({'execPath':r['execPath'],'node':r['versions']['node'],'bun':r['versions'].get('bun')})
for key,g in guards.items():
    if key=='guard-negative':assert len(g['denied'])==1 and g['denied'][0]['real']==str(LIVE/'src/index.ts')
    elif key in ['node-full49','wrapper-off','wrapper-on','red-no-atomic-no-witness','atomic-only-no-witness']:
        # Vite's bundled-config resolver probes the ancestor package.json; guard refused before bytes.
        assert len(g['denied'])==3 and all(r['real']=='/Users/shersingh/package.json' and r['allowed'] is False for r in g['denied']),(key,g['denied'])
    else:assert not g['denied'],(key,g['denied'])
assert guards['strict']['reads']>0 and guards['native-bun-selected-corrected']['hosts'][0]['bun']=='1.3.8'
strict=json.loads((E/'strict-result.json').read_text());assert strict['diagnosticCount']==0 and strict['options']['strict'] and strict['options']['noUncheckedIndexedAccess']
summary['strict']={'diagnostics':0,'sourceFiles':len(strict['sourceFiles']),'typescript':strict['typescript'],'roots':strict['roots'],'guardActive':True}
summary['guards']=guards
summary['heldoutCausal']=json.loads((E/'heldout/causal-results.json').read_text())
summary['heldoutPublication']=json.loads((E/'heldout/publication-contract.json').read_text())['controls']
summary['diagnosticIdentity']=json.loads((E/'heldout/bindings.json').read_text())['diagnosticControls']
summary['retainedToolingFailures']=[{'receipt':'native-bun-selected/execution.json','cause':'--preload before test selected package script test rather than native subcommand; rejected unknown --timeout before any tests; corrected by placing --preload after test'}]
summary['upstreamEvidence']='53 explicitly selected indexed A artifacts authenticated; parent already authenticated whole 3096. Source-bound raw RED/atomic/GREEN and parent receipts read, not substituted for reviewer execution.'
summary['productPython']=subprocess.run(['/usr/bin/python3','-B','-S','-c','import sys,json; print(json.dumps({"executable":sys.executable,"version":sys.version}))'],env=json.loads((ROOT/'environment.json').read_text()),capture_output=True,text=True,check=True).stdout.strip()
(E/'independent-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'verified':True,'runs':summary['runs'],'strict':summary['strict'],'guardLabels':list(guards)},indent=2))
