/**
 * QMD SDK - Library mode for programmatic access to QMD search and indexing.
 *
 * Usage:
 *   import { createStore } from '@tobilu/qmd'
 *
 *   const store = await createStore({
 *     dbPath: './my-index.sqlite',
 *     config: {
 *       collections: {
 *         docs: { path: '/path/to/docs', pattern: '**\/*.md' }
 *       }
 *     }
 *   })
 *
 *   const results = await store.search({ query: "how does auth work?" })
 *   await store.close()
 */

import {
  createStore as createStoreInternal,
  hybridQuery,
  structuredSearch,
  extractSnippet,
  addLineNumbers,
  DEFAULT_EMBED_MODEL,
  DEFAULT_MULTI_GET_MAX_BYTES,
  reindexCollection,
  generateEmbeddings,
  listCollections as storeListCollections,
  syncConfigToDb,
  getStoreCollections,
  getStoreCollection,
  getStoreGlobalContext,
  getStoreContexts,
  upsertStoreCollection,
  deleteStoreCollection,
  renameStoreCollection,
  updateStoreContext,
  removeStoreContext,
  setStoreGlobalContext,
  vacuumDatabase,
  cleanupOrphanedContent,
  cleanupOrphanedVectors,
  deleteLLMCache,
  deleteInactiveDocuments,
  clearAllEmbeddings,
  type Store as InternalStore,
  type DocumentResult,
  type DocumentNotFound,
  type SearchResult,
  type HybridQueryResult,
  type HybridQueryOptions,
  type HybridQueryExplain,
  type ExpandedQuery,
  type StructuredSearchOptions,
  type MultiGetResult,
  type IndexStatus,
  type IndexHealthInfo,
  type SearchHooks,
  type ReindexProgress,
  type ReindexResult,
  type EmbedProgress,
  type EmbedResult,
  type EmbedOutcomeStatus,
  type ChunkStrategy,
} from "./store.js";
import {
  runDurableIndexingJob,
} from "./indexing/job.js";
export {
  runDurableIndexingJob,
  validateShadowTarget,
  ShadowDatabaseProtectionError,
  IndexingFingerprintMismatchError,
  FingerprintMismatchError,
  type IndexingJobOptions,
} from "./indexing/job.js";
export {
  computeDescriptorSignature,
  saveCheckpoint,
  getActiveCheckpoint,
  initCheckpointTable,
  type IndexingJobCheckpoint,
  type IndexingFingerprint,
} from "./indexing/checkpoint.js";
import { basename, dirname, join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { accessSync, closeSync, constants, openSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import YAML from "yaml";
import { assertDatabaseAccess, createSavepoint, withExclusiveDatabaseOperation, withoutDatabaseOperation } from "./db.js";
export { DatabaseBusyError } from "./db.js";
import { LlamaCpp } from "./llm.js";
import { throwIfAborted } from "./llm/lifecycle.js";
import {
  withConfigSource,
  loadConfig,
  addCollection as collectionsAddCollection,
  renameCollection as collectionsRenameCollection,
  addContext as collectionsAddContext,
  removeContext as collectionsRemoveContext,
  setGlobalContext as collectionsSetGlobalContext,
  type Collection,
  type CollectionConfig,
  type NamedCollection,
  type ContextMap,
  type ConfigSource,
} from "./collections.js";

// Re-export types for SDK consumers
export type {
  DocumentResult,
  DocumentNotFound,
  SearchResult,
  HybridQueryResult,
  HybridQueryOptions,
  HybridQueryExplain,
  ExpandedQuery,
  StructuredSearchOptions,
  MultiGetResult,
  IndexStatus,
  IndexHealthInfo,
  SearchHooks,
  ReindexProgress,
  ReindexResult,
  EmbedProgress,
  EmbedResult,
  EmbedOutcomeStatus,
  Collection,
  CollectionConfig,
  NamedCollection,
  ContextMap,
};

// Re-export the internal Store type for advanced consumers
export type { InternalStore };

// Re-export utility functions and types used by frontends
export { extractSnippet, addLineNumbers, DEFAULT_MULTI_GET_MAX_BYTES };
export type { ChunkStrategy } from "./store.js";

// Re-export getDefaultDbPath for CLI/MCP that need the default database location
export { getDefaultDbPath } from "./store.js";

// Re-export Maintenance class for CLI housekeeping operations
export { Maintenance } from "./maintenance.js";

// Re-export MLX embedding client for SDK consumers
export {
  MlxEmbedClient,
  embedWithMlx,
  embedBatchWithMlx,
  embedBatchBinaryWithMlx,
  embedBatchConcurrent,
  mlxHealth,
  mlxMemory,
  mlxStats,
  isMlxAvailable,
  type MlxEmbedConfig,
  type MlxHealth,
  type MlxMemory,
  type MlxStats,
} from "./mlx.js";

/**
 * Progress info emitted during update() for each file processed.
 */
export type UpdateProgress = {
  collection: string;
  file: string;
  current: number;
  total: number;
};

/**
 * Aggregated result from update() across all collections.
 */
export type UpdateResult = {
  collections: number;
  indexed: number;
  updated: number;
  unchanged: number;
  removed: number;
  needsEmbedding: number;
};

/**
 * Options for the unified search() method.
 */
export interface SearchOptions {
  /** Cancel pending inference/transport work without releasing active native work early. */
  signal?: AbortSignal;
  /** Simple query string — will be auto-expanded via LLM */
  query?: string;
  /** Pre-expanded queries (from expandQuery) — skips auto-expansion */
  queries?: ExpandedQuery[];
  /** Domain intent hint — steers expansion and reranking */
  intent?: string;
  /** Rerank results using LLM (default: true) */
  rerank?: boolean;
  /** Filter to a specific collection */
  collection?: string;
  /** Filter to specific collections */
  collections?: string[];
  /** Max results (default: 10) */
  limit?: number;
  /** Minimum score threshold */
  minScore?: number;
  /** Include explain traces */
  explain?: boolean;
  /** Chunk strategy: "regex" (default) or "auto" (AST for code files) */
  chunkStrategy?: ChunkStrategy;
}

/**
 * Options for searchLex() — BM25 keyword search.
 */
export interface LexSearchOptions {
  limit?: number;
  collection?: string;
}

/**
 * Options for searchVector() — vector similarity search.
 */
export interface VectorSearchOptions {
  limit?: number;
  collection?: string;
  signal?: AbortSignal;
}

/**
 * Options for expandQuery() — manual query expansion.
 */
export interface ExpandQueryOptions {
  intent?: string;
  signal?: AbortSignal;
}

/**
 * Options for creating a QMD store.
 *
 * Provide `dbPath` and optionally `configPath` (YAML file) or `config` (inline).
 * If neither configPath nor config is provided, the store reads from existing
 * DB state (useful for reopening a previously-configured store).
 */
export interface StoreOptions {
  /** Path to the SQLite database file */
  dbPath: string;
  /** Path to a YAML config file (mutually exclusive with `config`) */
  configPath?: string;
  /** Inline collection config (mutually exclusive with `configPath`) */
  config?: CollectionConfig;
}

/**
 * The QMD SDK store — provides search, retrieval, collection management,
 * context management, and indexing operations.
 *
 * All methods are async. The store manages its own LlamaCpp instance
 * (lazy-loaded, auto-unloaded after inactivity) — no global singletons.
 */
export interface QMDStore {
  /** The underlying internal store (for advanced use) */
  readonly internal: InternalStore;
  /** Path to the SQLite database */
  readonly dbPath: string;

  // ── Search ──────────────────────────────────────────────────────────

  /** Full search: query expansion + multi-signal retrieval + LLM reranking */
  search(options: SearchOptions): Promise<HybridQueryResult[]>;

  /** BM25 keyword search (fast, no LLM) */
  searchLex(query: string, options?: LexSearchOptions): Promise<SearchResult[]>;

  /** Vector similarity search (embedding model, no reranking) */
  searchVector(query: string, options?: VectorSearchOptions): Promise<SearchResult[]>;

  /** Expand a query into typed sub-searches (lex/vec/hyde) for manual control */
  expandQuery(query: string, options?: ExpandQueryOptions): Promise<ExpandedQuery[]>;

  // ── Document Retrieval ──────────────────────────────────────────────

  /** Get a single document by path or docid */
  get(pathOrDocid: string, options?: { includeBody?: boolean }): Promise<DocumentResult | DocumentNotFound>;

  /** Get the body content of a document, optionally sliced by line range */
  getDocumentBody(pathOrDocid: string, opts?: { fromLine?: number; maxLines?: number }): Promise<string | null>;

  /** Get multiple documents by glob pattern or comma-separated list */
  multiGet(pattern: string, options?: { includeBody?: boolean; maxBytes?: number }): Promise<{ docs: MultiGetResult[]; errors: string[] }>;

  // ── Collection Management ───────────────────────────────────────────

  /** Add or update a collection */
  addCollection(name: string, opts: { path: string; pattern?: string; ignore?: string[] }): Promise<void>;

  /** Remove a collection */
  removeCollection(name: string): Promise<boolean>;

  /** Rename a collection */
  renameCollection(oldName: string, newName: string): Promise<boolean>;

  /** List all collections with document stats */
  listCollections(): Promise<{ name: string; pwd: string; glob_pattern: string; doc_count: number; active_count: number; last_modified: string | null; includeByDefault: boolean }[]>;

  /** Get names of collections included by default in queries */
  getDefaultCollectionNames(): Promise<string[]>;

  // ── Context Management ──────────────────────────────────────────────

  /** Add context for a path within a collection */
  addContext(collectionName: string, pathPrefix: string, contextText: string): Promise<boolean>;

  /** Remove context from a collection path */
  removeContext(collectionName: string, pathPrefix: string): Promise<boolean>;

  /** Set global context (applies to all collections) */
  setGlobalContext(context: string | undefined): Promise<void>;

  /** Get global context */
  getGlobalContext(): Promise<string | undefined>;

  /** List all contexts across all collections */
  listContexts(): Promise<Array<{ collection: string; path: string; context: string }>>;

  // ── Indexing ────────────────────────────────────────────────────────

  /** Re-index collections by scanning the filesystem */
  update(options?: {
    collections?: string[];
    onProgress?: (info: UpdateProgress) => void;
  }): Promise<UpdateResult>;

  /** Generate vector embeddings for documents that need them */
  embed(options?: {
    force?: boolean;
    model?: string;
    maxDocsPerBatch?: number;
    maxBatchBytes?: number;
    chunkStrategy?: ChunkStrategy;
    onProgress?: (info: EmbedProgress) => void;
    signal?: AbortSignal;
  }): Promise<EmbedResult>;

  // ── Index Health ────────────────────────────────────────────────────

  /** Get index status (document counts, collections, embedding state) */
  getStatus(): Promise<IndexStatus>;

  /** Get index health info (stale embeddings, etc.) */
  getIndexHealth(): Promise<IndexHealthInfo>;

  // ── Lifecycle ───────────────────────────────────────────────────────

  /** Close the store and release all resources (LLM models, DB connection) */
  close(): Promise<void>;
}

/** Release both resources even if one cleanup fails. Preserve every failure. */
async function closeStoreResources(internal: InternalStore, llm?: LlamaCpp): Promise<void> {
  const errors: unknown[] = [];
  try {
    await withoutDatabaseOperation(internal.db, () => llm?.dispose());
  } catch (error) {
    errors.push(error);
  }
  try {
    internal.close();
  } catch (error) {
    errors.push(error);
  }
  if (errors.length === 1) throw errors[0];
  if (errors.length > 1) throw new AggregateError(errors, "Failed to close QMD store");
}

/** Never truncate the source on a failed config write; own the temp exclusively. */
function writeRemovalConfig(path: string, contents: string, mode: number): void {
  const temporary = join(dirname(path), `.${basename(path)}.${randomUUID()}.tmp`);
  let descriptor: number | undefined;
  let ownsTemporary = false;
  let published = false;
  const errors: unknown[] = [];
  try {
    descriptor = openSync(temporary, "wx", mode);
    ownsTemporary = true;
    writeFileSync(descriptor, contents, "utf8");
    closeSync(descriptor);
    descriptor = undefined;
    renameSync(temporary, path);
    published = true;
  } catch (error) {
    errors.push(error);
  } finally {
    if (descriptor !== undefined) {
      try { closeSync(descriptor); } catch (error) { errors.push(error); }
    }
    if (ownsTemporary && !published) {
      try { unlinkSync(temporary); } catch (error) { errors.push(error); }
    }
  }
  if (errors.length === 1) throw errors[0];
  if (errors.length > 1) throw new AggregateError(errors, "Failed to persist collection removal config", { cause: errors[0] });
}

/**
 * Create a QMD store for programmatic access to search and indexing.
 *
 * @example
 * ```typescript
 * // With a YAML config file
 * const store = await createStore({
 *   dbPath: './index.sqlite',
 *   configPath: './qmd.yml',
 * })
 *
 * // With inline config (no files needed besides the DB)
 * const store = await createStore({
 *   dbPath: './index.sqlite',
 *   config: {
 *     collections: {
 *       docs: { path: '/path/to/docs', pattern: '**\/*.md' }
 *     }
 *   }
 * })
 *
 * const results = await store.search({ query: "authentication flow" })
 * await store.close()
 * ```
 */
export async function createStore(options: StoreOptions): Promise<QMDStore> {
  if (!options.dbPath) {
    throw new Error("dbPath is required");
  }
  if (options.configPath && options.config) {
    throw new Error("Provide either configPath or config, not both");
  }

  // Capture this store's target once. No SDK operation replaces/reset the CLI's
  // process-wide config source. Resolve file paths now so a later chdir is safe.
  const source: ConfigSource | undefined = options.configPath
    ? { configPath: resolve(options.configPath) }
    : options.config ? { config: options.config } : undefined;
  const writeConfig = (action: () => unknown): void => {
    if (source) withConfigSource(source, action);
  };

  // Create the internal store (opens DB, creates tables).
  const internal = createStoreInternal(options.dbPath);
  const db = internal.db;

  let llm: LlamaCpp | undefined;
  let transactionOpen = false;
  try {
    const config = source ? withConfigSource(source, loadConfig) : undefined;
    if (config) {
      // Failed sync/model setup must not leave a half-configured existing DB.
      db.exec("BEGIN IMMEDIATE");
      transactionOpen = true;
      syncConfigToDb(db, config);
    }

    // Models stay lazy and belong to this store. Let LlamaCpp resolve omitted
    // settings from the environment/defaults; never opt into an implicit fallback.
    llm = new LlamaCpp({
      embedModel: config?.models?.embed,
      generateModel: config?.models?.generate,
      rerankModel: config?.models?.rerank,
      embedBackend: config?.models?.embedBackend,
      mlxUrl: config?.models?.mlxUrl,
      mlxDtype: config?.models?.mlxDtype,
      mlxFallback: config?.models?.mlxFallback ?? false,
      mlxConcurrency: config?.models?.mlxConcurrency,
      inactivityTimeoutMs: 5 * 60 * 1000,
      disposeModelsOnInactivity: true,
    });
    internal.llm = llm;
    if (transactionOpen) {
      db.exec("COMMIT");
      transactionOpen = false;
    }
  } catch (error) {
    const errors: unknown[] = [error];
    if (transactionOpen) {
      try { db.exec("ROLLBACK"); } catch (rollbackError) { errors.push(rollbackError); }
    }
    try { await closeStoreResources(internal, llm); } catch (cleanupError) { errors.push(cleanupError); }
    if (errors.length > 1) {
      throw new AggregateError(errors, "Failed to create QMD store and release resources", { cause: error });
    }
    throw error;
  }

  let closePromise: Promise<void> | undefined;
  let closing = false;
  const assertOpen = () => {
    if (closing) throw new Error("QMD store is closing or closed");
    assertDatabaseAccess(db);
  };

  const store: QMDStore = {
    internal,
    dbPath: internal.dbPath,

    // Search
    search: async (opts) => {
      assertOpen();
      throwIfAborted(opts.signal);
      if (!opts.query && !opts.queries) {
        throw new Error("search() requires either 'query' or 'queries'");
      }
      // Normalize collection/collections
      const collections = [...new Set([
        ...(opts.collection ? [opts.collection] : []),
        ...(opts.collections ?? []),
      ])];
      const skipRerank = opts.rerank === false;

      if (opts.queries) {
        // Pre-expanded queries — use structuredSearch
        return structuredSearch(internal, opts.queries, {
          collections: collections.length > 0 ? collections : undefined,
          limit: opts.limit,
          minScore: opts.minScore,
          explain: opts.explain,
          intent: opts.intent,
          skipRerank,
          chunkStrategy: opts.chunkStrategy,
          signal: opts.signal,
        });
      }

      // Simple query string — use hybridQuery (expand + search + rerank)
      return hybridQuery(internal, opts.query!, {
        collections: collections.length > 0 ? collections : undefined,
        limit: opts.limit,
        minScore: opts.minScore,
        explain: opts.explain,
        intent: opts.intent,
        skipRerank,
        chunkStrategy: opts.chunkStrategy,
        signal: opts.signal,
      });
    },
    searchLex: async (q, opts) => { assertOpen(); return internal.searchFTS(q, opts?.limit, opts?.collection); },
    searchVector: async (q, opts) => { assertOpen(); return internal.searchVec(q, internal.llm?.embedModelName ?? DEFAULT_EMBED_MODEL, opts?.limit, opts?.collection, undefined, undefined, opts?.signal); },
    expandQuery: async (q, opts) => { assertOpen(); return internal.expandQuery(q, undefined, opts?.intent, opts?.signal); },
    get: async (pathOrDocid, opts) => { assertOpen(); return internal.findDocument(pathOrDocid, opts); },
    getDocumentBody: async (pathOrDocid, opts) => {
      assertOpen();
      const result = internal.findDocument(pathOrDocid, { includeBody: false });
      if ("error" in result) return null;
      return internal.getDocumentBody(result, opts?.fromLine, opts?.maxLines);
    },
    multiGet: async (pattern, opts) => { assertOpen(); return internal.findDocuments(pattern, opts); },

    // Collection Management — write to SQLite + write-through to YAML/inline if configured
    addCollection: async (name, opts) => {
      assertOpen();
      const existing = getStoreCollection(db, name);
      upsertStoreCollection(db, name, {
        ...existing,
        path: opts.path,
        pattern: opts.pattern,
        ignore: opts.ignore ?? existing?.ignore,
      });
      writeConfig(() => collectionsAddCollection(name, opts.path, opts.pattern, opts.ignore));
    },
    removeCollection: async (name) => {
      assertOpen();
      if (!source) return deleteStoreCollection(db, name);
      if (!getStoreCollection(db, name) && !db.prepare("SELECT 1 FROM documents WHERE collection = ? LIMIT 1").get(name)) return false;

      // Load/serialize without mutating caller-owned inline state. Any DB/FTS
      // deletion remains rollbackable until persistence and outer commit pass.
      const config = withConfigSource(source, loadConfig);
      const originalEntry = Object.getOwnPropertyDescriptor(config.collections, name);
      let publishConfig = () => {};
      let restoreConfig = () => {};
      if (originalEntry) {
        if (source.config) {
          publishConfig = () => { delete config.collections[name]; };
          restoreConfig = () => { Object.defineProperty(config.collections, name, originalEntry); };
        } else {
          const path = source.configPath!;
          const original = readFileSync(path, "utf8");
          const mode = statSync(path).mode & 0o777;
          // Atomic replacement must not silently bypass a read-only source.
          accessSync(path, constants.W_OK);
          const next = { ...config, collections: { ...config.collections } };
          delete next.collections[name];
          const contents = YAML.stringify(next, { indent: 2, lineWidth: 0 });
          publishConfig = () => writeRemovalConfig(path, contents, mode);
          restoreConfig = () => writeRemovalConfig(path, original, mode);
        }
      }
      const transaction = createSavepoint(db);
      let configPublished = false;
      try {
        const result = deleteStoreCollection(db, name);
        if (result) { publishConfig(); configPublished = true; }
        transaction.commit();
        return result;
      } catch (error) {
        const errors: unknown[] = [error];
        try { transaction.rollback(); } catch (rollbackError) { errors.push(rollbackError); }
        // No cross-resource crash atomicity is claimed. A failed DB commit
        // compensates config synchronously, retaining every cleanup failure.
        if (configPublished) {
          try { restoreConfig(); } catch (restoreError) { errors.push(restoreError); }
        }
        if (errors.length > 1) throw new AggregateError(errors, "Failed to remove collection and restore prior state", { cause: error });
        throw error;
      }
    },
    renameCollection: async (oldName, newName) => {
      assertOpen();
      const result = renameStoreCollection(db, oldName, newName);
      if (result) writeConfig(() => collectionsRenameCollection(oldName, newName));
      return result;
    },
    listCollections: async () => { assertOpen(); return storeListCollections(db); },
    getDefaultCollectionNames: async () => {
      assertOpen();
      const collections = storeListCollections(db);
      return collections.filter(c => c.includeByDefault).map(c => c.name);
    },

    // Context Management — write to SQLite + write-through to YAML/inline if configured
    addContext: async (collectionName, pathPrefix, contextText) => {
      assertOpen();
      const result = updateStoreContext(db, collectionName, pathPrefix, contextText);
      if (result) writeConfig(() => collectionsAddContext(collectionName, pathPrefix, contextText));
      return result;
    },
    removeContext: async (collectionName, pathPrefix) => {
      assertOpen();
      const result = removeStoreContext(db, collectionName, pathPrefix);
      if (result) writeConfig(() => collectionsRemoveContext(collectionName, pathPrefix));
      return result;
    },
    setGlobalContext: async (context) => {
      assertOpen();
      setStoreGlobalContext(db, context);
      writeConfig(() => collectionsSetGlobalContext(context));
    },
    getGlobalContext: async () => { assertOpen(); return getStoreGlobalContext(db); },
    listContexts: async () => { assertOpen(); return getStoreContexts(db); },

    // Indexing — reads collections from SQLite
    update: async (updateOpts) => {
      assertOpen();
      return withExclusiveDatabaseOperation(db, "collection update", async () => {
        const collections = getStoreCollections(db);
        const filtered = updateOpts?.collections
          ? collections.filter(c => updateOpts.collections!.includes(c.name))
          : collections;

        internal.clearCache();

        let totalIndexed = 0, totalUpdated = 0, totalUnchanged = 0, totalRemoved = 0;

        for (const col of filtered) {
          const result = await reindexCollection(internal, col.path, col.pattern || "**/*.md", col.name, {
            ignorePatterns: col.ignore,
            onProgress: updateOpts?.onProgress
              ? (info) => updateOpts.onProgress!({ collection: col.name, ...info })
              : undefined,
          });
          totalIndexed += result.indexed;
          totalUpdated += result.updated;
          totalUnchanged += result.unchanged;
          totalRemoved += result.removed;
        }

        return {
          collections: filtered.length,
          indexed: totalIndexed,
          updated: totalUpdated,
          unchanged: totalUnchanged,
          removed: totalRemoved,
          needsEmbedding: internal.getHashesNeedingEmbedding(),
        };
      });
    },

    embed: async (embedOpts) => {
      assertOpen();
      return runDurableIndexingJob(internal, {
        force: embedOpts?.force,
        model: embedOpts?.model,
        maxDocsPerBatch: embedOpts?.maxDocsPerBatch,
        maxBatchBytes: embedOpts?.maxBatchBytes,
        chunkStrategy: embedOpts?.chunkStrategy,
        signal: embedOpts?.signal,
        onProgress: embedOpts?.onProgress ? (info) => embedOpts.onProgress!(info) : undefined,
      });
    },

    // Index Health
    getStatus: async () => { assertOpen(); return internal.getStatus(); },
    getIndexHealth: async () => { assertOpen(); return internal.getIndexHealth(); },

    // Lifecycle
    close: () => {
      if (closePromise) return closePromise;
      try { assertDatabaseAccess(db); }
      catch (error) { return Promise.reject(error); }
      // Acquire ownership synchronously, before disposal can yield or call back.
      // A refused acquisition above leaves the store open and retryable.
      closing = true;
      return closePromise = withExclusiveDatabaseOperation(db, "store closing", () =>
        Promise.resolve().then(() => closeStoreResources(internal, llm)));
    },
  };

  return store;
}
