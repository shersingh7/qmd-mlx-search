async function observeStageFailure(check: () => Promise<void>, snapshot: () => unknown): Promise<void> {
  try { await check(); }
  catch (primary) {
    // Failure-only, before the caller's finally. Observation is not permission
    // to replace the required-stage failure, even if reading/logging fails.
    if (process.env.QMD_RECOVERY_BOOTSTRAP_DIAGNOSTICS === "1") {
      try { console.log(JSON.stringify(snapshot())); } catch { /* preserve primary */ }
    }
    throw primary;
  }
}
function instrument(root: string, stage: Stage, pause: "delay" | "stop", proofToStdout: boolean, fault?: Fault, forwardDelayMs = 250, probe?: FixtureProbe): string {
  const wrapper = path.join(root, "execution-boundary.py");
  writeFileSync(wrapper, `import json,os,select,signal,sys,time
source=${JSON.stringify(source)}
${proofToStdout ? "os.dup2(1,3)" : ""}
sys.path.insert(0,os.path.dirname(source))
scope=dict(__name__='execution_admission_regression')
exec(compile(open(source,'rb').read(),source,'exec'),scope)
original_read,original_write,original_fork,original_waitpid=os.read,os.write,os.fork,os.waitpid
owner=os.getpid()
held=False
if ${probe === "stage-open-hold" ? "True" : "False"}:
    original_open=open
    def open(file,*args,**kwargs):
        out=original_open(file,*args,**kwargs)
        stage_path=${JSON.stringify(path.join(root, "stage.json"))}
        if file==stage_path or str(file).startswith(stage_path+'.'):
            with original_open(${JSON.stringify(path.join(root, "probe.json"))},'x') as record:
                json.dump(dict(probe='stage-open-hold',pid=os.getpid(),stageVisible=os.path.exists(stage_path)),record)
            # Fault only: hold the ACTUAL generated fixture after its real open.
            time.sleep(.040)
        return out
def publish_stage(label,witness=None):
    stage_path=${JSON.stringify(path.join(root, "stage.json"))}
    stage_temp=stage_path+'.'+str(os.getpid())+'.tmp'
    # Existence is a cancellation handshake: publish only a complete record.
    with open(stage_temp,'x') as out:
        json.dump(dict(stage=label,pid=os.getpid(),owner=owner,at=time.monotonic(),witness=witness),out)
    os.replace(stage_temp,stage_path)
def hold(label,publish=True):
    global held
    if held or label!=${JSON.stringify(stage)}: return
    held=True
    if publish: publish_stage(label)
    ${pause === "stop" ? "os.kill(os.getpid(),signal.SIGSTOP)" : "time.sleep(1.300)"}
def read(fd,n):
    data=original_read(fd,n)
    if os.getpid()==owner and fd==0 and data==b'K' and ${fault === "cancel-read-hold" ? "True" : "False"}:
        frame=sys._getframe().f_back
        while frame and not (frame.f_code.co_filename==source and frame.f_code.co_name=='main'):
            frame=frame.f_back
        # Consuming K after real launch-pipe EOF (exec OR child exit) is the
        # legitimate handoff, not pre-admission revocation erasure.
        pre_exec=frame is not None and frame.f_locals.get('launch_eof') is False
        with open(${JSON.stringify(path.join(root, "control-reads.jsonl"))},'a') as out:
            out.write(json.dumps(dict(pid=os.getpid(),preExec=pre_exec))+'\\n')
        if pre_exec:
            with open(${JSON.stringify(path.join(root, "stage.json"))},'w') as out:
                json.dump(dict(stage='cancel-consumed',pid=os.getpid()),out)
            time.sleep(1.300)
    if data==b'E':
        if os.getpid()!=owner and ${stage === "supervisor-forwarded" && forwardDelayMs === 0 ? "True" : "False"}:
            # Real child receipt proves forwarding before its EOF refusal can
            # signal/interrupt the supervisor's auxiliary post-write observer.
            # Do not hold this child: this case requires a still-positive lease.
            publish_stage('supervisor-forwarded','child-received-E')
        hold('supervisor-consumed' if os.getpid()==owner and fd==0 else 'child-consumed')
        # At the post-forward boundary, the child must revalidate a grant that
        # actually aged past its lease, not already execute before parent death.
        if os.getpid()!=owner and ${stage === "supervisor-forwarded" && forwardDelayMs > 0 ? "True" : "False"}: time.sleep(${forwardDelayMs / 1000})
        if os.getpid()!=owner and ${fault === "control-read-error" || fault === "cancel-read-hold" ? "True" : "False"}: time.sleep(.050)
    return data
def write(fd,data):
    if os.getpid()==owner and fd!=3 and data==b'E' and ${stage === "supervisor-forwarded" && forwardDelayMs === 0 ? "True" : "False"}:
        # Isolate live-channel revocation from lease expiry: observe REAL queued
        # EOF before forwarding, rather than spending 50ms of a 200ms lease on
        # an artificial child sleep. EOF is persistent, not consumed authority.
        readable,_,_=select.select([0],[],[],.050)
        assert readable and original_read(0,1)==b''
        with open(${JSON.stringify(path.join(root, "queued-eof.json"))},'w') as out:
            json.dump(dict(pid=os.getpid(),at=time.monotonic()),out)
    if os.getpid()==owner and fd!=3 and data==b'E' and ${probe === "forward-write-hold" ? "True" : "False"}:
        with open(${JSON.stringify(path.join(root, "probe.json"))},'x') as out:
            json.dump(dict(probe='forward-write-hold',pid=os.getpid()),out)
        written=original_write(fd,data)
        # Fault only: child refusal can interrupt the owner after the real E
        # write, BEFORE the auxiliary supervisor-side stage publication.
        time.sleep(.040)
    else:
        written=original_write(fd,data)
    if os.getpid()==owner and fd!=3 and data==b'E':
        with open(${JSON.stringify(path.join(root, "gate-forwarded.json"))},'w') as out:
            json.dump(dict(pid=os.getpid()),out)
        if ${fault === "control-read-error" ? "True" : "False"}: os.close(0)
        hold('supervisor-forwarded',publish=${stage === "supervisor-forwarded" && forwardDelayMs === 0 ? "False" : "True"})
        # Preserve the reviewer's real runnable-child slice after forwarding.
        if ${stage === "supervisor-consumed" ? "True" : "False"}: time.sleep(.050)
    return written
def fork():
    pid=original_fork()
    if pid:
        with open(${JSON.stringify(path.join(root, "forks.jsonl"))},'a') as out:
            out.write(json.dumps(dict(parent=os.getpid(),pid=pid))+'\\n')
    return pid
def waitpid(*args):
    result=original_waitpid(*args)
    with open(${JSON.stringify(path.join(root, "reaps.jsonl"))},'a') as out:
        out.write(json.dumps(dict(owner=os.getpid(),pid=result[0],status=result[1]))+'\\n')
    return result
os.read,os.write,os.fork,os.waitpid=read,write,fork,waitpid
if ${fault === "proof-write-error" ? "True" : "False"}:
    original_send=scope['send']
    proof_closed=False
    def send(message):
        global proof_closed
        if message['type']=='ready' and not proof_closed:
            proof_closed=True
            os.close(3) # A real EBADF on the next production proof write.
        original_send(message)
    scope['send']=send
if 'execution_allowed' in scope:
    original_allowed=scope['execution_allowed']
    def allowed(*args):
        hold('child-validation')
        remaining=(args[1]-time.monotonic())*1000
        result=original_allowed(*args)
        with open(${JSON.stringify(path.join(root, "validation.json"))},'w') as out:
            json.dump(dict(pid=os.getpid(),allowed=result,remainingMs=remaining),out)
        if result: hold('child-admitted')
        return result
    scope['execution_allowed']=allowed
if ${probe === "startup-delay" ? "True" : "False"}:
    with open(${JSON.stringify(path.join(root, "probe.json"))},'x') as out:
        json.dump(dict(probe='startup-delay',pid=os.getpid()),out)
    time.sleep(.250) # Fixture-only: exhaust, never restart, the caller budget.
scope['main']()
`);
  return wrapper;
}
