import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {existsSync,writeFileSync} from 'node:fs';
import {executeRecoveryWorker} from "file:///Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/candidate/scripts/phase5_e2e_runner.ts";
const source="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/candidate/scripts/phase5_recovery_process.py",wrapper="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-PJYJi1/execution-boundary.py",root="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-PJYJi1";
if ((process.versions as Record<string,string>).bun) {
  const bun=(globalThis as any).Bun,original=bun.spawn;
  bun.spawn=function(command:string[],options:unknown) {
    return original.call(bun,command[3]===source?[...command.slice(0,3),wrapper,...command.slice(4)]:command,options);
  };
} else {
  const original=childProcess.spawn;
  (childProcess as any).spawn=function(executable:string,args:string[],options:unknown) {
    return original(executable,args[2]===source?[...args.slice(0,2),wrapper,...args.slice(3)]:args,options as any);
  }; syncBuiltinESMExports();
}
const events=['exit','SIGTERM','SIGINT'];
const hooksBefore=events.map(event=>process.listenerCount(event));
writeFileSync(root+'/started.json',JSON.stringify({executable:process.execPath,versions:process.versions}));
const started=performance.now();
const helper=executeRecoveryWorker({dbPath:root+'/unused.sqlite',docsDir:root,outputJson:root+'/absent-report.json',stateRoot:root+'/state',
  timeoutMs:200,command:['/bin/sh','-c','printf actual-user-work > "$1"','owned-shell',root+'/work']});
const exitPoll=undefined;
let guardFired=false;
const guard=setTimeout(()=>{guardFired=true;process.exitCode=99;},1800);
const result=await helper;
clearTimeout(guard);if(exitPoll)clearInterval(exitPoll);
writeFileSync(root+'/helper.json',JSON.stringify({elapsedMs:performance.now()-started,hooksBefore,hooksAfter:events.map(event=>process.listenerCount(event)),guardFired,result}));
