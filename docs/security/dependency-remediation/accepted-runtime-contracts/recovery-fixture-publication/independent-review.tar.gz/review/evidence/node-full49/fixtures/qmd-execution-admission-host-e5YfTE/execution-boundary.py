import json,os,select,signal,sys,time
source="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/candidate/scripts/phase5_recovery_process.py"

sys.path.insert(0,os.path.dirname(source))
scope=dict(__name__='execution_admission_regression')
exec(compile(open(source,'rb').read(),source,'exec'),scope)
original_read,original_write,original_fork,original_waitpid=os.read,os.write,os.fork,os.waitpid
owner=os.getpid()
held=False
if False:
    original_open=open
    def open(file,*args,**kwargs):
        out=original_open(file,*args,**kwargs)
        stage_path="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/stage.json"
        if file==stage_path or str(file).startswith(stage_path+'.'):
            with original_open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/probe.json",'x') as record:
                json.dump(dict(probe='stage-open-hold',pid=os.getpid(),stageVisible=os.path.exists(stage_path)),record)
            # Fault only: hold the ACTUAL generated fixture after its real open.
            time.sleep(.040)
        return out
def publish_stage(label,witness=None):
    stage_path="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/stage.json"
    stage_temp=stage_path+'.'+str(os.getpid())+'.tmp'
    # Existence is a cancellation handshake: publish only a complete record.
    with open(stage_temp,'x') as out:
        json.dump(dict(stage=label,pid=os.getpid(),owner=owner,at=time.monotonic(),witness=witness),out)
    os.replace(stage_temp,stage_path)
def hold(label,publish=True):
    global held
    if held or label!="supervisor-consumed": return
    held=True
    if publish: publish_stage(label)
    time.sleep(1.300)
def read(fd,n):
    data=original_read(fd,n)
    if os.getpid()==owner and fd==0 and data==b'K' and False:
        frame=sys._getframe().f_back
        while frame and not (frame.f_code.co_filename==source and frame.f_code.co_name=='main'):
            frame=frame.f_back
        # Consuming K after real launch-pipe EOF (exec OR child exit) is the
        # legitimate handoff, not pre-admission revocation erasure.
        pre_exec=frame is not None and frame.f_locals.get('launch_eof') is False
        with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/control-reads.jsonl",'a') as out:
            out.write(json.dumps(dict(pid=os.getpid(),preExec=pre_exec))+'\n')
        if pre_exec:
            with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/stage.json",'w') as out:
                json.dump(dict(stage='cancel-consumed',pid=os.getpid()),out)
            time.sleep(1.300)
    if data==b'E':
        if os.getpid()!=owner and False:
            # Real child receipt proves forwarding before its EOF refusal can
            # signal/interrupt the supervisor's auxiliary post-write observer.
            # Do not hold this child: this case requires a still-positive lease.
            publish_stage('supervisor-forwarded','child-received-E')
        hold('supervisor-consumed' if os.getpid()==owner and fd==0 else 'child-consumed')
        # At the post-forward boundary, the child must revalidate a grant that
        # actually aged past its lease, not already execute before parent death.
        if os.getpid()!=owner and False: time.sleep(0.25)
        if os.getpid()!=owner and False: time.sleep(.050)
    return data
def write(fd,data):
    if os.getpid()==owner and fd!=3 and data==b'E' and False:
        # Isolate live-channel revocation from lease expiry: observe REAL queued
        # EOF before forwarding, rather than spending 50ms of a 200ms lease on
        # an artificial child sleep. EOF is persistent, not consumed authority.
        readable,_,_=select.select([0],[],[],.050)
        assert readable and original_read(0,1)==b''
        with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/queued-eof.json",'w') as out:
            json.dump(dict(pid=os.getpid(),at=time.monotonic()),out)
    if os.getpid()==owner and fd!=3 and data==b'E' and False:
        with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/probe.json",'x') as out:
            json.dump(dict(probe='forward-write-hold',pid=os.getpid()),out)
        written=original_write(fd,data)
        # Fault only: child refusal can interrupt the owner after the real E
        # write, BEFORE the auxiliary supervisor-side stage publication.
        time.sleep(.040)
    else:
        written=original_write(fd,data)
    if os.getpid()==owner and fd!=3 and data==b'E':
        with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/gate-forwarded.json",'w') as out:
            json.dump(dict(pid=os.getpid()),out)
        if False: os.close(0)
        hold('supervisor-forwarded',publish=True)
        # Preserve the reviewer's real runnable-child slice after forwarding.
        if True: time.sleep(.050)
    return written
def fork():
    pid=original_fork()
    if pid:
        with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/forks.jsonl",'a') as out:
            out.write(json.dumps(dict(parent=os.getpid(),pid=pid))+'\n')
    return pid
def waitpid(*args):
    result=original_waitpid(*args)
    with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/reaps.jsonl",'a') as out:
        out.write(json.dumps(dict(owner=os.getpid(),pid=result[0],status=result[1]))+'\n')
    return result
os.read,os.write,os.fork,os.waitpid=read,write,fork,waitpid
if False:
    original_send=scope['send']
    proof_closed=False
    def send(message):
        global proof_closed
        if message['type']=='ready' and not proof_closed:
            proof_closed=True
            os.close(3) # A real EBADF on the next production proof write.
        original_send(message)
    scope['send']=send
if 'execution_allowed' in scope:
    original_allowed=scope['execution_allowed']
    def allowed(*args):
        hold('child-validation')
        remaining=(args[1]-time.monotonic())*1000
        result=original_allowed(*args)
        with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/validation.json",'w') as out:
            json.dump(dict(pid=os.getpid(),allowed=result,remainingMs=remaining),out)
        if result: hold('child-admitted')
        return result
    scope['execution_allowed']=allowed
if True:
    with open("/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/isolated/tmpdir/qmd-execution-admission-host-e5YfTE/probe.json",'x') as out:
        json.dump(dict(probe='startup-delay',pid=os.getpid()),out)
    time.sleep(.250) # Fixture-only: exhaust, never restart, the caller budget.
scope['main']()
