def publish_stage(label,witness=None):
    stage_path="/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3/evidence/heldout/no-E/stage.json"
    stage_temp=stage_path+'.'+str(os.getpid())+'.tmp'
    # Existence is a cancellation handshake: publish only a complete record.
    with open(stage_temp,'x') as out:
        json.dump(dict(stage=label,pid=os.getpid(),owner=owner,at=time.monotonic(),witness=witness),out)
    os.replace(stage_temp,stage_path)
