# SPEC review — A recovery-fixture repair

**Verdict: PASS (two-file scoped candidate; not release or CI acceptance).**

Independent reviewer workspace: `/Users/shersingh/.hermes/cache/scratch/qmd-review-a-avm1bin3`.
Only reviewer-owned scratch files were written. The frozen producer artifacts, parent composition, shared dependency files and live repository were not edited. No install, network, staging, commit, service, model/GPU, private-index or delegation work was performed.

## Exact candidate and review boundary

| Path | Verified postimage SHA256 |
|---|---|
| `test/audit-recovery-execution-admission.test.ts` | `9b305d366775be0e04a856a47ea40be467c37d7f7fe14644d81adeda028fdc0b` |
| `test/fixtures/bun_recovery_ownership.ts` | `8830c5fff7e66b82141a47c2a03cf92e97bbb858793ed0d7e979bc21bfed1592` |

- The supplied patch SHA256 is `21a74212439e8e6a1393e472dabbe0dc72d37d23db8bff42dee91ab94922e021`. Its only two `+++` paths are those above. Independently applying it to the exact live preimages in an owned two-file derivative produced both exact postimages (`evidence/patch-check.json`). Both live targets still have their stated original preimage hashes.
- Producer INDEX/REPORT hashes match the supplied digests. I authenticated 53 explicitly selected indexed report/receipt/raw-log/reduction artifacts against that INDEX. The parent's prior authentication of all 3096 artifacts is not represented as my own complete rehash.
- The execution closure consists of 50 verified public composition files, bound in `evidence/source-manifest.json`, from parent `source-after.json` SHA256 `7197501a2c7034693eb428063aeaa7571c53378d0d96acceafa0f19aafe7f23e`. It includes the parent's current AST bytes, not an import/reversion of A's historical AST snapshot. No broad equality claim about the live tree is necessary.

## Independent execution

All runs used a constructed environment allowlist, owned HOME/Hermes/knowledge/XDG/HF/TMP/tool caches, offline settings, `QMD_LLAMA_GPU=false`, `CI=1`, `REQUIRE_BUN=1`, and one Vitest worker. Before the first RED run, each derivative had its own real `node_modules` directory, **281 freshly resolved current per-package aliases**, and owned `.vite`, `.vite-temp`, `.cache`, `.vitest` directories. Inherited credential/context values were neither propagated nor printed.

| Reviewer execution | Observed result |
|---|---|
| `red-no-atomic-no-witness` — only publisher/witness changes reversed, final candidate tests retained | **2 failed, 47 filtered/skipped** |
| `atomic-only-no-witness` — real atomic publisher, old supervisor observation point | **1 passed, 1 failed, 47 filtered/skipped** |
| `node-full49` — exact final candidate, actual Node **22.22.3** | **49 passed, 0 failed, 0 skipped**, one file |
| `native-bun-selected-corrected` — native `bun test`, actual Bun **1.3.8**, explicit preloads | **6 passed, 0 failed, 43 filtered**, not a full native suite |
| `wrapper-off` / `wrapper-on` — unchanged `runNative` wrapper | **4 passed, 3 filtered/skipped each**; **13 real Bun calls per mode** |
| Source-exact held-out process controls | **Real interrupted E, no E, no admission all passed** |
| Source-exact publisher body on literal `/usr/bin/python3`, unit-only owned path remapping | **5 controls passed**: complete/closed rename, symlink refusal, hardlink refusal, write failure, rename failure |
| Two-root strict TypeScript + actual transitive declarations | **0 diagnostics**, TS **5.9.3**, strict + noUncheckedIndexedAccess; active guard |

Each test invocation has raw stdout/stderr, parsed records, argv, environment, source bindings and actual-host receipts beneath `evidence/<label>/`. Summaries are checked programmatically in `tools/aggregate.py` and `evidence/independent-summary.json`; no older-source counts or deleted temporary executable were used as final-source acceptance.

## Requirement findings

### 1. Complete, exclusively owned atomic readiness — PASS

Candidate admission file lines **74–86** creates `stage.json.<pid>.tmp` in the same call-owned, unpredictable mkdtemp directory with exclusive `'x'`, writes JSON through that actual returned file object, exits the context (closing the complete record), then uses `os.replace`. Failure is not converted into published readiness. This is atomic fixture publication, not target-CAS or power-loss durability.

The held actual-open regression (lines **63–73, 214–219, 250–254, 484**) discriminates the original behavior. In fresh reviewer RED, the final pathname was visible and **`stageAtEOF` was `""` at the real cancellation handshake**; the final record later completed. That is still a real premature-publication failure, not a claim the final record stayed empty. Atomic-only and full GREEN report `stageVisible=false` while the actual file is held open, then complete JSON at actual EOF. The original required-stage assertion remains unconditional for every non-`none` stage.

Held-out exact publisher-body controls additionally establish exclusive refusal of pre-existing symlink/hardlink temporaries without changing unrelated owned victim bytes. Injected write/replace errors leave the final path absent, retain only the owned temporary and close the real output handle. These unit controls supplement, rather than replace, the real process-race test.

### 2. Distinct missing auxiliary marker and genuine child witness — PASS

The actual Linux receipt is a **null marker**, not an empty JSON publication: child validation rejected with **197.51491600000293 ms remaining**, real queued EOF, no work and exact reap. Its scheduler interval is not retrospectively measured by these local tests.

Fresh reviewer RED and atomic-only both reproduce the separate causal mechanism: the fixture performs actual kernel E write, holds its post-write observation 40 ms, the real child rejects persistent EOF while its lease is positive, and the refusal interrupts the owner's auxiliary publication. The null records have **197.490291 ms** and **197.42000000000002 ms** remaining respectively. Atomic publication alone does not fix this case.

Candidate lines **87–113** call `original_read` first. Only an actual child-side `data == b'E'`, for the selected `supervisor-forwarded`/zero-forward-delay fixture, publishes the required record with `witness='child-received-E'`, real child PID and original owner PID. Production lines **379–397** identify that E read as the gate-pipe read before `execution_allowed` and exec. The child is not held at that witness. Supervisor lines **132–138** retain the original hold but suppress duplicate publication for this one case. Other stage meanings and ordinary 250 ms child aging remain unchanged.

Independent held-out execution uses that exact generated wrapper and literal `/usr/bin/python3`: PID **18102** received real E from owner **18101**, authored the correctly labelled marker, then actual validation returned false with **196.2605 ms** left. The supervisor-side `gate-forwarded.json` remained absent, demonstrating the marker is genuinely child-authored rather than a successful supervisor observer or fabricated fallback. Exact owner waitpid/reap, absent worker/supervisor, live sentinel and no work were recorded **before fixture cleanup**. Separate same-wrapper controls with no E and with no S produced **no marker, no validation and no work**; no admission produced no fork. All subject finally-kill lists were empty.

### 3. Original lease/EOF/cleanup contracts — PASS, existing limitations retained

All original assertion-containing lines remain mechanically present (34 admission / 64 native-fixture), but acceptance is based on behavior too: full Node execution ran all original malformed-frame, no-E, live-parent, expired-grant, 1300 ms held-stage, graceful-exit, actual SIGKILL and actual SIGSTOP Node/Bun-host cases.

The full receipt contains **17 raw cases**, **22 real-host cases** and the malformed-budget controls. Both original positive real hosts and the raw positive control authored actual user work. Every negative raw observation has no work, actual reap and absent subject processes before finally. Both zero-delay EOF records reject with positive remaining lease; the still-open expired-forwarded case still requires negative remaining lease. Original 1300 ms holds, caller-inclusive 200 ms, teardown 800 ms, fixture guard 1800 ms and `<1500 ms` assertions are not relaxed.

Production producer, supervisor, anchor, loader, S/E protocol, deadline initialization/charging, original literal `/usr/bin/python3`, permission and signal-authority code are outside the patch and bound unchanged in the public closure. Raw PREPARED-anchored admission is not relabelled caller-inclusive cold startup admission. A numeric PGID is not signal authority; destroyed streams are not EOF. **C1 still applies:** a paused sole reaper does not establish bounded complete cleanup merely because execution is refused and natural reap later occurs.

### 4. Failure-only host diagnostics and exact primary error — PASS

Admission lines **31–41, 330–345** wrap the existing required-stage await before the existing `hostCase` finally. The callback is invoked only when the check rejects and the opt-in equals literal `"1"`; snapshot/JSON/log failures are caught, then the exact original error value is rethrown. Disabled and successful checks never call the snapshot.

The real withheld-startup regressions run disabled and enabled on the actual test host. Full Node and selected native Bun both pass. The enabled Node snapshot precedes the host-finally record, reports absent stage, no forks/work, a complete real helper result with withheld admission and reaped supervisor, and no raw stdout/stderr fields. No subject finally kills occurred.

The candidate's identity regression plus source-exact held-out controls independently test disabled/success zero callback calls, snapshot throw, JSON serialization throw and logging throw. All preserve **object identity** of the primary error, with observation before finally. Reporting helper/launch/cleanup/transport metadata does not create admission or cleanup proof.

### 5. Opt-in native parent descriptor sets — PASS

The native-fixture delta is only the conditional object spread at lines **124–131**. Existing baseline/active union sets are observed, and `pipes()` performs parent fstat sampling after return; no new descriptor owner, release, GC, signal or await is introduced. Unchanged native wrapper executions prove the environment toggle really reaches Bun: **0/13** optional observations disabled, **13/13** enabled. Each mode independently satisfies all **7 required reused-index checks** in its actual eight-cycle stress, active-call GC and sentinel checks; sequential 200/5000 ms and actual TERM/INT cases pass too.

The record explicitly says `parent-side-fstat-only-not-writer-or-resource-identity`. These are numeric sets, not kernel writer, resource identity, causal pipe-holder or complete cleanup certification.

## Harness issues retained, not hidden

1. Initial reviewer Bun argv placed `--preload` before `test`, selecting the package's script instead of native test. It failed on unknown `--timeout` before tests ran. Raw failed `native-bun-selected/` is retained. Correcting argument placement only produced the explicit native-host 6-pass receipt.
2. Initial reducer incorrectly assumed RED's final file must remain empty. Its actual empty **handshake** plus later complete final record is preserved; reducer attempt/source and correction are retained in `aggregate-attempt1.*`.
3. The Node/Vitest bundled-config resolver attempted three ancestor `package.json` reads per invocation. The guard refused them **before bytes**, without relaxing its policy or reading that personal file. These recorded refusals are disclosed, not called zero-refusal runs (`guard-analysis.json`, `aggregate-attempt2.*`). Exact native Bun and strict compiler have zero refusals; a separate live-source negative control is actively refused before bytes. No live/unreviewed source read was allowed by that guard.
4. Initial metadata discovery used nonexistent parent `tools/` instead of `probes/`; it failed without candidate execution. The setup receipt records this.

## Gates deliberately left open

No local success is a new actual macOS/Linux CI pass. Parent live application/integration, whole-root/full-suite, package and actual-CI gates remain parent-owned. Parent canonical build receipts were read as parent evidence (passed tracker and active guards), not claimed as a reviewer build. Full native-Bun Vitest/SIGTRAP, historical cold-bootstrap/missing-stage incidents beyond the demonstrated mechanism, kernel FD-holder causality and C1 remain unqualified.

**No blocking SPEC defect found in the exact two-path candidate. QUALITY review may now proceed.**
