# QUALITY review — A recovery-fixture repair

**Verdict: PASS (scoped). No blocking or actionable quality finding in the reviewed two-file delta.**

This stage began only after the independent SPEC review passed and `SPEC-REVIEW.md` was written. It reviews the same exact postimages and evidence, not an implementation revision or a self-approved fix. No candidate/live/frozen source edits were made.

## Findings

### Correctness and locality

- `test/audit-recovery-execution-admission.test.ts:74–86` centralizes complete-stage publication instead of duplicating an open/write protocol at each hold. Exclusive same-directory creation and close-before-replace are explicit and independently exercised, including real held-open process behavior and bounded alias/write/replace controls.
- `:87–138` keeps the exceptional child witness narrowly tied to actual E read and the zero-delay forwarded fixture. It labels who witnessed what, retains actual worker/owner IDs, avoids a second supervisor publication and does not hold the validating child. No absence/null/parse failure becomes success. The existing stage name is intentionally retained as the required causal boundary, with `witness` disambiguating its observer.
- The original temporal/ownership assertions remain enforced. Source-bound RED/atomic-only controls fail for the intended reasons, full final-source Node runs all 49 cases, and held-out no-E/no-S controls specifically guard against a fabricated witness. This is stronger than checking retained assertion line counts alone.

### Failure and diagnostic behavior

- `:31–41` has a small, auditable error boundary: try the required check, conditionally observe only its failure, suppress only secondary observation/logging failures, rethrow the original value. It does not turn a helper result into authority or bury assertion failure in a fallback return.
- `:330–345` snapshots before finally, separates presence/JSON completeness from result fields, and emits byte counts rather than raw output or environment values. The new tests restore environment and spies in finally. Actual-host selection is corrected only in the new tests, not via a broader interpreter fallback.
- Exact-source held-out checks cover snapshot construction, JSON serialization and logging failures plus successful/disabled zero-callback behavior. The real missing-stage test supplies integration coverage rather than only a mocked helper test.

### Resource ownership and runtime fidelity

- `test/fixtures/bun_recovery_ownership.ts:124–131` reuses existing observed numeric sets and adds only conditional fstat observations. It neither acquires owners nor inserts GC/await/signal/release behavior. The label prevents promoting descriptor-number reuse to kernel writer/resource identity.
- The unchanged `runNative` wrapper was exercised in both modes, with 13 real Bun calls each and all 7 required reused-index observations in each stress. The actual native runtime was verified, not inferred from a launcher. The native-Bun selected test run has an explicit guard preload receipt; Bun compatibility is not inferred from NODE_OPTIONS.
- Diagnostic observations do not rescue fixture cleanup. Product-before-finally receipts independently show reap/absence/no work/sentinel survival; subject finally-kill lists remain empty. Existing paused-reaper/C1 and uncontained-command limitations remain explicit.

### Maintainability and test discipline

The helpers and fixture probes stay in the two authorized test paths; production APIs, protocol and clocks do not grow new testing switches. The 40 ms and 250 ms sleeps are visibly fixture-only and opt-in. Existing supervisor holds and all budget constants are preserved. New regressions are rerunnable candidate tests, not claims dependent on a removed one-off script.

Strict checking used the exact two roots and actual public transitive declarations: TypeScript 5.9.3, strict + noUncheckedIndexedAccess, **0 diagnostics**. The current 281-package alias map was independently resolved before testing, with owned caches. The canonical build is retained parent evidence, not a reviewer or full-suite substitute.

## Evidence qualifications

- Node **22.22.3**: **49 pass, 0 fail, 0 skip**, one admission file.
- Native Bun **1.3.8**: **6 pass, 0 fail, 43 filtered**; this is not the full native suite.
- Native wrapper toggle: **4 pass / 3 filtered each**, optional sets **0/13 disabled vs 13/13 enabled**, original reuse checks intact.
- RED **2 fail**; atomic-only **1 pass / 1 fail**. Final test count is 49 in both mutated derivatives; no old count is borrowed.
- Three real held-out process cases and five exact publisher-body controls pass. Primary object identity survives all three secondary diagnostic-failure kinds.
- All raw logs, actual-host/source receipts, failed tooling attempts and guard refusals remain in this workspace. In particular, guarded bundled-config ancestor-package probes were denied before bytes, not silently allowed or described as zero-refusal runs. Strict and explicit native-Bun guard runs have zero refusals.

## Remaining scope

This pass does not close parent integration/full-root/full-suite/package/actual-CI gates, the separate full native-Bun Vitest failure, kernel FD-holder causality, historical startup latency incidents or C1. Those are not newly introduced quality defects in A's two-path candidate. No unrelated architecture audit or speculative cleanup is requested.
