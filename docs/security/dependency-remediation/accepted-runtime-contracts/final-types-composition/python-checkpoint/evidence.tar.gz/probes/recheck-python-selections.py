from pathlib import Path
import json
import subprocess
import time

root = Path('/Users/shersingh/.hermes/cache/scratch/qmd-final-integration-jlczalso')
repo = Path('/Users/shersingh/github/qmd-mlx-search')
base = json.loads((root / 'environment.json').read_text())
selections = [
    ('security-repaired-full', Path('/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'), 'test/security'),
    ('finetune-activated-full', Path('/Users/shersingh/.hermes/cache/scratch/qmd-parent-gguf-lock-preview-f_xuxmo_/repo/finetune/.venv/bin/python'), 'finetune/tests'),
]
receipts = []
for label, executable, selection in selections:
    env = dict(base, PATH=f'{executable.parent}:{base["PATH"]}', OMP_NUM_THREADS='2',
               MKL_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2', TOKENIZERS_PARALLELISM='false')
    argv = [str(executable), '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
            '--basetemp', str(root / 'tmp' / label),
            '--junitxml', str(root / 'evidence' / f'{label}.xml'), selection]
    started = time.monotonic()
    result = subprocess.run(argv, cwd=repo, env=env, capture_output=True, text=True, timeout=300)
    (root / 'evidence' / f'{label}.stdout.txt').write_text(result.stdout)
    (root / 'evidence' / f'{label}.stderr.txt').write_text(result.stderr)
    receipt = dict(label=label, argv=argv, cwd=str(repo), exitCode=result.returncode,
                   seconds=time.monotonic() - started, venvBinOnPath=str(executable.parent))
    receipts.append(receipt)
    (root / 'evidence/python-final-recheck-commands.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    print(result.stdout[-5000:] + result.stderr[-2000:], flush=True)
raise SystemExit(1 if any(row['exitCode'] for row in receipts) else 0)
