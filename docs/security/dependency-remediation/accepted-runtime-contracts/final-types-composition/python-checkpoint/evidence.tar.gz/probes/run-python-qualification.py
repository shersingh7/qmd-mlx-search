from __future__ import annotations

import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/shersingh/.hermes/cache/scratch/qmd-final-integration-jlczalso')
REPO = Path('/Users/shersingh/github/qmd-mlx-search')
ENV = json.loads((ROOT / 'environment.json').read_text())
ENV.update(OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2', TOKENIZERS_PARALLELISM='false')
UV = '/Users/shersingh/.local/bin/uv'
ENVS = {
    'runtime': REPO / '.venv/bin/python',
    'security': Path('/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'),
    'finetune': Path('/Users/shersingh/.hermes/cache/scratch/qmd-parent-gguf-lock-preview-f_xuxmo_/repo/finetune/.venv/bin/python'),
}
RECEIPTS = []


def run(label: str, argv: list[str], timeout: int) -> int:
    started = time.monotonic()
    result = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True, text=True, timeout=timeout)
    stdout = ROOT / 'evidence' / f'{label}.stdout.txt'
    stderr = ROOT / 'evidence' / f'{label}.stderr.txt'
    stdout.write_text(result.stdout)
    stderr.write_text(result.stderr)
    receipt = dict(label=label, argv=argv, cwd=str(REPO), exitCode=result.returncode,
                   seconds=time.monotonic() - started, stdout=str(stdout), stderr=str(stderr))
    RECEIPTS.append(receipt)
    (ROOT / 'evidence/python-qualification-commands.json').write_text(json.dumps(RECEIPTS, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print(result.stdout[-9000:] + result.stderr[-5000:], flush=True)
    return result.returncode


failed = False
for name, python in ENVS.items():
    status = run(f'{name}-uv-check', [UV, '--no-config', '--offline', 'pip', 'check', '--python', str(python)], 60)
    failed |= status != 0
    if status:
        continue
    selection = {'runtime': ['test/python', '-m', 'not real_model'],
                 'security': ['test/security'], 'finetune': ['finetune/tests']}[name]
    argv = [str(python), '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
            '--basetemp', str(ROOT / 'tmp' / f'pytest-{name}'),
            '--junitxml', str(ROOT / 'evidence' / f'{name}-pytest.xml'), *selection]
    failed |= run(f'{name}-pytest', argv, 540) != 0
raise SystemExit(1 if failed else 0)
