from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path('/Users/shersingh/.hermes/cache/scratch/qmd-final-integration-jlczalso')
repo = Path('/Users/shersingh/github/qmd-mlx-search')
env = json.loads((root / 'environment.json').read_text())
receipts = []
tarball = None
for runtime in ('node', 'bun'):
    previous = set((root / 'tmp').glob('qmd-package-smoke-*'))
    argv = ['/bin/bash', 'test/smoke-install.sh', '--runtime', runtime]
    if tarball is not None:
        argv += ['--package', str(tarball)]
    started = time.monotonic()
    result = subprocess.run(argv, cwd=repo, env=env, capture_output=True, text=True, timeout=480)
    label = 'package-smoke-' + runtime
    (root / 'evidence' / f'{label}.stdout.txt').write_text(result.stdout)
    (root / 'evidence' / f'{label}.stderr.txt').write_text(result.stderr)
    created = sorted(set((root / 'tmp').glob('qmd-package-smoke-*')) - previous)
    receipt = dict(runtime=runtime, argv=argv, exitCode=result.returncode,
                   seconds=time.monotonic() - started, ownedWorkspaces=[str(p) for p in created])
    if result.returncode == 0:
        assert len(created) == 1
        artifact = created[0] / 'receipt.json'
        data = json.loads(artifact.read_text())
        assert data['ok'] is True and data['runtime'] == runtime
        tarball = Path(data['tarball'])
        assert tarball.is_file()
        receipt.update(receipt=str(artifact), checks=data['checks'], httpSupported=data['httpSupported'],
                       tarball=str(tarball), tarballSha256=hashlib.sha256(tarball.read_bytes()).hexdigest())
        (root / 'evidence' / f'{label}-receipt.json').write_text(json.dumps(data, indent=2) + '\n')
    receipts.append(receipt)
    (root / 'evidence/package-smoke-executions.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print(result.stdout[-9000:] + result.stderr[-5000:], flush=True)
raise SystemExit(1 if any(row['exitCode'] for row in receipts) else 0)
