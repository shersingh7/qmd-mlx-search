"""Parent-owned isolated runner; records exact argv/environment and raw exits."""
from pathlib import Path
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label, source, *command = sys.argv[1:]
assert label and all(c.isalnum() or c in '-_' for c in label)
cwd = (root / source).resolve()
assert cwd.is_relative_to(root) and cwd.is_dir()
state = root / 'state' / label
state.mkdir(parents=True)
locations = {'HOME': 'home', 'HERMES_HOME': 'hermes', 'HERMES_DIR': 'hermes',
             'HERMES_KNOWLEDGE_DIR': 'knowledge', 'KNOWLEDGE_DIR': 'knowledge',
             'XDG_CONFIG_HOME': 'config', 'XDG_CACHE_HOME': 'cache',
             'XDG_DATA_HOME': 'data', 'XDG_STATE_HOME': 'state',
             'HF_HOME': 'hf', 'HF_HUB_CACHE': 'hf/hub', 'TMPDIR': 'tmp',
             'TMP': 'tmp', 'TEMP': 'tmp', 'BUN_INSTALL_CACHE_DIR': 'cache/bun',
             'BUN_RUNTIME_TRANSPILER_CACHE_PATH': 'cache/bun-transpile',
             'npm_config_cache': 'cache/npm', 'PNPM_HOME': 'cache/pnpm',
             'UV_CACHE_DIR': 'cache/uv', 'NODE_COMPILE_CACHE': 'cache/node',
             'VITE_CACHE_DIR': 'cache/vite', 'VITEST_CACHE_DIR': 'cache/vitest'}
env = {key: str(state / leaf) for key, leaf in locations.items()}
for value in env.values():
    Path(value).mkdir(parents=True, exist_ok=True)
env.update({'PATH': str(root / 'tools/bin') + ':/usr/bin:/bin',
            'LANG': 'en_US.UTF-8', 'NO_COLOR': '1',
            'PYTHONDONTWRITEBYTECODE': '1', 'HF_HUB_OFFLINE': '1',
            'TRANSFORMERS_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1',
            'UV_OFFLINE': '1', 'npm_config_offline': 'true',
            'QMD_LLAMA_GPU': 'false', 'CI': '1', 'REQUIRE_BUN': '1',
            'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1',
            'GIT_OPTIONAL_LOCKS': '0', 'GIT_TERMINAL_PROMPT': '0',
            'QMD_COMPOSE_ROOT': str(root), 'QMD_RUN_LABEL': label,
            'QMD_REVIEW_HOST_RECEIPT': str(root / 'evidence' / (label + '-hosts.jsonl')),
            'QMD_BENCH_ENTRYPOINT_RECEIPT': str(root / 'evidence' / (label + '-entrypoints.jsonl')),
            'QMD_BENCH_TEST_RECEIPT': str(root / 'evidence' / (label + '-benchmark-host.json'))})
if label.startswith(('types-', 'build-')):
    env['NODE_OPTIONS'] = '--require=' + str(root / 'probes/compiler-read-guard.cjs')
start = time.monotonic()
result = subprocess.run(command, cwd=cwd, env=env, capture_output=True,
                        text=True, timeout=240)
record = {'label': label, 'cwd': str(cwd), 'argv': command, 'environment': env,
          'exitCode': result.returncode, 'seconds': time.monotonic() - start,
          'stdout': result.stdout, 'stderr': result.stderr}
(root / 'evidence' / (label + '-execution.json')).write_text(
    json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items()
                  if k not in ('environment', 'stdout', 'stderr')}, indent=2))
print(result.stdout)
print(result.stderr)
raise SystemExit(result.returncode)
