import { describe, it, expect } from 'vitest';
import { verifyRetrievalEquivalence, type StageMetrics } from '../candidate/scripts/phase5_e2e_runner.js';
function stage(): StageMetrics {
  return { recallAt1: 1, recallAt3: 1, recallAt5: 1, mrr: 1, ndcgAt5: 1,
    avgLatencyMs: 12, p50LatencyMs: 10, p95LatencyMs: 15,
    queryDetails: [{ queryId: 'Q01', query: 'public synthetic query', category: 'easy',
      expectedDocIds: ['doc-1'], topDocIds: ['doc-1', 'doc-2'], scores: [0.9, 0.6],
      rank1: 1, hitAt5: true, latencyMs: 10 }] };
}
describe('parent-held report validation boundaries', () => {
  it('does not certify a sparse score array as finite-score equivalence', () => {
    for (const side of ['pre', 'post', 'both']) {
      const pre = stage(); const post = stage();
      const sparse = new Array<number>(2); sparse[0] = 0.9;
      if (side !== 'post') pre.queryDetails[0]!.scores = sparse;
      if (side !== 'pre') post.queryDetails[0]!.scores = sparse;
      expect(verifyRetrievalEquivalence(pre, post).identical).toBe(false);
    }
  });
  it('does not certify missing document IDs in otherwise matching reports', () => {
    const pre = stage(); const post = stage();
    const sparse = new Array<string>(2); sparse[0] = 'doc-1';
    pre.queryDetails[0]!.topDocIds = sparse;
    post.queryDetails[0]!.topDocIds = sparse;
    expect(verifyRetrievalEquivalence(pre, post).identical).toBe(false);
  });
  it('refuses an explicitly missing query detail without throwing', () => {
    const pre = stage(); const post = stage();
    Object.defineProperty(pre.queryDetails, '0', { value: undefined });
    expect(verifyRetrievalEquivalence(pre, post).identical).toBe(false);
  });
});
