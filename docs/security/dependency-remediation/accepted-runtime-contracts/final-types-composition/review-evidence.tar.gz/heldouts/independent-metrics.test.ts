import { describe, it, expect } from 'vitest';
import { verifyRetrievalEquivalence as verify, type StageMetrics } from '../candidate/scripts/phase5_e2e_runner.js';
import { verifyRetrievalEquivalence as precursorVerify } from '../precursor/scripts/phase5_e2e_runner.js';

function stage(): StageMetrics {
  return { recallAt1: 0.5, recallAt3: 1, recallAt5: 1, mrr: 0.75, ndcgAt5: 0.8,
    avgLatencyMs: 12, p50LatencyMs: 10, p95LatencyMs: 15,
    queryDetails: [
      { queryId: 'Q1', query: 'first public fixture query', category: 'easy', expectedDocIds: ['d1'],
        topDocIds: ['d1', 'd2', 'd3'], scores: [0.75, 0.5, 0.25], rank1: 1, hitAt5: true, latencyMs: 10 },
      { queryId: 'Q2', query: 'second public fixture query', category: 'medium', expectedDocIds: ['d2'],
        topDocIds: ['d3', 'd2', 'd1'], scores: [0.5, 0.25, 0], rank1: 2, hitAt5: true, latencyMs: 14 },
    ] };
}
type Side = 'pre' | 'post' | 'both';
const sides: Side[] = ['pre', 'post', 'both'];
function targets(pre: StageMetrics, post: StageMetrics, side: Side): StageMetrics[] {
  return side === 'both' ? [pre, post] : [side === 'pre' ? pre : post];
}

describe('independent bounded report validation contracts', () => {
  it('accepts dense multi-query rankings with real finite scores and exact identities', () => {
    const before = stage(); const after = stage();
    const frozenBefore = structuredClone(before); const frozenAfter = structuredClone(after);
    expect(verify(before, after)).toEqual({ identical: true, details: [
      { queryId: 'Q1', docOrderMatch: true, scoreToleranceMatch: true },
      { queryId: 'Q2', docOrderMatch: true, scoreToleranceMatch: true },
    ] });
    expect(before).toEqual(frozenBefore); expect(after).toEqual(frozenAfter);
  });
  it('ignores both per-query and stage timing changes, not retrieval changes', () => {
    const before = stage(); const after = stage();
    after.avgLatencyMs = 900; after.p50LatencyMs = 800; after.p95LatencyMs = 1000;
    after.queryDetails.forEach(q => { q.latencyMs = 1000; });
    expect(verify(before, after).identical).toBe(true);
  });
  it('preserves zero and negative finite scores without inventing a score-range policy', () => {
    const before = stage(); const after = stage();
    before.queryDetails[0]!.scores = [-1, -0, 0]; after.queryDetails[0]!.scores = [-1, 0, -0];
    expect(verify(before, after, 0).identical).toBe(true);
  });
  it('accepts equality at an exactly representable inclusive tolerance in both directions', () => {
    const before = stage(); const after = stage();
    after.queryDetails[0]!.scores[2] = 0.375;
    expect(verify(before, after, 0.125).identical).toBe(true);
    expect(verify(after, before, 0.125).identical).toBe(true);
    expect(verify(before, after, 0.0625).identical).toBe(false);
    expect(verify(before, after, 0).identical).toBe(false);
  });
  it('accepts a single dense result per query and rejects count/identity mismatches', () => {
    const before = stage(); before.queryDetails.forEach(q => { q.topDocIds = [q.topDocIds[0]!]; q.scores = [q.scores[0]!]; });
    const after = structuredClone(before);
    expect(verify(before, after, 0).identical).toBe(true);
    after.queryDetails.pop(); expect(verify(before, after).identical).toBe(false);
  });
  for (const tolerance of [NaN, Infinity, -Infinity, -0.125]) it(`refuses invalid tolerance ${String(tolerance)}`, () => {
    expect(verify(stage(), stage(), tolerance).identical).toBe(false);
  });
  for (const field of ['recallAt1', 'recallAt3', 'recallAt5', 'mrr', 'ndcgAt5'] as const) it(`detects aggregate ${field} drift`, () => {
    const before = stage(); const after = stage(); after[field] -= 0.125;
    expect(verify(before, after).identical).toBe(false);
  });
  for (const change of ['query-order', 'query-id', 'doc-order', 'rank', 'hit'] as const) it(`detects dense ${change} drift`, () => {
    const before = stage(); const after = stage();
    if (change === 'query-order') after.queryDetails.reverse();
    if (change === 'query-id') after.queryDetails[1]!.queryId = 'Q-other';
    if (change === 'doc-order') after.queryDetails[1]!.topDocIds.reverse();
    if (change === 'rank') after.queryDetails[1]!.rank1 = 3;
    if (change === 'hit') after.queryDetails[1]!.hitAt5 = false;
    expect(verify(before, after).identical).toBe(false);
  });
  for (const side of sides) for (const slot of [0, 1, 2]) it(`rejects score hole at ${slot} on ${side}, including final position`, () => {
    const before = stage(); const after = stage();
    targets(before, after, side).forEach(report => { delete report.queryDetails[1]!.scores[slot]; });
    expect(verify(before, after).identical).toBe(false);
  });
  for (const side of sides) for (const slot of [0, 1, 2]) it(`rejects doc-ID hole at ${slot} on ${side}`, () => {
    const before = stage(); const after = stage();
    targets(before, after, side).forEach(report => { delete report.queryDetails[1]!.topDocIds[slot]; });
    expect(verify(before, after).identical).toBe(false);
  });
  for (const side of sides) for (const form of ['hole', 'undefined'] as const) it(`rejects ${form} query detail on ${side} without throwing`, () => {
    const before = stage(); const after = stage();
    targets(before, after, side).forEach(report => {
      if (form === 'hole') delete report.queryDetails[1];
      else Object.defineProperty(report.queryDetails, '1', { value: undefined });
    });
    expect(verify(before, after)).toMatchObject({ identical: false,
      details: [{ queryId: 'all', docOrderMatch: false, scoreToleranceMatch: false }] });
  });
  for (const side of sides) for (const score of [NaN, Infinity, -Infinity]) it(`rejects nonfinite ${String(score)} score on ${side}`, () => {
    const before = stage(); const after = stage();
    targets(before, after, side).forEach(report => { report.queryDetails[1]!.scores[2] = score; });
    expect(verify(before, after).identical).toBe(false);
  });
  for (const side of sides) for (const field of ['query-id', 'doc-id', 'duplicate-query', 'duplicate-doc', 'error'] as const) it(`refuses ${field} invalidity on ${side}`, () => {
    const before = stage(); const after = stage();
    targets(before, after, side).forEach(report => {
      const q = report.queryDetails[1]!;
      if (field === 'query-id') q.queryId = '';
      if (field === 'doc-id') q.topDocIds[2] = '';
      if (field === 'duplicate-query') q.queryId = report.queryDetails[0]!.queryId;
      if (field === 'duplicate-doc') q.topDocIds[2] = q.topDocIds[0]!;
      if (field === 'error') q.error = 'public synthetic failed query';
    });
    expect(verify(before, after).identical).toBe(false);
  });
  for (const side of sides) for (const length of [0, 2, 4]) it(`rejects score/result length ${length} mismatch on ${side}`, () => {
    const before = stage(); const after = stage();
    targets(before, after, side).forEach(report => { report.queryDetails[1]!.scores = Array.from({ length }, () => 0.5); });
    expect(verify(before, after).identical).toBe(false);
  });
  it('preserves exact predecessor outputs across 120 deterministic dense positive/negative controls', () => {
    for (let i = 0; i < 120; i++) {
      const before = stage(); const after = stage();
      const variant = i % 10;
      const tolerance = [0, 0.0625, 0.125, 0.25][i % 4]!;
      if (variant === 1) after.queryDetails[0]!.scores[0]! += 0.125;
      if (variant === 2) after.queryDetails[1]!.scores[2]! -= 0.25;
      if (variant === 3) after.queryDetails[1]!.topDocIds.reverse();
      if (variant === 4) after.queryDetails.reverse();
      if (variant === 5) after.queryDetails[1]!.queryId = 'different';
      if (variant === 6) after.queryDetails[1]!.rank1 = null;
      if (variant === 7) after.queryDetails[1]!.hitAt5 = false;
      if (variant === 8) after.mrr = 0.25;
      if (variant === 9) after.queryDetails[0]!.latencyMs = 200;
      const oldResult = precursorVerify(before, after, tolerance);
      expect(verify(before, after, tolerance), `dense case ${i}`).toEqual(oldResult);
    }
  });
});
