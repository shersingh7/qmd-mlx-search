# Reproducing this bounded review

Treat this directory as immutable after `report-index.json` is written. First verify that index, its artifact hashes and the separately bound baseline/candidate/precursor source manifests. Create another fresh managed `qmd-final-types-review-*` directory; do not execute into this archive. Copy only indexed public harness/heldout/bridge bytes and the exact manifested source files, never operational HOME/state/cache directories or a root `node_modules` symlink. Existing packages are individual read-use aliases; create owned `.vite`, `.vite-temp`, `.cache`, `.vitest` first. Bind the 44 genuine T3 declaration/metadata files against `inputs/composition.json`; do not materialize omitted documentation or run lifecycle scripts.

The original runner `run.py` derives every mutable path from its own location and uses fresh, non-reusable labels. It clears inherited environment and records actual command arrays, environments, stdout/stderr, runtime receipts and exits. The only reviewer runner addition is two owned optional benchmark receipt paths. Test assertions/fake data/model/egress denial are unchanged.

Examples in that new copy (use the exact verified runtime executables, not a Node substitute for Bun):

```text
<python> -I -B -S <new-root>/run.py green-new-node heldouts <node> node_modules/vitest/vitest.mjs run --config ../heldouts-isolated.config.mjs --no-cache --maxWorkers=2 --reporter=json --outputFile=../evidence/green-new-node.json metrics-inputs.test.ts
<python> -I -B -S <new-root>/run.py green-new-bun heldouts <bun> --bun node_modules/vitest/vitest.mjs run --config ../heldouts-isolated.config.mjs --no-cache --maxWorkers=2 --reporter=json --outputFile=../evidence/green-new-bun.json metrics-inputs.test.ts
<python> -I -B -S <new-root>/run.py independent-new-node heldouts <node> node_modules/vitest/vitest.mjs run --config ../heldouts-isolated.config.mjs --no-cache --maxWorkers=2 independent-metrics.test.ts
```

RED uses `red-heldouts-isolated.config.mjs`, `red-heldouts/metrics-inputs.test.ts`, and the exact reconstructed `precursor` source tree, not a rewritten parent RED artifact. The only test difference is the source import path. Expected RED is three genuine assertion failures, exit 1; do not relabel it green.

Use the exact focused file lists and selected lease patterns in their `*-execution.json` files. Appending paths to `npm test` would select the whole directory; these checks invoke the actual Vitest entrypoint directly. Lease probes keep production deadlines unchanged, retain pre-fixture-cleanup observations and include genuine raw/native positive work. Selection skips are not full-file coverage or universal C1 acceptance.

Build and compiler commands are the recorded `build-canonical`, `types-canonical-node` and `types-canonical-bun` invocations. Preserve the lexical/real read guard, actual roots/options/allowJs and the three historical scripts. Bun compiler commands explicitly preload the guard. Read the refused-access receipts even when `tsc` exits 0: whole-root acceptance stays false here. Never execute the historical scripts to claim fresh coverage.

`probes/independent-preservation.mjs` verifies complete complements and prior test bytes with actual TypeScript; `probes/quality-structural-check.mjs` requires completed SPEC evidence before QUALITY. These review tools read only verified copied public sources/owned evidence. The finalizer verifies reports/counts/source and package metadata, then binds the reports and all selected artifacts in `report-index.json`.
