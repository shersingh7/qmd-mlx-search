import { afterAll, beforeAll, describe, expect, test } from "vitest";
import { appendFileSync, mkdtempSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { basename, join, relative } from "node:path";
import { tmpdir } from "node:os";
import { pathToFileURL } from "node:url";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import * as ts from "typescript";

// Exercise the complete emitted benchmark with only a synthetic llama boundary.
// Forcing the native flag undefined qualifies the fallback on this host, NOT an
// older Node binary. The prefix stays after the retained shebang and leaves all
// executable benchmark statements unchanged.
let directory: string;
let sequence = 0;
const entries = new Map<string, { direct: string; symlink: string; multihop: string }>();
const variants = ["native", "fallback"] as const;
const modes = process.versions.bun ? ["default"] as const : ["default", "preserve-symlinks-main"] as const;
const receipt = process.env.QMD_BENCH_ENTRYPOINT_RECEIPT;
const record = (value: object) => { if (receipt) appendFileSync(receipt, JSON.stringify(value) + "\n"); };

beforeAll(() => {
  directory = mkdtempSync(join(tmpdir(), "qmd-bench-entrypoint-"));
  const special = join(directory, "space % # paths");
  mkdirSync(special);
  const stub = join(directory, "synthetic-llama.mjs");
  writeFileSync(stub, `
import { appendFileSync } from "node:fs";
const trace = event => appendFileSync(process.env.QMD_BENCH_ENTRY_TRACE, JSON.stringify(event) + "\\n");
export const LlamaLogLevel = { error: "error" };
export async function resolveModelFile() { trace("resolve"); return "/synthetic/model.gguf"; }
export async function getLlama() {
  trace("llama:create");
  return {
    gpu: false, cpuMathCores: 4,
    async loadModel() {
      trace("model:create");
      return {
        defaultContextFlashAttention: "auto", trainContextSize: 4096,
        async createRankingContext() {
          trace("context:create");
          return { async rankAll(_query, docs) { trace("rank"); return docs.map(() => 0.5); },
            async dispose() { trace("context:dispose"); } };
        },
        async dispose() { trace("model:dispose"); }
      };
    },
    async dispose() { trace("llama:dispose"); }
  };
}
`, { flag: "wx" });
  const source = readFileSync(new URL("../src/bench-rerank.ts", import.meta.url), "utf8");
  const ast = ts.createSourceFile("bench-rerank.ts", source, ts.ScriptTarget.Latest, true);
  const dependencies = ast.statements.filter(ts.isImportDeclaration).filter(node =>
    ts.isStringLiteral(node.moduleSpecifier) && node.moduleSpecifier.text === "node-llama-cpp");
  expect(dependencies).toHaveLength(1);
  const specifier = dependencies[0]!.moduleSpecifier;
  const rewritten = source.slice(0, specifier.getStart(ast)) + JSON.stringify(pathToFileURL(stub).href) + source.slice(specifier.end);
  const compile = (text: string) => ts.transpileModule(text, {
    compilerOptions: { target: ts.ScriptTarget.ESNext, module: ts.ModuleKind.ESNext }, reportDiagnostics: true,
  });
  const original = compile(source);
  const compiled = compile(rewritten);
  expect(compiled.diagnostics).toEqual([]);
  const bodies = (text: string) => {
    const parsed = ts.createSourceFile("bench.mjs", text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
    return parsed.statements.filter(node => !ts.isImportDeclaration(node)).map(node => node.getText(parsed)).join("\n");
  };
  expect(bodies(compiled.outputText)).toBe(bodies(original.outputText));
  record({ kind: "host", executable: process.execPath, versions: process.versions,
    sourceSha256: createHash("sha256").update(source).digest("hex"),
    exactExecutableBodiesVerified: true, dependencyBoundaryOnly: true, nativeModelRuns: 0 });
  for (const variant of variants) {
    // The native boolean must short-circuit before even reading fallback argv.
    // Observe that boundary without replacing the actual filesystem resolver.
    const prefix = `
import __entryFs from "node:fs";
let __entryArgv = process.argv[1];
let __argvReads = 0;
Object.defineProperty(process.argv, "1", {
  configurable: true, get() { __argvReads++; return __entryArgv; }, set(value) { __entryArgv = value; }
});
${variant === "fallback" ? 'Object.defineProperty(import.meta, "main", {value: undefined, configurable: true, writable: true});' : ""}
process.once("beforeExit", () => __entryFs.appendFileSync(process.env.QMD_BENCH_ENTRY_TRACE,
  JSON.stringify({kind: "runtime", executable: process.execPath, versions: process.versions,
    nativeMain: import.meta.main ?? null, argvReads: __argvReads}) + "\\n"));
`;
    const lineEnd = compiled.outputText.startsWith("#!") ? compiled.outputText.indexOf("\n") + 1 : 0;
    const direct = join(special, `${variant} bench %.# entry.mjs`);
    const symlink = join(special, `${variant} link %.# entry.mjs`);
    const multihop = join(special, `${variant} multihop %.# entry.mjs`);
    writeFileSync(direct, compiled.outputText.slice(0, lineEnd) + prefix + compiled.outputText.slice(lineEnd), { flag: "wx" });
    symlinkSync(basename(direct), symlink);
    symlinkSync(basename(symlink), multihop);
    entries.set(variant, { direct, symlink, multihop });
  }
});
afterAll(() => { if (directory) rmSync(directory, { recursive: true, force: true }); });

type RuntimeEvent = { kind: "runtime"; executable: string; versions: NodeJS.ProcessVersions; nativeMain: boolean | null; argvReads: number };
function run(variant: typeof variants[number], mode: typeof modes[number], scenario: string, command: string[]) {
  const id = sequence++;
  const trace = join(directory, `${id}.trace`);
  writeFileSync(trace, "", { flag: "wx" });
  const flags = mode === "preserve-symlinks-main" ? ["--preserve-symlinks-main"] : [];
  const result = spawnSync(process.execPath, [...flags, ...command], {
    cwd: directory, env: { ...process.env, QMD_BENCH_ENTRY_TRACE: trace }, encoding: "utf8", timeout: 10000,
  });
  const events = readFileSync(trace, "utf8").trim().split("\n").filter(Boolean).map(line => JSON.parse(line) as string | RuntimeEvent);
  record({ kind: "case", variant, mode, scenario, command: [process.execPath, ...flags, ...command],
    status: result.status, signal: result.signal, error: result.error?.message, stdout: result.stdout, stderr: result.stderr, events });
  expect(result.error).toBeUndefined();
  expect(result.status).toBe(0);
  expect(result.stderr).toBe("");
  const runtime = events.find((event): event is RuntimeEvent => typeof event !== "string" && event.kind === "runtime");
  expect(runtime).toBeDefined();
  expect(runtime!.executable).toBe(process.execPath);
  expect(runtime!.versions.bun ?? runtime!.versions.node).toBe(process.versions.bun ?? process.versions.node);
  if (variant === "native") expect(runtime!.argvReads).toBe(0);
  else expect(runtime!.nativeMain).toBeNull();
  return { result, events: events.filter((event): event is string => typeof event === "string"), runtime: runtime! };
}

for (const variant of variants) for (const mode of modes) {
  describe(`benchmark ${variant} entrypoint (${mode})`, () => {
    test.each(["direct", "symlink", "multihop", "relative-direct", "relative-symlink", "relative-multihop"] as const)("launches once through %s with URL-significant path characters", scenario => {
      const paths = entries.get(variant)!;
      const name = scenario.replace("relative-", "") as keyof typeof paths;
      const entry = scenario.startsWith("relative-") ? relative(directory, paths[name]) : paths[name];
      const { result, events, runtime } = run(variant, mode, scenario, [entry, "--quick"]);
      expect(result.stdout).toContain("QMD Reranker Benchmark");
      expect(result.stdout).toContain("Best:");
      expect(events).toEqual(["llama:create", "resolve", "model:create", "context:create", "rank", "rank",
        "context:dispose", "model:dispose", "llama:dispose"]);
      if (variant === "native") expect(runtime.nativeMain).toBe(true);
      else expect(runtime.argvReads).toBeGreaterThan(0);
    });
    test.each(["normal", "missing-argv", "missing-path", "dangling-symlink", "invalid-path"] as const)("import stays inert with %s argv", scenario => {
      let setup = "";
      if (scenario === "missing-argv") setup = "delete process.argv[1];";
      if (scenario === "missing-path") setup = `process.argv[1] = ${JSON.stringify(join(directory, "absent % #.mjs"))};`;
      if (scenario === "invalid-path") setup = `process.argv[1] = ${JSON.stringify("\0invalid.mjs")};`;
      if (scenario === "dangling-symlink") {
        const dangling = join(directory, `dangling-${sequence}.mjs`);
        symlinkSync("absent-target.mjs", dangling);
        setup = `process.argv[1] = ${JSON.stringify(dangling)};`;
      }
      const wrapper = join(directory, `import-${sequence}.mjs`);
      writeFileSync(wrapper, setup + `await import(${JSON.stringify(pathToFileURL(entries.get(variant)!.direct).href)});`, { flag: "wx" });
      const { result, events, runtime } = run(variant, mode, scenario, [wrapper, "--quick"]);
      expect(result.stdout).toBe("");
      expect(events).toEqual([]);
      if (variant === "native") expect(runtime.nativeMain).toBe(false);

    });
  });
}
