import { mergeConfig } from './candidate/node_modules/vitest/dist/config.js';
import project from './candidate/vitest.config.ts';
import { fileURLToPath } from 'node:url';
export default mergeConfig(project, {
  root: fileURLToPath(new URL('./red-heldouts/', import.meta.url)),
  cacheDir: process.env.VITE_CACHE_DIR,
  test: { include: ['*.test.ts'], setupFiles: [fileURLToPath(new URL('./probes/test-host-setup.mjs', import.meta.url))] },
});
