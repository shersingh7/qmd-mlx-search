from pathlib import Path
import os, json, hashlib
from collections import Counter
root=Path(__file__).resolve().parents[1]
def load(p):return json.loads((root/p).read_text())
def sha(p):
    assert p.name!='AGENTS.md'
    return hashlib.sha256(p.read_bytes()).hexdigest()
def write_new(p,obj):
    with (root/p).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
review=load('review-result.json');spec=load('evidence/spec-result.json');quality=load('evidence/quality-structural-check.json')
assert review['spec']==review['quality']=='PASS' and review['findings']==[]
assert spec['specStatus']=='PASS_SOURCE_BOUND_QUALIFIED' and quality['qualityStageAfterSpecPass']
assert quality['specReportSha256']==sha(root/'SPEC-REVIEW.md')
assert review['wholeRootAccepted'] is False and review['universalCompleteCleanupAccepted'] is False and review['T3DetailedProvenanceApprovedByThisReviewer'] is False and review['liveIntegrated'] is False
for tree,name,count in [('baseline','baseline',295),('candidate','candidate',298),('precursor','pre-parent-candidate',298),('patch-replay','candidate',298)]:
    manifest=load('inputs/'+name+'-manifest.json')['sourceSha256'];assert len(manifest)==count
    actual={}
    for directory,dirs,names in os.walk(root/tree,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ['node_modules','dist']]
        for filename in names:
            p=Path(directory)/filename
            assert filename!='AGENTS.md'
            actual[str(p.relative_to(root/tree))]=sha(p)
    assert actual==manifest,(tree,[p for p in set(actual)|set(manifest) if actual.get(p)!=manifest.get(p)])
parent=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-final-composition-mer5fi8x')
assert sha(parent/'report-index.json')==review['parentReportIndexSha256']
parent_index=load('inputs/report-index.json')
for p,h in parent_index['artifactSha256'].items():assert sha(parent/p)==h,p
for tree in ['baseline','candidate']:
    for p,h in load('inputs/'+tree+'-manifest.json')['sourceSha256'].items():assert sha(parent/tree/p)==h
for short,label in [('focusedNode','spec-focused-node'),('focusedActualBun','spec-focused-bun')]:
    r=load('evidence/test-summary.json')[label];declared=review['freshExecutions'][short]
    assert (r['files'],r['passes'],r['failures'],r['skips'],r['exitCode'])==(declared['files'],declared['passed'],declared['failed'],declared['skipped'],declared['exitCode'])
for suffix in ['node','bun']:
    for field,prefix in [('parentBoundaryRedPerHost','red-parent'),('parentBoundaryGreenPerHost','green-parent'),('independentMetricMatrixPerHost','spec-independent'),('realSdkPerHost','spec-sdk')]:
        r=load('evidence/test-summary.json')[prefix+'-'+suffix];d=review['freshExecutions'][field]
        assert (r['files'],r['passes'],r['failures'],r['skips'],r['exitCode'])==(d['files'],d['passed'],d['failed'],d['skipped'],d['exitCode'])
lease=load('evidence/lease-controls-summary.json')
for field,label in [('selectedLeaseNodeHost','spec-lease-controls-node'),('selectedLeaseActualBunHost','spec-lease-controls-bun')]:
    r=lease[label];d=review['freshExecutions'][field]
    assert (r['files'],r['passes'],r['failures'],r['skips'],r['exitCode'])==(d['files'],d['passed'],d['failed'],d['skipped'],d['exitCode'])
compilers=load('evidence/compiler-summary.json')['commands']
for label in ['types-canonical-node','types-canonical-bun']:assert compilers[label]['exitCode']==0 and compilers[label]['diagnostics']==0 and len(compilers[label]['refusals'])==2
assert quality['bothCompilerHostRootSelectionsIdentical'] and quality['canonicalRootCountAfterBuild']==153
for label in ['spec-patch-replay-check','spec-patch-replay-apply','spec-t2-patch-replay-check','spec-t2-patch-replay-apply','spec-preservation-r4','quality-structural-check']:
    assert load('evidence/'+label+'-execution.json')['exitCode']==0,label
assert sha(root/'final-composition.patch')==review['combinedPatchSha256']
assert sha(root/'candidate/scripts/phase5_e2e_runner.ts')==review['runnerSha256']
composition=load('inputs/composition.json')
for tree in ['candidate','baseline','precursor']:
    copied=0
    for d in composition['installedDeclarations']:
        for p,meta in d['files'].items():assert sha(root/tree/'node_modules'/d['name']/p)==meta['sha256'];copied+=1
    assert copied==44
shared=Path('/Users/shersingh/github/qmd-mlx-search/node_modules');metadata={}
for directory,dirs,names in os.walk(shared,followlinks=False):
    for name in sorted(dirs+names):
        p=Path(directory)/name;s=p.lstat()
        metadata[str(p.relative_to(shared))]={'mode':s.st_mode,'size':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'inode':s.st_ino,'link':os.readlink(p) if p.is_symlink() else None}
assert metadata==load('evidence/dependencies-before.json')
before=load('manifests/before-quality-artifacts.json')['artifactSha256']
assert all(sha(root/p)==h for p,h in before.items())
after=load('manifests/after-quality-artifacts.json')['artifactSha256']
assert all(sha(root/p)==h for p,h in after.items())
verification={'status':'VERIFIED','specThenQuality':True,'allBeforeQualityArtifactsUnchanged':len(before),'allFinalFrozenArtifactsUnchanged':len(after),'sourceCounts':{'baseline':295,'candidate':298,'precursor':298,'combinedReplay':298},'inputArtifactsStillExact':len(parent_index['artifactSha256']),'sharedDependencyMetadataStillExact':len(metadata),'wholeRootAccepted':False,'T3DetailedReviewSeparate':True,'noUniversalCompleteCleanupClaim':True,'noLiveIntegrationOrProductEdits':True}
write_new('evidence/final-verification.json',verification)
artifacts=dict(after)
for p in ['evidence/quality-freeze-final-execution.json','evidence/final-verification.json']:
    artifacts[p]=sha(root/p)
for p in sorted((root/'manifests').glob('*.json')):artifacts[str(p.relative_to(root))]=sha(p)
index={'root':str(root),'status':review['status'],'artifactCount':len(artifacts),'artifactSha256':dict(sorted(artifacts.items())),'candidateSourceCount':298,'baselineSourceCount':295,'changedPaths':22,'candidateSourceManifest':'inputs/candidate-manifest.json','baselineSourceManifest':'inputs/baseline-manifest.json','precursorSourceManifest':'inputs/pre-parent-candidate-manifest.json','combinedPatchSha256':review['combinedPatchSha256'],'wholeRootAccepted':False,'T3DetailedProvenanceApprovedByThisReviewer':False,'C1UniversalCompleteCleanupAccepted':False,'liveIntegrated':False,'excludedOperationalAndSeparatelyManifestedRoots':load('manifests/after-quality-artifacts.json')['excludedOperationalOrSeparatelyManifestedRoots']}
write_new('report-index.json',index)
readback=load('report-index.json');assert len(readback['artifactSha256'])==readback['artifactCount']
for p,h in readback['artifactSha256'].items():assert sha(root/p)==h,p
print(json.dumps({'reviewRoot':str(root),'reportIndex':str(root/'report-index.json'),'reportIndexSha256':sha(root/'report-index.json'),'indexedArtifacts':len(artifacts),'verification':verification},indent=2))
