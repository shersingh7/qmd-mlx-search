from pathlib import Path
from collections import Counter
import json, hashlib, os
root=Path(__file__).resolve().parents[1]
def load(p):return json.loads((root/p).read_text())
def sha(p):
    assert p.name!='AGENTS.md'
    return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,obj):
    with (root/p).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
assert load('evidence/spec-preservation-r4-execution.json')['exitCode']==0
preservation=load('evidence/independent-preservation.json')
for flag in ['topLevelMetricUnique','parentSourceComplementByteIdentical','parentEmittedCommentsRemovedComplementIdentical','baselineToT2SourceComplementIdentical','baselineToT2EmittedCommentsRemovedComplementIdentical','originalT2TestsBytePreserved','t1AndT2VitestEmittedJSIdenticalToFinal','leaseDeadlineAndGrantCodeOutsideAuthorizedSpansUnchanged']:
    assert preservation[flag],flag

lease={}
for label in ['spec-lease-controls-node','spec-lease-controls-bun']:
    report=load('evidence/'+label+'.json');execution=load('evidence/'+label+'-execution.json')
    assert execution['exitCode']==0 and report['numFailedTests']==0
    counts=Counter(a['status'] for f in report['testResults'] for a in f['assertionResults'])
    assert sum(counts.values())==report['numTotalTests'] and counts['passed']==report['numPassedTests']
    observations=[]
    for line in execution['stdout'].splitlines():
        if line.startswith('{"evidence":'):
            observations.append(json.loads(line))
    before=[o for o in observations if o['evidence'].endswith('before-finally')]
    final=[o for o in observations if o['evidence'].endswith('-finally') and not o['evidence'].endswith('before-finally')]
    assert len(before)==counts['passed']==len(final),(label,len(before),counts,len(final))
    assert all(o.get('finallyKilled')==[] for o in final)
    assert all(o.get('guardFired') is False and o.get('sentinelAlive') is True for o in before)
    native=[o for o in before if o['evidence']=='recovery-parent-death-before-finally']
    assert native
    for o in native:
        versions=o['nativeRuntime']['versions']
        if o['runtime']=='bun':assert versions['bun']=='1.3.8' and o['nativeRuntime']['executable']=='/Users/shersingh/.bun/bin/bun'
        else:assert 'bun' not in versions and versions['node']=='22.22.3' and o['nativeRuntime']['executable']=='/Users/shersingh/.hermes/node/bin/node'
        assert o['work']=='actual-user-work' and o['mode']=='valid'
    raw=[o for o in before if o['evidence']=='recovery-execution-admission-before-finally']
    assert len(raw)==3
    positive=[o for o in raw if o['stage']=='none'];assert len(positive)==1 and positive[0]['work']=='actual-user-work'
    eof=[o for o in raw if o['grant']=='eof'];assert len(eof)==1 and eof[0]['validation']['remainingMs']>0 and eof[0]['validation']['allowed'] is False and eof[0]['work'] is None
    expired=[o for o in raw if o['grant']=='open' and o['stage']=='supervisor-forwarded'];assert len(expired)==1 and expired[0]['validation']['remainingMs']<0 and expired[0]['validation']['allowed'] is False and expired[0]['work'] is None
    budget=[o for o in before if o['evidence']=='recovery-budget-frame-before-finally'];assert len(budget)==7 and all(not o['forked'] and o['work'] is None for o in budget)
    lease[label]={'files':len(report['testResults']),'passes':counts['passed'],'failures':counts['failed'],'skips':report['numPendingTests'],'exitCode':execution['exitCode'],'observationsBeforeFixtureCleanup':len(before),'finallyKilledEmpty':True,'rawAndNativeValidGrantsExecuted':True,'validLeaseEOFAndExpiredLeaseRefused':True,'runtimeChildren':[{'runtime':o['runtime'],'executable':o['nativeRuntime']['executable'],'nodeVersion':o['nativeRuntime']['versions']['node'],'bunVersion':o['nativeRuntime']['versions'].get('bun')} for o in native],'observations':observations}
put('evidence/lease-controls-summary.json',lease)

# Bind optional benchmark receipts to the exact complete product module.
benchmark={}
for label in ['spec-focused-node','spec-focused-bun']:
    entry=[json.loads(line) for line in (root/'evidence'/f'{label}-entrypoints.jsonl').read_text().splitlines()]
    host=[r for r in entry if r['kind']=='host'];cases=[r for r in entry if r['kind']=='case']
    life=load('evidence/'+label+'-benchmark-host.json')
    sourcehash=sha(root/'candidate/src/bench-rerank.ts')
    assert len(host)==1 and host[0]['sourceSha256']==life['sourceSha256']==sourcehash
    assert host[0]['exactExecutableBodiesVerified'] and life['exactExecutableBodiesVerified']
    assert all(r['status']==0 and r.get('signal') is None and not r.get('error') for r in cases)
    benchmark[label]={'sourceSha256':sourcehash,'entrypointCases':len(cases),'nativeAndForcedFallbackObserved':sorted(set(r['variant'] for r in cases)),'modes':sorted(set(r['mode'] for r in cases)),'executableBodiesExact':True,'realNativeModelOrGpuRuns':0,'host':host[0]}
put('evidence/benchmark-replay-summary.json',benchmark)

# Recheck immutable proposal bytes after all owned executions.
parent=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-final-composition-mer5fi8x')
index=load('inputs/report-index.json')
assert sha(parent/'report-index.json')=='20b7291d264daa47e2017070c8747ba962db1160ce5802bd38eac8e6b82859cb'
for p,expected in index['artifactSha256'].items():assert sha(parent/p)==expected,p
for tree in ['candidate','baseline']:
    manifest=load('inputs/'+tree+'-manifest.json')['sourceSha256']
    for p,h in manifest.items():assert sha(parent/tree/p)==sha(root/tree/p)==h,(tree,p)
shared=Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
metadata={}
for directory,dirs,names in os.walk(shared,followlinks=False):
    for name in sorted(dirs+names):
        p=Path(directory)/name;s=p.lstat()
        metadata[str(p.relative_to(shared))]={'mode':s.st_mode,'size':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'inode':s.st_ino,'link':os.readlink(p) if p.is_symlink() else None}
assert metadata==load('evidence/dependencies-before.json')
put('evidence/dependencies-final.json',metadata)
summary={'specStatus':'PASS_SOURCE_BOUND_QUALIFIED','qualityStarted':False,'sourceCount':298,'changedPaths':22,'inputArtifactCount':50,'tests':load('evidence/test-summary.json'),'leaseControls':{k:{p:v for p,v in x.items() if p!='observations'} for k,x in lease.items()},'benchmark':benchmark,'compiler':load('evidence/compiler-summary.json'),'preservation':preservation,'patch':load('evidence/patch-verification.json'),'immutableInputArtifactsAndSourcesUnchanged':True,'sharedDependencyMetadataFinalUnchanged':len(metadata),'C1UniversalCompleteCleanupAccepted':False,'T3DetailedReviewOwnedSeparately':True,'wholeRootAccepted':False,'liveIntegrated':False}
put('evidence/spec-result.json',summary)
print(json.dumps({'specStatus':summary['specStatus'],'leaseControls':summary['leaseControls'],'benchmark':benchmark,'preservedSourcesOutsideChangedPaths':preservation['protectedUnchangedSourceCount'],'protectedRecoveryPaths':preservation['protectedRecoveryAndLeasePaths'],'originalMetricFile':next(v for v in summary['tests']['spec-focused-node']['testFiles'] if v['file'].endswith('phase5-recovery.test.ts')),'sharedDependencyMetadataFinalUnchanged':len(metadata)},indent=2))
