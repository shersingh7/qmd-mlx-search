import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ts from '../candidate/node_modules/typescript/lib/typescript.js';
const root = path.resolve(import.meta.dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const before = read('baseline/scripts/phase5_e2e_runner.ts');
const t2 = read('inputs/t2/scripts/phase5_e2e_runner.ts');
const after = read('candidate/scripts/phase5_e2e_runner.ts');
assert.equal(sha(before), '6204b26a3a8218cd1da6ce03ec856065656d904cc9b936d9110900f8d79ac875');
assert.equal(sha(t2), 'ef2202822b4992acb27b9b989f23f49280f3b66b22a1630569ee057ef1a7601c');
assert.equal(sha(after), '4626805b4c9cefa234911d896395da6a56266c79e720164eee6a048e09c81630');
const cfg = ts.readConfigFile(path.join(root, 'candidate/tsconfig.json'), ts.sys.readFile);
assert.equal(cfg.error, undefined);
const converted = ts.convertCompilerOptionsFromJson(cfg.config.compilerOptions, path.join(root, 'candidate'));
assert.deepEqual(converted.errors, []);
const options = { ...converted.options, noEmit: false, removeComments: true, sourceMap: false,
  inlineSourceMap: false, declaration: false, declarationMap: false };
const emit = text => ts.transpileModule(text, { compilerOptions: options, fileName: 'runner.ts' }).outputText;
const parsed = (text, kind) => ts.createSourceFile('runner.' + kind, text, ts.ScriptTarget.ESNext, true,
  kind === 'ts' ? ts.ScriptKind.TS : ts.ScriptKind.JS);
function unique(items, label) { assert.equal(items.length, 1, label); return items[0]; }
function walk(node, accept, result = []) {
  if (accept(node)) result.push(node);
  ts.forEachChild(node, child => { walk(child, accept, result); });
  return result;
}
function applySpans(text, spans) {
  const ordered = [...spans].sort((a,b) => a.start-b.start);
  for (let i=1;i<ordered.length;i++) assert(ordered[i-1].end <= ordered[i].start);
  let at=0; let result='';
  for (const span of ordered) { result+=text.slice(at,span.start)+span.token;at=span.end; }
  return result+text.slice(at);
}
function metricSpan(ast) {
  const node = unique(ast.statements.filter(n => ts.isFunctionDeclaration(n) && n.name?.text === 'verifyRetrievalEquivalence'), 'one top-level metric declaration');
  return { start: node.getStart(ast), end: node.end, token: '<AUTHORIZED_METRIC>' };
}
function maskParent(text, kind) { const ast=parsed(text,kind);return applySpans(text,[metricSpan(ast)]); }
assert.equal(maskParent(t2,'ts'),maskParent(after,'ts'));
assert.equal(maskParent(emit(t2),'js'),maskParent(emit(after),'js'));

// Structural selections are complete ordered AST walks, never a flat name map.
// Only the already-authorized loop, guard and CLI variable statements are masked.
function maskBaselineToT2(text, kind, newer) {
  const ast=parsed(text,kind);const spans=[metricSpan(ast)];
  const latency = unique(ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='computeLatencies'),'latency');
  const guards=walk(latency,n=>ts.isIfStatement(n)&&n.expression.getText(ast).includes('p50 === undefined'));
  assert.equal(guards.length,newer?1:0);
  if(newer) spans.push({start:guards[0].getFullStart(),end:guards[0].end,token:''});
  const evaluate=unique(ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='evaluateRetrievalStage'),'evaluate');
  const loop=unique(walk(evaluate,n=>newer
    ? ts.isForOfStatement(n)&&n.expression.getText(ast)==='topIds.entries()'
    : ts.isForStatement(n)&&n.condition?.getText(ast)==='i < topIds.length'),'rank loop');
  spans.push({start:loop.getStart(ast),end:loop.end,token:'<AUTHORIZED_RANK_LOOP>'});
  const entry = unique(ast.statements.filter(n=>ts.isIfStatement(n)&&n.expression.getText(ast).includes('import.meta.url')), 'CLI entrypoint');
  const variables=walk(entry,ts.isVariableStatement);
  const mlx=unique(variables.filter(n=>n.declarationList.declarations.some(d=>ts.isIdentifier(d.name)&&d.name.text==='mlxPort')),'port');
  spans.push({start:mlx.getStart(ast),end:mlx.end,token:'<AUTHORIZED_PORT>'});
  const arg=variables.filter(n=>n.declarationList.declarations.some(d=>ts.isIdentifier(d.name)&&d.name.text==='mlxPortArg'));
  assert.equal(arg.length,newer?1:0);
  if(newer) spans.push({start:arg[0].getFullStart(),end:arg[0].end,token:''});
  return {text:applySpans(text,spans),spans};
}
for(const kind of ['ts','js']) {
  const left=kind==='ts'?before:emit(before); const right=kind==='ts'?t2:emit(t2);
  assert.equal(maskBaselineToT2(left,kind,false).text,maskBaselineToT2(right,kind,true).text,kind+' complete complement outside authorized metric/loop/guard/argv spans');
}
const t2test=read('inputs/t2/test/phase5-recovery.test.ts');
const finaltest=read('candidate/test/phase5-recovery.test.ts');
const first=finaltest.indexOf('    it("refuses sparse score slots');
const last=finaltest.indexOf('    it("refuses missing query slots',first);
assert(first>=0 && last>first);
assert.equal(finaltest.slice(0,first)+finaltest.slice(last),t2test);
assert.equal(emit(read('inputs/t2/vitest.config.ts')),emit(read('candidate/vitest.config.ts')));
assert.equal(emit(read('inputs/t1/vitest.config.ts')),emit(read('candidate/vitest.config.ts')));
const baselineManifest=JSON.parse(read('inputs/baseline-manifest.json')).sourceSha256;
const candidateManifest=JSON.parse(read('inputs/candidate-manifest.json')).sourceSha256;
const expectedChanges=Object.keys(JSON.parse(read('inputs/path-preimages.json'))).sort();
const actualChanges=[...new Set([...Object.keys(baselineManifest),...Object.keys(candidateManifest)])].filter(p=>baselineManifest[p]!==candidateManifest[p]).sort();
assert.deepEqual(actualChanges,expectedChanges);
const protectedPaths=Object.keys(baselineManifest).filter(p=>!(p in Object.fromEntries(actualChanges.map(p=>[p,true]))));
for(const p of protectedPaths) assert.equal(read('baseline/'+p),read('candidate/'+p));
const leasePaths=protectedPaths.filter(p=>/recovery|lease/i.test(p));
const spansBefore=maskBaselineToT2(before,'ts',false).spans;
const spansT2=maskBaselineToT2(t2,'ts',true).spans;
const output={typescriptVersion:ts.version,compilerOptions:options,
  hashes:{baseline:sha(before),t2:sha(t2),candidate:sha(after)},
  topLevelMetricUnique:true,parentSourceComplementByteIdentical:true,parentEmittedCommentsRemovedComplementIdentical:true,
  baselineToT2SourceComplementIdentical:true,baselineToT2EmittedCommentsRemovedComplementIdentical:true,
  originalT2TestsBytePreserved:true,newParentTestInsertionSha256:sha(finaltest.slice(first,last)),
  t1AndT2VitestEmittedJSIdenticalToFinal:true,protectedUnchangedSourceCount:protectedPaths.length,
  protectedRecoveryAndLeasePaths:leasePaths.map(p=>({path:p,sha256:candidateManifest[p]})),
  rawAuthorizedSpans:{baseline:spansBefore,t2:spansT2},
  leaseDeadlineAndGrantCodeOutsideAuthorizedSpansUnchanged:true,wholeRootAccepted:false};
fs.writeFileSync(path.join(root,'evidence/independent-preservation.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(output,null,2));
