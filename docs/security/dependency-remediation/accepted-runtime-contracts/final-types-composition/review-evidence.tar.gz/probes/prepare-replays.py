from pathlib import Path
import json, shutil, hashlib
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'inputs/baseline-manifest.json').read_text())['sourceSha256']
for destination in ['patch-replay','t2-patch-replay']:
    target=root/destination;target.mkdir()
    for relative,expected in manifest.items():
        assert Path(relative).name!='AGENTS.md'
        source=root/'baseline'/relative
        assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
        output=target/relative;output.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,output)
print(json.dumps({'preparedFreshReplays':['patch-replay','t2-patch-replay'],'baselineSourcesEach':len(manifest)}))
