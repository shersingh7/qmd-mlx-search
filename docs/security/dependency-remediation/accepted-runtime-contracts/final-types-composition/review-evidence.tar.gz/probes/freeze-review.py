from pathlib import Path
import json, hashlib, sys, os
root=Path(__file__).resolve().parents[1]
label=sys.argv[1]
assert label and all(c.isalnum() or c=='-' for c in label)
excluded={'candidate','baseline','precursor','patch-replay','t2-patch-replay','state','tools','home','hermes','knowledge','cache','config','data','hf','tmp','manifests'}
artifacts={}
for directory,dirs,names in os.walk(root,followlinks=False):
    rel=Path(directory).relative_to(root)
    if rel==Path('.'):
        dirs[:]=[d for d in dirs if d not in excluded]
    dirs[:]=[d for d in dirs if d not in ['node_modules','dist']]
    for name in names:
        p=Path(directory)/name
        assert name!='AGENTS.md'
        if p.is_symlink():continue
        artifacts[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in ['sdk-probe/node_modules/review-native-zod/package.json','sdk-probe/node_modules/review-native-zod/index.mjs','sdk-probe/node_modules/review-converter-native/package.json','sdk-probe/node_modules/review-converter-native/index.mjs']:
    artifacts[p]=hashlib.sha256((root/p).read_bytes()).hexdigest()
for tree in ['candidate','baseline','precursor']:
    name='pre-parent-candidate' if tree=='precursor' else tree
    manifest=json.loads((root/'inputs'/f'{name}-manifest.json').read_text())['sourceSha256']
    for p,h in manifest.items():assert hashlib.sha256((root/tree/p).read_bytes()).hexdigest()==h,(tree,p)
if label!='before-quality':
    before=json.loads((root/'manifests/before-quality-artifacts.json').read_text())['artifactSha256']
    assert all(artifacts[p]==h for p,h in before.items()),[p for p,h in before.items() if artifacts.get(p)!=h]
(root/'manifests').mkdir(exist_ok=True)
out={'artifactCount':len(artifacts),'artifactSha256':dict(sorted(artifacts.items())),'sourceManifestBindings':{n:hashlib.sha256((root/'inputs'/n).read_bytes()).hexdigest() for n in ['baseline-manifest.json','candidate-manifest.json','pre-parent-candidate-manifest.json']},'excludedOperationalOrSeparatelyManifestedRoots':sorted(excluded),'sourcePostimagesUnchanged':True,'beforeQualityArtifactsPreserved':label!='before-quality'}
with (root/'manifests'/f'{label}-artifacts.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'label':label,'artifactCount':len(artifacts),'sourceCounts':{'baseline':295,'candidate':298,'precursor':298},'sourcePostimagesUnchanged':True,'beforeQualityArtifactsPreserved':label!='before-quality'}))
