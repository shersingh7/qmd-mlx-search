from pathlib import Path
import os, json, hashlib, stat, shutil, re

ROOT = Path(__file__).resolve().parents[1]
PARENT = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-final-composition-mer5fi8x')
T1 = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-compose-nd8v4x2p')
T2 = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
T3 = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-declarations-1yp0w89j')
SHARED = Path('/Users/shersingh/github/qmd-mlx-search/node_modules')

def digest(p):
    assert p.name != 'AGENTS.md', str(p)
    assert stat.S_ISREG(p.lstat().st_mode), str(p)
    return hashlib.sha256(p.read_bytes()).hexdigest()

def verified_index(root, expected):
    index_path = root/'evidence/report-index.json' if root == T3 else root/'report-index.json'
    assert digest(index_path) == expected
    obj = json.loads(index_path.read_text())
    return obj, obj.get('artifactSha256', obj.get('files', {}))

def read_verified(root, name, files):
    p = root/name
    assert digest(p) == files[name], name
    return p.read_bytes()

def put(name, data, mode=0o644):
    p = ROOT/name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f: f.write(data)
    p.chmod(mode)

idx, files = verified_index(PARENT, '20b7291d264daa47e2017070c8747ba962db1160ce5802bd38eac8e6b82859cb')
assert len(files) == idx['artifactCount'] == 50
for n in files: read_verified(PARENT, n, files)
t1idx, t1files = verified_index(T1, '104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac')
t2idx, t2files = verified_index(T2, 'b64e19f60ac5ec3b7675f802a03f92cc0e632bd9aa7b189973c975c6f1bf272d')
t3idx, t3files = verified_index(T3, '35b02bf22d08f008adc60c684af3a2d56ae83260df6e97c79a697c7b91bc11dd')
for n in ['baseline-manifest.json','candidate-manifest.json','pre-parent-candidate-manifest.json','path-preimages.json','composition.json','composition-result.json','report-index.json']:
    data = (PARENT/n).read_bytes() if n=='report-index.json' else read_verified(PARENT,n,files)
    put('inputs/'+n,data)

manifests = {}
for source in ['baseline','candidate']:
    m = json.loads(read_verified(PARENT, source+'-manifest.json',files))
    mapping = m['sourceSha256']
    assert len(mapping) == m['sourceCount']
    for rel,h in mapping.items():
        rp = Path(rel)
        assert not rp.is_absolute() and '..' not in rp.parts and rp.name != 'AGENTS.md',rel
        assert digest(PARENT/source/rel)==h, rel
        put(source+'/'+rel,(PARENT/source/rel).read_bytes(), stat.S_IMODE((PARENT/source/rel).stat().st_mode))
    manifests[source]=mapping

changes=sorted(p for p in set(manifests['baseline'])|set(manifests['candidate']) if manifests['baseline'].get(p)!=manifests['candidate'].get(p))
preimages=json.loads(read_verified(PARENT,'path-preimages.json',files))
assert changes==sorted(preimages) and len(changes)==22
for p in changes:
    assert preimages[p]['preimageSha256']==manifests['baseline'].get(p)
    assert preimages[p]['postimageSha256']==manifests['candidate'][p]

partial=read_verified(T1,'parent-integration.partial.patch',t1files)
t1paths=re.findall(r'^diff --git a/(.+) b/\1$',partial.decode(),re.M)
assert len(t1paths)==17
identities={}
for p in t1paths:
    n='reference/accepted19/'+p
    src=read_verified(T1,n,t1files)
    put('inputs/t1/'+p,src)
    match=hashlib.sha256(src).hexdigest()==manifests['candidate'][p]
    assert match or p=='vitest.config.ts',p
    identities[p]=match

for n in ['after-manifest.json','T2-metric-guards.patch']:
    put('inputs/t2/'+n,read_verified(T2,n,t2files))
t2m=json.loads(read_verified(T2,'after-manifest.json',t2files))
# Accommodate the declared manifest object without inferring source data.
t2sources=t2m.get('sourceSha256',t2m.get('files',{}))
assert isinstance(t2sources,dict) and t2sources
for p in ['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts','vitest.config.ts']:
    target=T2/'mirror'/p
    value=t2sources[p]
    h=value if isinstance(value,str) else value['sha256']
    assert digest(target)==h
    put('inputs/t2/'+p,target.read_bytes())

preparent=json.loads(read_verified(PARENT,'pre-parent-candidate-manifest.json',files))
for p,h in preparent['sourceSha256'].items():
    inp=ROOT/'inputs/t2'/p if p in ['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts','vitest.config.ts'] else ROOT/'candidate'/p
    assert digest(inp)==h,('precursor',p)
    put('precursor/'+p,inp.read_bytes(),stat.S_IMODE(inp.stat().st_mode))

# This reviewer checks only byte-exact metadata composition, not T3 provenance approval.
t3after_name='evidence/mirror-source-after.json'
t3m=json.loads(read_verified(T3,t3after_name,t3files))
t3sources=t3m.get('sourceSha256',t3m.get('files',{}))
t3metadata={}
for p in ['package.json','bun.lock','pnpm-lock.yaml']:
    v=t3sources[p]; h=v if isinstance(v,str) else v['sha256']
    assert digest(T3/'mirror'/p)==h==manifests['candidate'][p]
    t3metadata[p]=h

for name in ['run.py','candidate-isolated.config.mjs','heldouts-isolated.config.mjs','final-composition.patch','probes/compiler-read-guard.cjs','probes/test-host-setup.mjs','heldouts/metrics-inputs.test.ts']:
    put(name,read_verified(PARENT,name,files))
original=read_verified(PARENT,'heldouts/metrics-inputs.test.ts',files)
red=original.replace(b"../candidate/scripts/phase5_e2e_runner.js",b"../precursor/scripts/phase5_e2e_runner.js")
assert red!=original and red.replace(b'../precursor/scripts/',b'../candidate/scripts/')==original
put('red-heldouts/metrics-inputs.test.ts',red)
config=read_verified(PARENT,'heldouts-isolated.config.mjs',files)
put('red-heldouts-isolated.config.mjs',config.replace(b"./heldouts/",b"./red-heldouts/"))

# Read-use package aliases in real owned containers, with writable caches created before RED.
aliases=json.loads(read_verified(PARENT,'evidence/candidate-package-aliases.json',files))
decl_name='evidence/mirror-installed-declarations.json'
declarations=json.loads(read_verified(T3,decl_name,t3files))
assert sum(len(d['files']) for d in declarations)==44
for d in declarations:
    for p,meta in d['files'].items():
        assert digest(Path(d['root'])/p)==meta['sha256']
for location in ['candidate','baseline','precursor','heldouts','red-heldouts','sdk-probe']:
    nm=ROOT/location/'node_modules'; nm.mkdir(parents=True)
    for cache in ['.vite','.vite-temp','.cache','.vitest']: (nm/cache).mkdir()
    for name,destination in aliases.items():
        dest=Path(destination)
        assert dest.is_dir() and dest.resolve().is_relative_to(SHARED.resolve()),name
        link=nm/name; link.parent.mkdir(parents=True,exist_ok=True); link.symlink_to(dest,target_is_directory=True)
    if location in ['candidate','baseline','precursor']:
        for d in declarations:
            for p,meta in d['files'].items():
                put(location+'/node_modules/'+d['name']+'/'+p,(Path(d['root'])/p).read_bytes())
    (ROOT/'evidence'/f'{location}-package-aliases.json').write_text(json.dumps(aliases,indent=2)+'\n')

sdk_prefix='reference/fixtures/'
for n in t1files:
    if n.startswith(sdk_prefix+'sdk-probe/'):
        put(n[len(sdk_prefix):],read_verified(T1,n,t1files))
for n in ['probes/sdk-network-guard.mjs','probes/host-setup.mjs']:
    put('probes/sdk-'+Path(n).name,read_verified(T1,sdk_prefix+n,t1files))
sdkconfig=read_verified(T1,sdk_prefix+'sdk-isolated.config.mjs',t1files)
sdkconfig=sdkconfig.replace(b'./mirror/',b'./candidate/').replace(b'./probes/host-setup.mjs',b'./probes/sdk-host-setup.mjs').replace(b'./probes/sdk-network-guard.mjs',b'./probes/sdk-sdk-network-guard.mjs')
put('sdk-isolated.config.mjs',sdkconfig)

bins=ROOT/'tools/bin';bins.mkdir(parents=True)
executables={'node':'/Users/shersingh/.hermes/node/bin/node','bun':'/Users/shersingh/.bun/bin/bun','python3':'/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python','git':'/usr/bin/git'}
for name,target in executables.items(): (bins/name).symlink_to(target)
# Hash selected runtime/library bytes; keep versions as independent runtime receipts.
runtime_hashes={name:hashlib.sha256(Path(target).read_bytes()).hexdigest() for name,target in executables.items()}
runtime_hashes['typescript.js']=digest(SHARED/'typescript/lib/typescript.js')
put('evidence/runtime-byte-identities.json',(json.dumps(runtime_hashes,indent=2)+'\n').encode())

# Metadata-only preservation of shared packages, including any AGENTS.md entries.
metadata={}
for directory,dirs,names in os.walk(SHARED,followlinks=False):
    for name in sorted(dirs+names):
        p=Path(directory)/name;s=p.lstat()
        metadata[str(p.relative_to(SHARED))]={'mode':s.st_mode,'size':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'inode':s.st_ino,'link':os.readlink(p) if p.is_symlink() else None}
put('evidence/dependencies-before.json',(json.dumps(metadata,sort_keys=True)+'\n').encode())
summary={'parentArtifactsVerified':len(files),'baselineSourceCount':len(manifests['baseline']),'candidateSourceCount':len(manifests['candidate']),'changedPaths':changes,'t1Identities':identities,'t3MetadataOnlyExact':t3metadata,'copiedGenuineDeclarationFilesPerCompilerTree':44,'precursorSourceCount':preparent['sourceCount'],'heldoutAssertionBytesUnchanged':True,'sharedDependencyMetadataEntries':len(metadata),'rootNodeModulesSymlinks':False,'ownedCachesBeforeRed':True}
put('evidence/setup-result.json',(json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary,indent=2))
