from pathlib import Path
from collections import Counter
import os, json, hashlib
root=Path(__file__).resolve().parents[1]
def sha(p):
    assert p.name!='AGENTS.md'
    return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads((root/p).read_text())
def put(p,obj):
    target=root/p
    with target.open('x') as f: json.dump(obj,f,indent=2);f.write('\n')
labels=['red-parent-node','red-parent-bun','green-parent-node','green-parent-bun','spec-independent-node','spec-independent-bun','spec-focused-node','spec-focused-bun','spec-sdk-node','spec-sdk-bun']
summary={}
for label in labels:
    r=load('evidence/'+label+'.json'); execution=load('evidence/'+label+'-execution.json')
    counts=Counter(a['status'] for f in r['testResults'] for a in f['assertionResults'])
    total=sum(counts.values())
    assert total==r['numTotalTests'],(label,total,r['numTotalTests'])
    assert counts['passed']==r['numPassedTests'] and counts['failed']==r['numFailedTests']
    assert counts['skipped']+counts['pending']+counts['todo']==r['numPendingTests'],(label,counts)
    assert execution['exitCode']==(1 if label.startswith('red-') else 0)
    assert r['numFailedTests']==(3 if label.startswith('red-') else 0)
    details=[{'file':str(Path(f['name']).relative_to(root)), 'statuses':dict(Counter(a['status'] for a in f['assertionResults']))} for f in r['testResults']]
    hosts=[json.loads(s) for s in (root/'evidence'/f'{label}-hosts.jsonl').read_text().splitlines()]
    actualhosts=[h for h in hosts if 'versions' in h]
    assert actualhosts
    hostisBun=label.endswith('-bun')
    assert all(bool(h['versions'].get('bun'))==hostisBun for h in actualhosts),(label,actualhosts)
    assert all(not h.get('attempts') and not h.get('boundaryAttempts') for h in hosts)
    summary[label]={'files':len(r['testResults']),'passes':counts['passed'],'failures':counts['failed'],'skips':r['numPendingTests'],'exitCode':execution['exitCode'],'statuses':dict(counts),'testFiles':details,'hostExecutables':sorted(set(h['execPath'] for h in actualhosts)),'nodeVersions':sorted(set(h['versions']['node'] for h in actualhosts)),'bunVersions':sorted(set(h['versions']['bun'] for h in actualhosts if 'bun' in h['versions'])),'boundaryAttemptCount':sum(len(h.get('attempts',[]))+len(h.get('boundaryAttempts',[])) for h in hosts)}
put('evidence/test-summary.json',summary)

compilers={}
for label in ['build-canonical','types-canonical-node','types-canonical-bun']:
    run=load('evidence/'+label+'-execution.json')
    assert run['exitCode']==0 and run['stdout']=='' and run['stderr']==''
    rows=[json.loads(line) for file in sorted((root/'evidence').glob(label+'-compiler-reads-*.jsonl')) for line in file.read_text().splitlines()]
    refused=[r for r in rows if r.get('allowed') is False]
    hosts=[r for r in rows if r.get('kind')=='compiler-host']
    assert hosts
    assert len(refused)==(0 if label.startswith('build-') else 2),(label,refused)
    compilers[label]={'exitCode':run['exitCode'],'diagnostics':0,'refusals':refused,'hosts':[{'execPath':h['execPath'],'nodeVersion':h['versions']['node'],'bunVersion':h['versions'].get('bun'),'source':h['source']} for h in hosts]}
rootselections={}
for label in ['types-roots-before-build','types-roots-after-build']:
    output=json.loads(load('evidence/'+label+'-execution.json')['stdout'])
    rootselections[label]={'compilerOptions':output['compilerOptions'],'rootCount':len(output['files']),'roots':output['files']}
assert rootselections['types-roots-before-build']['compilerOptions']==rootselections['types-roots-after-build']['compilerOptions']
assert rootselections['types-roots-after-build']['compilerOptions']['allowJs'] is True
historical=[p for p in rootselections['types-roots-after-build']['roots'] if p.startswith('./docs/') and p.endswith('.mjs')]
assert len(historical)==3,historical
put('evidence/compiler-summary.json',{'commands':compilers,'rootSelections':rootselections,'historicalRootsRetained':historical,'wholeRootAccepted':False})

baseline=load('inputs/baseline-manifest.json')['sourceSha256']
candidate=load('inputs/candidate-manifest.json')['sourceSha256']
precursor=load('inputs/pre-parent-candidate-manifest.json')['sourceSha256']
for tree,manifest in [('baseline',baseline),('candidate',candidate),('precursor',precursor),('patch-replay',candidate)]:
    actual={p:sha(root/tree/p) for p in manifest}
    assert actual==manifest,tree
    put('evidence/'+tree+'-source-after.json',{'sourceCount':len(actual),'sourceSha256':actual})
# Verify the entire T2 replay, not only its changed files.
t2expected=dict(baseline)
for p in ['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts']:
    t2expected[p]=sha(root/'inputs/t2'/p)
t2actual={p:sha(root/'t2-patch-replay'/p) for p in t2expected}
assert t2actual==t2expected
put('evidence/patch-verification.json',{'combinedPatchSha256':sha(root/'final-composition.patch'),'combinedReplayPostimages':len(candidate),'allCombinedReplayPostimagesMatched':True,'t2ReplayPostimages':len(t2actual),'allT2ReplayPostimagesMatched':True})

shared=Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
metadata={}
for directory,dirs,names in os.walk(shared,followlinks=False):
    for name in sorted(dirs+names):
        p=Path(directory)/name;s=p.lstat()
        metadata[str(p.relative_to(shared))]={'mode':s.st_mode,'size':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'inode':s.st_ino,'link':os.readlink(p) if p.is_symlink() else None}
old=load('evidence/dependencies-before.json')
assert metadata==old,[(p,old.get(p),metadata.get(p)) for p in set(metadata)|set(old) if old.get(p)!=metadata.get(p)][:10]
put('evidence/dependencies-after.json',metadata)
put('evidence/dependency-preservation.json',{'metadataEntries':len(metadata),'allMetadataUnchanged':True,'AGENTSContentNeverRead':True,'genuineDeclarationFilesOwned':44,'sharedPackagesReadOnlyUse':True})
print(json.dumps({'tests':{k:{p:v for p,v in val.items() if p not in ['testFiles']} for k,val in summary.items()},'compiler':compilers,'historicalRoots':historical,'compilerRootCounts':{k:v['rootCount'] for k,v in rootselections.items()},'sourceAndPatchPreservation':True,'sharedDependencyMetadataUnchanged':len(metadata),'recoverySourceNames':[p for p in candidate if 'recovery' in p or 'lease' in p]},indent=2))
