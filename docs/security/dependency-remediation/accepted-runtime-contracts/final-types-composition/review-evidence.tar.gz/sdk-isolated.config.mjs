import { mergeConfig } from './candidate/node_modules/vitest/dist/config.js';
import project from './candidate/vitest.config.ts';
import { fileURLToPath } from 'node:url';
export default mergeConfig(project, {
  root: fileURLToPath(new URL('./sdk-probe/', import.meta.url)),
  cacheDir: process.env.VITE_CACHE_DIR,
  test: { setupFiles: [fileURLToPath(new URL('./probes/sdk-host-setup.mjs', import.meta.url)), fileURLToPath(new URL('./probes/sdk-sdk-network-guard.mjs', import.meta.url))] },
});
