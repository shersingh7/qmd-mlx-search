// Independent graph preservation review. No resolution or lifecycle execution.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const R=process.env.QMD_DECLARATIONS_ROOT;
const require=createRequire(path.join(R,'mirror/package.json'));
const yaml=require('yaml');
const ts=require('typescript');
assert.equal(ts.version,'5.9.3');
const read=(dir,name)=>{
  const text=fs.readFileSync(path.join(R,dir,name),'utf8');
  if(name.endsWith('.yaml'))return yaml.parse(text);
  if(name==='bun.lock'){
    const p=ts.parseConfigFileTextToJson(name,text);
    assert.equal(p.error,undefined);return p.config;
  }
  return JSON.parse(text);
};
const files=['package.json','pnpm-lock.yaml','bun.lock'];
const before=Object.fromEntries(files.map(n=>[n,read('evidence/preimages',n)]));
const after=Object.fromEntries(files.map(n=>[n,read('mirror',n)]));
const mode=process.argv[2]??'positive';
// Deliberately wrong owned in-memory graphs prove the verifier checks old nodes.
if(mode==='integrity')after['pnpm-lock.yaml'].packages['@types/node@24.10.1'].resolution.integrity='negative-control-tampered-integrity';
if(mode==='edge')after['pnpm-lock.yaml'].snapshots['@types/node@24.10.1'].dependencies['undici-types']='0.0.0';
if(mode==='metadata')after['package.json'].scripts['independent-review-tamper']='must not be accepted';
const newIds=['@types/bun@1.3.8','@types/picomatch@4.0.3','bun-types@1.3.8'];
const newNames=['@types/bun','@types/picomatch','bun-types'];
const newDev={'@types/bun':'1.3.8','@types/picomatch':'4.0.3'};
function onlyAdded(a,b,keys,context){
  assert.deepEqual(Object.keys(b).filter(k=>!(k in a)).sort(),keys.toSorted(),context+' additions');
  assert.deepEqual(Object.keys(a).filter(k=>!(k in b)),[],context+' removals');
  for(const k of Object.keys(a))assert.deepEqual(b[k],a[k],context+' old record '+k);
}
const P=before['pnpm-lock.yaml'],Q=after['pnpm-lock.yaml'];
const B=before['bun.lock'],C=after['bun.lock'];
onlyAdded(P.packages,Q.packages,newIds,'pnpm packages/integrity');
onlyAdded(P.snapshots,Q.snapshots,newIds,'pnpm snapshots/edges');
onlyAdded(B.packages,C.packages,newNames,'Bun records/edges/integrity');
const stripped=structuredClone(after);
for(const [name,version] of Object.entries(newDev)){
  assert.equal(after['package.json'].devDependencies[name],version);
  assert.deepEqual(Q.importers['.'].devDependencies[name],{specifier:version,version});
  assert.equal(C.workspaces[''].devDependencies[name],version);
  delete stripped['package.json'].devDependencies[name];
  delete stripped['pnpm-lock.yaml'].importers['.'].devDependencies[name];
  delete stripped['bun.lock'].workspaces[''].devDependencies[name];
}
for(const id of newIds){delete stripped['pnpm-lock.yaml'].packages[id];delete stripped['pnpm-lock.yaml'].snapshots[id];}
for(const name of newNames)delete stripped['bun.lock'].packages[name];
assert.deepEqual(stripped,before,'entire metadata and graphs minus exactly allowed additions');
const provenance=JSON.parse(fs.readFileSync(path.join(R,'evidence/provenance.json'),'utf8'));
const expectedEdges={'@types/bun@1.3.8':{dependencies:{'bun-types':'1.3.8'}},'bun-types@1.3.8':{dependencies:{'@types/node':'24.10.1'}},'@types/picomatch@4.0.3':{}};
for(const row of provenance){
  const id=row.name+'@'+row.version;
  assert.deepEqual(Q.packages[id],{resolution:{integrity:row.integrity}});
  assert.deepEqual(Q.snapshots[id],expectedEdges[id]);
  assert.deepEqual(C.packages[row.name],[id,'',Object.keys(row.dependencies).length?{dependencies:row.dependencies}:{},row.integrity]);
}
const identities=x=>{
  const pnpm=Object.keys(x['pnpm-lock.yaml'].packages).toSorted();
  const bun=[...new Set(Object.values(x['bun.lock'].packages).map(x=>x[0]))].toSorted();
  for(const id of pnpm)assert.match(id,/^(.+)@(\d+\.\d+\.\d+(?:-[^()]+)?)$/,'identity must be literal');
  assert.deepEqual(pnpm,bun,'complete cross-manager inventory');
  return pnpm;
};
const inv0=identities(before),inv1=identities(after);
assert.equal(inv0.length,372);assert.equal(inv1.length,375);
assert.deepEqual(inv1.filter(x=>!inv0.includes(x)),newIds.toSorted());
assert.deepEqual(inv1.filter(x=>x.startsWith('@types/node@')),['@types/node@24.10.1']);
assert.deepEqual(inv0.filter(x=>!inv1.includes(x)),[]);
assert.equal(mode,'positive','negative control unexpectedly accepted');
const output={status:'PASS',compilerVersion:ts.version,allOldNodesEdgesSnapshotsIntegrityAndMetadataPreserved:true,onlyNewDev:newDev,addedIdentities:newIds,beforeInventory:inv0,afterInventory:inv1,distinctBefore:inv0.length,distinctAfter:inv1.length,bunLockKeysBefore:Object.keys(B.packages).length,bunLockKeysAfter:Object.keys(C.packages).length,nodeTypesResolution:'24.10.1',counts:{oldPnpmPackages:Object.keys(P.packages).length,oldPnpmSnapshots:Object.keys(P.snapshots).length,oldBunKeys:Object.keys(B.packages).length},newEdges:expectedEdges};
fs.writeFileSync(path.join(R,'evidence/independent-graph.json'),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
