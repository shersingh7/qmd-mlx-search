"""QUALITY gate, deliberately executed only after the SPEC verdict exists."""
from pathlib import Path
import sys, json, hashlib, re, stat, importlib.util
R=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('owned_review',R/'probes/review.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
load=m.load;save=m.save;sha=m.sha
assert load(R/'evidence/spec-verdict.json')['verdict']=='PASS','SPEC must precede QUALITY'
commands=load(R/'evidence/command-summary.json');assert len(commands)==33
expected={x['label']:x['exit'] for x in commands}
raw=[]
for label,code in expected.items():
    receipt=load(R/'evidence'/f'{label}.json')
    assert receipt['exit_code']==receipt['expectedExit']==code
    assert receipt['argv'][:2]==['/usr/bin/sandbox-exec','-f']
    assert sha(Path(receipt['argv'][2]))==receipt['sandboxSha256']
    profile=Path(receipt['argv'][2]).read_text()
    assert '(deny network*)' in profile and '(deny file-write*)' in profile
    env=receipt['environment']
    for k in ['HOME','HERMES_HOME','HERMES_DIR','HERMES_ROOT','HERMES_KNOWLEDGE_DIR','KNOWLEDGE_DIR','XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','HF_HOME','HF_HUB_CACHE','TMPDIR','TMP','TEMP','UV_CACHE_DIR']:
        assert Path(env[k]).is_relative_to(R/'state'/label),(label,k)
    for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','QMD_LLAMA_GPU':'false','CI':'1','REQUIRE_BUN':'1','npm_config_ignore_scripts':'true','npm_config_offline':'true'}.items():assert env[k]==v
    for k in env:assert not re.search(r'(SECRET|TOKEN|PASSWORD|AUTH|API_KEY)',k,re.I),(label,k)
    assert Path(env['npm_config_userconfig']).is_relative_to(R/'state'/label)
    assert Path(env['npm_config_globalconfig']).is_relative_to(R/'state'/label)
    for stream in ['stdout','stderr']:assert sha(R/'logs'/f'{label}.{stream}.log')==receipt[stream+'Sha256']
    raw.append({'label':label,'exit':code,'argv':receipt['argv'],'receiptSha256':sha(R/'evidence'/f'{label}.json'),'stdoutSha256':receipt['stdoutSha256'],'stderrSha256':receipt['stderrSha256']})
# All controls must fail at their intended check, not at a setup/import boundary.
controlMessages={
'control-declarations-missing':"('missing payload', ['@types/picomatch/index.d.ts'])",
'control-declarations-tampered':"('payload identity/hash', '@types/picomatch/index.d.ts')",
'control-declarations-metadata':"('payload identity/hash', '@types/bun/package.json')",
'control-graph-integrity':'pnpm packages/integrity old record @types/node@24.10.1',
'control-graph-edge':'pnpm snapshots/edges old record @types/node@24.10.1',
'control-graph-metadata':'entire metadata and graphs minus exactly allowed additions',
'control-pnpm-stale':'ERR_PNPM_OUTDATED_LOCKFILE',
'control-bun-stale':'lockfile had changes, but lockfile is frozen'}
for label,message in controlMessages.items():
    text='\n'.join((R/'logs'/f'{label}.{stream}.log').read_text() for stream in ['stdout','stderr'])
    assert message in text and 'negative control unexpectedly accepted' not in text and 'Cannot find module' not in text
hosts={host:load(R/'logs'/f'host-{host}.stdout.log') for host in ['node','bun','python']}
assert hosts['node']['execPath']==m.NODE and hosts['node']['versions']['node']=='22.22.3'
assert hosts['bun']['execPath']==m.BUN and hosts['bun']['versions']['bun']=='1.3.8'
assert hosts['python']['executable']==m.PY and hosts['python']['version'].startswith('3.12.13 ')
assert (R/'logs/host-pnpm.stdout.log').read_text().strip()=='10.33.0'
proofs={}
for host in ['node','bun']:
    data=load(R/'evidence'/f'resolution-{host}-bindings.json')
    assert data['host']['execPath']==(m.NODE if host=='node' else m.BUN)
    assert data['compilerVersion']=='5.9.3' and data['rootCount']==153 and len(data['diagnostics'])==31
    access=data['bunAccess'];assert access and all(not a['isAny'] and a['type']=='typeof import("bun")' for a in access)
    refs={name:row['version'] for name,row in data['installed'].items()}
    assert refs=={'typescript':'5.9.3','picomatch':'4.0.4','@types/node':'24.10.1','@types/bun':'1.3.8','bun-types':'1.3.8','@types/picomatch':'4.0.3'}
    for a in access:
        for row in a['declarations']:assert sha(Path(row['path']))==row['sha256']
    for name in ['bun:sqlite','bun:test']:
        for row in data['ambient'][name]['declarations']:
            assert Path(row['real']).is_relative_to(R/'mirror/node_modules/bun-types')
            assert sha(Path(row['path']))==row['sha256']
    assert data['picomatch']['packageId']['name']=='@types/picomatch' and data['picomatch']['packageId']['version']=='4.0.3'
    assert sha(Path(data['picomatch']['binding']['path']))==data['picomatch']['binding']['sha256']
    proofs[host]={'execPath':data['host']['execPath'],'versions':refs,'rootCount':153,'diagnosticCount':31,'BunAccess':access,'ambientBindings':{n:data['ambient'][n]['declarations'] for n in ['bun:sqlite','bun:test']},'picomatch':data['picomatch']}
    guard=load(R/'logs'/f'readguard-control-{host}.stdout.log');assert len(guard['refused'])==3 and all(x['code']=='DECLARATIONS_COMPILER_READ_DENIED' for x in guard['refused'])
# Verify the complete post-build source root, not just manifest-selected paths.
expectedFiles=set(load(R/'evidence/source-after.json')['sourceSha256'])|set(load(R/'evidence/generated-after.json'))
actual=set()
def inventory(p):
    for q in p.iterdir():
        if q==R/'mirror/node_modules':continue
        assert not q.is_symlink(),str(q)
        if q.is_dir():inventory(q)
        else:assert q.is_file();actual.add(str(q.relative_to(R/'mirror')))
inventory(R/'mirror');assert actual==expectedFiles
supplierGenerated=load(m.D/'evidence/replay-generated-baseline.json')['artifacts']
assert load(R/'evidence/generated-before.json')==load(R/'evidence/generated-after.json')==supplierGenerated
# Read authoritative producer raw receipts without running any producer helper.
supplierLabels=['lock-pnpm-regenerate','lock-bun-regenerate','frozen-pnpm','frozen-bun','control-pnpm-stale','control-bun-stale','control-bun-stale-removed','types-node-baseline','types-bun-baseline','types-node-after','types-bun-after','test-dependency-locks-runner','patch-apply-check','patch-apply','patch-reverse-check']
supplier=[]
for label in supplierLabels:
    receipt=load(m.D/'evidence'/f'{label}.json')
    logs={stream:(m.D/'logs'/f'{label}.{stream}.log').read_text() for stream in ['stdout','stderr']}
    supplier.append({'label':label,'exit':receipt['exit_code'],'argv':receipt['argv'],'receiptSha256':sha(m.D/'evidence'/f'{label}.json'),'stdoutSha256':sha(m.D/'logs'/f'{label}.stdout.log'),'stderrSha256':sha(m.D/'logs'/f'{label}.stderr.log')})
    if label.startswith(('lock-','frozen-','control-')):assert '--ignore-scripts' in receipt['argv']
    if label in ['lock-pnpm-regenerate','lock-bun-regenerate']:assert '--lockfile-only' in receipt['argv'] and receipt['exit_code']==0
    if label=='control-bun-stale':assert 'lockfile is frozen' not in logs['stderr'] and receipt['exit_code']==1
    if label=='control-bun-stale-removed':assert 'lockfile had changes, but lockfile is frozen' in logs['stderr'] and receipt['exit_code']==1
save(R/'evidence/supplier-raw-receipts-reviewed.json',supplier)
save(R/'evidence/verified-raw-commands.json',raw)
save(R/'evidence/type-binding-summary.json',proofs)
locks=load(R/'evidence/dependency-locks-results.json')
assert len(locks['testResults'])==1 and len(locks['testResults'][0]['assertionResults'])==5
assert all(x['status']=='passed' for x in locks['testResults'][0]['assertionResults'])
summary={'commandCount':len(commands),'exits':{str(code):sum(x['exit']==code for x in commands) for code in sorted({x['exit'] for x in commands})},'expectedNegativeControls':len(controlMessages),'strictCompilerInvocations':4,'lockTestFiles':1,'lockTests':{'passed':5,'failed':0,'skipped':0},'actualHosts':hosts,'pnpmVersion':'10.33.0','controlsReachedIntendedChecks':True,'actualOwnedSourceRootFiles':len(actual),'sourceFiles':251,'generatedFiles':48,'sourceInventoryExact':True,'generatedMatchesSupplierAndOwnBaseline':True,'originalBunVersionChangeControl':'retained metadata-resolution failure, not accepted as stale-lock proof','reviewHarnessSetupFailures':[],'externalProductFindings':[]}
save(R/'evidence/quality-evidence.json',summary)
quality={'verdict':'PASS','specPrerequisite':'PASS','findings':[],'scope':'reviewed three product paths only','rationale':['Minimal two exact direct dev pins; official bun-types only as genuine exact transitive dependency','Whole package metadata and both entire lock objects become identical to preimages after removing exactly the allowed additions','No runtime source, scripts, optional/peer requirements, previous dev pins, compiler roots/configuration or overrides changed','Real Node and Bun binding resolves non-any Bun plus genuine picomatch types; build emissions are byte/size/mode-identical','Independent cold-cache manager controls and guarded before/after runs support the claim without overstating the two denied historical reads'],'remainingGates':['Parent integrated whole-checkout canonical build/check/tests','Fresh online dependency-alert/audit retrieval','Actual Linux/Darwin Nix dependency hashes','Parent integration/CI/merge/publication']}
save(R/'evidence/quality-verdict.json',quality)
print(json.dumps({'SPEC':'PASS','QUALITY':'PASS','findings':[],'commandCount':len(commands),'exits':summary['exits'],'lockTests':summary['lockTests'],'sourceFiles':251,'generatedFiles':48,'typeBindingHosts':list(proofs),'setupFailures':[]},indent=2))
