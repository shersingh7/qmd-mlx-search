const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const targets=['/Users/shersingh/github/qmd-mlx-search/package.json','/Users/shersingh/github/qmd-mlx-search/src/mcp/server.ts'];
const link=path.join(process.cwd(),'.independent-review-readguard-escape');
assert.equal(fs.existsSync(link),false);
fs.symlinkSync(targets[0],link);
const refused=[];
try{
  for(const target of [...targets,link]){
    let code;
    try{fs.readFileSync(target,'utf8');}catch(e){code=e.code;}
    assert.equal(code,'DECLARATIONS_COMPILER_READ_DENIED',target+' was not refused before content read');
    refused.push({target,code});
  }
}finally{fs.unlinkSync(link);}
console.log(JSON.stringify({status:'PASS',refused,execPath:process.execPath,versions:process.versions}));
