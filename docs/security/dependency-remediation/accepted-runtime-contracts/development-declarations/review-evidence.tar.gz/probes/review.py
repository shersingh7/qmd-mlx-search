"""Independent T3 SPEC review. Only writes under this fresh owned root.
No registry, live sources, application imports or native/model initialization.
AGENTS.md dependency inventory is metadata-only: never open its contents.
"""
from pathlib import Path, PurePosixPath
import os, sys, json, hashlib, base64, tarfile, shutil, stat, subprocess, time, re, copy
R=Path(__file__).resolve().parents[1]
D=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-declarations-1yp0w89j')
I=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-compose-nd8v4x2p')
SHARED=Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
NODE='/Users/shersingh/.hermes/node/bin/node'
BUN='/Users/shersingh/.bun/bin/bun'
PNPM='/opt/homebrew/bin/pnpm'
PY='/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'
INDEX='35b02bf22d08f008adc60c684af3a2d56ae83260df6e97c79a697c7b91bc11dd'
PATCH='174a639eec01e7b135deb5823335fb7b6b41360b059b456709b9cc4037dcf7f3'
PRODUCT={'package.json':'7607a98a802ec455328ce0452fb2e43fb6c955e774d30e17cc49befac5e7ef1a','pnpm-lock.yaml':'c8dc5bf3011bef4a9417f49dbb37f47fa8aaa45dad97ba13366709554f2e308e','bun.lock':'c1dca7fd35ac82ef213872fc997d023218028d51b9fffb92b0e12b0ac070d329'}

def sha(p):
    assert p.name != 'AGENTS.md', 'AGENTS.md content read forbidden'
    return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):
    assert p.name != 'AGENTS.md'
    return json.loads(p.read_text())
def save(p,o):
    assert p.is_relative_to(R)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def statrow(p):
    s=p.lstat()
    row={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'ino':s.st_ino,'dev':s.st_dev,'nlink':s.st_nlink}
    if stat.S_ISLNK(s.st_mode):row['link']=os.readlink(p)
    elif stat.S_ISREG(s.st_mode):
        if p.name=='AGENTS.md':row['contentNotRead']='AGENTS.md metadata-only exception'
        else:row['sha256']=sha(p)
    elif not stat.S_ISDIR(s.st_mode):raise AssertionError('unexpected object '+str(p))
    return row
def snapshot(base):
    out={}
    def walk(p):
        out[str(p.relative_to(base))]=statrow(p)
        if p.is_dir() and not p.is_symlink():
            for x in sorted(p.iterdir()):walk(x)
    walk(base);return out

def cleanenv(label):
    state=R/'state'/label;state.mkdir(parents=True,exist_ok=False)
    locations={'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes','HERMES_ROOT':'hermes','HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge','XDG_CONFIG_HOME':'xdg/config','XDG_CACHE_HOME':'xdg/cache','XDG_DATA_HOME':'xdg/data','XDG_STATE_HOME':'xdg/state','HF_HOME':'hf','HF_HUB_CACHE':'hf/hub','TMPDIR':'tmp','TMP':'tmp','TEMP':'tmp','BUN_RUNTIME_TRANSPILER_CACHE_PATH':'cache/bun-transpile','npm_config_cache':'cache/npm','PNPM_HOME':'cache/pnpm','UV_CACHE_DIR':'cache/uv','PYTHONPYCACHEPREFIX':'cache/python','NODE_COMPILE_CACHE':'cache/node','VITE_CACHE_DIR':'cache/vite','VITEST_CACHE_DIR':'cache/vitest'}
    e={k:str(state/v) for k,v in locations.items()}
    for v in e.values():Path(v).mkdir(parents=True,exist_ok=True)
    npmrc=state/'npmrc';npmrc.write_text('registry=https://registry.npmjs.org/\nignore-scripts=true\naudit=false\nfund=false\nupdate-notifier=false\noffline=true\n')
    empty=state/'empty-npmrc';empty.write_text('')
    e.update({'PATH':str(R/'tools/bin')+':/usr/bin:/bin','LANG':'en_US.UTF-8','PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','UV_NO_SYNC':'1','npm_config_offline':'true','CI':'1','REQUIRE_BUN':'1','QMD_LLAMA_GPU':'false','QMD_DECLARATIONS_ROOT':str(R),'QMD_RUN_LABEL':label,'NO_COLOR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_CEILING_DIRECTORIES':str(R),'npm_config_userconfig':str(npmrc),'npm_config_globalconfig':str(empty),'npm_config_registry':'https://registry.npmjs.org/','npm_config_ignore_scripts':'true','npm_config_audit':'false','npm_config_fund':'false','npm_config_update_notifier':'false','COREPACK_ENABLE_NETWORK':'0','BUN_INSTALL_CACHE_DIR':str(state/'cache/bun-store'),'npm_config_store_dir':str(state/'cache/pnpm-store')})
    return e

def run(label,cmd,cwd='mirror',expected=0,guard=False,probe_profile=False):
    env=cleanenv(label);cwd=(R/cwd).resolve();assert cwd.is_relative_to(R)
    if guard:
        env['NODE_OPTIONS']='--require='+str(R/'probes/compiler-read-guard.cjs')
        if cmd[0]==BUN:cmd=[BUN,'--preload',str(R/'probes/compiler-read-guard.cjs'),*cmd[1:]]
    profile=R/'state'/label/'offline.sb'
    write_root=R/'state'/label/'probe-allowed' if probe_profile else R
    write_root.mkdir(exist_ok=True,parents=True)
    profile.write_text('(version 1)\n(allow default)\n(deny network*)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(write_root))+'))\n(allow file-write* (literal "/dev/null"))\n')
    cmd=['/usr/bin/sandbox-exec','-f',str(profile),*map(str,cmd)]
    receipt={'label':label,'cwd':str(cwd),'argv':cmd,'environment':env,'sandboxSha256':sha(profile),'expectedExit':expected}
    t=time.monotonic()
    p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=240)
    receipt.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t)
    for stream,b in [('stdout',p.stdout),('stderr',p.stderr)]:
        log=R/'logs'/f'{label}.{stream}.log';log.write_bytes(b);receipt[stream+'Sha256']=sha(log)
    save(R/'evidence'/f'{label}.json',receipt)
    print(json.dumps({'label':label,'exit':p.returncode,'expected':expected}),flush=True)
    assert p.returncode==expected,(label,p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'))
    return p

def public_paths():
    idx=load(D/'evidence/report-index.json');paths={D/'evidence/report-index.json'}
    assert sha(D/'evidence/report-index.json')==INDEX
    assert idx['artifactCount']==len(idx['artifactSha256'])==263
    for n,h in idx['artifactSha256'].items():
        rel=Path(n);assert not rel.is_absolute() and '..' not in rel.parts and rel.name!='AGENTS.md'
        p=D/rel;assert p.is_file() and not p.is_symlink() and sha(p)==h,n;paths.add(p)
    src=load(D/'evidence/source-before.json');assert src['sourceCount']==len(src['sourceSha256'])==251
    assert sha(I/'report-index.json')==src['inputReportIndexSha256']=='104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac'
    im=load(I/'after-manifest.json');assert sha(I/'after-manifest.json')==src['inputManifestSha256']==load(I/'report-index.json')['files']['after-manifest.json']
    assert im['sourceSha256']==src['sourceSha256']
    paths.update([I/'report-index.json',I/'after-manifest.json'])
    for n,h in src['sourceSha256'].items():
        assert Path(n).name!='AGENTS.md'
        p=I/'mirror'/n;assert sha(p)==h,n;paths.add(p)
    for manifest,tree in [('mirror-source-after.json','mirror'),('replay-source-before.json',None),('replay-source-after.json','replay')]:
        m=load(D/'evidence'/manifest);f=m.get('sourceSha256',m)
        assert len(f)==251,(manifest,list(m)[:5])
        if tree:
            for n,h in f.items():
                p=D/tree/n;assert sha(p)==h,(tree,n);paths.add(p)
    for tree in ['mirror','replay']:
        manifest=load(D/'evidence'/f'{tree}-installed-declarations.json')
        assert sum(len(row['files']) for row in manifest)==44
        for row in manifest:
            pbase=D/tree/'node_modules'/row['name']
            found={str(p.relative_to(pbase)) for p in pbase.rglob('*') if p.is_file()}
            assert found==set(row['files'])
            for n,item in row['files'].items():
                p=pbase/n;assert sha(p)==item['sha256'] and p.stat().st_size==item['size'];paths.add(p)
        generated=load(D/'evidence/replay-generated-baseline.json')['artifacts']
        for n,item in generated.items():
            p=D/tree/n;assert sha(p)==item['sha256'] and stat.S_IMODE(p.stat().st_mode)==item['mode'] and p.stat().st_size==item['size'];paths.add(p)
    assert sha(D/'evidence/declarations.patch')==PATCH
    for n,h in PRODUCT.items():assert sha(D/'mirror'/n)==sha(D/'replay'/n)==h
    return sorted(paths),src

def archive_payload(row):
    archive=D/'reference'/Path(row['archive']).name;b=archive.read_bytes()
    assert hashlib.sha256(b).hexdigest()==row['sha256']
    assert len(b)==row['bytes'] and hashlib.sha1(b).hexdigest()==row['sha1']
    assert 'sha512-'+base64.b64encode(hashlib.sha512(b).digest()).decode()==row['integrity']
    tag=archive.name.removesuffix('.tgz')
    meta=load(D/'reference'/('types-picomatch.metadata.json' if row['name']=='@types/picomatch' else tag+'.metadata.json'))
    if 'versions' in meta:meta=meta['versions'][row['version']]
    assert meta['name']==row['name'] and meta['version']==row['version']
    for k,v in {'tarball':row['url'],'integrity':row['integrity'],'shasum':row['sha1'],'fileCount':row['registryFileCount'],'unpackedSize':row['registryUnpackedSize']}.items():assert meta['dist'][k]==v
    members=[];dirs=[];selected={};omitted=[];total=0
    with tarfile.open(archive,'r:gz') as tar:
        for m in tar.getmembers():
            rel=PurePosixPath(m.name);assert not rel.is_absolute() and '..' not in rel.parts and (m.isfile() or m.isdir())
            assert rel.name!='AGENTS.md'
            if m.isdir():dirs.append(m.name);continue
            value=tar.extractfile(m).read();total+=len(value)
            decl=m.name.endswith(('.d.ts','.d.mts','.d.cts'))
            members.append({'path':m.name,'size':len(value),'sha256':hashlib.sha256(value).hexdigest(),'declaration':decl})
            name=str(PurePosixPath(*rel.parts[1:]))
            if decl or name in ['package.json','README.md','LICENSE','LICENSE.md']:selected[name]=value
            else:assert PurePosixPath(name).suffix in ['.md','.mdx'];omitted.append(name)
    assert members==load(D/'reference'/(tag+'.members.json'))
    assert len(members)==row['fileCount'] and sum(x['declaration'] for x in members)==row['declarationCount']
    assert len(members)+len(dirs)==row['registryFileCount'] and total==row['registryUnpackedSize']==row['verifiedUnpackedSize']
    pkg=json.loads(selected['package.json']);assert pkg['name']==row['name'] and pkg['version']==row['version'] and pkg['types'].removeprefix('./') in selected
    assert pkg.get('dependencies',{})==meta.get('dependencies',{})
    return selected,{'name':row['name'],'version':row['version'],'archiveSha256':row['sha256'],'integrity':row['integrity'],'sha1':row['sha1'],'url':row['url'],'fileCount':len(members),'directoryCount':len(dirs),'registryFileCount':row['registryFileCount'],'unpackedSize':total,'materializedCount':len(selected),'omittedDocumentationCount':len(omitted),'dependencies':pkg.get('dependencies',{}),'typescriptMinimum':meta.get('typeScriptVersion'),'registrySignatureVerificationClaimed':False}

def generated():
    return {str(p.relative_to(R/'mirror')):{'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode),'size':p.stat().st_size} for p in sorted((R/'mirror/dist').rglob('*')) if p.is_file()}

def preflight():
    for n in ['evidence','configs','reference','mirror','logs','state','tools/bin']:(R/n).mkdir(parents=True,exist_ok=True)
    paths,src=public_paths();save(R/'evidence/protected-input-before.json',{str(p):statrow(p) for p in paths})
    shared=snapshot(SHARED);save(R/'evidence/shared-before.json',shared)
    authoritative=load(D/'evidence/shared-dependencies-after.json')
    for name,row in authoritative.items():
        if Path(name).name=='AGENTS.md':row.pop('sha256',None);row['contentNotRead']='AGENTS.md metadata-only exception'
    diffs=[n for n in set(shared)|set(authoritative) if shared.get(n)!=authoritative.get(n)]
    save(R/'evidence/dependency-inventory-policy.json',{'AGENTS.md':'metadata only; no content hash or content read','metadataOnlyPaths':[n for n in shared if Path(n).name=='AGENTS.md'],'rows':len(shared),'authoritativeDifferences':diffs})
    assert not diffs,('dependency pre-existing drift',diffs[:10])
    for n,h in src['sourceSha256'].items():
        s=D/'evidence/preimages'/n if n in PRODUCT else D/'mirror'/n
        assert sha(s)==h
        p=R/'mirror'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,p)
    aliases=load(D/'evidence/mirror-package-aliases.json');assert len(aliases)==274
    nm=R/'mirror/node_modules';nm.mkdir()
    for n,target in aliases.items():
        p=Path(target);assert p.is_relative_to(SHARED) and p.resolve().is_relative_to(SHARED.resolve()) and (p/'package.json').is_file()
        q=nm/n;q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(target,target_is_directory=True)
    for n in ['.vite','.vite-temp','.cache','.vitest']:(nm/n).mkdir()
    save(R/'evidence/mirror-package-aliases.json',aliases)
    for n,target in {'node':NODE,'bun':BUN,'pnpm':PNPM,'python':PY}.items():(R/'tools/bin'/n).symlink_to(target)
    for n in ['compiler-read-guard.cjs','resolution-proof.mjs']:shutil.copy2(D/'probes'/n,R/'probes'/n)
    for n in ['bunfig.toml','locks.vitest.config.mjs']:shutil.copy2(D/'configs'/n,R/'configs'/n)
    for n in PRODUCT:
        q=R/'evidence/preimages'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/'evidence/preimages'/n,q)
    shutil.copy2(D/'evidence/declarations.patch',R/'evidence/declarations.patch')
    payload={};provenance=[]
    for row in load(D/'evidence/declaration-tarballs.json'):
        selected,receipt=archive_payload(row);payload[row['name']]=selected;provenance.append(receipt)
        shutil.copy2(D/'reference'/Path(row['archive']).name,R/'reference'/Path(row['archive']).name)
    assert sum(x['materializedCount'] for x in provenance)==44
    assert {x['name']:x['dependencies'] for x in provenance}=={'@types/bun':{'bun-types':'1.3.8'},'bun-types':{'@types/node':'*'},'@types/picomatch':{}}
    save(R/'evidence/provenance.json',provenance)
    save(R/'evidence/source-before.json',src)
    save(R/'evidence/preflight.json',{'status':'PASS','artifactCount':263,'indexedArtifactsSha256':INDEX,'patchSha256':PATCH,'sourceCount':251,'dependencyRows':len(shared),'aliasCount':len(aliases),'protectedPublicPaths':len(paths),'declarationFileCount':44})
    print(json.dumps({'preflight':'PASS','root':str(R),'protectedPaths':len(paths),'dependencyRows':len(shared)}),flush=True)

def execute():
    src=load(R/'evidence/source-before.json')['sourceSha256']
    steps=[]
    def command(label,cmd,**kw):
        p=run(label,cmd,**kw);steps.append({'label':label,'exit':p.returncode});save(R/'evidence/command-summary.json',steps);return p
    command('host-python',[PY,'-I','-c','import sys,json;print(json.dumps({"executable":sys.executable,"version":sys.version}))'])
    command('host-node',[NODE,'-e','console.log(JSON.stringify({execPath:process.execPath,versions:process.versions}))'])
    command('host-bun',[BUN,'-e','console.log(JSON.stringify({execPath:process.execPath,versions:process.versions}))'])
    command('host-pnpm',[PNPM,'--version'])
    command('sandbox-probe',[NODE,R/'probes/safety-probe.cjs',R/'state/sandbox-denied-owned-target'],probe_profile=True)
    tsc=['node_modules/typescript/bin/tsc','-p','tsconfig.json','--noEmit','--pretty','false']
    command('build-before',[NODE,'scripts/build.mjs'],guard=True)
    g0=generated();assert len(g0)==48;save(R/'evidence/generated-before.json',g0)
    command('types-node-before',[NODE,*tsc],expected=2,guard=True)
    command('types-bun-before',[BUN,*tsc],expected=2,guard=True)
    command('roots-node-before',[NODE,'node_modules/typescript/bin/tsc','-p','tsconfig.json','--showConfig'],guard=True)
    git=['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.attributesFile=/dev/null','apply']
    command('patch-check',[*git,'--check','../evidence/declarations.patch'])
    command('patch-apply',[*git,'../evidence/declarations.patch'])
    command('patch-reverse-check',[*git,'--reverse','--check','../evidence/declarations.patch'])
    rows=load(D/'evidence/declaration-tarballs.json');files={}
    for row in rows:
        selected,_=archive_payload(row)
        for n,b in selected.items():
            p=R/'mirror/node_modules'/row['name']/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(0o444)
            files[str(p.relative_to(R/'mirror/node_modules'))]={'sha256':sha(p),'size':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
    assert len(files)==44;save(R/'evidence/owned-installed-manifest.json',files)
    command('verify-installed',[PY,'-I',R/'probes/verify-owned.py',R/'mirror/node_modules'])
    command('graph-review',[NODE,R/'probes/graph-review.mjs'])
    pnpm=lambda label:[PNPM,'install','--lockfile-only','--frozen-lockfile','--ignore-scripts','--ignore-pnpmfile','--ignore-workspace','--offline','--registry=https://registry.npmjs.org/','--store-dir='+str(R/'state'/label/'cache/pnpm-store'),'--reporter=ndjson']
    bun=lambda label:[BUN,'install','--lockfile-only','--frozen-lockfile','--ignore-scripts','--save-text-lockfile','--registry=https://registry.npmjs.org/','--config='+str(R/'configs/bunfig.toml'),'--cache-dir='+str(R/'state'/label/'cache/bun-store'),'--network-concurrency=2']
    command('frozen-pnpm',pnpm('frozen-pnpm'))
    command('frozen-bun',bun('frozen-bun'))
    for label,manager in [('control-pnpm-stale','pnpm'),('control-bun-stale','bun')]:
        cwd='configs/'+label;p=R/cwd;p.mkdir()
        for n in PRODUCT:shutil.copy2(R/'mirror'/n,p/n)
        pkg=load(p/'package.json')
        if manager=='pnpm':pkg['devDependencies']['@types/bun']='1.3.7'
        else:del pkg['devDependencies']['@types/bun']
        save(p/'package.json',pkg)
        pre={n:sha(p/n) for n in PRODUCT};command(label,pnpm(label) if manager=='pnpm' else bun(label),cwd=cwd,expected=1)
        assert pre=={n:sha(p/n) for n in PRODUCT},label+' mutated frozen fixture'
    assert 'ERR_PNPM_OUTDATED_LOCKFILE' in (R/'logs/control-pnpm-stale.stdout.log').read_text()
    assert 'lockfile had changes, but lockfile is frozen' in (R/'logs/control-bun-stale.stderr.log').read_text()
    command('build-after',[NODE,'scripts/build.mjs'],guard=True)
    g1=generated();save(R/'evidence/generated-after.json',g1);assert g1==g0
    command('types-node-after',[NODE,*tsc],expected=2,guard=True)
    command('types-bun-after',[BUN,*tsc],expected=2,guard=True)
    command('roots-node-after',[NODE,'node_modules/typescript/bin/tsc','-p','tsconfig.json','--showConfig'],guard=True)
    command('resolution-node',[NODE,R/'probes/resolution-proof.mjs'],guard=True)
    command('resolution-bun',[BUN,R/'probes/resolution-proof.mjs'],guard=True)
    command('test-dependency-locks',[NODE,'node_modules/vitest/vitest.mjs','run','--config','../configs/locks.vitest.config.mjs','--configLoader','runner','--maxWorkers=1','--no-file-parallelism','--reporter=json','--outputFile=../evidence/dependency-locks-results.json'])
    # Readguard controls access only paths the guard must refuse before content reads.
    for host,exe in [('node',NODE),('bun',BUN)]:command('readguard-control-'+host,[exe,R/'probes/readguard-control.cjs'],guard=True)
    # Installed-payload negative controls, isolated from the accepted source tree.
    for case in ['missing','tampered','metadata']:
        base=R/'configs'/('declarations-'+case);base.mkdir()
        for name in ['@types/bun','@types/picomatch','bun-types']:
            p=base/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(R/'mirror/node_modules'/name,p)
        if case=='missing':(base/'@types/picomatch/index.d.ts').unlink()
        elif case=='tampered':
            p=base/'@types/picomatch/index.d.ts';p.chmod(0o644);p.write_bytes(p.read_bytes()+b'\n// independent negative-control tamper\n')
        else:
            p=base/'@types/bun/package.json';p.chmod(0o644);obj=load(p);obj['version']='0.0.0';save(p,obj)
        command('control-declarations-'+case,[PY,'-I',R/'probes/verify-owned.py',base],expected=1)
    for case in ['integrity','edge','metadata']:
        command('control-graph-'+case,[NODE,R/'probes/graph-review.mjs',case],expected=1)
    # Each source postimage is independently compared, not inferred from git's exit.
    hashes={n:sha(R/'mirror'/n) for n in src}
    changed=sorted(n for n in hashes if hashes[n]!=src[n]);assert changed==sorted(PRODUCT)
    assert all(hashes[n]==PRODUCT.get(n,src[n]) for n in src)
    save(R/'evidence/source-after.json',{'sourceCount':len(hashes),'changedProductPaths':changed,'sourceSha256':hashes})
    counts={};diags={};guards={}
    for phase,expectedCount in [('before',35),('after',31)]:
        for host in ['node','bun']:
            label=f'types-{host}-{phase}';text=(R/'logs'/f'{label}.stdout.log').read_text()
            ds=[s for s in text.splitlines() if re.search(r'error TS\d+:',s)];assert len(ds)==expectedCount
            counts[label]=len(ds);diags[label]=ds
            rows=[json.loads(s) for p in (R/'evidence').glob(label+'-compiler-reads-*.jsonl') for s in p.read_text().splitlines()]
            denied=[x for x in rows if x.get('allowed') is False];hosts=[x for x in rows if x.get('kind')=='compiler-host']
            assert len(denied)==2 and len(hosts)==1
            assert {x['lexical'] for x in denied}=={'/Users/shersingh/github/qmd-mlx-search/package.json','/Users/shersingh/github/qmd-mlx-search/src/mcp/server.ts'}
            assert hosts[0]['execPath']==(NODE if host=='node' else BUN)
            guards[label]={'denials':denied,'host':hosts[0],'readEvents':len(rows)-1}
    assert diags['types-node-before']==diags['types-bun-before'] and diags['types-node-after']==diags['types-bun-after']
    removed=sorted(set(diags['types-node-before'])-set(diags['types-node-after']));assert len(removed)==4
    assert not set(diags['types-node-after'])-set(diags['types-node-before'])
    assert all(s.startswith('scripts/phase5_e2e_runner.ts(') for s in diags['types-node-after'])
    rootsBefore=load(R/'logs/roots-node-before.stdout.log');rootsAfter=load(R/'logs/roots-node-after.stdout.log')
    assert rootsBefore==rootsAfter and len(rootsBefore['files'])==153
    assert len([n for n in rootsBefore['files'] if n.endswith('.mjs') and 'docs/reviews/' in n])==3
    tests=load(R/'evidence/dependency-locks-results.json');assert tests['success'] and tests['numPassedTests']==tests['numTotalTests']==5 and tests['numFailedTests']==tests['numPendingTests']==0
    save(R/'evidence/diagnostic-comparison.json',{'counts':counts,'removed':removed,'retained':diags['types-node-after'],'added':[],'guards':guards,'rootsAndOptionsIdentical':True,'roots':rootsBefore})
    save(R/'evidence/replay-acceptance.json',{'status':'SCOPED_REPLAY_PASS_NOT_WHOLE_ROOT','commands':steps,'sourceCount':251,'changedPaths':changed,'postimages':PRODUCT,'generatedCount':len(g1),'generatedBytesSizesModesUnchanged':True,'diagnosticCounts':counts,'strictExits':2,'roots':153,'denialsPerStrict':2,'lockTests':{'passed':5,'failed':0,'skipped':0}})
    print('SCOPED_REPLAY_PASS',flush=True)

def preserve():
    paths,_=public_paths();before=load(R/'evidence/protected-input-before.json');after={str(p):statrow(p) for p in paths};save(R/'evidence/protected-input-after.json',after)
    drift=[n for n in set(before)|set(after) if before.get(n)!=after.get(n)];assert not drift,('public input preservation',drift[:10])
    shared=snapshot(SHARED);save(R/'evidence/shared-after.json',shared);sb=load(R/'evidence/shared-before.json')
    d=[n for n in set(sb)|set(shared) if sb.get(n)!=shared.get(n)];assert not d,('shared dependency preservation',d[:10])
    cacheFiles={}
    for label in ['frozen-pnpm','frozen-bun','control-pnpm-stale','control-bun-stale']:
        caches=[R/'state'/label/'cache/pnpm-store',R/'state'/label/'cache/bun-store']
        found=[str(p.relative_to(R)) for q in caches for p in q.rglob('*') if p.is_file()];assert not found,(label,found)
        cacheFiles[label]=found
    save(R/'evidence/preservation.json',{'status':'PASS','protectedPublicPaths':len(paths),'publicBytesAndTrackedStatUnchanged':True,'sharedRows':len(shared),'sharedBytesAndTrackedStatUnchanged':True,'AGENTS.mdPolicy':'metadata only: no content read/hash','cacheFiles':cacheFiles,'scopedCacheClaimOnly':True})
    save(R/'evidence/spec-verdict.json',{'verdict':'PASS','scope':'T3 three-file declaration repair only; not final whole-root acceptance','findings':[],'provenance':'all three existing archived tarballs, hashes, SRI/SHA1/metadata/member inventories and 44 installed files verified','graph':'all preexisting package/snapshot/edge/integrity/direct metadata retained; exactly 3 new identities; 372 to 375 on both managers','replay':'real Node/Bun strict 35 to 31; retained runner31;153roots/options;2historical read refusals each;48generated bytes/size/modes unchanged','frozen':'real cold-cache pnpm and Bun positives0; valid stale controls1; scripts disabled; OS network/write sandbox','notClaimed':['current online vulnerabilities','Linux or Darwin Nix fixed-output hashes','final integrated whole checkout tests/CI','model/native/application install or runtime','integration/merge/publication']})
    print('SPEC_PASS_PRESERVATION_PASS',flush=True)

if __name__=='__main__':
    mode=sys.argv[1]
    try:
        if mode=='preflight':preflight()
        elif mode=='execute':execute()
        elif mode=='preserve':preserve()
        else:raise AssertionError('unknown mode')
    except BaseException as exc:
        save(R/'evidence'/('failure-'+mode+'.json'),{'phase':mode,'classification':'REVIEW_HARNESS_OR_ASSERTION_FAILURE_REQUIRES_TRIAGE','exception':repr(exc)})
        raise
