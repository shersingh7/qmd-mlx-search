"""Seal only reviewer-owned public evidence; retain external inputs readonly."""
from pathlib import Path
import json, hashlib, shutil, importlib.util, datetime
R=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('owned_review',R/'probes/review.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.load(R/'evidence/spec-verdict.json')['verdict']=='PASS'
assert m.load(R/'evidence/quality-verdict.json')['verdict']=='PASS'
paths,_=m.public_paths()
assert {str(p):m.statrow(p) for p in paths}==m.load(R/'evidence/protected-input-before.json')
shared=m.snapshot(m.SHARED)
assert shared==m.load(R/'evidence/shared-before.json')==m.load(R/'evidence/shared-after.json')
for f in ['types-bun-1.3.8.metadata.json','types-bun-1.3.8.members.json','bun-types-1.3.8.metadata.json','bun-types-1.3.8.members.json','types-picomatch.metadata.json','types-picomatch-4.0.3.members.json']:
    shutil.copy2(m.D/'reference'/f,R/'reference'/f)
shutil.copy2(m.D/'evidence/report-index.json',R/'reference/producer-report-index.json')
m.save(R/'evidence/final-preservation.json',{'status':'PASS','protectedPublicInputFiles':len(paths),'sharedInventoryRows':len(shared),'AGENTS.md':'one metadata-only exception, never opened or hashed','publicInputsAndSharedDependenciesUnchangedAfterQUALITY':True,'verificationScope':'bytes and tracked metadata; not access time'})
artifacts={}
for folder in ['probes','configs','reference','evidence','logs']:
    for p in sorted((R/folder).rglob('*')):
        if p==R/'evidence/review-index.json':continue
        assert not p.is_symlink(),p
        if p.is_file():artifacts[str(p.relative_to(R))]=m.sha(p)
for n in ['REPORT.md','REPRODUCE.md']:artifacts[n]=m.sha(R/n)
profiles={}
for p in sorted((R/'state').glob('*/offline.sb')):
    rel=str(p.relative_to(R));profiles[rel]=m.sha(p);artifacts[rel]=profiles[rel]
assert len(profiles)==33
sources=m.load(R/'evidence/source-after.json')['sourceSha256']
generated=m.load(R/'evidence/generated-after.json')
installed=m.load(R/'evidence/owned-installed-manifest.json')
for n,h in sources.items():assert m.sha(R/'mirror'/n)==h
for n,item in generated.items():assert m.sha(R/'mirror'/n)==item['sha256']
for n,item in installed.items():assert m.sha(R/'mirror/node_modules'/n)==item['sha256']
assert len(sources)==251 and len(generated)==48 and len(installed)==44
nm=R/'mirror/node_modules';assert nm.is_dir() and not nm.is_symlink()
for n in ['.vite','.vite-temp','.cache','.vitest']:assert (nm/n).is_dir() and not (nm/n).is_symlink()
index={'root':str(R),'timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'SPEC':'PASS','QUALITY':'PASS','productFindings':[],'artifactCount':len(artifacts),'artifactSha256':dict(sorted(artifacts.items())),'selfExcluded':'evidence/review-index.json','sourceManifests':{'before':'evidence/source-before.json','after':'evidence/source-after.json','count':251,'root':'mirror','changedPaths':sorted(m.PRODUCT)},'generatedManifests':{'before':'evidence/generated-before.json','after':'evidence/generated-after.json','count':48},'installedDeclarationManifest':{'path':'evidence/owned-installed-manifest.json','count':44,'root':'mirror/node_modules'},'packageReadUseAliases':{'path':'evidence/mirror-package-aliases.json','count':274,'ownedNodeModulesRoot':True,'ownedCaches':['.vite','.vite-temp','.cache','.vitest']},'sandboxProfilesSha256':profiles,'commandSummary':'evidence/command-summary.json','rawCommandCount':33,'excludedOperationalPrefixes':['state (except bound offline.sb profiles)','outer','mirror (explicit source/generated/declaration/alias manifests instead)'],'producerDelivery':{'root':str(m.D),'index':'evidence/report-index.json','indexSha256':m.INDEX,'authenticatedArtifactCount':263,'patch':'evidence/declarations.patch','patchSha256':m.PATCH},'predecessor':{'root':str(m.I),'indexSha256':'104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac','sourceCount':251},'publicPreservation':'evidence/final-preservation.json','notWholeRootAcceptance':True,'parentGates':['Integrated whole-checkout canonical build/check/tests and CI','Fresh online dependency advisory/alert audit','Actual Linux/Darwin Nix dependency hashes','Integration/merge/publication']}
m.save(R/'evidence/review-index.json',index)
# Validate the finished machine index, with exact declared/enumerated totals.
assert len(index['artifactSha256'])==index['artifactCount']
for rel,h in index['artifactSha256'].items():assert m.sha(R/rel)==h,rel
print(json.dumps({'status':'SPEC_PASS_QUALITY_PASS_INDEPENDENT_REVIEW_SEALED','root':str(R),'report':str(R/'REPORT.md'),'reportSha256':m.sha(R/'REPORT.md'),'artifactIndex':str(R/'evidence/review-index.json'),'artifactIndexSha256':m.sha(R/'evidence/review-index.json'),'artifactCount':index['artifactCount'],'specVerdictSha256':m.sha(R/'evidence/spec-verdict.json'),'qualityVerdictSha256':m.sha(R/'evidence/quality-verdict.json'),'commandCount':33,'sourceCount':len(sources),'generatedCount':len(generated),'installedDeclarationFileCount':len(installed),'protectedPublicInputFileCount':len(paths),'sharedInventoryRows':len(shared),'productFindings':[]},indent=2))
