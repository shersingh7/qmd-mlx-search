"""Verify only declared, genuine, already materialized declaration bytes."""
from pathlib import Path
import sys, json, hashlib, stat
R=Path(__file__).resolve().parents[1]
base=Path(sys.argv[1]).resolve()
assert base.is_relative_to(R)
manifest=json.loads((R/'evidence/owned-installed-manifest.json').read_text())
assert len(manifest)==44
names=['@types/bun','@types/picomatch','bun-types']
found=set()
for name in names:
    pkg=base/name
    assert pkg.is_dir() and not pkg.is_symlink()
    for p in pkg.rglob('*'):
        assert not p.is_symlink() and (p.is_file() or p.is_dir())
        if p.is_file():
            assert p.name!='AGENTS.md'
            key=str(p.relative_to(base));found.add(key)
            assert key in manifest,('unexpected payload',key)
            assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest[key]['sha256'],('payload identity/hash',key)
            assert p.stat().st_size==manifest[key]['size'],('payload size',key)
assert found==set(manifest),('missing payload',sorted(set(manifest)-found))
for name,version,deps in [('@types/bun','1.3.8',{'bun-types':'1.3.8'}),('bun-types','1.3.8',{'@types/node':'*'}),('@types/picomatch','4.0.3',{})]:
    pkg=json.loads((base/name/'package.json').read_text())
    assert pkg['name']==name and pkg['version']==version and pkg.get('dependencies',{})==deps
    assert (base/name/pkg['types']).is_file()
print(json.dumps({'status':'PASS','fileCount':len(found),'root':str(base)}))
