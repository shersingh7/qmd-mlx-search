const assert=require('node:assert/strict');
const fs=require('node:fs');
const net=require('node:net');
const target=process.argv[2];
let writeCode;
try{fs.writeFileSync(target,'sandbox write control');}catch(e){writeCode=e.code;}
assert.equal(writeCode,'EPERM','sandbox must deny write to owned path outside its allowlist');
assert.equal(fs.existsSync(target),false);
const socket=new net.Socket();
socket.once('error',e=>{
  assert.equal(e.code,'EPERM','sandbox must deny network, not simply find a closed port');
  console.log(JSON.stringify({status:'PASS',writeDenied:writeCode,networkDenied:e.code,target,execPath:process.execPath,versions:process.versions}));
});
socket.connect({host:'127.0.0.1',port:9});
