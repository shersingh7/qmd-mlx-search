import picomatch = require("./lib/picomatch");

export = picomatch;

// independent negative-control tamper
