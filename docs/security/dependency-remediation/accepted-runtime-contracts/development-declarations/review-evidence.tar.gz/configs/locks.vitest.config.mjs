import path from 'node:path';
const root=process.env.QMD_DECLARATIONS_ROOT;
export default {
  root:path.join(root,'mirror'),
  cacheDir:process.env.VITE_CACHE_DIR,
  test:{
    include:['test/dependency-locks.test.ts'],
    setupFiles:[],
    globalSetup:[],
    pool:'threads',
    maxWorkers:1,
    fileParallelism:false,
    isolate:true,
    watch:false,
    cache:false,
  },
};
