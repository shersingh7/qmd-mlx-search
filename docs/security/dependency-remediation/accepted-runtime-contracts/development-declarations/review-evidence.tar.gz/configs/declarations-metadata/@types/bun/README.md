# Installation
> `npm install --save @types/bun`

# Summary
This package contains type definitions for bun (https://bun.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bun.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bun/index.d.ts)
````ts
/// <reference types="bun-types" />

````

### Additional Details
 * Last updated: Thu, 29 Jan 2026 20:42:40 GMT
 * Dependencies: [bun-types](https://npmjs.com/package/bun-types)

# Credits
These definitions were written by [Jarred Sumner](https://github.com/Jarred-Sumner), [Robobun](https://github.com/robobun), [Dylan Conway](https://github.com/dylan-conway), [Ciro Spaciari](https://github.com/cirospaciari), [Sosuke Suzuki](https://github.com/sosukesuzuki), and [Alistair Smith](https://github.com/alii).
