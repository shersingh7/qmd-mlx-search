"""Test-only transport: the verbatim controller's owner launches only owned Python fakes."""
from pathlib import Path
import json
import os
import platform
import select
import signal
import subprocess
import sys

cfg_path = Path(sys.argv[1])
cfg = json.loads(cfg_path.read_text())
owned = sys.argv[2]
code = sys.stdin.read()

platform.system = lambda: cfg.get('host_os', 'Linux')
platform.machine = lambda: cfg.get('host_arch', 'x86_64')
original_popen = subprocess.Popen
hits = []

def fixture_popen(argv, **kwargs):
    assert argv[:4] == [sys.executable, '-I', '-B', '-S'], argv
    assert Path(argv[4]) == Path(owned) / 'command-owner.py'
    assert kwargs['start_new_session'] is True
    assert kwargs['pass_fds'] == (int(argv[5]), int(argv[6]))
    original = argv[8:]
    assert original[0] in ('docker', 'git'), original
    adapted = list(argv[:8])
    if original[0] == 'docker' and 'run' in original and cfg.get('probe_timeout'):
        # Relocate the old fake's 0.3s timeout at the new active boundary;
        # retain the controller's original start, never a fresh 0.3s on receipt.
        adapted[7] = str(float(adapted[7]) - 180 + 0.3)
    fake = cfg_path.parent.parent.parent / 'fake_cli.py'
    assert fake.is_file() and fake.is_relative_to(Path(__file__).parent)
    hits.append({'original': original, 'owner_deadline': float(adapted[7])})
    (cfg_path.parent / 'transport-hits.json').write_text(json.dumps(hits) + '\n')
    return original_popen(adapted + [sys.executable, '-I', '-B', '-S', str(fake), str(cfg_path), *original], **kwargs)

subprocess.Popen = fixture_popen
original_select = select.select
signal_requested = False
def fixture_select(read, write, error, timeout=None):
    global signal_requested
    if cfg.get('probe_signal') and not signal_requested and (cfg_path.parent / 'signal-request').exists():
        signal_requested = True
        signal.raise_signal(signal.SIGTERM)
    return original_select(read, write, error, timeout)
select.select = fixture_select
sys.argv = ['-', owned]
exec(compile(code, '<verbatim-workflow-controller>', 'exec'), {'__name__': '__main__'})
