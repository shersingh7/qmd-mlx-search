from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).parent
ORIGINAL = Path('/Users/shersingh/.hermes/cache/scratch/qmd-gguf-workflow-ffsshvav')
REVIEW = Path('/Users/shersingh/.hermes/cache/scratch/qmd-workflow-review.k6XUMg0e')
SHA = lambda raw: hashlib.sha256(raw).hexdigest()

def authenticate(root, manifest, expected_sha, count):
    raw = (root / manifest).read_bytes()
    assert SHA(raw) == expected_sha
    data = json.loads(raw)
    seen = set()
    for item in data['files']:
        relative = Path(item['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        assert relative.as_posix() not in seen
        seen.add(relative.as_posix())
        path = root / relative
        assert not path.is_symlink()
        body = path.read_bytes()
        assert len(body) == item['bytes'] and SHA(body) == item['sha256'], str(path)
    assert len(seen) == count
    destination = ROOT / 'original' / root.name
    destination.mkdir(parents=True)
    shutil.copyfile(root / manifest, destination / manifest.replace('/', '-'))
    return {'root': str(root), 'manifest': manifest, 'sha256': SHA(raw), 'verified_unique_files': len(seen)}

records = [
    authenticate(ORIGINAL, 'delivery/manifest.json', 'e84773ff3b1a44694df7fd55d2a1305486185a2f8ee8c41aed0bb0d17f2f1dfe', 518),
    authenticate(REVIEW, 'review-manifest.json', '64c57cf940312afa6a630bef76fbbeb6256c10913bd27f78e1263c5eb721ef12', 267),
]
assert SHA((REVIEW / 'review-result.json').read_bytes()) == '624159cf2c039dabab145556b3f0d90657e553552efe980f0c129b04e7490394'
workflow = ORIGINAL / 'mirror/.github/workflows/gguf-native-image-qualification.yml'
assert SHA(workflow.read_bytes()) == 'a384be7b604411d9a41b15568dd9d37324632416d3fe7c2346b06f3f7d60b306'
launcher = ORIGINAL / 'mirror/finetune/tools/submit_locked_job.py'
assert SHA(launcher.read_bytes()) == 'f61076c5a71e5b251db42aadb1bbe15fb1689a2d3293f1085edcdefc1958a83b'
assert SHA((ORIGINAL / 'delivery/proposal.patch').read_bytes()) == 'dd03de5b3075b9a39b0bf2d4ff7cd03199ac34881dbb4d0cf009a0b6251d042c'

def copy(root, destination, paths):
    for relative in paths:
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / relative, target)

source_paths = [
    'mirror/.github/workflows/gguf-native-image-qualification.yml',
    'mirror/finetune/tools/submit_locked_job.py',
    'mirror/finetune/tools/qualify_gguf_image.py',
]
evidence_paths = ['evidence/' + name for name in (
    'control_flow_tests.py', 'fixture_adapter.py', 'fake_cli.py', 'validate_workflow.py',
    'generated-step.bash', 'generated-controller.py')]
for name in ('baseline-supplied', 'baseline-heldout', 'final-supplied', 'final-heldout'):
    target = ROOT / name
    copy(ORIGINAL, target, source_paths + evidence_paths)
    for directory in ('home', 'hermes', 'knowledge', 'cache', 'config', 'data', 'hf', 'tmp'):
        (target / directory).mkdir()
    if name.endswith('heldout'):
        copy(REVIEW, target, ['heldout/' + part for part in ('heldout_tests.py', 'fake_cli.py', 'fixture_adapter.py', 'descendant_worker.py')])

copy(ORIGINAL, ROOT / 'original', source_paths + evidence_paths + ['REPORT.md', 'PLAN.md', 'delivery/proposal.patch'])
copy(REVIEW, ROOT / 'original/review', ['REPORT.md', 'review-result.json', 'heldout/heldout_tests.py', 'heldout/fake_cli.py', 'heldout/fixture_adapter.py', 'heldout/descendant_worker.py', 'heldout/summary.json'])
copy(ORIGINAL, ROOT / 'candidate', source_paths)
(ROOT / 'evidence').mkdir()
(ROOT / 'delivery').mkdir()
(ROOT / 'evidence/authentication.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
