"""SPEC gate only: aggregate independently observed receipts and identities."""
from pathlib import Path
from collections import Counter
import ast
import copy
import hashlib
import json
import os
import re
import stat
ROOT=Path(__file__).parent
F=ROOT/'inputs/source'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
expected={'supplied':(74,74,0,0),'positive':(34,34,0,0),'characterization':(34,33,1,1)}
suites=[]
transport=[]
for mode,(count,passed,failed,errors) in expected.items():
    base=ROOT/mode/('evidence/synthetic-independent' if mode=='supplied' else 'heldout/cases')
    summary=load(ROOT/mode/('evidence/synthetic-independent/summary.json' if mode=='supplied' else 'heldout/summary.json'))
    execution=load(ROOT/'evidence'/(mode+'-execution.json'))
    assert (summary['cases'],summary['passed'],summary['failed'])==(count,passed,failed)
    assert sum('fixture_error' in r for r in summary['results'])==errors
    assert len(summary['results'])==count and summary['skipped']==0
    assert execution['raw_exit']==(1 if mode=='characterization' else 0)
    checked=[]
    for case in sorted(base.iterdir()):
        if not stat.S_ISDIR(case.lstat().st_mode):continue
        calls=[json.loads(line) for line in (case/'calls.jsonl').read_text().splitlines()]
        hits=load(case/'transport-hits.json')
        assert [row['argv'] for row in calls]==[row['original'] for row in hits]
        assert load(case/'independent-environment-transport.json')['controller_body_unchanged']
        for row in calls:
            env=row['environment']
            assert env['PATH']==str(ROOT/'denied') and env['UV_OFFLINE']=='1'
            for key in ('HOME','HERMES_HOME','HERMES_DIR','HERMES_KNOWLEDGE_DIR','KNOWLEDGE_DIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME','TMPDIR','HF_HOME','DOCKER_CONFIG'):
                assert Path(env[key]).is_relative_to(case)
            assert env['HF_HUB_OFFLINE']==env['TRANSFORMERS_OFFLINE']==env['HF_DATASETS_OFFLINE']=='1'
            assert not {'GITHUB_TOKEN','DOCKER_HOST','DOCKER_CONTEXT','DOCKER_AUTH_CONFIG','PYTHONPATH','NODE_OPTIONS'} & set(env)
        checked.append({'case':case.name,'fake_hits':len(hits)})
    assert len(checked)==count
    transport.append({'suite':mode,'cases_checked':len(checked),'all_cli_hits_matched':True,'rows':checked})
    suites.append({'suite':mode,'raw_exit':execution['raw_exit'],'cases':count,'passed':passed,'failed':failed,'fixture_errors':errors,'skipped':0,'actual_exit_rows':sum('actual_exit' in r for r in summary['results']),'actual_nonzero_rows':sum(r.get('actual_exit',0)!=0 for r in summary['results']),'positive_rows':sum(r.get('actual_exit')==0 for r in summary['results']),'summary':str(ROOT/mode/('evidence/synthetic-independent/summary.json' if mode=='supplied' else 'heldout/summary.json'))})
    if mode=='characterization':
        red=[r for r in summary['results'] if not r['passed']]
        assert len(red)==1 and red[0]['case']=='timeout-group-descendant' and 'failed to terminate naturally' in red[0]['fixture_error']
        # It failed only in the old completion oracle after a real 124 receipt.
        case=base/'timeout-group-descendant'
        rs=[json.loads(l)['qualification_receipt'] for l in (case/'stdout.log').read_text().splitlines() if 'qualification_receipt' in json.loads(l)]
        assert len(rs)==1 and rs[0]['final_exit']==124 and rs[0]['status']=='not-qualified'

permanent=load(ROOT/'evidence/permanent-final-execution.json')
assert permanent['raw_exit']==0 and re.search(r'Ran 26 tests ',permanent['stderr'])
assert len(re.findall(r'\.\.\. ok\n',permanent['stderr']))==26 and 'skipped' not in permanent['stderr']
permanent_life=[]
for case in sorted((ROOT/'permanent/cases-final').iterdir()):
    if not stat.S_ISDIR(case.lstat().st_mode):continue
    audit=load(case/'transport.json')
    calls=[json.loads(line)['argv'] for line in (case/'calls.jsonl').read_text().splitlines()]
    starts=[r['start'] for r in audit if 'start' in r]
    cfg=load(case/'config.json')
    assert calls==(starts[:-1] if cfg.get('admission_delay') else starts)
    if (case/'observation.json').is_file():
        snap=load(case/'return-state.json'); obs=load(case/'observation.json')
        assert not snap['late_at_return'] and snap['sentinel_alive_at_return'] and snap['sentinel_ready_at_return'] and not snap['fixture_cleanup_started']
        assert obs['no_late_work'] and obs['worker_terminated'] and obs['sentinel_exit']==0 and obs['observation_seconds']>=3.0
        permanent_life.append({'case':case.name,'worker_terminated_at_return':snap['terminated_at_return'],'observed_seconds':obs['observation_seconds'],'sentinel_raw_exit':obs['sentinel_exit'],'fixture_cleanup_started':False})
assert len(permanent_life)==7
held=load(ROOT/'independent-heldouts/summary.json')
assert (held['cases'],held['passed'],held['failed'],held['fixture_errors'],held['skipped'])==(20,20,0,0,0)
assert all(not r['fixture_cleanup_killed_controller'] for r in held['results'])
assert load(ROOT/'evidence/independent-heldout-execution.json')['raw_exit']==0
assert load(ROOT/'evidence/validation.json')['all_passed']

# Compare the whole heldout AST after excluding only the authorized S3 setup /
# positive oracle and the corrected controller-hash literal, not just asserts.
old=(F/'original/review/heldout/heldout_tests.py').read_text()
positive=(F/'verified-heldout-positive/heldout/heldout_tests.py').read_text()
class AllowedDelta(ast.NodeTransformer):
    def __init__(self):self.removed=0
    def visit_If(self,n):
        test=n.test
        if isinstance(test,ast.Call) and isinstance(test.func,ast.Attribute) and isinstance(test.func.value,ast.Name) and test.func.value.id=='cfg' and test.func.attr=='get' and len(test.args)==1 and isinstance(test.args[0],ast.Constant) and test.args[0].value=='descendant_on_timeout':
            self.removed+=1; return None
        return self.generic_visit(n)
    def visit_Constant(self,n):
        if n.value=='b0cc257ab4ede6c2e6ea9e887e4a4e5747edea9ba43d5ed52a86f19590606df4':return ast.Constant(value='80444b357af0fe1e53675f9441d8a9400d66d687224c170bf5cdb2de3ce2540c')
        return n
oldnorm,newnorm=AllowedDelta(),AllowedDelta()
a=oldnorm.visit(ast.parse(old)); b=newnorm.visit(ast.parse(positive))
assert (oldnorm.removed,newnorm.removed)==(1,2)
assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
assert (F/'original/evidence/control_flow_tests.py').read_bytes()==(F/'verified-supplied/evidence/control_flow_tests.py').read_bytes()
oldworker=(F/'original/review/heldout/descendant_worker.py').read_text()
newworker=(F/'verified-heldout-positive/heldout/descendant_worker.py').read_text()
assert newworker==oldworker.replace('started = time.monotonic()',"fd = os.open(root / 'lifetime.fifo', os.O_WRONLY)\nos.write(fd, b'alive')\nstarted = time.monotonic()")
oldfake=(F/'original/evidence/fake_cli.py').read_text()
newfake=(F/'verified-supplied/evidence/fake_cli.py').read_text()
assert newfake==oldfake.replace('os.kill(os.getppid(), signal.SIGTERM)',"(root / 'signal-request').write_text('request controller self-signal')")
oldfake=(F/'original/review/heldout/fake_cli.py').read_text()
newfake=(F/'verified-heldout-positive/heldout/fake_cli.py').read_text()
assert newfake==oldfake.replace('str(root), str(os.getpid())','str(root), str(os.getpgrp())')

# Preserve all authenticated input bytes, not a mutable live-tree fingerprint.
before=load(ROOT/'evidence/source-inputs-before.json')
after=[]
for row in before:
    path=Path(row['path']); info=path.lstat(); assert stat.S_ISREG(info.st_mode)
    for parent in path.parents:assert stat.S_ISDIR(parent.lstat().st_mode)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as stream:
        assert stat.S_ISREG(os.fstat(stream.fileno()).st_mode); raw=stream.read()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],str(path)
    after.append(dict(row))
dump(ROOT/'evidence/source-inputs-after.json',after)
m=load(ROOT/'inputs/delivery-manifest.json')
specials=[]
for row in m['special_fixtures']:
    path=Path(m['root'])/row['path']; info=path.lstat()
    assert stat.S_IFMT(info.st_mode)==row['mode']
    specials.append({'path':str(path),'mode':stat.S_IFMT(info.st_mode),'opened_or_followed':False})
assert len(specials)==47
# Every owned immutable copy used for runtime was still source-identical.
for rel in ('.github/workflows/gguf-native-image-qualification.yml','test/security/test_gguf_workflow_controller.py','test/security/fixtures/gguf_workflow_fake_cli.py','finetune/tools/submit_locked_job.py','finetune/tools/qualify_gguf_image.py'):
    assert (ROOT/'permanent/mirror'/rel).read_bytes()==(F/'candidate/mirror'/rel).read_bytes()
for mode,origin in [('supplied','verified-supplied'),('positive','verified-heldout-positive'),('characterization','verified-heldout-characterization')]:
    for rel in ('mirror/.github/workflows/gguf-native-image-qualification.yml','mirror/finetune/tools/submit_locked_job.py','mirror/finetune/tools/qualify_gguf_image.py','evidence/fixture_adapter.py','evidence/fake_cli.py'):
        assert (ROOT/mode/rel).read_bytes()==(F/origin/rel).read_bytes()

result={'SPEC':'PASS','blocking_findings':[],'sources':m['merge_paths'],'suites':suites,'permanent':{'cases':26,'passed':26,'raw_exit':0,'fixture_errors':0,'skipped':0,'summary':str(ROOT/'evidence/permanent-final-execution.json')},'independent_edges':{'cases':20,'passed':20,'raw_exit':0,'fixture_errors':0,'skipped':0,'summary':str(ROOT/'independent-heldouts/summary.json')},'transport':transport,'permanent_lifecycle':permanent_life,'preservation':{'source_hash_records_unchanged':len(after),'delivery_regular_files':12170,'original_regular_files':518,'original_review_regular_files':267,'special_metadata_only':specials},'original_oracles':{'74_runner_byte_identical':True,'34_CASES_preserved':True,'nonS3_whole_AST_preserved_except_hash':True,'positive_worker_only_FD_witness_added':True,'original_characterization_left_red':True},'development_first':{'initial_test_source_not_separately_archived':True,'retained_states_support_three_new_oracle_corrections':True,'final_assertions_inspected_at_lines':[195,202,292,299],'not_original_assertion_weakening':True},'own_initial_fixture_error':{'raw_exit':1,'cases':26,'passed':19,'fixture_failures':7,'cause':'Reviewer outer allowlist omitted the exact fake.py --sentinel entrypoint; stopped before each sentinel process creation','product_source_changed':False,'retained':str(ROOT/'evidence/permanent-execution.json'),'fresh_corrected_run':str(ROOT/'evidence/permanent-final-execution.json')},'limitations':['Synthetic only; not Linux/image/container/native/CI qualification','Same-group KILL plus anchor reap is not all-descendant reap','Escaped groups, sole-owner descheduling/death, runner hardkill outside unconditional guarantee','Abrupt controller death has raw -9 and no qualification receipt; worker/anchor FD closure observed, not controller anchor reap'],'QUALITY':'NOT_STARTED'}
dump(ROOT/'evidence/spec-verdict.json',result)
print(json.dumps({'SPEC':result['SPEC'],'suites':[{k:v for k,v in r.items() if k not in ('summary',)} for r in suites],'permanent':result['permanent'],'independent_edges':result['independent_edges'],'unchanged_input_records':len(after),'specials_metadata_only':len(specials),'QUALITY':'NOT_STARTED'},indent=2))
