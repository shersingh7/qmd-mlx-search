"""QUALITY gate after SPEC; assemble read-only review report and manifests."""
from pathlib import Path
import ast
import hashlib
import json
import os
import stat
import zipfile
ROOT=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
spec_path=ROOT/'evidence/spec-verdict.json'
spec=load(spec_path)
assert spec['SPEC']=='PASS' and spec['QUALITY']=='NOT_STARTED'
spec_sha=sha(spec_path.read_bytes())
source=ROOT/'inputs/source/candidate/mirror'
paths=['.github/workflows/gguf-native-image-qualification.yml','test/security/test_gguf_workflow_controller.py','test/security/fixtures/gguf_workflow_fake_cli.py']
# Quality checks use the exact reviewed tree, after the SPEC artifact exists.
workflow=(source/paths[0]).read_text()
script='\n'.join(line[10:] if line else '' for line in workflow.split('        run: |\n',1)[1].splitlines())+'\n'
body=script.split("<<'PY'\n",1)[1].rsplit('\nPY\n',1)[0]
tree=ast.parse(body)
owner=next(n.value.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='owner_program' for t in n.targets))
owner_ast=ast.parse(owner)
imports={a.name.split('.')[0] for n in ast.walk(owner_ast) if isinstance(n,ast.Import) for a in n.names}
assert imports=={'json','os','select','signal','subprocess','sys','time'}
assert owner.count('subprocess.Popen(')==1 and owner.count('os.killpg(')==1
assert body.count('child.wait(')==1 and body.count('os.killpg(child.pid')==1
assert 'child.poll(' not in body and 'shell=True' not in body
assert body.index('os.killpg(child.pid')<body.index('child.wait(')
assert body.index('os.replace(temporary_receipt')<body.index("print(json.dumps({'qualification_receipt'")
assert workflow.split('          sparse-checkout: |\n',1)[1].split('      - name:',1)[0].splitlines()==['            /finetune/tools/qualify_gguf_image.py','            /finetune/tools/submit_locked_job.py']
checks=[
 {'area':'cohesive ownership model','path':paths[0],'lines':'125-250','result':'PASS','basis':'One call-owned stdlib session/group anchor; exact sole group signal is before sole anchor wait, no controller poll, private command result/control pipes, same executable absolute deadline.'},
 {'area':'failure composition and publication','path':paths[0],'lines':'282-290, 370-417','result':'PASS','basis':'Nonthrowing first-signal handler, primary failure retained, command/container cleanup tracked separately, exclusive temporary publication precedes sole final receipt log.'},
 {'area':'selection scope and dependency closure','path':paths[0],'lines':'17-25, 306-326','result':'PASS','basis':'Two public sparse sources remain; no new checkout dependency or second image pin; AST scanner is conservative for direct bindings without executing launcher.'},
 {'area':'portable regression observability','path':paths[1],'lines':'53-132, 173-343, 346-365','result':'PASS','basis':'26 named tests, exact controller hash and per-CLI hit assertions; wait/signal guards and actual lifetime FD witnesses, raw/process/public exit distinction, explicit diagnostic seams and no native claims.'},
 {'area':'synthetic fixture boundaries','path':paths[2],'lines':'11-30, 36-44, 67-109','result':'PASS','basis':'No real CLI invocation; bounded same-group TERM-resistant worker and independent naturally draining sentinel; malformed destinations fail closed.'},
]
quality={'QUALITY':'PASS','SPEC_prerequisite':{'verdict':'PASS','artifact':str(spec_path),'sha256':spec_sha,'read_before_quality_checks':True},'blocking_findings':[],'nonblocking_findings':[],'checks':checks,'scope':'Focused three-file review, not whole-repository integration or real image qualification.'}
dump(ROOT/'evidence/quality-verdict.json',quality)

source_manifest=[]
for rel in paths:
    raw=(source/rel).read_bytes()
    source_manifest.append({'path':rel,'delivery_source':str(Path('/Users/shersingh/.hermes/cache/scratch/qmd-gguf-w1-repair.WDt8LlYR/candidate/mirror')/rel),'sha256':sha(raw),'bytes':len(raw),'lines':len(raw.splitlines())})
for rel,digest in [('delivery/workflow-repair.patch','db0e846e4d8f06a538815a8d9a765462772f90dccf3253698dbc205df94edd88'),('delivery/unintegrated-new-files.patch','ba2463a0f8417134b85ebe51b001a1b29b29208c8881a1943f44239f03aee932')]:
    raw=(ROOT/'inputs/source'/rel).read_bytes();assert sha(raw)==digest
source_doc={'reviewed_files':source_manifest,'repair_baseline':spec['sources'],'actual_live_preimages':'All three ABSENT is parent-provided context, not a live-tree read by this reviewer. Empty-tree new-file patch replay passed independently.','accepted_public_static_inputs':{'launcher_sha256':'f61076c5a71e5b251db42aadb1bbe15fb1689a2d3293f1085edcdefc1958a83b','probe_sha256':'292f01cedb9f2b61f3dce87baba3680749f72ea32566953f937146f09a0114d2','imported_or_executed':False},'source_before':str(ROOT/'evidence/source-inputs-before.json'),'source_after':str(ROOT/'evidence/source-inputs-after.json'),'unchanged_hash_records':spec['preservation']['source_hash_records_unchanged']}
dump(ROOT/'source-manifest.json',source_doc)

archive_baseline=load(ROOT/'inputs/source/baseline-safe-heldout/heldout/summary.json')
assert (archive_baseline['cases'],archive_baseline['passed'],archive_baseline['failed'],archive_baseline['fixture_errors'])==(34,30,4,0)
assert {r['case'] for r in archive_baseline['results'] if not r['passed']}=={'ast-match-direct-capture','ast-match-mapping-capture','receipt-write-failure','timeout-group-descendant'}
# The archived first three corrected assertions are corroborated by actual
# failure states. No unsupported claim that an initial test-source snapshot exists.
first=load(ROOT/'evidence/development-first-artifact-audit.json')
failed_first=[r for r in first if r['case'] in ('test_startup_consumes_original_budget','test_timeout_descendant','test_timeout_with_failed_docker_cleanup')]
assert len(failed_first)==3
assert all(r['final_exit']==124 and r['lifetime']['anchor_reaped'] and not r['lifetime']['signal_delivered'] and 'PermissionError' in r['lifetime']['error'] for r in failed_first)
assert all(r['worker_at_return'] for r in failed_first if not r['admission_delay'])

lines=[
 '# Independent W1 GGUF workflow review',
 '',
 '**SPEC: PASS. QUALITY: PASS (started only after the recorded SPEC pass).**',
 'No blocking or nonblocking code findings in the exact three-file repair. This is offline controller/test acceptance only; parent integration and real native Linux amd64 image/CI qualification remain gates.',
 '',
 '## Observed executions — distinct runs, not summed',
 '',
 '| Execution | Raw runner exit | Cases | Passed | Failed / fixture errors |',
 '|---|---:|---:|---:|---:|',
 '| Preserved supplied suite | 0 | 74 | 74 | 0 / 0 |',
 '| Authorized positive heldouts | 0 | 34 | 34 | 0 / 0 |',
 '| Permanent unittest discovery | 0 | 26 | 26 | 0 / 0 |',
 '| New bounded independent edges | 0 | 20 | 20 | 0 / 0 |',
 '| Original S3 characterization | 1 | 34 | 33 | 1 / 1 |',
 '',
 'All primary passing runs have zero skips. The 74-case suite includes eight actual zero-exit positive controls and 66 refusals/failures; the 34-case positive-contract suite includes seven zero-exit controls and 27 nonzero cases. Every admitted CLI has a matching fake hit. Original characterization still fails only because it requires the killed worker’s normal-completion marker; its actual S3 controller receipt is 124/not-qualified. It was not relabeled green.',
 '',
 '## SPEC conclusions and concrete witnesses',
 '',
 '| Contract / source lines | Result | Independent witness |',
 '|---|---|---|',
 '| S1 — workflow 306–326 | PASS | MatchAs, MatchStar, MatchMapping.rest refused before Docker, including nested/OR/class/unused-function edges; unrelated patterns, actual launcher and replacement digest controls pass. Single literal selection is not a proof of arbitrary Python immutability. |',
 '| S2 — workflow 87–89, 205–208, 238–240, 387–417 | PASS | Actual required-directory storage failure never logs qualified, preserves raw -2 → public 130 and primary failure; exclusive mkstemp collisions avoid symlink/hardlink alias damage; successful required-path replacement leaves alias targets unchanged. Diagnostic create/replace/unlink failures remain nonqualified with explicit errors, no concealed deletion. |',
 '| S3 — workflow 125–250, 282–290 | PASS | Unreaped anchor signal-before-wait guards; same-group TERM-resistant worker termination, early CLI success/failure, INT/TERM during registration, registration held beyond deadline, helper startup expiry with no fake admission, actual exec failure, early anchor exit and controller SIGKILL/EOF. No post-reap/recycled-PGID signal. |',
 '',
 'Seven permanent, one preserved-positive and four new independent lifecycle runs retain return-time snapshots before fixture cleanup and observe the original three-second post-return window without late work. Worker lifetime FDs close; unrelated sentinels are alive at return and naturally exit 0. Normal cases record anchor reap. Abrupt controller death is raw -9 with no qualification receipt; independent anchor FD closure proves termination, **not** controller reap. The permanent abrupt snapshot initially observes a live worker, then EOF revocation closes its FD within the observation window; no instant-death claim is made.',
 '',
 'Actual Python is 3.12.13 on Darwin/arm64. A same-executable child monotonic sample falls between parent samples; helper/controller use that executable and original absolute deadlines. Startup/transport delays consume rather than restart the synthetic budget. Redundant Darwin EPERM is explicit nonqualification, not fabricated signal delivery.',
 '',
 'Preserved positive/refusal controls exercise source and checkout/head/context identity, exact JSON/digest membership, host/runner/daemon/image architecture gates, bounded no-follow snapshot, empty Docker credentials and explicit Unix endpoint, container hardening, full probe/no native-only bypass, JSON-safe logging, full CID + label ownership and successful absence readback, primary-vs-cleanup failures. Current accepted launcher/probe hashes are statically compatible; the additional accepted-probe-data positive binds the current 292f01ce… bytes without executing/importing them.',
 '',
 '## Assertion / oracle / transport preservation',
 '',
 '- All 74 runner bytes are identical to the authenticated original. All 34 CASES AST entries are identical. After excluding only the authorized S3 fixture setup/oracle and corrected source-hash literal, the **whole heldout AST** is unchanged, not merely selected assertions.',
 '- Positive S3 worker differs only by a held lifetime FD; the original two-second side-effect code remains unchanged. No completion marker or timestamp was invented. Fake transports move only the active CLI boundary, preserve helper argv/session/fds and original deadlines, and fail closed without Docker/git fallback.',
 '- The three W1 development-oracle corrections were checked against retained actual states: no CLI hit after expired admission, and truthful nonqualification for two already-self-KILLed/EPERM paths. Final assertions retain worker FD, anchor reap, sentinel and no-late-work requirements. The initial full test source was not separately archived, so no literal before/after hash claim is made for that development version.',
 '- Review-only environment transport narrows shell bootstrap PATH to env/mktemp/mkdir, inner Python PATH to an empty owned directory, supplements explicit Hermes aliases and UV_OFFLINE=1 before imports, and leaves controller bytes unchanged. Synthetic polluted outer values remain in the credential-stripping controls. No inherited real credentials/context are forwarded or printed.',
 '',
 '## QUALITY after SPEC',
 '',
 'PASS: cohesive single-owner design, stdlib-only generated helper, no third sparse source/dependency, explicit lifetime limits, separate CLI/anchor/public statuses, fail-closed cleanup/persistence composition, and named source-bound regressions. Reviewed workflow 125–250/282–290/387–417, test 53–132/173–343/346–365, fake 11–30/36–44/67–109. No implementation changes requested.',
 '',
 '## Identity, syntax and scope',
 '',
 '- All 12,170 delivery regular files, 518 original-delivery files and 267 original-review files reauthenticated before and after. All 12,962 input-hash records remain unchanged, including the accepted public inputs and supplied actionlint. The 47 source special fixtures were lstat-only, never opened/followed/copied.',
 '- Both the repair-baseline patch and all-new-files integration patch independently pass actual git apply --check and apply in separate fresh nonrepository trees; each yields exact candidate bytes for all three files. Baseline workflow preimage is not confused with parent-declared absent live preimages.',
 '- Python controller/helper/test/fake compile, Bash -n, and authenticated actionlint 1.7.12 pass. Shellcheck/pyflakes are explicitly disabled. No Docker/daemon/registry/network/qualifier/launcher/compiler/converter/model/GPU/cloud/CI execution, live edits, installation, staging/commit/push or skills writes occurred.',
 '- Group KILL plus anchor reap does not certify all descendant reap. Escaped groups, sole-owner descheduling/death, runner hardkill/loss and uninterruptible work are not unconditional guarantees. No real image, container lifecycle, Linux native or combined-integration acceptance is inferred.',
 '',
 '## Reviewer fixture issues retained, not product failures',
 '',
 'The superseded executable path ending python3.12.13 failed with raw 127 before any Python execution; the user erratum supplied the actual bin/python. My first permanent replay had 19/26 passing and seven reviewer allowlist failures before sentinel creation (fake.py --sentinel was omitted). Those raw artifacts remain; only the reviewer transport allowlist changed, with an exact fixture hash/argv guard. A fresh case root then passed 26/26 with unchanged product bytes. Neither run is folded into the primary passing counts.',
 '',
 '## Evidence / replay handles',
 '',
 f'- SPEC decision: `{spec_path}`',
 f'- QUALITY decision: `{ROOT/"evidence/quality-verdict.json"}`',
 f'- Source identities: `{ROOT/"source-manifest.json"}`',
 f'- Primary raw executions: `{ROOT/"evidence/supplied-execution.json"}`, `{ROOT/"evidence/positive-execution.json"}`, `{ROOT/"evidence/permanent-final-execution.json"}`, `{ROOT/"evidence/independent-heldout-execution.json"}`',
 f'- New edge configurations, syscall/ownership audits, raw logs, snapshots: `{ROOT/"independent-heldouts"}`',
 f'- Syntax / real patch replay results: `{ROOT/"evidence/validation.json"}`',
 f'- Clock proof: `{ROOT/"evidence/clock-domain.json"}`',
 f'- Whole-AST oracle delta: `{ROOT/"evidence/positive-oracle.diff"}`',
 f'- Archived W1 first-oracle state audit: `{ROOT/"evidence/development-first-artifact-audit.json"}`',
 '',
 'Actual replay commands were run with run-isolated.sh (clean allowlist before Python imports), run_replays.py, and independent_heldouts.py under this fresh owned root. Reproduce in a **new** qmd-w1-independent-* root using the recorded source hashes and copied regular input closure, not in this evidence root or the original deliveries; the fresh-create guards deliberately reject overwriting evidence. Scripts/configs plus per-execution literal argv are included in the archive.',
 '',
 'Reusable review lesson (recorded here only; skill writes out of scope): preserve the unreaped ownership anchor through the final signal, distinguish prevention oracles from killed-worker completion characterizations, and publish required persistence before success.',
]
(ROOT/'REPORT.md').write_text('\n'.join(lines)+'\n')
result={'SPEC':'PASS','QUALITY':'PASS','findings':[],'root':str(ROOT),'report':str(ROOT/'REPORT.md'),'source_manifest':str(ROOT/'source-manifest.json'),'spec_sha256':spec_sha,'quality_sha256':sha((ROOT/'evidence/quality-verdict.json').read_bytes()),'source_hashes':source_manifest,'primary_runs':[{'suite':'permanent','cases':26,'passed':26,'raw_exit':0},{'suite':'supplied','cases':74,'passed':74,'raw_exit':0},{'suite':'positive','cases':34,'passed':34,'raw_exit':0},{'suite':'independent-heldouts','cases':20,'passed':20,'raw_exit':0}],'characterization':{'cases':34,'passed':33,'fixture_errors':1,'raw_exit':1},'native_docker_CI_execution':False,'live_edits':False}
dump(ROOT/'review-result.json',result)
# Own artifact manifest excludes itself/archive to avoid a circular hash. Never
# follows symlinks or opens FIFOs, including intentional fixture aliases.
files=[]; special=[]
for directory,dirs,names in os.walk(ROOT,followlinks=False):
    base=Path(directory)
    for name in list(dirs):
        p=base/name; info=p.lstat()
        if not stat.S_ISDIR(info.st_mode):
            dirs.remove(name); special.append({'path':str(p.relative_to(ROOT)),'mode':stat.S_IFMT(info.st_mode),'opened_or_followed':False})
    for name in names:
        p=base/name; rel=p.relative_to(ROOT).as_posix()
        if rel in ('review-manifest.json','review-bundle.zip','bundle.json'):continue
        info=p.lstat()
        if stat.S_ISREG(info.st_mode):
            raw=p.read_bytes();files.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
        else:special.append({'path':rel,'mode':stat.S_IFMT(info.st_mode),'opened_or_followed':False})
files.sort(key=lambda r:r['path']);special.sort(key=lambda r:r['path'])
dump(ROOT/'review-manifest.json',{'root':str(ROOT),'SPEC':'PASS','QUALITY':'PASS','regular_file_count':len(files),'files':files,'specials_metadata_only':special})
archive=ROOT/'review-bundle.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for row in files:
        p=ROOT/row['path']; assert stat.S_ISREG(p.lstat().st_mode)
        raw=p.read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes'];z.writestr(row['path'],raw)
    z.writestr('review-manifest.json',(ROOT/'review-manifest.json').read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist())==len(files)+1
bundle={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'entries':len(files)+1,'only_regular_artifacts_archived':True,'review_manifest':str(ROOT/'review-manifest.json'),'review_manifest_sha256':sha((ROOT/'review-manifest.json').read_bytes()),'report':str(ROOT/'REPORT.md'),'report_sha256':sha((ROOT/'REPORT.md').read_bytes()),'result':str(ROOT/'review-result.json')}
dump(ROOT/'bundle.json',bundle)
print(json.dumps({'SPEC':'PASS','QUALITY':'PASS','findings':[],'bundle':bundle,'regular_artifacts':len(files),'metadata_only_specials':len(special)},indent=2))
