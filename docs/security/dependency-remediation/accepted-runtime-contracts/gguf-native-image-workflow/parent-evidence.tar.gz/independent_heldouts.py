"""Bounded independent SPEC edges, not additional production implementation."""
from pathlib import Path
import ast
import hashlib
import json
import os
import select
import signal
import stat
import subprocess
import sys
import time

ROOT=Path(__file__).parent
BASE=ROOT/'independent-heldouts'
BASE.mkdir()
DRIVER=ROOT/'independent_driver.py'
CURRENT=ROOT/'inputs/current-public-inputs/finetune/tools'
ALIAS={'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes','HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge','XDG_CACHE_HOME':'cache','XDG_CONFIG_HOME':'config','XDG_DATA_HOME':'data','HF_HOME':'hf','TMPDIR':'tmp'}
def clean_env(base):
    env={'PATH':str(ROOT/'denied'),'PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','QMD_LLAMA_GPU':'false','CUDA_VISIBLE_DEVICES':''}
    for key,leaf in ALIAS.items():
        path=base/leaf; path.mkdir(parents=True,exist_ok=True); env[key]=str(path)
    return env

def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
# Establish shared clock domain using the actual selected interpreter, not an
# API-name inference or a fabricated target-platform timestamp.
before=time.monotonic()
clock=subprocess.run([sys.executable,'-I','-B','-S','-c','import json,sys,time,platform; print(json.dumps({"monotonic":time.monotonic(),"executable":sys.executable,"version":sys.version,"host":platform.system()+"/"+platform.machine(),"clock":vars(time.get_clock_info("monotonic"))}))'],cwd=ROOT,env=clean_env(ROOT/'clock-env'),capture_output=True,text=True,timeout=5)
after=time.monotonic(); sample=json.loads(clock.stdout)
assert clock.returncode==0 and before<=sample['monotonic']<=after and sample['executable']==sys.executable
assert sys.version_info>=(3,10)
dump(ROOT/'evidence/clock-domain.json',{'parent_before':before,'child':sample,'parent_after':after,'same_executable':True,'same_host_observed':True,'cross_process_interval_proven':True,'not_a_Linux_qualification':True})

CASES=[
 ('binding-class-or-capture',1,{'pattern':'C(GGUF_IMAGE) | [GGUF_IMAGE]','refused':True}),
 ('binding-nested-or-mapping-rest',1,{'pattern':'[{"x": _, **GGUF_IMAGE}] | {"y": GGUF_IMAGE}','refused':True}),
 ('binding-middle-star',1,{'pattern':'(head, *GGUF_IMAGE, tail)','refused':True}),
 ('binding-unused-async-match',1,{'pattern':'(_ as GGUF_IMAGE)','refused':True,'async_nested':True}),
 ('binding-harmless-literal-or',0,{'pattern':'("GGUF_IMAGE" | "other") as harmless','refused':False}),
 ('binding-harmless-attribute-value',0,{'pattern':'Namespace.GGUF_IMAGE','refused':False}),
 ('receipt-required-symlink-no-follow',0,{'required_alias':'symlink'}),
 ('receipt-required-hardlink-no-truncate',0,{'required_alias':'hardlink'}),
 ('receipt-exclusive-collision-ownership',0,{'temp_collisions':True}),
 ('receipt-create-failure-keeps-primary',37,{'mkstemp_failure':True,'probe_exit':37}),
 ('receipt-real-directory-failure-raw-SIGINT',130,{'storage_failure':True,'raw_signal':True,'raw_interrupt':True}),
 ('receipt-replace-and-temp-cleanup-failures',1,{'replace_failure':True,'temporary_cleanup_failure':True}),
 ('lifetime-registration-return-past-original-deadline',124,{'descendant':True,'short_budget':0.35,'registration_hold':0.65,'lifetime':True}),
 ('lifetime-INT-before-registration-first-signal',130,{'descendant':True,'short_budget':0.9,'registration_hold':0.2,'interrupt_before_registration':True,'lifetime':True}),
 ('lifetime-early-CLI-exit-group-still-anchored',0,{'descendant':True,'early_exit':True,'short_budget':0.7,'lifetime':True}),
 ('lifetime-abrupt-EOF-after-early-CLI-exit',-signal.SIGKILL,{'descendant':True,'early_exit':True,'short_budget':1.8,'hold_result_for_abrupt':True,'anchor_witness':True,'lifetime':True,'abrupt':True}),
 ('deadline-helper-startup-consumes-original-budget',124,{'short_budget':0.2,'helper_startup_delay':0.4,'no_probe_hit':True}),
 ('ownership-actual-helper-exec-failure',1,{'actual_spawn_failure':True,'no_probe_hit':True}),
 ('ownership-anchor-exits-before-result-unreaped-signal',1,{'owner_exits_without_result':True,'no_probe_hit':True}),
 ('positive-accepted-full-probe-interface-data',0,{'accepted_probe':True}),
]

rows=[]
for name,expected,base_cfg in CASES:
    case=BASE/name; case.mkdir()
    cfg=dict(base_cfg)
    env=clean_env(case)
    tools=case/'workspace/finetune/tools'; tools.mkdir(parents=True)
    launcher=(CURRENT/'submit_locked_job.py').read_bytes()
    if 'pattern' in cfg:
        snippet='match None:\n    case '+cfg['pattern']+':\n        pass\n'
        if cfg.get('async_nested'):
            snippet='async def harmless_uninvoked():\n'+''.join('    '+line+'\n' for line in snippet.splitlines())
        launcher+=b'\n'+snippet.encode()
        ast.parse(launcher)  # Data-only syntax check. Never exec launcher bytes.
    (tools/'submit_locked_job.py').write_bytes(launcher)
    probe=(CURRENT/'qualify_gguf_image.py').read_bytes() if cfg.get('accepted_probe') else b'# Independent synthetic probe data; never imported or executed.\n'
    (tools/'qualify_gguf_image.py').write_bytes(probe)
    owned=case/'owned'; owned.mkdir(); (owned/'docker').mkdir()
    if cfg.get('required_alias') or cfg.get('temp_collisions') or cfg.get('replace_failure'):
        alias_target=case/'alias-target'; alias_target.write_bytes(b'independent unchanged alias evidence\n')
        if cfg.get('required_alias')=='symlink':(owned/'receipt.json').symlink_to(alias_target)
        if cfg.get('required_alias')=='hardlink':os.link(alias_target,owned/'receipt.json')
        if cfg.get('temp_collisions'):
            (owned/'receipt.preseed-symlink').symlink_to(alias_target)
            os.link(alias_target,owned/'receipt.preseed-hardlink')
        if cfg.get('replace_failure'):(owned/'receipt.json').write_bytes(b'preexisting required evidence\n')
    cfg['workspace']=str(tools.parent.parent); dump(case/'config.json',cfg)
    env.update(QMD_WORKSPACE=cfg['workspace'],QMD_EVENT='pull_request',QMD_CONTEXT_SHA='3'*40,QMD_EVENT_HEAD_SHA='2'*40,QMD_RUNNER_OS='Linux',QMD_RUNNER_ARCH='X64',QMD_RUNNER_NAME='INDEPENDENT SYNTHETIC')
    readers=[]; sentinel=None; child=None; fixture_cleanup=False
    try:
        if cfg.get('lifetime'):
            os.mkfifo(case/'lifetime.fifo'); worker_fd=os.open(case/'lifetime.fifo',os.O_RDONLY|os.O_NONBLOCK); readers.append(worker_fd)
            if cfg.get('anchor_witness'):
                os.mkfifo(case/'anchor.fifo'); anchor_fd=os.open(case/'anchor.fifo',os.O_RDONLY|os.O_NONBLOCK); readers.append(anchor_fd)
            sentinel=subprocess.Popen([sys.executable,'-I','-B','-S',str(DRIVER),'--sentinel',str(case)],env=clean_env(case/'sentinel-env'),cwd=case,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        command=[sys.executable,'-I','-B','-S',str(DRIVER),'--driver',str(case)]
        child=subprocess.Popen(command,env=env,cwd=case,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        if cfg.get('abrupt'):
            until=time.monotonic()+2.0
            while not (case/'controller-held').exists():
                assert time.monotonic()<until,'fixture did not reach early-result hold'; time.sleep(0.005)
            child.kill()  # The exact owned controller handle, not a sampled PID.
        stdout,stderr=child.communicate(timeout=12)
        returned=time.monotonic(); raw_exit=child.returncode
        (case/'stdout.log').write_text(stdout); (case/'stderr.log').write_text(stderr)
        records=[json.loads(line) for line in stdout.splitlines()]
        finals=[r['qualification_receipt'] for r in records if 'qualification_receipt' in r]
        assert raw_exit==expected,(raw_exit,expected,stderr)
        if cfg.get('abrupt'):
            assert not finals,'abrupt death must not claim qualification'
            receipt=None
        else:
            assert len(finals)==1
            receipt=finals[0]
            assert receipt['final_exit']==raw_exit
            assert (receipt['status']=='qualified-native-amd64-prerequisites')==(raw_exit==0)
            assert stderr=='',stderr
            if receipt['receipt_persistence']['status']=='written':
                assert json.loads((owned/'receipt.json').read_text())==receipt
            if cfg.get('storage_failure'):
                assert (owned/'receipt.json').is_dir() and receipt['receipt_persistence']['status']=='failed'
                assert receipt['primary_exit']==130
                pc=next(r for r in receipt['commands'] if r['name']=='probe')
                assert pc['command_exit']==-signal.SIGINT and pc['exit']==130
            if cfg.get('mkstemp_failure'):
                assert receipt['primary_exit']==37 and receipt['receipt_persistence']['status']=='failed'
            if cfg.get('replace_failure'):
                assert receipt['primary_exit']==0 and receipt['receipt_persistence']['status']=='failed'
                assert 'temporary_cleanup_error' in receipt['receipt_persistence']
                assert (owned/'receipt.json').read_bytes()==b'preexisting required evidence\n'
                assert len([p for p in owned.iterdir() if p.name.startswith('receipt.') and p.name!='receipt.json'])==1
            if cfg.get('required_alias'):
                assert stat.S_ISREG((owned/'receipt.json').lstat().st_mode)
                assert (owned/'receipt.json').stat().st_nlink==1
            if cfg.get('refused'):
                assert 'ambiguous/missing' in receipt['error']
        audit=json.loads((case/'independent-audit.json').read_text())
        calls=[json.loads(s)['argv'] for s in (case/'calls.jsonl').read_text().splitlines()]
        starts=[r['start'] for r in audit if 'start' in r]
        if cfg.get('no_probe_hit'):
            assert starts[:-1]==calls and starts[-1][0]=='docker' and starts[-1][5]=='run'
        else:assert starts==calls,'every admitted CLI must hit the fake exactly'
        if cfg.get('refused'):assert all(c[0]!='docker' for c in calls),'binding refusal before Docker'
        if cfg.get('accepted_probe'):
            assert receipt['sources']['probe_sha256']==hashlib.sha256(probe).hexdigest()=='292f01cedb9f2b61f3dce87baba3680749f72ea32566953f937146f09a0114d2'
            assert receipt['probe_receipt']['native_only'] is False
        if cfg.get('required_alias') or cfg.get('temp_collisions') or cfg.get('replace_failure'):
            assert (case/'alias-target').read_bytes()==b'independent unchanged alias evidence\n'
        if cfg.get('temp_collisions'):
            attempts=[r for r in audit if 'receipt_open' in r]
            assert len(attempts)==3 and all(r['exclusive'] and r['create'] for r in attempts)
            assert (owned/'receipt.preseed-symlink').is_symlink()
            assert (owned/'receipt.preseed-hardlink').stat().st_ino==(case/'alias-target').stat().st_ino
        details={'fake_hit_count':len(calls),'controller_start_count':len(starts),'source_sha256':audit[0]['controller_sha256'],'receipt_exit':receipt['final_exit'] if receipt else None}
        if cfg.get('lifetime'):
            ready=json.loads((case/'ready.json').read_text())
            anchor=next(r['anchor'] for r in audit if 'anchor' in r and 'original' in r and r['original'][0]=='docker' and r['original'][5]=='run')
            assert ready['pgid']==anchor and ready['pid']!=anchor and ready['leader_pid']!=anchor
            assert os.read(worker_fd,1024)==b'alive'
            def closed(fd):
                try:return os.read(fd,1)==b''
                except BlockingIOError:return False
            terminated=closed(worker_fd)
            anchor_terminated=None
            if cfg.get('anchor_witness'):
                assert os.read(anchor_fd,1024)==b'anchor-alive'
                anchor_terminated=closed(anchor_fd)
            snap={'returned':returned,'raw_exit':raw_exit,'worker_terminated_at_return':terminated,'anchor_terminated_at_return':anchor_terminated,'late_at_return':(case/'late.json').exists(),'sentinel_ready':(case/'sentinel-ready').exists(),'sentinel_alive':sentinel.poll() is None,'fixture_cleanup_started':False,'ready':ready,'anchor':anchor}
            dump(case/'return-state.json',snap)
            assert not snap['late_at_return'] and snap['sentinel_ready'] and snap['sentinel_alive']
            until=returned+3.0
            while time.monotonic()<until:
                assert not (case/'late.json').exists(),'late owned worker work'
                terminated=terminated or closed(worker_fd)
                if cfg.get('anchor_witness'):anchor_terminated=anchor_terminated or closed(anchor_fd)
                time.sleep(0.02)
            assert terminated,'worker lifetime FD stayed open'
            if cfg.get('anchor_witness'):assert anchor_terminated,'anchor lifetime FD stayed open after EOF'
            if receipt:
                pc=next(r for r in receipt['commands'] if r['name']=='probe')
                assert pc['lifetime']['anchor_reaped']
                if not (pc['lifetime']['signal_delivered'] or pc['lifetime'].get('group_absent_at_signal')):
                    assert 'error' in pc['lifetime'] and not receipt['command_cleanup_ok'] and raw_exit!=0
                assert pc['lifetime']['descendant_reap_certified'] is False
                if raw_exit==0:assert snap['worker_terminated_at_return']
            sentinel.wait(timeout=3)
            assert sentinel.returncode==0 and (case/'sentinel-finished').read_text()=='natural'
            observation={'worker_fd_closed':terminated,'anchor_fd_closed':anchor_terminated,'no_late_work':True,'observed_seconds':time.monotonic()-returned,'sentinel_raw_exit':sentinel.returncode,'fixture_cleanup_started':False,'anchor_reaped':pc['lifetime']['anchor_reaped'] if receipt else None,'all_descendant_reap_claimed':False}
            dump(case/'observation.json',observation); details.update(return_state=snap,observation=observation)
        row={'case':name,'passed':True,'expected_raw_exit':expected,'actual_raw_exit':raw_exit,'details':details,'synthetic_only':True,'fixture_error':None}
    except Exception as exc:
        row={'case':name,'passed':False,'fixture_error':type(exc).__name__+': '+str(exc),'synthetic_only':True}
    finally:
        if child is not None and child.returncode is None:
            fixture_cleanup=True; child.kill(); child.communicate(timeout=5)
        if sentinel is not None and sentinel.returncode is None:sentinel.wait(timeout=6)
        for fd in readers:os.close(fd)
    row['fixture_cleanup_killed_controller']=fixture_cleanup
    rows.append(row); dump(case/'result.json',row)
    with (BASE/'results.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
    print(json.dumps({'case':name,'passed':row['passed'],'raw_exit':row.get('actual_raw_exit'),'fixture_error':row.get('fixture_error')}),flush=True)
summary={'cases':len(rows),'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'fixture_errors':sum(bool(r.get('fixture_error')) for r in rows),'skipped':0,'results':rows,'synthetic_only':True,'native_docker_CI_execution':False}
dump(BASE/'summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
raise SystemExit(0 if summary['failed']==0 else 1)
