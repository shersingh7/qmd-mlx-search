"""Parent-owned, clean-environment replay of the integrated 26-case suite."""
from pathlib import Path
import json
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/shersingh/github/qmd-mlx-search')
state = root / 'integrated-environment'
state.mkdir()
env = {'PATH': '/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1',
       'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
       'HF_DATASETS_OFFLINE': '1', 'UV_OFFLINE': '1',
       'QMD_LLAMA_GPU': 'false', 'CUDA_VISIBLE_DEVICES': '',
       'GGUF_TEST_ARTIFACTS': str(root / 'integrated-cases')}
for key, leaf in {
    'HOME': 'home', 'HERMES_HOME': 'hermes', 'HERMES_DIR': 'hermes',
    'HERMES_KNOWLEDGE_DIR': 'knowledge', 'KNOWLEDGE_DIR': 'knowledge',
    'XDG_CACHE_HOME': 'cache', 'XDG_CONFIG_HOME': 'config',
    'XDG_DATA_HOME': 'data', 'HF_HOME': 'hf', 'TMPDIR': 'tmp',
}.items():
    target = state / leaf
    target.mkdir(parents=True, exist_ok=True)
    env[key] = str(target)
command = [sys.executable, '-I', '-B', '-S', '-m', 'unittest', 'discover',
           '-s', 'test/security', '-p', 'test_gguf_workflow_controller.py', '-v']
result = subprocess.run(command, cwd=repo, env=env, capture_output=True,
                        text=True, timeout=180)
record = {'argv': command, 'cwd': str(repo), 'environment': env,
          'exitCode': result.returncode, 'stdout': result.stdout,
          'stderr': result.stderr}
match = re.search(r'Ran (\d+) tests in ([\d.]+)s', result.stderr)
if match:
    record.update(tests=int(match[1]), seconds=float(match[2]),
                  passed=len(re.findall(r'\.\.\. ok\n', result.stderr)),
                  failures=len(re.findall(r'\.\.\. FAIL\n', result.stderr)),
                  errors=len(re.findall(r'\.\.\. ERROR\n', result.stderr)))
(root / 'evidence/integrated-execution.json').write_text(
    json.dumps(record, indent=2) + '\n')
print(result.stderr)
print(json.dumps({key: value for key, value in record.items()
                  if key not in ('stdout', 'stderr', 'environment')}, indent=2))
raise SystemExit(result.returncode)
