import json, os, select, signal, subprocess, sys, time
control, result = map(int, sys.argv[1:3])
deadline = float(sys.argv[3])
assert os.getpid() == os.getpgrp()
def send(value):
    os.write(result, json.dumps(value).encode() + b'\n')
def revoked(delay):
    return bool(select.select([control], [], [], delay)[0]) and not os.read(control, 1)
try:
    if time.monotonic() >= deadline:
        send({'timeout': True})
    elif not revoked(0):
        try:
            command = subprocess.Popen(sys.argv[4:], close_fds=True)
        except Exception as exc:
            send({'error': type(exc).__name__ + ': ' + str(exc)})
        else:
            sent = False
            while time.monotonic() < deadline:
                code = command.poll()
                if code is not None and not sent:
                    send({'command_exit': code})
                    sent = True
                if revoked(min(0.02, max(0, deadline - time.monotonic()))):
                    break
            else:
                if not sent:
                    send({'timeout': True})
finally:
    # Still executing as the owned group leader: no recycled-ID window.
    os.killpg(os.getpid(), signal.SIGKILL)
