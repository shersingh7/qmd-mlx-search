"""Independent test-only transport; executes verbatim workflow/helper, fake CLI only."""
from pathlib import Path
import ast
import errno
import hashlib
import itertools
import json
import os
import platform
import runpy
import select
import signal
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).parent
SOURCE=ROOT/'inputs/source/candidate/mirror/.github/workflows/gguf-native-image-qualification.yml'
FAKE=ROOT/'inputs/source/candidate/mirror/test/security/fixtures/gguf_workflow_fake_cli.py'

def dump(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')

if sys.argv[1]=='--fake':
    case=Path(sys.argv[2]); cfg=json.loads((case/'config.json').read_text())
    if cfg.get('raw_interrupt'):
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        real_raise=signal.raise_signal
        signal.raise_signal=lambda sig: real_raise(signal.SIGINT if sig==signal.SIGTERM else sig)
    sys.argv=[str(FAKE),str(case/'config.json'),*sys.argv[3:]]
    runpy.run_path(str(FAKE),run_name='__main__')
elif sys.argv[1]=='--owner':
    case=Path(sys.argv[2]); target=Path(sys.argv[3]); args=sys.argv[4:]
    cfg=json.loads((case/'config.json').read_text())
    # Same interpreter/host, same original absolute deadline. Wrapper is a
    # declared diagnostic start delay/lifetime witness, not a source edit.
    fd=None
    if cfg.get('anchor_witness'):
        fd=os.open(case/'anchor.fifo',os.O_WRONLY)
        os.write(fd,b'anchor-alive')
    dump(case/'owner-clock.json',{'executable':sys.executable,'monotonic':time.monotonic(),'deadline':float(args[2]),'clock':vars(time.get_clock_info('monotonic')),'source_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
    if cfg.get('helper_startup_delay'):
        time.sleep(cfg['helper_startup_delay'])
    if cfg.get('owner_exits_without_result'):
        raise SystemExit(42)
    sys.argv=[str(target),*args]
    runpy.run_path(str(target),run_name='__main__')
elif sys.argv[1]=='--sentinel':
    case=Path(sys.argv[2]); (case/'sentinel-ready').write_text('ready')
    time.sleep(4.0); (case/'sentinel-finished').write_text('natural')
else:
    assert sys.argv[1]=='--driver'
    case=Path(sys.argv[2]); cfg=json.loads((case/'config.json').read_text())
    script='\n'.join(line[10:] if line else '' for line in SOURCE.read_text().split('        run: |\n',1)[1].splitlines())+'\n'
    body=script.split("<<'PY'\n",1)[1].rsplit('\nPY\n',1)[0]
    assert hashlib.sha256(body.encode()).hexdigest()=='80444b357af0fe1e53675f9441d8a9400d66d687224c170bf5cdb2de3ce2540c'
    platform.system=lambda:'Linux'; platform.machine=lambda:'x86_64'
    actual_popen,actual_kill,actual_select=subprocess.Popen,os.killpg,select.select
    actual_open,actual_replace,actual_unlink=os.open,os.replace,os.unlink
    audit=[]; owned={}; signaled=set(); reaped=set(); held=False
    def save(event):
        audit.append(event); dump(case/'independent-audit.json',audit)
    def transport(argv,**kwargs):
        assert argv[:4]==[sys.executable,'-I','-B','-S']
        assert Path(argv[4])==case/'owned/command-owner.py'
        assert kwargs['start_new_session'] is True
        assert kwargs['pass_fds']==(int(argv[5]),int(argv[6]))
        original=argv[8:]; assert original[0] in ('git','docker')
        probe=original[0]=='docker' and original[5]=='run'
        adapted=list(argv[:8]); start=time.monotonic()
        if probe and 'short_budget' in cfg:
            adapted[7]=str(float(adapted[7])-180+cfg['short_budget'])
        fake=[sys.executable,'-I','-B','-S',str(Path(__file__).resolve()),'--fake',str(case),*original]
        full=adapted+fake
        if probe and (cfg.get('helper_startup_delay') or cfg.get('anchor_witness') or cfg.get('owner_exits_without_result')):
            full=adapted[:4]+[str(Path(__file__).resolve()),'--owner',str(case),str(adapted[4]),*adapted[5:],*fake]
        if probe and cfg.get('actual_spawn_failure'):
            full[0]=str(case/'nonexistent-owned-interpreter')
        save({'start':original,'raw_deadline':float(argv[7]),'effective_deadline':float(adapted[7]),'before_spawn':start,'same_executable':full[0]==sys.executable})
        try:
            child=actual_popen(full,**kwargs)
        except OSError as exc:
            save({'spawn_error':type(exc).__name__,'original':original,'cli_admitted':False})
            raise
        owned[child.pid]=probe
        save({'anchor':child.pid,'original':original,'registered_transport':time.monotonic()})
        wait=child.wait
        def guarded_wait(timeout=None):
            assert child.pid in signaled and child.pid not in reaped
            value=wait(timeout=timeout); reaped.add(child.pid)
            save({'reaped':child.pid,'raw_exit':value,'at':time.monotonic()})
            return value
        child.wait=guarded_wait
        child.poll=lambda:(_ for _ in ()).throw(AssertionError('anchor polled before final signal'))
        if probe and cfg.get('registration_hold'):
            until=time.monotonic()+1.0
            while not (case/'ready.json').exists():
                assert time.monotonic()<until; time.sleep(0.005)
            if cfg.get('interrupt_before_registration'):
                signal.raise_signal(signal.SIGINT); signal.raise_signal(signal.SIGTERM)
            save({'registration_hold_start':time.monotonic(),'anchor':child.pid})
            time.sleep(cfg['registration_hold'])
            if cfg.get('interrupt_before_registration'):
                signal.raise_signal(signal.SIGTERM)
            save({'registration_hold_end':time.monotonic(),'anchor':child.pid})
        return child
    def group_signal(pgid,sig):
        assert pgid in owned and pgid not in reaped and pgid not in signaled and sig==signal.SIGKILL
        signaled.add(pgid); save({'final_signal_attempt':pgid,'at':time.monotonic(),'already_reaped':False})
        try:
            value=actual_kill(pgid,sig)
        except OSError as exc:
            save({'signal_error':type(exc).__name__,'anchor':pgid,'errno':exc.errno}); raise
        save({'signal_delivered':pgid,'at':time.monotonic()}); return value
    def waiting(read,write,error,timeout=None):
        global held
        if cfg.get('hold_result_for_abrupt') and not held and (case/'ready.json').exists():
            held=True; (case/'controller-held').write_text('real controller held with early CLI result pending')
            time.sleep(2.0)
        return actual_select(read,write,error,timeout)
    def opening(path,flags,*args,**kwargs):
        if isinstance(path,(str,bytes,os.PathLike)) and Path(path).parent==case/'owned' and Path(path).name.startswith('receipt.'):
            save({'receipt_open':str(path),'flags':flags,'exclusive':bool(flags&os.O_EXCL),'create':bool(flags&os.O_CREAT)})
        return actual_open(path,flags,*args,**kwargs)
    def replacing(source,destination,*args,**kwargs):
        if Path(destination)==case/'owned/receipt.json':
            save({'receipt_replace':str(source),'destination':str(destination),'source_is_symlink':Path(source).is_symlink()})
            if cfg.get('replace_failure'):
                raise PermissionError(errno.EACCES,'SYNTHETIC diagnostic replace failure')
        return actual_replace(source,destination,*args,**kwargs)
    def unlinking(path,*args,**kwargs):
        if cfg.get('temporary_cleanup_failure') and Path(path).parent==case/'owned' and Path(path).name.startswith('receipt.') and Path(path).name!='receipt.json':
            save({'temporary_cleanup_failure':str(path)}); raise PermissionError(errno.EACCES,'SYNTHETIC diagnostic unlink failure')
        return actual_unlink(path,*args,**kwargs)
    if cfg.get('temp_collisions'):
        candidate_names=tempfile._get_candidate_names()
        names=itertools.chain(['preseed-symlink','preseed-hardlink'],candidate_names)
        tempfile._get_candidate_names=lambda:names
    if cfg.get('mkstemp_failure'):
        def failed_mkstemp(*args,**kwargs):
            save({'mkstemp_failure':'SYNTHETIC ENOSPC diagnostic'}); raise OSError(errno.ENOSPC,'SYNTHETIC diagnostic create failure')
        tempfile.mkstemp=failed_mkstemp
    subprocess.Popen,os.killpg,select.select=transport,group_signal,waiting
    os.open,os.replace,os.unlink=opening,replacing,unlinking
    sys.argv=['-',str(case/'owned')]
    save({'controller_sha256':hashlib.sha256(body.encode()).hexdigest(),'executable':sys.executable,'clock':vars(time.get_clock_info('monotonic'))})
    exec(compile(body,str(SOURCE)+':inline','exec'),{'__name__':'__main__'})
