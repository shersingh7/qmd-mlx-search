GGUF_IMAGE = 'ghcr.io/astral-sh/uv:0.11.18-python3.12-trixie@sha256:c8fe61165767c52118d7d3e67db5d0be5454c2e0da1f9fe15c697ebdd72f304e'

match 'ghcr.io/astral-sh/uv:0.11.18-python3.12-trixie@sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd':
    case GGUF_IMAGE:
        pass
