from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil

root = Path(__file__).parent
frozen = root / 'original'
workflow = root / 'candidate/mirror/.github/workflows/gguf-native-image-qualification.yml'
raw = workflow.read_bytes()
block = raw.decode().split('        run: |\n', 1)[1]
script = '\n'.join(line[10:] if line else '' for line in block.splitlines()) + '\n'
controller = script.split("<<'PY'\n", 1)[1].rsplit('\nPY\n', 1)[0]
sha = lambda text: hashlib.sha256(text).hexdigest()
compile(controller, '<candidate-controller>', 'exec')
helper = next(node.value.value for node in ast.parse(controller).body if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'owner_program' for t in node.targets))
compile(helper, '<candidate-owner>', 'exec')
changes = []
for name, heldout in [('verified-supplied', False), ('verified-heldout-characterization', True), ('verified-heldout-positive', True)]:
    work = root / name
    work.mkdir()
    for directory in ('home','hermes','knowledge','cache','config','data','hf','tmp','evidence'):
        (work / directory).mkdir()
    for rel in ('mirror/finetune/tools/submit_locked_job.py','mirror/finetune/tools/qualify_gguf_image.py',
                'evidence/control_flow_tests.py','evidence/validate_workflow.py','evidence/fake_cli.py'):
        target = work / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(frozen / rel, target)
    target = work / 'mirror/.github/workflows/gguf-native-image-qualification.yml'
    target.parent.mkdir(parents=True)
    target.write_bytes(raw)
    (work / 'evidence/generated-step.bash').write_text(script)
    (work / 'evidence/generated-controller.py').write_text(controller + '\n')
    shutil.copyfile(root / 'transport_adapter.py', work / 'evidence/fixture_adapter.py')
    if heldout:
        (work / 'heldout').mkdir()
        for name_part in ('heldout_tests.py', 'fake_cli.py', 'descendant_worker.py'):
            shutil.copyfile(frozen / 'review/heldout' / name_part, work / 'heldout' / name_part)
        path = work / 'heldout/heldout_tests.py'
        before = path.read_text()
        after = before.replace('b0cc257ab4ede6c2e6ea9e887e4a4e5747edea9ba43d5ed52a86f19590606df4', sha(controller.encode()))
        if name.endswith('positive'):
            after = after.replace("    result = subprocess.run(['/bin/bash'", """    if cfg.get('descendant_on_timeout'):
        os.mkfifo(case / 'lifetime.fifo')
        lifetime_read = os.open(case / 'lifetime.fifo', os.O_RDONLY | os.O_NONBLOCK)
        sentinel_source = case / 'sentinel.py'
        sentinel_source.write_text("from pathlib import Path\\nimport sys,time\\nroot=Path(sys.argv[1])\\n(root/'sentinel-ready').write_text('ready')\\ntime.sleep(4)\\n(root/'sentinel-finished').write_text('natural')\\n")
        sentinel_env = {'PATH':'/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE':'1'}
        for key, leaf in {'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes',
                          'HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge',
                          'XDG_CACHE_HOME':'cache','XDG_CONFIG_HOME':'config','XDG_DATA_HOME':'data',
                          'HF_HOME':'hf','TMPDIR':'tmp'}.items():
            directory = case / 'sentinel-env' / leaf
            directory.mkdir(parents=True, exist_ok=True)
            sentinel_env[key] = str(directory)
        sentinel = subprocess.Popen([PYTHON, '-I', '-B', '-S', str(sentinel_source), str(case)],
                                    env=sentinel_env, cwd=case, start_new_session=True)
    result = subprocess.run(['/bin/bash'""")
            old_start = after.index("    if cfg.get('descendant_on_timeout'):\n        ready =")
            old_end = after.index("    passed = all(checks.values())", old_start)
            after = after[:old_start] + """    if cfg.get('descendant_on_timeout'):
        ready = json.loads((case / 'descendant-ready.json').read_text())
        assert ready['same_group_as_owned_popen']
        complete = case / 'descendant-late-side-effect.json'
        assert os.read(lifetime_read, 1024) == b'alive', 'fixture never held its lifetime FD'
        try:
            terminated = os.read(lifetime_read, 1) == b''
        except BlockingIOError:
            terminated = False
        snapshot = {'ready':ready, 'returned_monotonic':returned, 'worker_terminated':terminated,
                    'late_at_return':complete.exists(), 'sentinel_alive':sentinel.poll() is None,
                    'fixture_cleanup_started':False}
        (case / 'return-state.json').write_text(json.dumps(snapshot, indent=2) + '\\n')
        no_late = not complete.exists()
        # Authorized separate positive oracle. A killed worker cannot supply its
        # old normal-completion marker; FD closure is its owned lifetime witness.
        deadline = returned + 3.0
        while time.monotonic() < deadline:
            no_late = no_late and not complete.exists()
            if not terminated:
                try:
                    terminated = os.read(lifetime_read, 1) == b''
                except BlockingIOError:
                    pass
            time.sleep(0.02)
        os.close(lifetime_read)
        probe_record = next(item for item in receipt['commands'] if item['name'] == 'probe')
        lifetime = probe_record['lifetime']
        signal_or_truthful_failure = (lifetime['signal_delivered'] or lifetime.get('group_absent_at_signal')
                                     or ('error' in lifetime and not receipt['command_cleanup_ok'] and receipt['final_exit'] != 0))
        sentinel.wait(timeout=3)
        sentinel_ok = sentinel.returncode == 0 and (case / 'sentinel-finished').read_text() == 'natural'
        details.update(ready=ready, return_state=snapshot, worker_terminated=terminated,
                       no_late_work_through_original_window=no_late,
                       observed_seconds=time.monotonic() - returned, sentinel_exit=sentinel.returncode,
                       anchor_reaped=lifetime['anchor_reaped'], descendant_reap_certified=False,
                       external_pid_signals_used=False, fixture_cleanup_started=False)
        checks['owned_process_group_drained_on_timeout'] = bool(no_late and terminated and lifetime['anchor_reaped']
            and signal_or_truthful_failure and not snapshot['late_at_return'] and snapshot['sentinel_alive'] and sentinel_ok)
""" + after[old_end:]
        path.write_text(after)
        changes.append({'path':str(path.relative_to(root)), 'reason':'source binding; positive only has parent-authorized S3 oracle replacement and owned sentinel/lifetime fixtures',
                        'diff':''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True)))})
        if name.endswith('positive'):
            path = work / 'heldout/descendant_worker.py'
            before = path.read_text()
            after = before.replace('started = time.monotonic()', "fd = os.open(root / 'lifetime.fifo', os.O_WRONLY)\nos.write(fd, b'alive')\nstarted = time.monotonic()")
            path.write_text(after)
            changes.append({'path':str(path.relative_to(root)), 'reason':'lifetime FD closed by real process termination; original 2s side-effect code unchanged', 'diff':''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True)))})
    fake_path = work / ('heldout/fake_cli.py' if heldout else 'evidence/fake_cli.py')
    before = fake_path.read_text()
    after = before.replace('os.kill(os.getppid(), signal.SIGTERM)', "(root / 'signal-request').write_text('request controller self-signal')")
    after = after.replace('str(root), str(os.getpid())', 'str(root), str(os.getpgrp())')
    fake_path.write_text(after)
    changes.append({'path':str(fake_path.relative_to(root)), 'reason':'actual parent/group boundary moved to anchor; request a self-signal rather than signal numeric grandparent PID',
                    'diff':''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True)))})
(root / 'evidence/generated-step.bash').write_text(script)
(root / 'evidence/generated-controller.py').write_text(controller + '\n')
(root / 'evidence/generated-command-owner.py').write_text(helper)
(root / 'evidence/verified-fixture-delta.json').write_text(json.dumps(changes, indent=2) + '\n')
print(json.dumps({'workflow_sha256':sha(raw), 'controller_body_sha256':sha(controller.encode()),
                  'generated_controller_sha256':sha((controller + '\n').encode()), 'helper_sha256':sha(helper.encode()),
                  'python_and_owner_syntax':True}, indent=2))
