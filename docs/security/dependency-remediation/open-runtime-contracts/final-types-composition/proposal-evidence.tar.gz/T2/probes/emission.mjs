import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, relative } from 'node:path';
import { createHash } from 'node:crypto';
const root=process.env.QMD_COMPOSE_ROOT;
const require=createRequire(join(root,'mirror/package.json'));
const ts=require('typescript');
const hash=value=>createHash('sha256').update(value).digest('hex');
const roots={};
for(const tree of ['baseline','mirror']) {
  const base=join(root,tree);
  const config=ts.readConfigFile(join(base,'tsconfig.json'),ts.sys.readFile);
  if(config.error)throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText,'\n'));
  const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,base);
  if(parsed.errors.length)throw new Error(JSON.stringify(parsed.errors));
  roots[tree]={files:parsed.fileNames.map(p=>relative(base,p)).sort(),options:parsed.options};
}
const added=roots.mirror.files.filter(p=>!roots.baseline.files.includes(p));
const removed=roots.baseline.files.filter(p=>!roots.mirror.files.includes(p));
if(added.length||removed.length)throw new Error('Unexpected root drift');
const result=[];
for(const rel of ['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts']) {
  const pair={path:rel,trees:{}};
  for(const tree of ['baseline','mirror']) {
    const input=readFileSync(join(root,tree,rel),'utf8');
    const out=ts.transpileModule(input,{fileName:rel,compilerOptions:{...roots[tree].options,noEmit:false,declaration:false,sourceMap:false},reportDiagnostics:true});
    if(out.diagnostics?.length)throw new Error(JSON.stringify(out.diagnostics));
    const dest=join(root,'evidence/emitted',tree,rel.replace(/\.ts$/,'.mjs'));
    mkdirSync(join(dest,'..'),{recursive:true});
    writeFileSync(dest,out.outputText);
    // Positional ordered inventory, never a name-keyed projection: duplicates
    // and every nested/anonymous function survive. Mask proof uses whole bytes.
    const ast=ts.createSourceFile(rel+'.mjs',out.outputText,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
    const functions=[];
    function visit(node,ancestry) {
      if(ts.isFunctionLike(node))functions.push({kind:ts.SyntaxKind[node.kind],start:node.getStart(ast),end:node.end,ancestry,name:node.name?.getText(ast)??null});
      let child=0;
      ts.forEachChild(node,n=>visit(n,[...ancestry,child++]));
    }
    visit(ast,[]);
    pair.trees[tree]={sourceSha256:hash(input),emittedSha256:hash(out.outputText),emittedPath:relative(root,dest),functionInventory:functions};
  }
  result.push(pair);
}
const receipt={typescript:ts.version,execPath:process.execPath,versions:process.versions,compilerRoots:roots,rootDiff:{added,removed},files:result,scope:'Full-file installed TypeScript transpileModule; no import resolution or whole-root pass inferred. Ordered inventories preserve duplicates and nested definitions; no function-name flattening.'};
writeFileSync(join(root,'evidence/emission-and-roots.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({typescript:ts.version,roots:Object.fromEntries(Object.entries(roots).map(([k,v])=>[k,v.files.length])),rootDiff:{added,removed},files:result.map(p=>({path:p.path,hashes:Object.fromEntries(Object.entries(p.trees).map(([k,v])=>[k,{source:v.sourceSha256,emitted:v.emittedSha256,functions:v.functionInventory.length}]))}))},null,2));
