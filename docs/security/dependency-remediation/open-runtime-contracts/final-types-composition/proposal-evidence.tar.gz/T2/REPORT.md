# T2 metric paths — implemented; independent parent gates pending

Owned derivative: `/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/mirror`. No live source, configuration, service, metadata, lockfile, skill, install, model/GPU, registry, network, staging or commit operation was performed.

## Delivered delta

- Copied only the **251** public files authorized by the authenticated composition's `after-manifest.json`, into fresh owned `baseline/` and `mirror/`. Verified input index SHA-256 `104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac`, all **188** indexed artifacts, and all **19** accepted reference hashes; rechecked immutable input at completion.
- Applied exactly the **five explicitly authorized executable runner hunks** from `reference/original-source.patch:1–57`: missing query slots, typed finite `postScore`, undefined percentile sample, entry iteration, and cached mlx-port argument. Added exactly the accepted **sparse-query regression**. No cast/assertion substitution, lease/recovery rewrite, clock/deadline/grant/Python-owner change, observer change or existing-fixture edit.
- Only product source changes: `scripts/phase5_e2e_runner.ts` and `test/phase5-recovery.test.ts`. **249/251 source files remain byte-identical.** The older complete runner was not copied.
- Patch: `T2-metric-guards.patch`, SHA-256 **`222dcc9efbb2fe4b29b1f5d87ef3b68dafef161b83efb75038f3773f30e1eda2`**. Actual fresh `git apply --check` and apply both returned **0**; all **251** replayed postimage hashes match `mirror/` (`evidence/patch-replay-verification.json`).

| Path | Preimage SHA-256 | Postimage SHA-256 |
|---|---|---|
| `scripts/phase5_e2e_runner.ts` | `6204b26a3a8218cd1da6ce03ec856065656d904cc9b936d9110900f8d79ac875` | `ef2202822b4992acb27b9b989f23f49280f3b66b22a1630569ee057ef1a7601c` |
| `test/phase5-recovery.test.ts` | `9882a80d11235b31403fb897ea7bdb75597972256d323417b26e772cbddacff3` | `8cb9052208d525552aca5705acc984a97fb9da732336031c86bcc4886038452c` |

## Actual RED / GREEN

All runs use fresh synthetic HOME/Hermes/knowledge/XDG/HF/TMP/cache environments, empty inherited credentials/context, offline flags, `QMD_LLAMA_GPU=false`, `CI=1`, `REQUIRE_BUN=1`, and at most **two** test workers. Shared dependencies are per-package read-use aliases inside real owned node_modules containers; owned `.vite/.cache/.vitest` existed before RED. Per-invocation argv, environment, cwd, exit status and complete logs are retained.

| Run | Actual result |
|---|---|
| Accepted sparse test safely relocated against unchanged runner, before product edit | **1 failed, 17 pattern-unselected skips**, exit 1; `qPre.topDocIds` TypeError |
| Repeatable RED fixture `held-red/` against unchanged `baseline/` | **1 failed, 17 pattern-unselected skips**, exit 1; same actual failure |
| Metric/recovery file, Node **22.22.3** | **18 passed**, 0 skips, exit 0 |
| Same file, actual Bun **1.3.8** Vitest host (`bun --bun`) | **18 passed**, 0 skips, exit 0 |
| Exact 13-file focused union from authenticated REPRODUCE, Node | **246 passed, 40 existing skips**, exit 0 |
| Same 13 files, actual Bun host | **224 passed, 40 existing skips**, exit 0 |
| Native-Bun ownership wrappers, outer Node host | **7 passed**, 0 skips, exit 0; child runtime **Bun 1.3.8** independently verified from child records |
| Canonical `node scripts/build.mjs`, baseline and derivative | Both **exit 0** |
| Unchanged-baseline strict root, after canonical build | **35 diagnostics**, exit 2; 31 belong to held runner |
| Rebased strict root, Node and actual Bun compiler hosts | Each **4 diagnostics**, exit 2; **zero diagnostics on either scoped path** |

Counts were freshly parsed from assertion results and verified against each report's totals; the new sparse test is passed in both focused runs, not inherited from historical 246/224 receipts. `evidence/runtime-results.json`, `runtime-hosts.json`, `strict-root-results.json` and raw `logs/` supply the receipts. Test-host model/network/native-model attempt lists are empty. Native ownership tests retain their existing **200/800/1800ms** policies; no budget was increased.

## Preservation proof

- `evidence/scoped-source-preservation.json`: exact official-hunk reconstruction equals both delivered postimages; full-source byte comparisons mask only five runner edit spans plus the regression insertion. Exact byte/character offsets, text, hashes and whole masked files are retained.
- `evidence/emission-preservation.json` and `evidence/emitted*`: installed **TypeScript 5.9.3** full-file emissions differ only in the six explicitly allowlisted emitted spans. Unmasked emitted bytes are exactly identical. No function-name projection is used: complete emitted strings preserve every nested/duplicate definition; ordered positional function inventories are also retained in `emission-and-roots.json`. These are controlled transpileModule comparisons, not a claim of whole-root acceptance.
- All **4 observer paths** are byte-identical. Of the authenticated **12 lease paths**, **10** are byte-identical and the **two scoped paths** have the exact complement-preservation proof above. Metadata/locks and both tsconfigs are unchanged (`protected-paths.json`).
- T2 preserves **153 → 153** canonical compiler roots with no additions/removals. The authenticated earlier **150 → 153** transition was only the three accepted new tests. Historical `.mjs` archive imports remain present and unchanged.
- Dependency preservation: **18,642 entries** retain identical size, nanosecond mtime/ctime, mode, inode/device/owner and link metadata; **16,768 permitted regular-file byte hashes** are identical. **1 dependency AGENTS.md file** was intentionally not read: metadata equality only, not byte equality, is claimed for it (`dependency-final-summary.json`).

## Remaining limits and parent gates

1. **Whole root remains blocked, not green.** Four real declaration diagnostics remain: `bun:sqlite`, `globalThis.Bun`, `picomatch`, and `bun:test`. No typings were installed or fabricated; package/lock ownership remains the separate metadata lane.
2. The compiler filesystem guard still refuses the historical archives' absolute reads of live `package.json` / `src/mcp/server.ts` before content read. Raw Node/Bun readguard logs and `compiler-read-guard-summary.json` show this. No root/config narrowing, archive rewrite or live-source read was used to hide it. This JS filesystem guard is not an OS sandbox, and blocked import resolution means no isolated whole-root pass can be inferred even if diagnostic count later reaches zero.
3. **C1 remains qualified:** an artificially paused sole cleanup owner may return truthful incomplete-cleanup proof, prevent forbidden work, then naturally reap. No universal complete-cleanup guarantee is claimed.
4. Independent **SPEC**, then **QUALITY**, followed by parent-owned whole-root/actual combined CI remain gates. This lane does not self-approve or claim release/combined-CI acceptance.

Harness-only incidents retained: the first dependency snapshot stopped at an AGENTS.md path **before reading it**; the successful snapshot explicitly uses metadata only there. An initial proof/receipt basename collision was corrected by regenerating proof under a distinct filename and replaying again in fresh `patch-replay-final/`; the initial run receipts remain. Neither incident changed product code or immutable input.

See `REPRODUCE.md` for runnable isolated commands, `RESULT.json` for machine-readable outcomes, `before-manifest.json` / `after-manifest.json` for all 251 source hashes, `path-preimages.json` for the two exact pre/post bindings, and `report-index.json` for delivered artifact hashes.
