from pathlib import Path
import json,hashlib,sys
R=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((R/'report-index.json').read_text())
assert index['artifact_count']==len(index['files'])
for rel,h in index['files'].items():assert sha((R/rel).read_bytes())==h,rel
before=json.loads((R/'before-manifest.json').read_text())['sourceSha256']
after=json.loads((R/'after-manifest.json').read_text())['sourceSha256']
for rel,h in before.items():assert sha((R/'baseline'/rel).read_bytes())==h,rel
for tree in ['mirror',sys.argv[1] if len(sys.argv)>1 else 'patch-replay-final']:
    assert Path(tree).name==tree and tree not in ['.','..']
    for rel,h in after.items():assert sha((R/tree/rel).read_bytes())==h,(tree,rel)
print(json.dumps({'status':'ARTIFACT_AND_REPLAY_VERIFIED_NOT_APPROVED','indexSha256':sha((R/'report-index.json').read_bytes()),'indexedArtifactsVerified':len(index['files']),'unchangedBaselineSourcesVerified':len(before),'postimageSourcesVerifiedPerTree':len(after),'patchSha256':sha((R/'T2-metric-guards.patch').read_bytes()),'independentSpecQualityAndCombinedCIRemainParentGates':True},indent=2))
