from pathlib import Path
import sys,json,hashlib
R=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
name=sys.argv[1]
assert name and all(c.isalnum() or c in '-_' for c in name)
p=R/name;p.mkdir()
manifest=json.loads((R/'before-manifest.json').read_text())['sourceSha256']
for rel,h in manifest.items():
    b=(R/'baseline'/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==h
    dest=p/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
print(json.dumps({'freshReplay':str(p),'copiedPublicSources':len(manifest)},indent=2))
