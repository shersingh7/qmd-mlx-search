from pathlib import Path
import json,hashlib,difflib,os,stat
R=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
I=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-compose-nd8v4x2p')
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(rel,value):
    p=R/rel;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,indent=2)+'\n')
def edits_from_patch(p):
    hunks=[];h=None
    for line in p.read_text().splitlines(keepends=True):
        if line.startswith('@@'):
            h=[];hunks.append(h)
        elif h is not None:
            assert line[0] in ' +-','unexpected patch content'
            h.append(line)
    out=[]
    for h in hunks:
        old=''.join(x[1:] for x in h if x[0]!='+')
        new=''.join(x[1:] for x in h if x[0]!='-')
        j=next(j for j,x in enumerate(h) if x[0]!=' ')
        k=len(h)-next(j for j,x in enumerate(reversed(h)) if x[0]!=' ')
        assert all(x[0]!=' ' for x in h[j:k]),'only one contiguous edit per authorized hunk'
        prefix=''.join(x[1:] for x in h[:j])
        oldedit=''.join(x[1:] for x in h[j:k] if x[0]=='-')
        newedit=''.join(x[1:] for x in h[j:k] if x[0]=='+')
        out.append({'oldContext':old,'newContext':new,'prefix':prefix,'old':oldedit,'new':newedit})
    return out

def mask(s,spans,key):
    for n,span in reversed(list(enumerate(spans))):
        start,end=span[key]
        s=s[:start]+f'/* EXACT_AUTHORIZED_DELTA_{n+1} */\n'+s[end:]
    return s

def positions(text,start,end):
    return {'charStart':start,'charEnd':end,'byteStart':len(text[:start].encode()),'byteEnd':len(text[:end].encode()),'lineStart':text[:start].count('\n')+1,'lineEndExclusive':text[:end].count('\n')+1,'sha256':sha(text[start:end].encode()),'text':text[start:end]}

before=json.loads((R/'before-manifest.json').read_text())['sourceSha256']
auth=json.loads((R/'evidence/authentication.json').read_text())
after={p:sha((R/'mirror'/p).read_bytes()) for p in before}
assert all(sha((R/'baseline'/p).read_bytes())==h for p,h in before.items())
changed=sorted(p for p in before if after[p]!=before[p])
assert changed==['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts'],changed
names=['missing-query-slot guard','typed postScore finite check','undefined-percentile guard','entry iteration','cached mlx-port argument','sparse-query-slot regression']
sourceproof=[]
for rel,patch,count,offset in [('scripts/phase5_e2e_runner.ts',R/'reference/runner-five-hunks.patch',5,0),('test/phase5-recovery.test.ts',R/'reference/diffs/test__phase5-recovery.test.ts.diff',1,5)]:
    old=(R/'baseline'/rel).read_text();new=(R/'mirror'/rel).read_text()
    edits=edits_from_patch(patch)
    assert len(edits)==count
    expected=old;spans=[]
    for n,e in enumerate(edits):
        assert old.count(e['oldContext'])==new.count(e['newContext'])==1
        assert expected.count(e['oldContext'])==1
        expected=expected.replace(e['oldContext'],e['newContext'],1)
        b=old.index(e['oldContext'])+len(e['prefix']);a=new.index(e['newContext'])+len(e['prefix'])
        assert old[b:b+len(e['old'])]==e['old'] and new[a:a+len(e['new'])]==e['new']
        spans.append({'id':names[offset+n],'before':(b,b+len(e['old'])),'after':(a,a+len(e['new'])),'preimage':positions(old,b,b+len(e['old'])),'postimage':positions(new,a,a+len(e['new']))})
    assert expected==new,rel
    maskedold=mask(old,spans,'before');maskednew=mask(new,spans,'after')
    assert maskedold==maskednew
    for tree,text in [('baseline',maskedold),('mirror',maskednew)]:
        dest=R/'evidence/source-masked'/tree/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
    sourceproof.append({'path':rel,'referencePatchSha256':sha(patch.read_bytes()),'exactReferenceHunksApplied':count,'unmaskedBytesIdentical':True,'maskedWholeFileSha256':sha(maskedold.encode()),'spans':spans})
save('evidence/scoped-source-preservation.json',sourceproof)

# Explicit installed-emission allowlist, not arbitrary diff masking. These six
# literal before/after spans are the emitted forms of the six authorized edits.
allow=[
('', '        if (!qPre || !qPost) {\n            return {\n                identical: false,\n                details: [{ queryId: "all", docOrderMatch: false, scoreToleranceMatch: false, diff: `Missing query detail at index ${i}` }],\n            };\n        }\n'),
('            && qPre.scores.every((score, j) => Number.isFinite(score) && Number.isFinite(qPost.scores[j]) && Math.abs(score - qPost.scores[j]) <= tolerance);\n', '            && qPre.scores.every((score, j) => {\n                const postScore = qPost.scores[j];\n                return Number.isFinite(score) && typeof postScore === "number" && Number.isFinite(postScore)\n                    && Math.abs(score - postScore) <= tolerance;\n            });\n'),
('', '    if (p50 === undefined || p95 === undefined)\n        throw new Error("Missing latency percentile sample");\n'),
('        for (let i = 0; i < topIds.length; i++) {\n            if (relSet.has(topIds[i])) {\n', '        for (const [i, id] of topIds.entries()) {\n            if (relSet.has(id)) {\n'),
('    const mlxPort = mlxPortIdx !== -1 && args[mlxPortIdx + 1] ? parseInt(args[mlxPortIdx + 1], 10) : 8797;\n', '    const mlxPortArg = mlxPortIdx !== -1 ? args[mlxPortIdx + 1] : undefined;\n    const mlxPort = mlxPortArg ? parseInt(mlxPortArg, 10) : 8797;\n'),
('', '        (0, vitest_1.it)("refuses missing query slots in either retrieval report without throwing", () => {\n            for (const missingSide of ["pre", "post", "both"]) {\n                const pre = stage();\n                const post = stage();\n                if (missingSide !== "post")\n                    pre.queryDetails = new Array(1);\n                if (missingSide !== "pre")\n                    post.queryDetails = new Array(1);\n                (0, vitest_1.expect)((0, phase5_e2e_runner_js_1.verifyRetrievalEquivalence)(pre, post)).toMatchObject({\n                    identical: false,\n                    details: [{ docOrderMatch: false, scoreToleranceMatch: false }],\n                });\n            }\n        });\n')]
emissionproof=[]
for rel,count,offset in [('scripts/phase5_e2e_runner.mjs',5,0),('test/phase5-recovery.test.mjs',1,5)]:
    old=(R/'evidence/emitted/baseline'/rel).read_text();new=(R/'evidence/emitted/mirror'/rel).read_text()
    ol=old.splitlines(keepends=True);nl=new.splitlines(keepends=True)
    ops=[x for x in difflib.SequenceMatcher(None,ol,nl,autojunk=False).get_opcodes() if x[0]!='equal']
    assert len(ops)==count,(rel,len(ops))
    spans=[]
    for n,(tag,i,j,k,l) in enumerate(ops):
        assert (''.join(ol[i:j]),''.join(nl[k:l]))==allow[offset+n],(rel,n)
        b=len(''.join(ol[:i]));be=len(''.join(ol[:j]));a=len(''.join(nl[:k]));ae=len(''.join(nl[:l]))
        spans.append({'id':names[offset+n],'before':(b,be),'after':(a,ae),'preimage':positions(old,b,be),'postimage':positions(new,a,ae)})
    mo=mask(old,spans,'before');mn=mask(new,spans,'after')
    assert mo==mn
    for tree,text in [('baseline',mo),('mirror',mn)]:
        dest=R/'evidence/emitted-masked'/tree/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
    emissionproof.append({'path':rel,'wholeEmittedBaselineSha256':sha(old.encode()),'wholeEmittedPostimageSha256':sha(new.encode()),'maskedWholeFileSha256':sha(mo.encode()),'unmaskedEmittedBytesIdentical':True,'exactAllowedEmissionSpans':spans,'projection':'none: compares complete installed TypeScript emitted strings, including every nested/duplicate function definition'})
save('evidence/emission-preservation.json',emissionproof)

observer=['.github/workflows/ci.yml','test/audit-recovery-tree.test.ts','test/helpers/recovery-bootstrap-diagnostics.mjs','test/helpers/recovery-bootstrap-diagnostics.selftest.mjs']
lease=list(auth['leaseBaselineChecks'])
assert len(lease)==12
protected={}
for group,paths in [('observer',observer),('lease',lease),('metadata-and-config',['package.json','pnpm-lock.yaml','bun.lock','tsconfig.json','tsconfig.build.json'])]:
    protected[group]={p:{'preimageSha256':before[p],'postimageSha256':after[p],'identical':before[p]==after[p],'scopedDeltaProof':'evidence/scoped-source-preservation.json' if p in changed else None} for p in paths}
    assert all(v['identical'] or p in changed for p,v in protected[group].items())
# Product additions may only be owned tool caches or canonical build output.
extras={}
for tree in ['baseline','mirror']:
    unexpected=[]
    for base,dirs,files in os.walk(R/tree,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ['node_modules','dist','.cache','.vite','.vitest']]
        for name in files:
            p=Path(base)/name;rel=str(p.relative_to(R/tree))
            if rel not in before:unexpected.append(rel)
    extras[tree]=unexpected
    assert not unexpected,unexpected
save('evidence/protected-paths.json',{'groups':protected,'baselineSourceCount':len(before),'postimageSourceCount':len(after),'unchangedSourceCount':len(before)-len(changed),'unexpectedSourcePaths':extras,'allOtherProductSourceBytesIdentical':True})
save('after-manifest.json',{'sourceCount':len(after),'sourceSha256':after,'changedPaths':changed})
images={p:{'preimageSha256':before[p],'postimageSha256':after[p]} for p in changed}
save('path-preimages.json',images)
patch=[]
for p in changed:
    patch.append(f'diff --git a/{p} b/{p}\n')
    patch.extend(difflib.unified_diff((R/'baseline'/p).read_text().splitlines(keepends=True),(R/'mirror'/p).read_text().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p,n=3))
(R/'T2-metric-guards.patch').write_text(''.join(patch))
# A genuinely fresh 251-file source replay; no dependency aliases or outputs.
replay=R/'patch-replay-final';replay.mkdir()
for p,h in before.items():
    data=(R/'baseline'/p).read_bytes();assert sha(data)==h
    dest=replay/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
# Bind the earlier 150 -> 153 history without re-running or reading older roots.
legacy=json.loads((I/'evidence/source-emission-proof.json').read_text())
roots=json.loads((R/'evidence/emission-and-roots.json').read_text())
assert roots['compilerRoots']['baseline']['files']==roots['compilerRoots']['mirror']['files']==legacy['compilerRoots']['mirror']['files']
save('evidence/root-preservation.json',{'historicalRoots':{t:len(v['files']) for t,v in legacy['compilerRoots'].items()},'historicalAdded':legacy['rootDiff']['added'],'T2BaselineRoots':roots['compilerRoots']['baseline']['files'],'T2PostimageRoots':roots['compilerRoots']['mirror']['files'],'T2Added':[],'T2Removed':[],'productionConfigsUnchanged':True,'fullRootPass':False,'qualification':'Canonical import resolution still guarded against forbidden live absolute documentation imports; unchanged roots are not a green whole-root result.'})
# Verify every read-only source and indexed input again; do not execute delivery.
idxbytes=(I/'report-index.json').read_bytes();assert sha(idxbytes)==auth['inputIndexSha256']
idx=json.loads(idxbytes)
assert all(sha((I/p).read_bytes())==h for p,h in idx['files'].items())
assert all(sha((I/'mirror'/p).read_bytes())==h for p,h in before.items())
assert all(sha((I/'reference/accepted19'/p).read_bytes())==h for p,h in auth['accepted19Sha256'].items())
save('evidence/readonly-input-preservation.json',{'indexSha256':sha(idxbytes),'indexedArtifactsVerifiedUnchanged':len(idx['files']),'publicMirrorSourcesVerifiedUnchanged':len(before),'accepted19VerifiedUnchanged':len(auth['accepted19Sha256'])})
print(json.dumps({'changedPaths':images,'sourceFiles':len(after),'sourceDeltaGroups':sum(x['exactReferenceHunksApplied'] for x in sourceproof),'emittedDeltaGroups':sum(len(x['exactAllowedEmissionSpans']) for x in emissionproof),'fullUnmaskedSourceAndEmissionEquality':True,'patchSha256':sha((R/'T2-metric-guards.patch').read_bytes()),'freshReplay':str(replay)},indent=2))
