from pathlib import Path
import json,hashlib,collections,re,os,shlex
R=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
PY='/Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(rel):return json.loads((R/rel).read_text())
def save(rel,obj):(R/rel).write_text(json.dumps(obj,indent=2)+'\n')
before=load('before-manifest.json')['sourceSha256'];after=load('after-manifest.json')['sourceSha256']
assert len(before)==len(after)==251
replay={p:sha((R/'patch-replay-final'/p).read_bytes()) for p in before}
assert replay==after
for label in ['patch-replay-final-check','patch-replay-final-apply']:
    assert load('evidence/'+label+'.json')['exit_code']==0
save('evidence/patch-replay-verification.json',{'sourceCount':len(replay),'allPostimageHashesEqualMirror':True,'checkExitCode':0,'applyExitCode':0,'replayRoot':str(R/'patch-replay-final'),'sourceSha256':replay})
labels=['red-node-sparse','red-node-sparse-baseline','green-node-metric','green-bun-metric','green-node-focused13','green-bun-focused13','green-node-native-bun-wrappers']
runtime={}
regression='refuses missing query slots in either retrieval report without throwing'
for label in labels:
    data=load('evidence/'+label+'-results.json');rec=load('evidence/'+label+'.json')
    assertions=[a for f in data['testResults'] for a in f.get('assertionResults',[])]
    counts=dict(collections.Counter(a['status'] for a in assertions))
    assert len(assertions)==data['numTotalTests'],(label,len(assertions),data['numTotalTests'])
    assert counts.get('passed',0)==data['numPassedTests'] and counts.get('failed',0)==data['numFailedTests']
    isred=label.startswith('red-')
    assert rec['exit_code']==(1 if isred else 0)
    assert data['success']==(not isred)
    matches=[a for a in assertions if a['title']==regression]
    if 'native-bun-wrappers' not in label:
        assert len(matches)==1 and matches[0]['status']==('failed' if isred else 'passed'),label
    wanted=13 if 'focused13' in label else 1
    assert len(data['testResults'])==wanted
    runtime[label]={'exitCode':rec['exit_code'],'success':data['success'],'files':len(data['testResults']),'assertions':counts,'regressionStatus':matches[0]['status'] if matches else 'not-selected-wrapper-suite','maxWorkers':next(a.split('=',1)[1] for a in rec['argv'] if a.startswith('--maxWorkers=')),'perFile':[{'path':f['name'],'counts':dict(collections.Counter(a['status'] for a in f.get('assertionResults',[])))} for f in data['testResults']]}
    assert int(runtime[label]['maxWorkers'])<=2
    if isred:assert 'Cannot read properties of undefined' in (R/'logs'/f'{label}.stderr.log').read_text()
assert runtime['green-node-metric']['assertions']=={'passed':18}
assert runtime['green-bun-metric']['assertions']=={'passed':18}
assert runtime['green-node-focused13']['assertions']=={'passed':246,'skipped':40}
assert runtime['green-bun-focused13']['assertions']=={'passed':224,'skipped':40}
assert runtime['green-node-native-bun-wrappers']['assertions']=={'passed':7}
save('evidence/runtime-results.json',runtime)
hosts={}
for label in labels:
    rows=[json.loads(s) for s in (R/'evidence'/f'{label}-hosts.jsonl').read_text().splitlines()]
    attempts=[x for x in rows if x.get('attempts')]
    assert not attempts,label
    actual=[x for x in rows if x.get('kind')=='host']
    assert len(actual)==runtime[label]['files']
    if label.startswith('green-bun-'):
        assert all(x['versions']['bun']=='1.3.8' for x in actual)
        assert all(x['execPath']=='/Users/shersingh/.bun/bin/bun' for x in actual)
    else:
        assert all(x['versions']['node']=='22.22.3' and not x['versions'].get('bun') for x in actual)
        assert all(x['execPath']=='/Users/shersingh/.hermes/node/bin/node' for x in actual)
    hosts[label]={'workerHostReceipts':len(actual),'actualHosts':[{'execPath':p,'node':n,'bun':b} for p,n,b in sorted(set((x['execPath'],x['versions'].get('node'),x['versions'].get('bun')) for x in actual))],'boundaryAttempts':attempts}
children=[]
for line in (R/'logs/green-node-native-bun-wrappers.stdout.log').read_text().splitlines():
    if line.startswith('{"evidence":'):
        children.append(json.loads(line))
native=[x for x in children if x.get('evidence','').endswith('runtime') and x.get('bun')]
assert native and all(x['bun']=='1.3.8' for x in native)
assert all(x['executable']=='/Users/shersingh/.bun/bin/bun' for x in native)
hosts['nativeBunChildren']={'runtimeReceipts':native,'evidenceRecords':len(children),'qualification':'Outer wrapper host is Node, child test/fixture hosts are actual Bun. No wrapper launcher is substituted for runtime identity.'}
save('evidence/runtime-hosts.json',hosts)
types={}
for label,wanted in [('types-node-baseline',35),('types-node-green',4),('types-bun-green',4)]:
    lines=(R/'logs'/f'{label}.stdout.log').read_text().splitlines()
    diagnostics=[s for s in lines if re.match(r'.+\(\d+,\d+\): error TS\d+:',s)]
    assert len(diagnostics)==wanted and load('evidence/'+label+'.json')['exit_code']==2
    counts=dict(collections.Counter(s.split('(',1)[0] for s in diagnostics))
    if label!='types-node-baseline':assert not any(p in ['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts'] for p in counts)
    types[label]={'exitCode':2,'diagnosticCount':len(diagnostics),'perPath':counts,'diagnostics':diagnostics,'canonicalRootPass':False}
assert types['types-node-baseline']['perPath']['scripts/phase5_e2e_runner.ts']==31
for label in ['build-node-baseline','build-node-green']:assert load('evidence/'+label+'.json')['exit_code']==0
save('evidence/strict-root-results.json',types)
guards=[]
for p in sorted((R/'evidence').glob('*-compiler-reads-*.jsonl')):
    rows=[json.loads(s) for s in p.read_text().splitlines()]
    denied=[x for x in rows if x.get('allowed') is False]
    actual=[x for x in rows if x.get('kind')=='compiler-host']
    guards.append({'log':str(p.relative_to(R)),'operations':sum('operation' in x for x in rows),'denied':denied,'actualCompilerHosts':actual})
for label in ['types-node-baseline','types-node-green','types-bun-green']:
    own=[x for x in guards if Path(x['log']).name.startswith(label+'-compiler-reads-')]
    denied=[d for x in own for d in x['denied']]
    assert denied,label
    assert any(d['lexical']=='/Users/shersingh/github/qmd-mlx-search/src/mcp/server.ts' for d in denied)
    assert all(d['lexical'] in ['/Users/shersingh/github/qmd-mlx-search/package.json','/Users/shersingh/github/qmd-mlx-search/src/mcp/server.ts'] for d in denied)
save('evidence/compiler-read-guard-summary.json',{'runs':guards,'scope':'JS filesystem compiler read guard on lexical + real paths, not an OS sandbox. Historical absolute live source/package reads remain refused before content read; metadata path resolution is not content authorization. No compiler-root/config/docs edits or isolated whole-root pass claimed.'})
deps=load('evidence/dependencies-before.json');depafter=load('evidence/dependencies-after.json')
assert deps==depafter
skipped=[p for p,v in deps.items() if 'content_read_refused' in v]
depreport={'entriesMetadataIdentical':len(deps),'regularFileByteHashesIdentical':sum('sha256' in v for v in deps.values()),'excludedFromContentReadByScope':skipped,'excludedMetadataIdentical':True,'beforeManifestSha256':sha((R/'evidence/dependencies-before.json').read_bytes()),'afterManifestSha256':sha((R/'evidence/dependencies-after.json').read_bytes()),'mismatches':[],'qualification':'AGENTS.md content was not read. Its byte identity is not claimed; metadata is identical. All permitted regular dependency bytes and all dependency entry metadata are preserved.'}
save('evidence/dependency-final-summary.json',depreport)
sourceproof=load('evidence/scoped-source-preservation.json');emission=load('evidence/emission-preservation.json')
assert len(sourceproof)==len(emission)==2
assert all(x['unmaskedBytesIdentical'] for x in sourceproof)
assert all(x['unmaskedEmittedBytesIdentical'] for x in emission)
patchhash=sha((R/'T2-metric-guards.patch').read_bytes())
result={'status':'T2_IMPLEMENTED_NOT_INDEPENDENTLY_REVIEWED_ROOT_BLOCKED','ownedRoot':str(R),'writeScope':['scripts/phase5_e2e_runner.ts','test/phase5-recovery.test.ts'],'sourceCount':251,'unchangedSourceCount':249,'patch':{'path':'T2-metric-guards.patch','sha256':patchhash,'pathPreimages':'path-preimages.json','freshReplay':'patch-replay-final','replayedSourcesVerified':251,'checkExitCode':0,'applyExitCode':0},'runtimeResults':runtime,'actualHosts':'evidence/runtime-hosts.json','strictRoot':types,'strictRunnerDiagnosticsRemoved':31,'remainingCanonicalRootDiagnostics':4,'canonicalRootPass':False,'sourcePreservation':'evidence/scoped-source-preservation.json','emissionPreservation':'evidence/emission-preservation.json','protectedPaths':'evidence/protected-paths.json','rootPreservation':'evidence/root-preservation.json','dependencyPreservation':depreport,'c1Qualification':'An artificially paused sole cleanup owner may truthfully return incomplete-cleanup proof, prevent forbidden work, and naturally reap later. No universal bounded complete-cleanup guarantee is claimed.','pendingParentGates':['independent SPEC','independent QUALITY after SPEC','declaration/metadata lane integration','parent-owned whole-root and actual combined CI'],'selfApproval':False,'liveEdits':False,'installs':False,'networkModelGPUActions':False,'commitsPushesOrServiceChanges':False}
save('RESULT.json',result)
images=load('path-preimages.json')
report=f'''# T2 metric paths — implemented; independent parent gates pending

Owned derivative: `{R}/mirror`. No live source, configuration, service, metadata, lockfile, skill, install, model/GPU, registry, network, staging or commit operation was performed.

## Delivered delta

- Copied only the **251** public files authorized by the authenticated composition's `after-manifest.json`, into fresh owned `baseline/` and `mirror/`. Verified input index SHA-256 `104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac`, all **188** indexed artifacts, and all **19** accepted reference hashes; rechecked immutable input at completion.
- Applied exactly the **five explicitly authorized executable runner hunks** from `reference/original-source.patch:1–57`: missing query slots, typed finite `postScore`, undefined percentile sample, entry iteration, and cached mlx-port argument. Added exactly the accepted **sparse-query regression**. No cast/assertion substitution, lease/recovery rewrite, clock/deadline/grant/Python-owner change, observer change or existing-fixture edit.
- Only product source changes: `scripts/phase5_e2e_runner.ts` and `test/phase5-recovery.test.ts`. **249/251 source files remain byte-identical.** The older complete runner was not copied.
- Patch: `T2-metric-guards.patch`, SHA-256 **`{patchhash}`**. Actual fresh `git apply --check` and apply both returned **0**; all **251** replayed postimage hashes match `mirror/` (`evidence/patch-replay-verification.json`).

| Path | Preimage SHA-256 | Postimage SHA-256 |
|---|---|---|
| `scripts/phase5_e2e_runner.ts` | `{images['scripts/phase5_e2e_runner.ts']['preimageSha256']}` | `{images['scripts/phase5_e2e_runner.ts']['postimageSha256']}` |
| `test/phase5-recovery.test.ts` | `{images['test/phase5-recovery.test.ts']['preimageSha256']}` | `{images['test/phase5-recovery.test.ts']['postimageSha256']}` |

## Actual RED / GREEN

All runs use fresh synthetic HOME/Hermes/knowledge/XDG/HF/TMP/cache environments, empty inherited credentials/context, offline flags, `QMD_LLAMA_GPU=false`, `CI=1`, `REQUIRE_BUN=1`, and at most **two** test workers. Shared dependencies are per-package read-use aliases inside real owned node_modules containers; owned `.vite/.cache/.vitest` existed before RED. Per-invocation argv, environment, cwd, exit status and complete logs are retained.

| Run | Actual result |
|---|---|
| Accepted sparse test safely relocated against unchanged runner, before product edit | **1 failed, 17 pattern-unselected skips**, exit 1; `qPre.topDocIds` TypeError |
| Repeatable RED fixture `held-red/` against unchanged `baseline/` | **1 failed, 17 pattern-unselected skips**, exit 1; same actual failure |
| Metric/recovery file, Node **22.22.3** | **18 passed**, 0 skips, exit 0 |
| Same file, actual Bun **1.3.8** Vitest host (`bun --bun`) | **18 passed**, 0 skips, exit 0 |
| Exact 13-file focused union from authenticated REPRODUCE, Node | **246 passed, 40 existing skips**, exit 0 |
| Same 13 files, actual Bun host | **224 passed, 40 existing skips**, exit 0 |
| Native-Bun ownership wrappers, outer Node host | **7 passed**, 0 skips, exit 0; child runtime **Bun 1.3.8** independently verified from child records |
| Canonical `node scripts/build.mjs`, baseline and derivative | Both **exit 0** |
| Unchanged-baseline strict root, after canonical build | **35 diagnostics**, exit 2; 31 belong to held runner |
| Rebased strict root, Node and actual Bun compiler hosts | Each **4 diagnostics**, exit 2; **zero diagnostics on either scoped path** |

Counts were freshly parsed from assertion results and verified against each report's totals; the new sparse test is passed in both focused runs, not inherited from historical 246/224 receipts. `evidence/runtime-results.json`, `runtime-hosts.json`, `strict-root-results.json` and raw `logs/` supply the receipts. Test-host model/network/native-model attempt lists are empty. Native ownership tests retain their existing **200/800/1800ms** policies; no budget was increased.

## Preservation proof

- `evidence/scoped-source-preservation.json`: exact official-hunk reconstruction equals both delivered postimages; full-source byte comparisons mask only five runner edit spans plus the regression insertion. Exact byte/character offsets, text, hashes and whole masked files are retained.
- `evidence/emission-preservation.json` and `evidence/emitted*`: installed **TypeScript 5.9.3** full-file emissions differ only in the six explicitly allowlisted emitted spans. Unmasked emitted bytes are exactly identical. No function-name projection is used: complete emitted strings preserve every nested/duplicate definition; ordered positional function inventories are also retained in `emission-and-roots.json`. These are controlled transpileModule comparisons, not a claim of whole-root acceptance.
- All **4 observer paths** are byte-identical. Of the authenticated **12 lease paths**, **10** are byte-identical and the **two scoped paths** have the exact complement-preservation proof above. Metadata/locks and both tsconfigs are unchanged (`protected-paths.json`).
- T2 preserves **153 → 153** canonical compiler roots with no additions/removals. The authenticated earlier **150 → 153** transition was only the three accepted new tests. Historical `.mjs` archive imports remain present and unchanged.
- Dependency preservation: **{depreport['entriesMetadataIdentical']:,} entries** retain identical size, nanosecond mtime/ctime, mode, inode/device/owner and link metadata; **{depreport['regularFileByteHashesIdentical']:,} permitted regular-file byte hashes** are identical. **{len(skipped)} dependency AGENTS.md file** was intentionally not read: metadata equality only, not byte equality, is claimed for it (`dependency-final-summary.json`).

## Remaining limits and parent gates

1. **Whole root remains blocked, not green.** Four real declaration diagnostics remain: `bun:sqlite`, `globalThis.Bun`, `picomatch`, and `bun:test`. No typings were installed or fabricated; package/lock ownership remains the separate metadata lane.
2. The compiler filesystem guard still refuses the historical archives' absolute reads of live `package.json` / `src/mcp/server.ts` before content read. Raw Node/Bun readguard logs and `compiler-read-guard-summary.json` show this. No root/config narrowing, archive rewrite or live-source read was used to hide it. This JS filesystem guard is not an OS sandbox, and blocked import resolution means no isolated whole-root pass can be inferred even if diagnostic count later reaches zero.
3. **C1 remains qualified:** an artificially paused sole cleanup owner may return truthful incomplete-cleanup proof, prevent forbidden work, then naturally reap. No universal complete-cleanup guarantee is claimed.
4. Independent **SPEC**, then **QUALITY**, followed by parent-owned whole-root/actual combined CI remain gates. This lane does not self-approve or claim release/combined-CI acceptance.

Harness-only incidents retained: the first dependency snapshot stopped at an AGENTS.md path **before reading it**; the successful snapshot explicitly uses metadata only there. An initial proof/receipt basename collision was corrected by regenerating proof under a distinct filename and replaying again in fresh `patch-replay-final/`; the initial run receipts remain. Neither incident changed product code or immutable input.

See `REPRODUCE.md` for runnable isolated commands, `RESULT.json` for machine-readable outcomes, `before-manifest.json` / `after-manifest.json` for all 251 source hashes, `path-preimages.json` for the two exact pre/post bindings, and `report-index.json` for delivered artifact hashes.
'''
(R/'REPORT.md').write_text(report)
locations={'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes','HERMES_ROOT':'hermes','HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge','XDG_CONFIG_HOME':'xdg/config','XDG_CACHE_HOME':'xdg/cache','XDG_DATA_HOME':'xdg/data','XDG_STATE_HOME':'xdg/state','HF_HOME':'hf','HF_HUB_CACHE':'hf/hub','TMPDIR':'tmp','TMP':'tmp','TEMP':'tmp'}
seed={k:str(R/v) for k,v in locations.items()}
seed.update({'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','QMD_LLAMA_GPU':'false','CI':'1','REQUIRE_BUN':'1','PYTHONDONTWRITEBYTECODE':'1','PATH':'/usr/bin:/bin'})
function='qmd_t2() {\n  /usr/bin/env -i \\\n'+''.join('    '+shlex.quote(k+'='+v)+' \\\n' for k,v in seed.items())+'    '+shlex.quote(PY)+' '+shlex.quote(str(R/'harness/run.py'))+' "$@"\n}\n'
sections=[]
for label in ['red-node-sparse-baseline','green-node-metric','green-bun-metric','green-node-focused13','green-bun-focused13','green-node-native-bun-wrappers','build-node-baseline','build-node-green','types-node-baseline','types-node-green','types-bun-green','source-emission']:
    rec=load('evidence/'+label+'.json')
    newlabel=('types-' if label.startswith('types-') else 'build-' if label.startswith('build-') else '')+'rerun-'+label
    argv=[a.replace('--outputFile.json=../evidence/'+label+'-results.json','--outputFile.json=../evidence/'+newlabel+'-results.json') for a in rec['argv']]
    cmd=['qmd_t2',newlabel,str(Path(rec['cwd']).relative_to(R)),*argv]
    sections.append('## '+label+'\n\n```sh\n'+shlex.join(cmd)+'\n```\n')
replaycmds=[['qmd_t2','rerun-copy-replay','.',PY,str(R/'harness/copy-replay.py'),'replay-rerun'],['qmd_t2','rerun-patch-check','replay-rerun','/usr/bin/git','apply','--check',str(R/'T2-metric-guards.patch')],['qmd_t2','rerun-patch-apply','replay-rerun','/usr/bin/git','apply',str(R/'T2-metric-guards.patch')],['qmd_t2','rerun-replay-verify','.',PY,str(R/'harness/verify-delivery.py'),'replay-rerun']]
reproduce='# Reproduce T2 in the owned derivative\n\nDo not run in the live checkout or original delivery. Paste this shell function once. Every spawned invocation begins with an empty environment and synthetic public-only HOME/Hermes/knowledge/XDG/HF/managed TMPDIR; the wrapper creates fresh per-label owned caches. Use unique new labels for repeat runs; listed workloads are serial and use <=2 workers. RED and strict-root commands are intentionally nonzero. Do not run setup/prove in place: they create exclusive fresh directories.\n\n```sh\n'+function+'```\n\n'+ '\n'.join(sections)+'\n## Fresh patch replay\n\nUse a fresh destination name if replay-rerun already exists. The helper copies only the 251 authenticated preimage source files, then actual git checks/applies the two-path patch.\n\n```sh\n'+'\n'.join(shlex.join(a) for a in replaycmds)+'\n```\n\n`source-emission` rewrites only deterministic owned emission/roots evidence. RED imports the unchanged baseline; GREEN imports the derivative. No command performs installation, model setup, registry access or live integration. Root checks retain/refuse historical absolute live imports. Native wrappers spawn actual installed Bun; their outer host is Node. Independent SPEC/QUALITY and actual combined CI are not performed here.\n'
(R/'REPRODUCE.md').write_text(reproduce)
# Index complete public evidence only; exclude the active finalizer receipt/logs
# and all source-tree outputs, caches and dependency aliases.
active=os.environ['QMD_RUN_LABEL']
index={}
for rel in ['REPORT.md','REPRODUCE.md','RESULT.json','before-manifest.json','after-manifest.json','path-preimages.json','T2-metric-guards.patch','mirror-isolated.config.mjs','held-isolated.config.mjs','held-red-isolated.config.mjs']:
    index[rel]=sha((R/rel).read_bytes())
for dirname in ['harness','probes','evidence','logs','reference','held','held-red']:
    for base,dirs,files in os.walk(R/dirname,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ['node_modules','.cache','.vite','.vitest','__pycache__']]
        for name in files:
            p=Path(base)/name
            if p.is_symlink():continue
            rel=str(p.relative_to(R))
            if rel in [f'evidence/{active}.json',f'logs/{active}.stdout.log',f'logs/{active}.stderr.log']:continue
            index[rel]=sha(p.read_bytes())
save('report-index.json',{'root':str(R),'status':result['status'],'artifact_count':len(index),'files':dict(sorted(index.items())),'notIndexed':['source trees and generated dist/caches','per-package read-use aliases and state',f'evidence/{active}.json',f'logs/{active}.stdout.log',f'logs/{active}.stderr.log'],'sourceManifest':'after-manifest.json'})
print(json.dumps({'status':result['status'],'patchSha256':patchhash,'reportIndexSha256':sha((R/'report-index.json').read_bytes()),'indexedArtifacts':len(index),'sourceFilesReplayedAndVerified':251,'runtimeResults':{k:{f:v[f] for f in ['exitCode','files','assertions']} for k,v in runtime.items()},'strictDiagnosticCounts':{k:v['diagnosticCount'] for k,v in types.items()},'dependencyPreservation':depreport,'report':str(R/'REPORT.md')},indent=2))
