from pathlib import Path
import hashlib, json, os, stat, shutil
ROOT = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
INPUT = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-compose-nd8v4x2p')
DEP = Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
def sha(b): return hashlib.sha256(b).hexdigest()
def data(p):
    assert not p.is_symlink(), str(p)
    assert stat.S_ISREG(p.stat().st_mode), str(p)
    return p.read_bytes()
def save(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2)+'\n')
assert os.environ['HOME'] == str(ROOT/'home')
assert os.environ['TMPDIR'] == str(ROOT/'tmp')
idxbytes=data(INPUT/'report-index.json')
assert sha(idxbytes)=='104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac'
index=json.loads(idxbytes)
checked={}
for rel,expected in index['files'].items():
    p=Path(rel)
    assert not p.is_absolute() and '..' not in p.parts and p.name!='AGENTS.md'
    actual=sha(data(INPUT/p))
    assert actual==expected,rel
    checked[rel]=actual
manifest=json.loads(data(INPUT/'after-manifest.json'))
sources=manifest['sourceSha256']
assert len(sources)==251
assert sources['scripts/phase5_e2e_runner.ts']=='6204b26a3a8218cd1da6ce03ec856065656d904cc9b936d9110900f8d79ac875'
assert sources['test/phase5-recovery.test.ts']=='9882a80d11235b31403fb897ea7bdb75597972256d323417b26e772cbddacff3'
for rel,expected in sources.items():
    p=Path(rel)
    assert not p.is_absolute() and '..' not in p.parts and p.name!='AGENTS.md'
    src=INPUT/'mirror'/p
    b=data(src)
    assert sha(b)==expected,rel
    for tree in ['baseline','mirror']:
        dst=ROOT/tree/p
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(b)
        dst.chmod(stat.S_IMODE(src.stat().st_mode))
auth=json.loads(data(INPUT/'evidence/authentication.json'))
assert len(auth['accepted19_sha256'])==19
for rel,expected in auth['accepted19_sha256'].items():
    b=data(INPUT/'reference/accepted19'/rel)
    assert sha(b)==expected,rel
    dst=ROOT/'reference/accepted19'/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(b)
for rel in ['reference/original-source.patch','reference/diffs/test__phase5-recovery.test.ts.diff','probes/test-host-setup.mjs','probes/compiler-read-guard.cjs','mirror-isolated.config.mjs']:
    dst=ROOT/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(data(INPUT/rel))
# Keep only the authorized runner segment as an executable apply payload.
runner=data(INPUT/'reference/original-source.patch').splitlines(keepends=True)[:57]
assert sum(x.startswith(b'@@') for x in runner)==5
(ROOT/'reference/runner-five-hunks.patch').write_bytes(b''.join(runner))
for sub in ['tools/bin','xdg/state','cache/bun','cache/npm','cache/pnpm','cache/node','cache/uv','cache/python','logs','held']:
    (ROOT/sub).mkdir(parents=True,exist_ok=True)
for name,target in [('node','/Users/shersingh/.hermes/node/bin/node'),('bun','/Users/shersingh/.bun/bin/bun')]:
    p=Path(target)
    assert p.is_file() and os.access(p,os.X_OK)
    (ROOT/'tools/bin'/name).symlink_to(p.resolve())
aliases={}
for entry in sorted(DEP.iterdir()):
    if entry.name.startswith('.'): continue
    packages=sorted(entry.iterdir()) if entry.name.startswith('@') else [entry]
    for p in packages:
        target=p.resolve(strict=True)
        assert target.is_relative_to(DEP.resolve()),str(target)
        if (target/'package.json').is_file():
            rel=p.relative_to(DEP)
            aliases[str(rel)]=str(target)
for tree in ['baseline','mirror','held']:
    nm=ROOT/tree/'node_modules'
    nm.mkdir()
    assert not nm.is_symlink()
    for name,target in aliases.items():
        dst=nm/name
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.symlink_to(target,target_is_directory=True)
    for name in ['.vite','.cache','.vitest']:
        (nm/name).mkdir()
        (ROOT/tree/name).mkdir()
    save(ROOT/'evidence'/f'{tree}-package-aliases.json',aliases)
# Relocate the authenticated older test to owned source-only imports for RED.
held=data(ROOT/'reference/accepted19/test/phase5-recovery.test.ts').decode()
for old,new in [('"./fixtures/public_eval_dataset.js"','"../mirror/test/fixtures/public_eval_dataset.js"'),('"../src/','"../mirror/src/'),('"../scripts/','"../mirror/scripts/')]:
    held=held.replace(old,new)
assert '/Users/' not in held
(ROOT/'held/phase5-recovery.test.ts').write_text(held)
(ROOT/'held/package.json').write_text('{"type":"module","private":true}\n')
(ROOT/'held-isolated.config.mjs').write_text("import { mergeConfig } from './mirror/node_modules/vitest/dist/config.js';\nimport project from './mirror/vitest.config.ts';\nimport { fileURLToPath } from 'node:url';\nexport default mergeConfig(project, { root:fileURLToPath(new URL('./held/',import.meta.url)), cacheDir:process.env.VITE_CACHE_DIR, test:{ setupFiles:[fileURLToPath(new URL('./probes/test-host-setup.mjs',import.meta.url))] } });\n")
save(ROOT/'before-manifest.json',{'sourceCount':251,'sourceSha256':sources,'inputManifestSha256':sha(data(INPUT/'after-manifest.json'))})
save(ROOT/'evidence/authentication.json',{'inputRoot':str(INPUT),'inputIndexSha256':sha(idxbytes),'indexedArtifactsVerified':len(checked),'indexedArtifactSha256':checked,'sourceCount':251,'accepted19Sha256':auth['accepted19_sha256'],'leaseBaselineChecks':auth['lease_baseline_checks'],'aliasCount':len(aliases),'ownedCachesBeforeRed':True})
print(json.dumps({'root':str(ROOT),'indexedArtifactsVerified':len(checked),'sourceCount':len(sources),'accepted19Verified':len(auth['accepted19_sha256']),'aliasCount':len(aliases),'ownedCachesBeforeRed':True},indent=2))
