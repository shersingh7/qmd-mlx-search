from pathlib import Path
import json,hashlib
R=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
a=json.loads((R/'evidence/mirror-package-aliases.json').read_text())
fixture=R/'held-red';fixture.mkdir()
nm=fixture/'node_modules';nm.mkdir()
for name,target in a.items():
    p=nm/name;p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(target,target_is_directory=True)
for name in ['.vite','.cache','.vitest']:
    (nm/name).mkdir();(fixture/name).mkdir()
(fixture/'package.json').write_text('{"type":"module","private":true}\n')
source=(R/'reference/accepted19/test/phase5-recovery.test.ts').read_text()
replacements=[('"./fixtures/public_eval_dataset.js"','"../baseline/test/fixtures/public_eval_dataset.js"'),('"../src/','"../baseline/src/'),('"../scripts/','"../baseline/scripts/')]
for old,new in replacements:
    assert old in source
    source=source.replace(old,new)
assert '/Users/' not in source
(fixture/'phase5-recovery.test.ts').write_text(source)
(R/'held-red-isolated.config.mjs').write_text("import { mergeConfig } from './mirror/node_modules/vitest/dist/config.js';\nimport project from './mirror/vitest.config.ts';\nimport { fileURLToPath } from 'node:url';\nexport default mergeConfig(project,{root:fileURLToPath(new URL('./held-red/',import.meta.url)),cacheDir:process.env.VITE_CACHE_DIR,test:{include:['*.test.ts'],setupFiles:[fileURLToPath(new URL('./probes/test-host-setup.mjs',import.meta.url))]}});\n")
receipt={'acceptedTestSha256':hashlib.sha256((R/'reference/accepted19/test/phase5-recovery.test.ts').read_bytes()).hexdigest(),'relocatedTestSha256':hashlib.sha256(source.encode()).hexdigest(),'onlyReplacements':replacements,'baselineRunnerSha256':hashlib.sha256((R/'baseline/scripts/phase5_e2e_runner.ts').read_bytes()).hexdigest(),'aliasCount':len(a),'realNodeModulesContainer':not nm.is_symlink(),'ownedCachesReadyBeforeRed':True}
(R/'evidence/red-baseline-relocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
