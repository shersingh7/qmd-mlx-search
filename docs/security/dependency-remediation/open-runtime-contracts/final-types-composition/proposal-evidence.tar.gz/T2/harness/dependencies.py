from pathlib import Path
import os,stat,hashlib,json,sys
ROOT=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1')
DEP=Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
label=sys.argv[1]
assert label in ['before','after']
rows={}
for parent,dirs,files in os.walk(DEP,followlinks=False):
    for name in sorted(dirs+files):
        p=Path(parent)/name
        s=p.lstat()
        row={'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'mode':s.st_mode,'ino':s.st_ino,'dev':s.st_dev,'uid':s.st_uid,'gid':s.st_gid}
        if p.is_symlink(): row['link']=os.readlink(p)
        elif stat.S_ISREG(s.st_mode):
            # Dependency package bytes only; never discover project context.
            if p.name=='AGENTS.md':
                row['content_read_refused']='AGENTS.md excluded by task scope; metadata only'
                rows[str(p.relative_to(DEP))]=row
                continue
            h=hashlib.sha256()
            with p.open('rb') as f:
                for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
            row['sha256']=h.hexdigest()
        rows[str(p.relative_to(DEP))]=row
p=ROOT/'evidence'/f'dependencies-{label}.json'
p.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
summary={'entries':len(rows),'files':sum('sha256' in r for r in rows.values()),'manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
if label=='after':
    old=json.loads((ROOT/'evidence/dependencies-before.json').read_text())
    summary['changed']=[k for k in sorted(set(old)|set(rows)) if old.get(k)!=rows.get(k)]
    (ROOT/'evidence/dependency-preservation.json').write_text(json.dumps(summary,indent=2)+'\n')
    assert not summary['changed'],summary['changed']
print(json.dumps(summary,indent=2))
