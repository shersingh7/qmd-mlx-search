# Reproduce T2 in the owned derivative

Do not run in the live checkout or original delivery. Paste this shell function once. Every spawned invocation begins with an empty environment and synthetic public-only HOME/Hermes/knowledge/XDG/HF/managed TMPDIR; the wrapper creates fresh per-label owned caches. Use unique new labels for repeat runs; listed workloads are serial and use <=2 workers. RED and strict-root commands are intentionally nonzero. Do not run setup/prove in place: they create exclusive fresh directories.

```sh
qmd_t2() {
  /usr/bin/env -i \
    HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/home \
    HERMES_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/hermes \
    HERMES_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/hermes \
    HERMES_ROOT=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/hermes \
    HERMES_KNOWLEDGE_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/knowledge \
    KNOWLEDGE_DIR=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/knowledge \
    XDG_CONFIG_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/xdg/config \
    XDG_CACHE_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/xdg/cache \
    XDG_DATA_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/xdg/data \
    XDG_STATE_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/xdg/state \
    HF_HOME=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/hf \
    HF_HUB_CACHE=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/hf/hub \
    TMPDIR=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/tmp \
    TMP=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/tmp \
    TEMP=/Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/tmp \
    HF_HUB_OFFLINE=1 \
    TRANSFORMERS_OFFLINE=1 \
    HF_DATASETS_OFFLINE=1 \
    UV_OFFLINE=1 \
    QMD_LLAMA_GPU=false \
    CI=1 \
    REQUIRE_BUN=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PATH=/usr/bin:/bin \
    /Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python /Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/harness/run.py "$@"
}
```

## red-node-sparse-baseline

```sh
qmd_t2 rerun-red-node-sparse-baseline held-red /Users/shersingh/.hermes/node/bin/node ../mirror/node_modules/vitest/vitest.mjs run --config ../held-red-isolated.config.mjs --no-cache --maxWorkers=1 --reporter=dot --reporter=json --outputFile.json=../evidence/rerun-red-node-sparse-baseline-results.json '--testNamePattern=refuses missing query slots' phase5-recovery.test.ts
```

## green-node-metric

```sh
qmd_t2 rerun-green-node-metric mirror /Users/shersingh/.hermes/node/bin/node node_modules/vitest/vitest.mjs run --config ../mirror-isolated.config.mjs --no-cache --maxWorkers=1 --reporter=dot --reporter=json --outputFile.json=../evidence/rerun-green-node-metric-results.json test/phase5-recovery.test.ts
```

## green-bun-metric

```sh
qmd_t2 rerun-green-bun-metric mirror /Users/shersingh/.bun/bin/bun --bun node_modules/vitest/vitest.mjs run --config ../mirror-isolated.config.mjs --no-cache --maxWorkers=1 --reporter=dot --reporter=json --outputFile.json=../evidence/rerun-green-bun-metric-results.json test/phase5-recovery.test.ts
```

## green-node-focused13

```sh
qmd_t2 rerun-green-node-focused13 mirror /Users/shersingh/.hermes/node/bin/node node_modules/vitest/vitest.mjs run --config ../mirror-isolated.config.mjs --no-cache --maxWorkers=2 --reporter=dot --reporter=json --outputFile.json=../evidence/rerun-green-node-focused13-results.json test/audit-llm-cleanup-review.test.ts test/audit-llm-deadline-review.test.ts test/audit-llm-lifecycle.test.ts test/bench-rerank-entrypoint.test.ts test/bench-rerank-lifecycle.test.ts test/eval-bm25.test.ts test/eval.test.ts test/llm.test.ts test/multi-collection-filter.test.ts test/phase5-recovery.test.ts test/rrf-trace.test.ts test/store.helpers.unit.test.ts test/zod-import.test.ts
```

## green-bun-focused13

```sh
qmd_t2 rerun-green-bun-focused13 mirror /Users/shersingh/.bun/bin/bun --bun node_modules/vitest/vitest.mjs run --config ../mirror-isolated.config.mjs --no-cache --maxWorkers=2 --reporter=dot --reporter=json --outputFile.json=../evidence/rerun-green-bun-focused13-results.json test/audit-llm-cleanup-review.test.ts test/audit-llm-deadline-review.test.ts test/audit-llm-lifecycle.test.ts test/bench-rerank-entrypoint.test.ts test/bench-rerank-lifecycle.test.ts test/eval-bm25.test.ts test/eval.test.ts test/llm.test.ts test/multi-collection-filter.test.ts test/phase5-recovery.test.ts test/rrf-trace.test.ts test/store.helpers.unit.test.ts test/zod-import.test.ts
```

## green-node-native-bun-wrappers

```sh
qmd_t2 rerun-green-node-native-bun-wrappers mirror /Users/shersingh/.hermes/node/bin/node node_modules/vitest/vitest.mjs run --config ../mirror-isolated.config.mjs --no-cache --maxWorkers=1 --reporter=dot --reporter=json --outputFile.json=../evidence/rerun-green-node-native-bun-wrappers-results.json test/audit-native-bun-recovery.test.ts
```

## build-node-baseline

```sh
qmd_t2 build-rerun-build-node-baseline baseline /Users/shersingh/.hermes/node/bin/node scripts/build.mjs
```

## build-node-green

```sh
qmd_t2 build-rerun-build-node-green mirror /Users/shersingh/.hermes/node/bin/node scripts/build.mjs
```

## types-node-baseline

```sh
qmd_t2 types-rerun-types-node-baseline baseline /Users/shersingh/.hermes/node/bin/node node_modules/typescript/bin/tsc -p tsconfig.json --noEmit --pretty false
```

## types-node-green

```sh
qmd_t2 types-rerun-types-node-green mirror /Users/shersingh/.hermes/node/bin/node node_modules/typescript/bin/tsc -p tsconfig.json --noEmit --pretty false
```

## types-bun-green

```sh
qmd_t2 types-rerun-types-bun-green mirror /Users/shersingh/.bun/bin/bun --preload ../probes/compiler-read-guard.cjs node_modules/typescript/bin/tsc -p tsconfig.json --noEmit --pretty false
```

## source-emission

```sh
qmd_t2 rerun-source-emission mirror /Users/shersingh/.hermes/node/bin/node ../probes/emission.mjs
```

## Fresh patch replay

Use a fresh destination name if replay-rerun already exists. The helper copies only the 251 authenticated preimage source files, then actual git checks/applies the two-path patch.

```sh
qmd_t2 rerun-copy-replay . /Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python /Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/harness/copy-replay.py replay-rerun
qmd_t2 rerun-patch-check replay-rerun /usr/bin/git apply --check /Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/T2-metric-guards.patch
qmd_t2 rerun-patch-apply replay-rerun /usr/bin/git apply /Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/T2-metric-guards.patch
qmd_t2 rerun-replay-verify . /Users/shersingh/.hermes/cache/scratch/qmd-dependency-remediation/security-venv/bin/python /Users/shersingh/.hermes/cache/scratch/qmd-types-metrics-ppnll4m1/harness/verify-delivery.py replay-rerun
```

`source-emission` rewrites only deterministic owned emission/roots evidence. RED imports the unchanged baseline; GREEN imports the derivative. No command performs installation, model setup, registry access or live integration. Root checks retain/refuse historical absolute live imports. Native wrappers spawn actual installed Bun; their outer host is Node. Independent SPEC/QUALITY and actual combined CI are not performed here.
