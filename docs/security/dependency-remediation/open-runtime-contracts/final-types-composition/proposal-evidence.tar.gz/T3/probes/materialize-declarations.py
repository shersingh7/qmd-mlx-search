from pathlib import Path, PurePosixPath
import sys, json, tarfile, hashlib, base64
R=Path(__file__).resolve().parents[1]
target=R/(sys.argv[1] if len(sys.argv)>1 else 'mirror')
assert target.resolve().is_relative_to(R) and (target/'node_modules').is_dir()
rows=json.loads((R/'evidence/declaration-tarballs.json').read_text())
graph=json.loads((R/'evidence/graph-delta.json').read_text())
installed=[]
for row in rows:
    archive=R/'reference'/Path(row['archive']).name;data=archive.read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['sha256']
    assert 'sha512-'+base64.b64encode(hashlib.sha512(data).digest()).decode()==row['integrity']
    assert graph['newRecords']['pnpm'][row['name']+'@'+row['version']]['resolution']['integrity']==row['integrity']
    assert graph['newRecords']['bun'][row['name']][-1]==row['integrity']
    out=target/'node_modules'/row['name']
    assert not out.exists() and not out.is_symlink(),out
    files={};omitted=[]
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers()
        directoryMembers=[m.name for m in members if m.isdir()]
        prefixes={PurePosixPath(m.name).parts[0] for m in members}
        assert len(prefixes)==1
        for m in members:
            p=PurePosixPath(m.name)
            assert not p.is_absolute() and '..' not in p.parts and (m.isfile() or m.isdir())
            if not m.isfile():continue
            rel=Path(*p.parts[1:]);value=tar.extractfile(m).read()
            selected=str(rel).endswith(('.d.ts','.d.cts','.d.mts')) or str(rel) in ['package.json','README.md','LICENSE','LICENSE.md']
            if not selected:
                assert rel.suffix in ['.md','.mdx'],rel
                omitted.append(str(rel));continue
            dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(value);dst.chmod(0o444)
            files[str(rel)]={'sha256':hashlib.sha256(value).hexdigest(),'size':len(value)}
    package=json.loads((out/'package.json').read_text())
    assert package['name']==row['name'] and package['version']==row['version']
    assert package.get('types') and (out/package['types']).is_file()
    installed.append({'name':row['name'],'version':row['version'],'root':str(out),'archiveSha256':row['sha256'],'integrity':row['integrity'],'packageJsonSha256':files['package.json']['sha256'],'files':files,'omittedDocumentation':omitted,'tarDirectoryMembers':directoryMembers,'tarFileAndDirectoryCount':row['fileCount']+len(directoryMembers),'registryFileCount':row['registryFileCount'],'scriptsPresentButNotExecuted':package.get('scripts',{}),'dependencies':package.get('dependencies',{})})
path=R/'evidence'/f'{target.name}-installed-declarations.json'
path.write_text(json.dumps(installed,indent=2)+'\n')
print(json.dumps([{key:value for key,value in x.items() if key not in ['files','omittedDocumentation']}|{'materializedFileCount':len(x['files']),'omittedDocumentationCount':len(x['omittedDocumentation'])} for x in installed],indent=2))
