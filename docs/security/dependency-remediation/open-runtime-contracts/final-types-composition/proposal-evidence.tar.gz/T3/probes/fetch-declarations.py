from pathlib import Path, PurePosixPath
import urllib.request, urllib.parse, json, hashlib, base64, tarfile, io
R=Path(__file__).resolve().parents[1]
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
items=[json.loads((R/'reference/types-bun-1.3.8.metadata.json').read_text()),json.loads((R/'reference/bun-types-1.3.8.metadata.json').read_text()),json.loads((R/'reference/types-picomatch.metadata.json').read_text())['versions']['4.0.3']]
records=[]
for metadata in items:
    name,version=metadata['name'],metadata['version']
    assert (name,version) in [('@types/bun','1.3.8'),('bun-types','1.3.8'),('@types/picomatch','4.0.3')]
    url=metadata['dist']['tarball']
    assert urllib.parse.urlparse(url).hostname=='registry.npmjs.org' and url.endswith('.tgz')
    label=name.replace('@','').replace('/','-')+'-'+version
    archive=R/'reference'/f'{label}.tgz'
    if archive.exists():
        data=archive.read_bytes()
    else:
        req=urllib.request.Request(url,headers={'User-Agent':'qmd-declarations-repair-integrity-check'})
        with opener.open(req,timeout=60) as res:
            assert res.url==url
            data=res.read()
    integrity='sha512-'+base64.b64encode(hashlib.sha512(data).digest()).decode()
    assert integrity==metadata['dist']['integrity']
    assert hashlib.sha1(data).hexdigest()==metadata['dist']['shasum']
    label=name.replace('@','').replace('/','-')+'-'+version
    archive=R/'reference'/f'{label}.tgz';archive.write_bytes(data)
    listing=[]
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
        for member in tar.getmembers():
            rel=PurePosixPath(member.name)
            assert not rel.is_absolute() and '..' not in rel.parts and not member.issym() and not member.islnk()
            assert member.isdir() or member.isfile(), member.name
            if member.isfile():
                value=tar.extractfile(member).read()
                listing.append({'path':member.name,'size':len(value),'sha256':hashlib.sha256(value).hexdigest(),'declaration':member.name.endswith(('.d.ts','.d.cts','.d.mts'))})
    (R/'reference'/f'{label}.members.json').write_text(json.dumps(listing,indent=2)+'\n')
    record={'name':name,'version':version,'url':url,'archive':str(archive),'sha256':hashlib.sha256(data).hexdigest(),'integrity':integrity,'sha1':metadata['dist']['shasum'],'bytes':len(data),'fileCount':len(listing),'declarationCount':sum(x['declaration'] for x in listing),'otherFiles':[x['path'] for x in listing if not x['declaration']]}
    record['registryFileCount']=metadata['dist']['fileCount']
    record['registryUnpackedSize']=metadata['dist']['unpackedSize']
    record['verifiedUnpackedSize']=sum(x['size'] for x in listing)
    record['fileCountMatchesMetadata']=record['fileCount']==record['registryFileCount']
    assert record['verifiedUnpackedSize']==record['registryUnpackedSize']
    records.append(record)
(R/'evidence/declaration-tarballs.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
