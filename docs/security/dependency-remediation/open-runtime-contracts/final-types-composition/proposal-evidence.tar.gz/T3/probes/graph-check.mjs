import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const R=process.env.QMD_DECLARATIONS_ROOT;
const require=createRequire(path.join(R,'mirror/package.json'));
const ts=require('typescript');
const yaml=require('yaml');
const hash=await import('node:crypto');
const digest=p=>hash.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const stable=o=>JSON.stringify(o&&typeof o==='object'?(Array.isArray(o)?o.map(v=>JSON.parse(stable(v))):Object.fromEntries(Object.keys(o).sort().map(k=>[k,JSON.parse(stable(o[k]))]))):o);
const same=(a,b)=>stable(a)===stable(b);
const diff=(a,b)=>({added:Object.keys(b).filter(k=>!(k in a)),removed:Object.keys(a).filter(k=>!(k in b)),changed:Object.keys(a).filter(k=>k in b&&!same(a[k],b[k])).map(k=>({key:k,before:a[k],after:b[k]}))});
const load=(where,file)=>{
  const text=fs.readFileSync(path.join(R,where,file),'utf8');
  if(file.endsWith('.yaml'))return yaml.parse(text);
  if(file==='bun.lock'){const r=ts.parseConfigFileTextToJson(file,text);if(r.error)throw new Error('bun JSON parse');return r.config;}
  return JSON.parse(text);
};
const before=Object.fromEntries(['package.json','pnpm-lock.yaml','bun.lock'].map(f=>[f,load('evidence/preimages',f)]));
const after=Object.fromEntries(['package.json','pnpm-lock.yaml','bun.lock'].map(f=>[f,load('mirror',f)]));
const result={productHashes:Object.fromEntries(Object.keys(before).map(f=>[f,{before:digest(path.join(R,'evidence/preimages',f)),after:digest(path.join(R,'mirror',f))}])),packageDiff:diff(before['package.json'],after['package.json']),pnpm:{packages:diff(before['pnpm-lock.yaml'].packages,after['pnpm-lock.yaml'].packages),snapshots:diff(before['pnpm-lock.yaml'].snapshots,after['pnpm-lock.yaml'].snapshots),importer:diff(before['pnpm-lock.yaml'].importers['.'],after['pnpm-lock.yaml'].importers['.'])},bun:{packages:diff(before['bun.lock'].packages,after['bun.lock'].packages),workspace:diff(before['bun.lock'].workspaces[''],after['bun.lock'].workspaces[''])}};
for(const field of ['dependencies','optionalDependencies','peerDependencies','scripts'])if(!same(before['package.json'][field],after['package.json'][field]))throw new Error('unexpected package field delta '+field);
result.runtimePackageFieldsUnchanged=true;
result.counts={pnpmBefore:Object.keys(before['pnpm-lock.yaml'].packages).length,pnpmAfter:Object.keys(after['pnpm-lock.yaml'].packages).length,bunBefore:Object.keys(before['bun.lock'].packages).length,bunAfter:Object.keys(after['bun.lock'].packages).length};
result.newRecords={pnpm:Object.fromEntries(result.pnpm.packages.added.map(k=>[k,after['pnpm-lock.yaml'].packages[k]])),snapshots:Object.fromEntries(result.pnpm.snapshots.added.map(k=>[k,after['pnpm-lock.yaml'].snapshots[k]])),bun:Object.fromEntries(result.bun.packages.added.map(k=>[k,after['bun.lock'].packages[k]]))};
const expected=['@types/bun@1.3.8','@types/picomatch@4.0.3','bun-types@1.3.8'].sort();
for(const [label,d] of Object.entries({pnpm:result.pnpm.packages,snapshots:result.pnpm.snapshots})){
  if(d.changed.length||d.removed.length||!same([...d.added].sort(),expected))throw new Error('unexpected '+label+' graph delta');
}
if(result.bun.packages.changed.length||result.bun.packages.removed.length||!same([...result.bun.packages.added].sort(),['@types/bun','@types/picomatch','bun-types']))throw new Error('unexpected Bun graph delta');
for(const section of ['dependencies','devDependencies','optionalDependencies','peerDependencies']){
  if(!same(after['package.json'][section]??{},after['bun.lock'].workspaces[''][section]??{}))throw new Error('Bun direct metadata mismatch '+section);
  if(section==='peerDependencies')continue;
  const importer=after['pnpm-lock.yaml'].importers['.'][section]??{};
  if(!same(Object.keys(importer).sort(),Object.keys(after['package.json'][section]??{}).sort()))throw new Error('pnpm direct keys mismatch '+section);
  for(const [name,specifier] of Object.entries(after['package.json'][section]??{}))if(importer[name].specifier!==specifier)throw new Error('pnpm direct requirement mismatch '+name);
}
const inventories=which=>({pnpm:[...new Set(Object.keys(which['pnpm-lock.yaml'].packages))].sort(),bun:[...new Set(Object.values(which['bun.lock'].packages).map(v=>v[0]))].sort()});
const invBefore=inventories(before),invAfter=inventories(after);
const discrepancy=inv=>({onlyPnpm:inv.pnpm.filter(x=>!inv.bun.includes(x)),onlyBun:inv.bun.filter(x=>!inv.pnpm.includes(x))});
result.inventory={before:discrepancy(invBefore),after:discrepancy(invAfter),uniqueCounts:{pnpmBefore:invBefore.pnpm.length,pnpmAfter:invAfter.pnpm.length,bunBefore:invBefore.bun.length,bunAfter:invAfter.bun.length}};
if(!same(result.inventory.before,result.inventory.after))throw new Error('introduced cross-manager inventory discrepancy');
result.allExistingRecordsAndIntegrityPreserved=true;
result.directMetadataConsistent=true;
fs.writeFileSync(path.join(R,'evidence/graph-delta.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
