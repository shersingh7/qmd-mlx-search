"""Seal explicit delivery artifacts; operational caches are not deliverables."""
from pathlib import Path
import json, hashlib
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def artifacts(base):
    paths=[]
    for rel in ['REPORT.md','REPRODUCE.md','run']:
        if (base/rel).is_file():paths.append(base/rel)
    for prefix in ['configs','probes','evidence','logs','reference']:
        paths.extend(p for p in (base/prefix).rglob('*') if p.is_file() and p!=base/'evidence/report-index.json')
    profiles={}
    for p in (base/'evidence').glob('*.json'):
        value=load(p)
        if isinstance(value,dict) and isinstance(value.get('argv'),list) and value['argv'][:2]==['/usr/bin/sandbox-exec','-f']:
            profile=Path(value['argv'][2]);assert profile.resolve().is_relative_to(base) and profile.is_file() and not profile.is_symlink()
            paths.append(profile);profiles[str(profile.relative_to(base))]=sha(profile)
    out={}
    for p in paths:
        assert not p.is_symlink() and p.resolve().is_relative_to(base),p
        out[str(p.relative_to(base))]=sha(p)
    return dict(sorted(out.items())),profiles
result=load(R/'evidence/result.json')
proof=load(R/'evidence/offline-reproduction-binding.json');repro=Path(proof['root'])
assert repro.is_relative_to('/Users/shersingh/.hermes/cache/scratch') and repro.name.startswith('qmd-types-declarations-repro-')
assert sha(Path(proof['result']))==proof['resultSha256']
reference=load(R/'evidence/mirror-source-after.json')['sourceSha256']
actual={name:sha(repro/'mirror'/name) for name in reference};assert actual==reference and len(actual)==251
reproArtifacts,reproProfiles=artifacts(repro)
generated={str(p.relative_to(repro/'mirror')):sha(p) for p in (repro/'mirror/dist').rglob('*') if p.is_file()}
assert len(generated)==48 and all(value==sha(R/'mirror'/name) for name,value in generated.items())
installed={}
for row in load(repro/'evidence/mirror-installed-declarations.json'):
    for rel,binding in row['files'].items():
        name=str(Path('node_modules')/row['name']/rel)
        installed[name]=sha(repro/'mirror'/name);assert installed[name]==binding['sha256']
external={'root':str(repro),'artifactCount':len(reproArtifacts),'artifactSha256':reproArtifacts,'sandboxProfilesSha256':reproProfiles,'sourceCount':len(actual),'sourceSha256':actual,'generatedCount':len(generated),'generatedSha256':generated,'installedDeclarationFileCount':len(installed),'installedDeclarationSha256':installed,'resultSha256':proof['resultSha256']}
(R/'evidence/offline-reproduction-artifacts.json').write_text(json.dumps(external,indent=2,sort_keys=True)+'\n')
files,profiles=artifacts(R)
index={'root':str(R),'status':result['status'],'artifactCount':len(files),'artifactSha256':files,'sandboxProfilesSha256':profiles,'sourceCountPerTree':result['sourceCount'],'sourceManifests':['evidence/source-before.json','evidence/mirror-source-after.json','evidence/replay-source-before.json','evidence/replay-source-after.json'],'generatedManifests':['evidence/replay-generated-baseline.json','evidence/replay-generated-after.json'],'installedDeclarationManifests':['evidence/mirror-installed-declarations.json','evidence/replay-installed-declarations.json'],'productPatch':result['patch'],'ownedOfflineReproductionManifest':'evidence/offline-reproduction-artifacts.json','excludedOperationalPrefixes':['cache','state (except exact executed sandbox profiles)','tmp','tools','home','hermes','knowledge','hf','xdg'],'selfExcluded':'evidence/report-index.json'}
path=R/'evidence/report-index.json';path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
print(json.dumps({'root':str(R),'artifactCount':len(files),'index':str(path),'indexSha256':sha(path),'externalOwnedReproductionArtifactCount':len(reproArtifacts),'sourceCountPerTree':result['sourceCount'],'patchSha256':result['patch']['sha256'],'status':result['status']},indent=2))
