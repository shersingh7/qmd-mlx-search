from pathlib import Path
import os, json, hashlib, re, importlib.util, collections
from datetime import datetime, timezone
R=Path(__file__).resolve().parents[1]
def load(rel):return json.loads((R/rel).read_text())
def save(rel,obj):(R/rel).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=load('evidence/source-before.json')['sourceSha256']
changes=['bun.lock','package.json','pnpm-lock.yaml']
expectedBefore={'package.json':'ae1aa01c0275dcabb174872a6a2b5ef24518c15f109796236a76d321805c3eaa','pnpm-lock.yaml':'fe935e0afa6f90131e21b1ad295d4cc9acbdfd8c68cde6a46ba1acd07dc0c42a','bun.lock':'484035b1459455e18d7aac3e7b5fb8d8b671c77021ad43243b8ba0961277a719'}
assert len(before)==251
sourceHashes={}
for name in ['mirror','replay']:
    base=R/name
    actual={k:sha(base/k) for k in before}
    assert sorted(k for k in actual if actual[k]!=before[k])==changes
    discovered=[]
    for root,dirs,files in os.walk(base,followlinks=False):
        dirs[:]=[d for d in dirs if not (Path(root)==base and d in ['node_modules','dist'])]
        discovered.extend(str((Path(root)/f).relative_to(base)) for f in files)
    assert set(discovered)==set(before),(name,set(discovered)-set(before))
    sourceHashes[name]=actual
    save(f'evidence/{name}-source-after.json',{'sourceCount':len(actual),'sourceSha256':actual,'changedPaths':changes})
assert sourceHashes['mirror']==sourceHashes['replay']
assert all(before[k]==v and sha(R/'evidence/preimages'/k)==v for k,v in expectedBefore.items())
graph=load('evidence/graph-delta.json')
for k,row in graph['productHashes'].items():assert sha(R/'mirror'/k)==row['after'] and row['before']==expectedBefore[k]
assert graph['allExistingRecordsAndIntegrityPreserved'] and graph['directMetadataConsistent']
assert graph['inventory']['before']==graph['inventory']['after']=={'onlyPnpm':[],'onlyBun':[]}
shared=Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
spec=importlib.util.spec_from_file_location('owned_bootstrap',R/'probes/bootstrap.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
sharedAfter=mod.snapshot(shared);sharedBefore=load('evidence/shared-dependencies-before.json')
save('evidence/shared-dependencies-after.json',sharedAfter)
assert sharedBefore==sharedAfter,'shared dependency bytes/stat metadata changed'
aliases=load('evidence/mirror-package-aliases.json');assert len(aliases)==274
for tree in ['mirror','replay']:
    nm=R/tree/'node_modules';assert nm.is_dir() and not nm.is_symlink()
    for name,target in aliases.items():assert (nm/name).is_symlink() and os.readlink(nm/name)==target
    for sub in ['.vite','.cache','.vitest']:assert (nm/sub).is_dir() and not (nm/sub).is_symlink()
    installed=load(f'evidence/{tree}-installed-declarations.json')
    for row in installed:
        assert row['tarFileAndDirectoryCount']==row['registryFileCount']
        base=nm/row['name'];assert base.is_dir() and not base.is_symlink()
        for rel,binding in row['files'].items():assert sha(base/rel)==binding['sha256'] and (base/rel).stat().st_size==binding['size']
        actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
        assert actual==set(row['files'])
        assert graph['newRecords']['pnpm'][row['name']+'@'+row['version']]['resolution']['integrity']==row['integrity']==graph['newRecords']['bun'][row['name']][-1]
# Compare actual compiler CLI diagnostics, not inferred absence of errors.
rx=re.compile(r'^(.+?)\((\d+),(\d+)\): error TS(\d+): (.+)$',re.M)
def diagnostics(label):
    return [{'file':m[0],'line':int(m[1]),'column':int(m[2]),'code':int(m[3]),'message':m[4]} for m in rx.findall((R/'logs'/f'{label}.stdout.log').read_text())]
canonical=[]
for tree,suffix in [('mirror',''),('replay','-replay')]:
    for host in ['node','bun']:
        b=f'types-{host}{suffix}-baseline';a=f'types-{host}{suffix}-after'
        bd,ad=diagnostics(b),diagnostics(a)
        assert len(bd)==35 and len(ad)==31
        assert all(x['file']=='scripts/phase5_e2e_runner.ts' for x in ad)
        retained=[x for x in bd if x['file']=='scripts/phase5_e2e_runner.ts']
        assert retained==ad
        removed=[x for x in bd if x not in ad]
        assert sorted((x['file'],x['code']) for x in removed)==[('migrate-schema.ts',2307),('src/db.ts',7017),('src/store.ts',7016),('src/test-preload.ts',2307)]
        for label in [b,a]:assert load('evidence/'+label+'.json')['exit_code']==2
        guards=[]
        for label in [b,a]:
            rows=[json.loads(line) for p in (R/'evidence').glob(label+'-compiler-reads-*.jsonl') for line in p.read_text().splitlines()]
            denied=[x for x in rows if x.get('allowed') is False]
            expectedDenied={str(shared.parent/'package.json'),str(shared.parent/'src/mcp/server.ts')}
            assert len(denied)==2 and {x['lexical'] for x in denied}==expectedDenied
            hosts=[x for x in rows if x.get('kind')=='compiler-host'];assert len(hosts)==1
            if host=='bun':assert hosts[0]['versions'].get('bun')=='1.3.8' and hosts[0]['execPath']=='/Users/shersingh/.bun/bin/bun'
            else:assert hosts[0]['versions'].get('node')=='22.22.3' and hosts[0]['execPath']=='/Users/shersingh/.hermes/node/bin/node'
            guards.append({'label':label,'readCount':sum('operation' in x for x in rows),'denied':denied,'host':hosts[0]})
        canonical.append({'tree':tree,'host':host,'beforeLabel':b,'afterLabel':a,'beforeCount':len(bd),'afterCount':len(ad),'removed':removed,'retainedRunnerDiagnostics':ad,'readguards':guards})
rootLabels=['roots-node-baseline','roots-node-after','roots-node-replay-baseline','roots-node-replay-after']
roots=[load('logs/'+label+'.stdout.log') for label in rootLabels]
assert all(x==roots[0] for x in roots) and len(roots[0]['files'])==153
save('evidence/canonical-root-selection.json',{'rootCount':153,'showConfig':roots[0],'labels':rootLabels,'unchanged':True})
for label in ['resolution-node','resolution-bun']:
    x=load('evidence/'+label+'-bindings.json');assert x['rootCount']==153 and x['compilerVersion']=='5.9.3' and len(x['diagnostics'])==31
    assert x['installed']['@types/bun']['version']=='1.3.8' and x['installed']['bun-types']['version']=='1.3.8' and x['installed']['@types/picomatch']['version']=='4.0.3'
    assert not x['bunAccess'][0]['isAny']
requiredZero=['lock-pnpm-regenerate','lock-bun-regenerate','frozen-pnpm','frozen-bun','frozen-pnpm-replay','frozen-bun-replay','build-node-before','build-node-after','build-node-replay-baseline','build-node-replay-after','patch-apply-check','patch-apply','patch-reverse-check','test-dependency-locks-runner','resolution-node','resolution-bun']
assert all(load('evidence/'+label+'.json')['exit_code']==0 for label in requiredZero)
for label in ['control-pnpm-stale','control-bun-stale-removed']:assert load('evidence/'+label+'.json')['exit_code']==1
assert 'ERR_PNPM_OUTDATED_LOCKFILE' in (R/'logs/control-pnpm-stale.stdout.log').read_text()
assert 'lockfile had changes, but lockfile is frozen' in (R/'logs/control-bun-stale-removed.stderr.log').read_text()
tests=load('evidence/dependency-locks-results.json');assert tests['success'] and tests['numTotalTests']==tests['numPassedTests']==5 and tests['numFailedTests']==tests['numPendingTests']==0
emittedBefore=load('evidence/replay-generated-baseline.json');emittedAfter=load('evidence/replay-generated-after.json')
assert emittedBefore==emittedAfter and emittedAfter['artifactCount']==48
for rel,row in emittedAfter['artifacts'].items():assert sha(R/'mirror'/rel)==row['sha256']==sha(R/'replay'/rel)
storeFiles=[p for p in (R/'cache/pnpm-store').rglob('*') if p.is_file()]
bunFiles=[p for p in (R/'cache/bun').rglob('*') if p.is_file()]
assert not storeFiles and bunFiles and all(p.suffix=='.npm' for p in bunFiles)
pmRows=[json.loads(x) for x in (R/'logs/lock-pnpm-regenerate.stdout.log').read_text().splitlines()]
assert not any(any(t in x.get('name','') for t in ['fetch','download','lifecycle']) for x in pmRows)
pmStatuses=dict(collections.Counter(x.get('status') for x in pmRows if x.get('name')=='pnpm:progress'))
assert pmStatuses=={'resolved':375}
requests=re.findall(r'^> HTTP/1\.1 GET (\S+)',(R/'logs/lock-bun-regenerate.stderr.log').read_text(),re.M)
assert len(requests)==4 and all(x.startswith('https://registry.npmjs.org/') and not x.endswith('.tgz') for x in requests)
publicInput=Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-compose-nd8v4x2p')
assert sha(publicInput/'report-index.json')=='104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac'
assert sha(publicInput/'after-manifest.json')==load('evidence/source-before.json')['inputManifestSha256']
assert all(sha(publicInput/'mirror'/rel)==h for rel,h in before.items())
summary={'status':'T3_IMPLEMENTED_PENDING_INDEPENDENT_REVIEW_AND_PARENT_GATES','root':str(R),'timestampUtc':datetime.now(timezone.utc).isoformat(),'sourceCount':251,'changedProductPaths':changes,'productHashes':graph['productHashes'],'patch':{'path':'evidence/declarations.patch','sha256':sha(R/'evidence/declarations.patch'),'applyCheckExit':0,'applyExit':0,'reverseCheckExit':0,'replayMatchesAll251':True},'graph':{'added':['@types/bun@1.3.8','@types/picomatch@4.0.3','bun-types@1.3.8'],'allExistingRecordsAndIntegrityPreserved':True,'unrelatedGraphDeltas':[],'directMetadataConsistent':True,'distinctPackagesBefore':372,'distinctPackagesAfter':375,'sameCompleteInventoryBothManagers':True},'canonical':canonical,'rootSelectionCount':153,'rootSelectionAndOptionsUnchanged':True,'canonicalStrictExitCode':2,'canonicalStrictPass':False,'guardedHistoricalReadRefusalsPerStrictRun':2,'generatedArtifactCount':48,'allGeneratedBytesUnchangedByDeclarationAddition':True,'dependencyLockTests':{'total':5,'passed':5,'failed':0,'skipped':0},'sharedDependencies':{'aliases':274,'descendantEntries':len(sharedAfter)-1,'snapshotRowsIncludingRoot':len(sharedAfter),'bytesAndStatMetadataUnchanged':True},'installSafety':{'lifecycleScriptsDisabled':True,'pnpmProgressStatuses':pmStatuses,'pnpmPackageStoreFileCount':len(storeFiles),'bunCacheMetadataFileCount':len(bunFiles),'bunRegistryMetadataRequests':requests,'onlyDownloadedTarballs':[{'name':x['name'],'version':x['version'],'url':x['url'],'sha256':x['sha256'],'integrity':x['integrity']} for x in load('evidence/declaration-tarballs.json')],'installedNewFilesPerTree':sum(len(x['files']) for x in load('evidence/mirror-installed-declarations.json'))},'requiredParentGates':['Independent SPEC and QUALITY review; no self-approval','Compose with the separate 31-diagnostic runner repair','Run final canonical whole-root checks in the actual integrated public checkout; refused historical reads prevent full-root acceptance here','Fresh parent dependency-alert retrieval and online audit for the changed graph; previous receipts do not certify it','Compute and verify the actual Nix dependency fixed-output hash; flake.nix/hash unchanged in this lane','Parent owns integration, commit, push, merge and any release decision'],'issuesResolvedOrBounded':['An initial pre-build compiler observation had 39 diagnostics and 105 roots because dist was absent. Canonical build emitted 48 files; both repeated prepared baselines had the required 35 diagnostics and 153 roots.','Type-package registry fileCount includes tar directory entries for @types/bun and @types/picomatch. All SHA512 SRI, SHA1, total unpacked bytes and full file+directory counts match; no integrity mismatch.','The first Bun version-change negative control attempted metadata resolution under network denial, so was not accepted as the freshness rejection proof. A removal-only stale manifest deterministically failed with the frozen-lockfile error.','An initial Vitest bundled-config attempt tried writing a config cache outside the owned root; the write sandbox refused EPERM. The documented --configLoader runner rerun passed all five tests without widening write permissions.'],'claimsNotMade':['No whole-root strict pass or independent approval','No fresh online advisory clearance or Nix hash verification','No native build, GPU/model materialization, daemon/index run, cloud/paid execution, publication, live checkout edits, stage, commit, push or merge']}
proofBinding=load('evidence/offline-reproduction-binding.json')
proofPath=Path(proofBinding['result'])
assert proofPath.is_relative_to(Path(proofBinding['root'])) and sha(proofPath)==proofBinding['resultSha256']
proof=json.loads(proofPath.read_text())
assert proof['status']=='OFFLINE_REPLAY_REPRODUCED_NOT_FULL_ROOT_APPROVAL' and proof['sameThreePostimages'] and proof['sourceCount']==251
assert proof['freshPackageCachesRemainedEmpty'] and proof['sharedDependencySnapshotUnchanged']
assert load(proofBinding['driverReceipt'])['exit_code']==0
save('evidence/offline-reproduction-result.json',proof)
summary['freshOfflineReproduction']=proofBinding|{'stepCount':len(proof['steps']),'sourceCount':251,'diagnosticCounts':proof['diagnosticCounts'],'freshPackageCachesRemainedEmpty':True,'dependencyLockTestsPassed':5}
save('evidence/result.json',summary)
print(json.dumps({k:summary[k] for k in ['status','sourceCount','changedProductPaths','productHashes','patch','graph','rootSelectionCount','canonicalStrictExitCode','guardedHistoricalReadRefusalsPerStrictRun','generatedArtifactCount','dependencyLockTests','sharedDependencies']},indent=2))
