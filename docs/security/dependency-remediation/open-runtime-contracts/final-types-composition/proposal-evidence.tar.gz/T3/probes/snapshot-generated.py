from pathlib import Path
import sys, json, hashlib, stat
R=Path(__file__).resolve().parents[1]
name,label=sys.argv[1:]
base=R/name
assert base.resolve().is_relative_to(R)
rows={}
for p in sorted((base/'dist').rglob('*')):
    if p.is_file():rows[str(p.relative_to(base))]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode),'size':p.stat().st_size}
assert len(rows)==48,len(rows)
(R/'evidence'/f'{name}-generated-{label}.json').write_text(json.dumps({'artifactCount':len(rows),'artifacts':rows},indent=2,sort_keys=True)+'\n')
print(json.dumps({'tree':name,'phase':label,'generatedArtifacts':len(rows)}))
