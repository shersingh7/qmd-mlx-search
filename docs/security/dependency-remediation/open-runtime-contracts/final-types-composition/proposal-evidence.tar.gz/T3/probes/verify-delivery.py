"""Read-only verification of the delivered artifact index and bound postimages."""
from pathlib import Path
import sys, json, hashlib, base64
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
indexPath=R/'evidence/report-index.json'
index=load(indexPath)
if len(sys.argv)>1:assert sha(indexPath)==sys.argv[1],'artifact-index SHA256 mismatch'
files=index['artifactSha256'];assert len(files)==index['artifactCount']
for rel,expected in files.items():
    p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
    target=R/p;assert target.is_file() and not target.is_symlink() and target.resolve().is_relative_to(R)
    assert sha(target)==expected,rel
result=load(R/'evidence/result.json');assert result['sourceCount']==251 and result['canonicalStrictPass'] is False
for tree in ['mirror','replay']:
    manifest=load(R/'evidence'/f'{tree}-source-after.json')
    assert manifest['sourceCount']==len(manifest['sourceSha256'])==251
    for rel,h in manifest['sourceSha256'].items():assert sha(R/tree/rel)==h,(tree,rel)
    nm=R/tree/'node_modules';assert nm.is_dir() and not nm.is_symlink()
    for row in load(R/'evidence'/f'{tree}-installed-declarations.json'):
        assert (nm/row['name']).is_dir() and not (nm/row['name']).is_symlink()
        for rel,binding in row['files'].items():assert sha(nm/row['name']/rel)==binding['sha256']
for row in load(R/'evidence/declaration-tarballs.json'):
    p=R/'reference'/Path(row['archive']).name;value=p.read_bytes()
    assert hashlib.sha256(value).hexdigest()==row['sha256']
    assert 'sha512-'+base64.b64encode(hashlib.sha512(value).digest()).decode()==row['integrity']
    assert hashlib.sha1(value).hexdigest()==row['sha1']
assert sha(R/result['patch']['path'])==result['patch']['sha256']
assert load(R/'evidence/shared-dependencies-before.json')==load(R/'evidence/shared-dependencies-after.json')
external=load(R/index['ownedOfflineReproductionManifest']);owned=Path(external['root'])
assert owned.is_relative_to('/Users/shersingh/.hermes/cache/scratch') and owned.name.startswith('qmd-types-declarations-repro-')
assert len(external['artifactSha256'])==external['artifactCount']
for rel,h in external['artifactSha256'].items():
    p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
    target=owned/p;assert target.is_file() and not target.is_symlink() and target.resolve().is_relative_to(owned)
    assert sha(target)==h,(str(owned),rel)
for field in ['sourceSha256','generatedSha256','installedDeclarationSha256']:
    for rel,h in external[field].items():assert sha(owned/'mirror'/rel)==h,(field,rel)
assert {(x['beforeCount'],x['afterCount']) for x in result['canonical']}=={(35,31)}
counts=result['canonical'][0]
print(json.dumps({'status':'DELIVERY_HASHES_VERIFIED_NOT_INDEPENDENT_APPROVAL','root':str(R),'artifactCount':len(files),'artifactIndexSha256':sha(indexPath),'sourceCountPerTree':result['sourceCount'],'changedProductPaths':result['changedProductPaths'],'strictDiagnosticCounts':{'before':counts['beforeCount'],'after':counts['afterCount']},'strictExitCode':result['canonicalStrictExitCode'],'historicalReadRefusalsPerStrictRun':result['guardedHistoricalReadRefusalsPerStrictRun'],'independentSpecQualityAndParentSecurityNixGatesPending':True},indent=2))
