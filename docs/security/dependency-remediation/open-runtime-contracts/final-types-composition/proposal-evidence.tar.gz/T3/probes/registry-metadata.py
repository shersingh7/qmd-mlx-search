from pathlib import Path
import urllib.request, urllib.parse, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
queries={'types-bun-1.3.8':'@types/bun/1.3.8','bun-types-1.3.8':'bun-types/1.3.8','types-picomatch':'@types/picomatch'}
rows=[]
for label,part in queries.items():
    name,sep,version=part.rpartition('/')
    if part=='@types/picomatch': name,version=part,''
    url='https://registry.npmjs.org/'+urllib.parse.quote(name,safe='')+('/'+version if version else '')
    request=urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':'qmd-declarations-repair-public-metadata'})
    with opener.open(request,timeout=60) as response:
        assert urllib.parse.urlparse(response.url).hostname=='registry.npmjs.org'
        data=response.read();headers={key:response.headers.get(key) for key in ['Content-Type','ETag','Date']}
    path=ROOT/'reference'/f'{label}.metadata.json';path.write_bytes(data)
    metadata=json.loads(data)
    row={'label':label,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'headers':headers,'path':str(path)}
    if version: row['package']={key:metadata.get(key) for key in ['name','version','types','typings','dependencies','scripts','typeScriptVersion','dist']}
    else:
        row['versions']=[{key:value.get(key) for key in ['name','version','dependencies','typeScriptVersion','dist']} for v,value in metadata['versions'].items() if v.startswith('4.')]
    rows.append(row)
(ROOT/'evidence/registry-metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
