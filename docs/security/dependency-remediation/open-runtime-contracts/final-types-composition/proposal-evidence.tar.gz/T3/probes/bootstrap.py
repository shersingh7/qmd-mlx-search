from pathlib import Path
import os, json, stat, hashlib, shutil, sys
ROOT = Path(__file__).resolve().parents[1]
INPUT = Path('/Users/shersingh/.hermes/cache/scratch/qmd-types-compose-nd8v4x2p')
SHARED = Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')
def snapshot(base):
    out = {}
    def scan(p):
        s = p.lstat()
        row = {'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'ino':s.st_ino,'dev':s.st_dev,'nlink':s.st_nlink}
        if stat.S_ISLNK(s.st_mode): row['link'] = os.readlink(p)
        elif stat.S_ISREG(s.st_mode): row['sha256'] = digest(p)
        elif stat.S_ISDIR(s.st_mode):
            for x in sorted(p.iterdir()): scan(x)
        else: raise RuntimeError('unexpected dependency entry '+str(p))
        out[str(p.relative_to(base))] = row
    scan(base)
    return out
if __name__ == '__main__':
    assert digest(INPUT/'report-index.json') == '104aaf1f4b4c56af6415aa2dbce692998d635a38b97abb1762d2397df8e661ac'
    idx = json.loads((INPUT/'report-index.json').read_text())
    manifest = json.loads((INPUT/'after-manifest.json').read_text())
    assert digest(INPUT/'after-manifest.json') == idx['files']['after-manifest.json']
    files = manifest['sourceSha256']
    assert len(files) == manifest['sourceCount'] == 251
    for name, h in files.items():
        rel = Path(name)
        assert not rel.is_absolute() and '..' not in rel.parts
        src = INPUT/'mirror'/rel
        assert not src.is_symlink() and src.is_file() and digest(src) == h, name
        dst = ROOT/'mirror'/rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src,dst)
    save(ROOT/'evidence/source-before.json', {'sourceCount':len(files),'sourceSha256':files,'inputManifestSha256':digest(INPUT/'after-manifest.json'),'inputReportIndexSha256':digest(INPUT/'report-index.json')})
    for name in ['package.json','pnpm-lock.yaml','bun.lock']:
        dst=ROOT/'evidence/preimages'/name
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/'mirror'/name,dst)
    before = snapshot(SHARED)
    save(ROOT/'evidence/shared-dependencies-before.json',before)
    aliases = {}
    for p in sorted(SHARED.iterdir()):
        if p.name.startswith('.'): continue
        candidates = sorted(p.iterdir()) if p.name.startswith('@') else [p]
        for pkg in candidates:
            assert (pkg/'package.json').is_file(), pkg
            name = str(pkg.relative_to(SHARED))
            assert pkg.resolve().is_relative_to(SHARED.resolve()),pkg
            aliases[name] = str(pkg.resolve())
    assert len(aliases)==274, len(aliases)
    assert all(x not in aliases for x in ['@types/bun','bun-types','@types/picomatch'])
    nm=ROOT/'mirror/node_modules'
    nm.mkdir()
    for name,target in aliases.items():
        dst=nm/name
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.symlink_to(target,target_is_directory=True)
    for name in ['.vite','.cache','.vitest']: (nm/name).mkdir()
    save(ROOT/'evidence/mirror-package-aliases.json',aliases)
    tools={}
    for p in sorted((INPUT/'tools/bin').iterdir()): tools[p.name]=str(p.resolve())
    save(ROOT/'evidence/input-tool-bindings.json',tools)
    for name in ['logs','reference','configs','state','tools/bin']:(ROOT/name).mkdir(parents=True,exist_ok=True)
    print(json.dumps({'root':str(ROOT),'sourceCount':len(files),'dependencyEntries':len(before),'packageAliases':len(aliases),'tools':tools},indent=2))
