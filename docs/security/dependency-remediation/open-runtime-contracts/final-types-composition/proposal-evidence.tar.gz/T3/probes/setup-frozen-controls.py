from pathlib import Path
import json, shutil
R=Path(__file__).resolve().parents[1]
for name in ['pnpm','bun']:
    dst=R/'configs'/f'frozen-stale-{name}'
    dst.mkdir()
    for f in ['package.json','pnpm-lock.yaml','bun.lock']:shutil.copy2(R/'mirror'/f,dst/f)
    package=json.loads((dst/'package.json').read_text());package['devDependencies']['@types/bun']='1.3.7'
    (dst/'package.json').write_text(json.dumps(package,indent=2)+'\n')
print('Created two owned stale-manifest negative controls; only @types/bun 1.3.8 -> 1.3.7 in their package.json files.')
