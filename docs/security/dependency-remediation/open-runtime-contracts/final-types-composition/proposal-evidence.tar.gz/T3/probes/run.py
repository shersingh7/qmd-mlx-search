from pathlib import Path
import os, sys, json, subprocess, time
ROOT = Path(__file__).resolve().parents[1]
label, cwd_arg, *cmd = sys.argv[1:]
assert label and all(c.isalnum() or c in '-_' for c in label)
cwd = (ROOT/cwd_arg).resolve()
assert cwd.is_relative_to(ROOT) and cwd.is_dir(), cwd
state = ROOT/'state'/label
state.mkdir(parents=True, exist_ok=False)
locations = {'HOME':'home','HERMES_HOME':'hermes','HERMES_DIR':'hermes','HERMES_ROOT':'hermes','HERMES_KNOWLEDGE_DIR':'knowledge','KNOWLEDGE_DIR':'knowledge','XDG_CONFIG_HOME':'xdg/config','XDG_CACHE_HOME':'xdg/cache','XDG_DATA_HOME':'xdg/data','XDG_STATE_HOME':'xdg/state','HF_HOME':'hf','HF_HUB_CACHE':'hf/hub','TMPDIR':'tmp','TMP':'tmp','TEMP':'tmp','BUN_RUNTIME_TRANSPILER_CACHE_PATH':'cache/bun-transpile','npm_config_cache':'cache/npm','PNPM_HOME':'cache/pnpm','UV_CACHE_DIR':'cache/uv','PYTHONPYCACHEPREFIX':'cache/python','NODE_COMPILE_CACHE':'cache/node','VITE_CACHE_DIR':'cache/vite','VITEST_CACHE_DIR':'cache/vitest'}
env = {key:str(state/value) for key,value in locations.items()}
for value in env.values(): Path(value).mkdir(parents=True, exist_ok=True)
# Only this owned config exists; no inherited auth or user npm configuration.
npmrc=state/'npmrc'; npmrc.write_text('registry=https://registry.npmjs.org/\nignore-scripts=true\naudit=false\nfund=false\nupdate-notifier=false\n')
empty=state/'empty-npmrc';empty.write_text('')
env.update({'PATH':str(ROOT/'tools/bin')+':/usr/bin:/bin','LANG':'en_US.UTF-8','PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_DATASETS_OFFLINE':'1','UV_OFFLINE':'1','npm_config_offline':'true','CI':'1','REQUIRE_BUN':'1','QMD_LLAMA_GPU':'false','QMD_DECLARATIONS_ROOT':str(ROOT),'QMD_RUN_LABEL':label,'NO_COLOR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','npm_config_userconfig':str(npmrc),'npm_config_globalconfig':str(empty),'npm_config_registry':'https://registry.npmjs.org/','npm_config_ignore_scripts':'true','npm_config_audit':'false','npm_config_fund':'false','npm_config_update_notifier':'false','COREPACK_ENABLE_NETWORK':'0','BUN_INSTALL_CACHE_DIR':str(ROOT/'cache/bun'),'npm_config_store_dir':str(ROOT/'cache/pnpm-store')})
(ROOT/'cache/bun').mkdir(parents=True,exist_ok=True)
(ROOT/'cache/pnpm-store').mkdir(parents=True,exist_ok=True)
env['GIT_CEILING_DIRECTORIES']=str(ROOT)
if label.startswith(('lock-','registry-')): env['npm_config_offline']='false'
if label.startswith(('types-','build-','roots-','resolution-')):
    env['NODE_OPTIONS'] = '--require='+str(ROOT/'probes/compiler-read-guard.cjs')
    if cmd[0].endswith('/bun'):
        cmd=[cmd[0],'--preload',str(ROOT/'probes/compiler-read-guard.cjs'),*cmd[1:]]
if label.startswith(('frozen-','control-','types-','build-','roots-','resolution-','test-')):
    profile=state/'offline.sb'
    profile.write_text('(version 1)\n(allow default)\n(deny network*)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(ROOT))+'))\n(allow file-write* (literal "/dev/null"))\n')
    cmd=['/usr/bin/sandbox-exec','-f',str(profile),*cmd]
receipt={'label':label,'cwd':str(cwd),'argv':cmd,'environment':env,'started_monotonic':time.monotonic()}
p=ROOT/'evidence'/f'{label}.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
try:
    with (ROOT/'logs'/f'{label}.stdout.log').open('wb') as out,(ROOT/'logs'/f'{label}.stderr.log').open('wb') as err:
        result=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=err,timeout=500)
    receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-receipt['started_monotonic'])
except subprocess.TimeoutExpired:
    receipt.update(exit_code=124,timeout=True,elapsed_seconds=time.monotonic()-receipt['started_monotonic'])
p.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['label','exit_code','elapsed_seconds']}))
for stream in ['stdout','stderr']:
    data=(ROOT/'logs'/f'{label}.{stream}.log').read_text(errors='replace')
    if len(data)>18000: print(f'{stream}: {len(data)} characters; complete raw log saved')
    elif data: print(f'--- {stream} ---\n{data}',end='' if data.endswith('\n') else '\n')
sys.exit(receipt['exit_code'])
