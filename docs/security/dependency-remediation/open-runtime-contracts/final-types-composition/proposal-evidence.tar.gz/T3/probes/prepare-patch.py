from pathlib import Path
import json, shutil, hashlib, difflib
R=Path(__file__).resolve().parents[1]
manifest=json.loads((R/'evidence/source-before.json').read_text())
files=manifest['sourceSha256'];changes=['package.json','pnpm-lock.yaml','bun.lock']
patch=[]
for name in changes:
    a=(R/'evidence/preimages'/name).read_text();b=(R/'mirror'/name).read_text()
    patch.append(f'diff --git a/{name} b/{name}\n')
    patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
p=R/'evidence/declarations.patch';p.write_text(''.join(patch))
replay=R/'replay';replay.mkdir()
for name,expected in files.items():
    src=R/'evidence/preimages'/name if name in changes else R/'mirror'/name
    assert hashlib.sha256(src.read_bytes()).hexdigest()==expected,name
    dst=replay/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
nm=replay/'node_modules';nm.mkdir()
aliases=json.loads((R/'evidence/mirror-package-aliases.json').read_text())
for name,target in aliases.items():
    dst=nm/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.symlink_to(target,target_is_directory=True)
for name in ['.vite','.cache','.vitest']:(nm/name).mkdir()
(R/'evidence/replay-package-aliases.json').write_text(json.dumps(aliases,indent=2,sort_keys=True)+'\n')
(R/'evidence/replay-source-before.json').write_text(json.dumps({'sourceCount':len(files),'sourceSha256':{n:hashlib.sha256((replay/n).read_bytes()).hexdigest() for n in files}},indent=2,sort_keys=True)+'\n')
print(json.dumps({'patch':str(p),'patchSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'replay':str(replay),'sourceCount':len(files),'packageAliases':len(aliases)},indent=2))
