"""Offline proof in a NEW owned derivative; never mutate this delivery or its input."""
from pathlib import Path
import os, sys, json, hashlib, shutil, tempfile, subprocess, importlib.util, re
SOURCE=Path(__file__).resolve().parents[1]
SCRATCH=Path('/Users/shersingh/.hermes/cache/scratch')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
source=load(SOURCE/'evidence/source-before.json')['sourceSha256']
expected=load(SOURCE/'evidence/graph-delta.json')['productHashes']
assert len(source)==251
assert sha(SOURCE/'evidence/declarations.patch')=='174a639eec01e7b135deb5823335fb7b6b41360b059b456709b9cc4037dcf7f3'
root=Path(tempfile.mkdtemp(prefix='qmd-types-declarations-repro-',dir=SCRATCH))
print('OWNED_REPRODUCTION_ROOT='+str(root),flush=True)
for name in ['probes','configs','evidence/preimages','reference','mirror','tools/bin','tmp','logs','state']:(root/name).mkdir(parents=True,exist_ok=True)
for rel in ['run','probes/run.py','probes/compiler-read-guard.cjs','probes/materialize-declarations.py','probes/graph-check.mjs','probes/resolution-proof.mjs','probes/bootstrap.py','configs/bunfig.toml','configs/locks.vitest.config.mjs','evidence/source-before.json','evidence/graph-delta.json','evidence/declaration-tarballs.json','evidence/declarations.patch','evidence/mirror-package-aliases.json']:
    shutil.copy2(SOURCE/rel,root/rel)
for name in ['package.json','pnpm-lock.yaml','bun.lock']:shutil.copy2(SOURCE/'evidence/preimages'/name,root/'evidence/preimages'/name)
for row in load(SOURCE/'evidence/declaration-tarballs.json'):
    src=SOURCE/'reference'/Path(row['archive']).name
    assert sha(src)==row['sha256']
    shutil.copy2(src,root/'reference'/src.name)
for name,h in source.items():
    rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts
    src=SOURCE/'evidence/preimages'/name if name in expected else SOURCE/'mirror'/name
    assert sha(src)==h,name
    dst=root/'mirror'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
nm=root/'mirror/node_modules';nm.mkdir()
aliases=load(root/'evidence/mirror-package-aliases.json');assert len(aliases)==274
for name,target in aliases.items():
    assert Path(target).is_relative_to('/Users/shersingh/github/qmd-mlx-search/node_modules') and (Path(target)/'package.json').is_file()
    dst=nm/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.symlink_to(target,target_is_directory=True)
for name in ['.vite','.cache','.vitest']:(nm/name).mkdir()
tools={'node':'/Users/shersingh/.hermes/node/bin/node','bun':'/Users/shersingh/.bun/bin/bun','pnpm':'/opt/homebrew/bin/pnpm'}
for name,target in tools.items():(root/'tools/bin'/name).symlink_to(target)
spec=importlib.util.spec_from_file_location('repro_bootstrap',root/'probes/bootstrap.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
shared=Path('/Users/shersingh/github/qmd-mlx-search/node_modules')
sharedBefore=mod.snapshot(shared)
assert sharedBefore==load(SOURCE/'evidence/shared-dependencies-after.json'),'authoritative dependency snapshot drifted before offline replay'
# The outer wrapper also starts from an empty environment. Every tested command
# gets the independently reconstructed allowlist, offline variables and sandbox.
outer={'PATH':'/usr/bin:/bin','TMPDIR':str(root/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','HOME':str(root/'state/outer-home')}
Path(outer['HOME']).mkdir()
steps=[]
def run(label,*argv,expectedExit=0):
    p=subprocess.run([str(root/'run'),label,'mirror',*map(str,argv)],env=outer,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    steps.append({'label':label,'exitCode':p.returncode})
    print(json.dumps(steps[-1]),flush=True)
    assert p.returncode==expectedExit,(label,p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'))
    return p
node=tools['node'];bun=tools['bun'];pnpm=tools['pnpm'];tsc=['node_modules/typescript/bin/tsc','-p','tsconfig.json','--noEmit','--pretty','false']
run('build-node-baseline',node,'scripts/build.mjs')
run('types-node-baseline',node,*tsc,expectedExit=2)
run('types-bun-baseline',bun,*tsc,expectedExit=2)
run('roots-node-baseline',node,'node_modules/typescript/bin/tsc','-p','tsconfig.json','--showConfig')
run('patch-apply-check','/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.attributesFile=/dev/null','apply','--check','../evidence/declarations.patch')
run('patch-apply','/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.attributesFile=/dev/null','apply','../evidence/declarations.patch')
run('materialize-declarations','/usr/bin/python3','-I',root/'probes/materialize-declarations.py')
run('graph-verified',node,root/'probes/graph-check.mjs')
run('frozen-pnpm',pnpm,'install','--lockfile-only','--frozen-lockfile','--ignore-scripts','--ignore-pnpmfile','--ignore-workspace','--offline','--registry=https://registry.npmjs.org/','--store-dir='+str(root/'cache/pnpm-store'),'--reporter=ndjson')
run('frozen-bun',bun,'install','--lockfile-only','--frozen-lockfile','--ignore-scripts','--save-text-lockfile','--registry=https://registry.npmjs.org/','--config='+str(root/'configs/bunfig.toml'),'--cache-dir='+str(root/'cache/bun'),'--network-concurrency=2')
run('build-node-after',node,'scripts/build.mjs')
run('types-node-after',node,*tsc,expectedExit=2)
run('types-bun-after',bun,*tsc,expectedExit=2)
run('roots-node-after',node,'node_modules/typescript/bin/tsc','-p','tsconfig.json','--showConfig')
run('resolution-node',node,root/'probes/resolution-proof.mjs')
run('resolution-bun',bun,root/'probes/resolution-proof.mjs')
run('test-dependency-locks',node,'node_modules/vitest/vitest.mjs','run','--config','../configs/locks.vitest.config.mjs','--configLoader','runner','--maxWorkers=1','--no-file-parallelism','--reporter=json','--outputFile=../evidence/dependency-locks-results.json')
assert all(sha(root/'mirror'/name)==value['after'] for name,value in expected.items())
assert all(sha(root/'mirror'/name)==h for name,h in source.items() if name not in expected)
counts={label:len(re.findall(r'error TS\d+:',(root/'logs'/f'{label}.stdout.log').read_text())) for label in ['types-node-baseline','types-bun-baseline','types-node-after','types-bun-after']}
assert counts=={'types-node-baseline':35,'types-bun-baseline':35,'types-node-after':31,'types-bun-after':31}
a=load(root/'logs/roots-node-baseline.stdout.log');b=load(root/'logs/roots-node-after.stdout.log');assert a==b and len(a['files'])==153
refusals={}
for label in counts:
    rows=[json.loads(s) for p in (root/'evidence').glob(label+'-compiler-reads-*.jsonl') for s in p.read_text().splitlines()]
    denied=[x for x in rows if x.get('allowed') is False];assert len(denied)==2
    refusals[label]=denied
assert mod.snapshot(shared)==sharedBefore,'authoritative dependency bytes/stat metadata changed'
tests=load(root/'evidence/dependency-locks-results.json');assert tests['success'] and tests['numPassedTests']==tests['numTotalTests']==5
assert not [p for p in (root/'cache/pnpm-store').rglob('*') if p.is_file()]
assert not [p for p in (root/'cache/bun').rglob('*') if p.is_file()],'empty-cache frozen Bun unexpectedly wrote cache payloads'
result={'status':'OFFLINE_REPLAY_REPRODUCED_NOT_FULL_ROOT_APPROVAL','root':str(root),'sourceCount':251,'sameThreePostimages':True,'steps':steps,'diagnosticCounts':counts,'rootSelectionCount':153,'historicalReadRefusals':refusals,'dependencyLockTestsPassed':5,'networkDeniedForAllBuildCompilerFrozenAndTestCommands':True,'freshPackageCachesRemainedEmpty':True,'sharedDependencySnapshotUnchanged':True}
out=root/'evidence/offline-reproduction-result.json';out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'root':str(root),'result':str(out),'resultSha256':sha(out),'status':result['status']},indent=2),flush=True)
