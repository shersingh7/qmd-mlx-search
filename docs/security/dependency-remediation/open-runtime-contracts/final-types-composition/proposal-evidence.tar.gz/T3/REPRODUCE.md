# Reproduce and inspect T3 safely

Do not run or edit the input delivery or the live checkout. This delivery is an unapproved scoped implementation. All commands below either read it or create a **new owned derivative**; no model, native build, install lifecycle, daemon, index or release operation is involved.

## 1. Read-only artifact verification

Use the index SHA256 supplied with the handoff as the optional final argument:

```sh
R=/Users/shersingh/.hermes/cache/scratch/qmd-types-declarations-1yp0w89j
/usr/bin/env -i PATH=/usr/bin:/bin PYTHONDONTWRITEBYTECODE=1 \
  TMPDIR=/Users/shersingh/.hermes/cache/scratch \
  /usr/bin/python3 -I "$R/probes/verify-delivery.py"
```

To verify the handoff anchor as well, append its actual 64-hex index SHA256 as the final argument. The no-argument form checks the internally indexed hashes. The index deliberately excludes itself. It inventories the report, reproduction guide, runner, configs/probes, evidence/logs and public references. Operational HOME/Hermes/knowledge/XDG/HF/TMP/cache state is excluded except the exact executed sandbox profiles, which are explicitly hash-bound. Product sources, generated files and verified installed declarations have separate explicit manifests.

`evidence/result.json` states all required parent gates and failures that must not be mistaken for success. Verification of hashes is not an independent SPEC/QUALITY review.

## 2. Fully offline proof in a fresh derivative

This exact helper was exercised successfully. It makes a new `qmd-types-declarations-repro-*` root under managed scratch, copies exactly the 251 verified preimage sources from this delivery's bound source/preimage files, supplies per-package read-only-use aliases and owned cache directories, applies the actual three-path patch, materializes only the SRI-verified declaration payloads already archived here, and runs the actual tools. It does **not** fetch registry metadata or tarballs, and does not rerun the original input's scripts.

```sh
R=/Users/shersingh/.hermes/cache/scratch/qmd-types-declarations-1yp0w89j
/usr/bin/env -i PATH=/usr/bin:/bin PYTHONDONTWRITEBYTECODE=1 \
  TMPDIR=/Users/shersingh/.hermes/cache/scratch \
  /usr/bin/python3 -I "$R/probes/offline-replay.py"
```

The helper refuses dependency-snapshot drift. Each tested command is launched through `run`, which builds a new environment from an empty allowlist with owned HOME, Hermes/knowledge, XDG, HF, temp and tool caches; no inherited authentication or npm user config. It sets `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`, `HF_DATASETS_OFFLINE=1`, `QMD_LLAMA_GPU=false`, `CI=1`, `REQUIRE_BUN=1`, and disables scripts. Compiler/build/frozen/test commands additionally use an OS sandbox denying network and writes outside the new root. The compiler preload separately enforces lexical **and real-path** read restrictions. Bun receives an explicit `--preload`; it is not represented by Node running a wrapper.

The 17 serial steps include:

- Canonical Node build before each strict-check phase.
- Actual Node **22.22.3** and Bun **1.3.8** running genuine installed TypeScript **5.9.3**: **35 → 31** diagnostics, exit **2** in all four strict invocations.
- `--showConfig`: exactly the same **153** roots/options before/after.
- Real `git apply --check` and actual apply; all 251 postimages checked.
- Parsed complete graph/direct metadata/integrity preservation assertions.
- Real frozen pnpm and Bun with cold package caches, scripts disabled, network denied; both exit 0 and caches remain empty.
- Actual ambient/module/global Bun type-binding proof on both hosts.
- Existing dependency-lock test: **5 passed**, one worker and `--configLoader runner`.
- Shared dependency byte/stat snapshot recheck unchanged.

The actual exercised reproduction is:

`/Users/shersingh/.hermes/cache/scratch/qmd-types-declarations-repro-zs5rz6xo`

Its result SHA256 is `8003a0bd7c9fceaa8b900f6e64f43f91a3bcf48bfc5b678f501a2758f25ab304`, bound in `evidence/offline-reproduction-binding.json`. That result explicitly remains **not full-root approval**.

## 3. Exact lock regeneration modes already exercised

These are the genuine regeneration argv, run only inside the owned derivative and clean environment. `run` retains exact absolute arguments, environment, exit code, stdout/stderr and elapsed time under each label. The installed manager help outputs in `logs/help-pnpm.stdout.log` and `logs/help-bun.stdout.log` establish the flag meanings. Original labels cannot be reused because state directories are intentionally exclusive.

```sh
# Under the owned runner, working directory mirror:
/opt/homebrew/bin/pnpm install \
  --lockfile-only --ignore-scripts --ignore-pnpmfile --ignore-workspace \
  --no-frozen-lockfile --prefer-offline \
  --registry=https://registry.npmjs.org/ \
  --store-dir="$OWN_ROOT/cache/pnpm-store" --reporter=ndjson

/Users/shersingh/.bun/bin/bun install \
  --lockfile-only --ignore-scripts --save-text-lockfile \
  --registry=https://registry.npmjs.org/ \
  --config="$OWN_ROOT/configs/bunfig.toml" \
  --cache-dir="$OWN_ROOT/cache/bun" --network-concurrency=2 --verbose
```

Only these original lock-resolution and declaration-fetch labels enabled the explicit anonymous public-NPM exception. No application/native package was installed or downloaded. Do not convert these into a normal install; do not use live npm/Bun configs or introduce an audit/other-network call into this exception. Fresh offline reproduction deliberately does not rerun regeneration.

## 4. Exact frozen modes

Inside a freshly created derivative, the offline helper exercises these modes through the network/write-denying runner:

```sh
/opt/homebrew/bin/pnpm install \
  --lockfile-only --frozen-lockfile --ignore-scripts \
  --ignore-pnpmfile --ignore-workspace --offline \
  --registry=https://registry.npmjs.org/ \
  --store-dir="$OWN_ROOT/cache/pnpm-store" --reporter=ndjson

/Users/shersingh/.bun/bin/bun install \
  --lockfile-only --frozen-lockfile --ignore-scripts --save-text-lockfile \
  --registry=https://registry.npmjs.org/ \
  --config="$OWN_ROOT/configs/bunfig.toml" \
  --cache-dir="$OWN_ROOT/cache/bun" --network-concurrency=2
```

Bun 1.3.8 has no documented `--offline` install flag in the retained help. Its frozen proof instead uses OS-level network denial; the cold-cache pass demonstrates it needs no fetch. No unsupported flag or fabricated resolver is substituted.

Positive receipts: `evidence/frozen-{pnpm,bun}.json`, corresponding replay receipts, and the fresh reproduction's receipts. Stale-manifest controls live only under `configs/`: pnpm's altered Bun requirement fails `ERR_PNPM_OUTDATED_LOCKFILE`; Bun's removal-only requirement fails with `lockfile had changes, but lockfile is frozen`. A prior version-change Bun control failed at blocked metadata resolution and is retained but not treated as the stale-lock proof.

## 5. Compiler scope and meaning of results

Canonical build:

```sh
/Users/shersingh/.hermes/node/bin/node scripts/build.mjs
```

Then run both actual hosts, under the readguard and clean offline runner:

```sh
/Users/shersingh/.hermes/node/bin/node node_modules/typescript/bin/tsc \
  -p tsconfig.json --noEmit --pretty false
/Users/shersingh/.bun/bin/bun --preload "$OWN_ROOT/probes/compiler-read-guard.cjs" \
  node_modules/typescript/bin/tsc -p tsconfig.json --noEmit --pretty false
```

These show the effective child argv. When passing argv to `run`, omit Bun's explicit `--preload` pair because `run` prepends it; do not preload the guard twice. The runner also sets `NODE_OPTIONS=--require=...`. Do not replace the guard with a filtered `files` list, a new ambient shim, changed compiler options, or rewritten historical probes. The original root has `allowJs=true`; after canonical build it includes 48 generated files and the unchanged archive `.mjs` files. Starting before that build gives a different 105-root/39-diagnostic observation and is not the prepared baseline.

Both strict phases retain **two denied reads** into the live checkout due to historical absolute imports. They establish a relative four-diagnostic improvement, **not** an unguarded whole-root pass. The remaining 31 diagnostics are exactly the separate held runner's original diagnostics. Parent must compose that lane and run final whole-root checks in the actual integrated public checkout.

## 6. Preservation/security boundary

- Three product paths only; the patch and full pre/post hashes are in `REPORT.md` and `evidence/graph-delta.json`.
- No existing runtime/optional/dev dependency version, integrity or edge changes; three new development declaration identities only.
- Shared `node_modules` is never root-symlinked. Its before/after manifests track bytes, symlink targets, mode, size, mtime/ctime nanoseconds, inode, device and link count for 18,642 descendants plus the root. Access time is not an immutability assertion.
- NPM integrity checks are bound to actual public HTTPS metadata and genuine tarball bytes; no claim that optional registry signing signatures were independently verified.
- No fresh alert/online-audit clearance or actual Nix fixed-output hash verification is claimed. Those changed-graph gates and independent SPEC/QUALITY reviews remain parent-owned. No native/model/release/publication claim is made.
